# MediCare Pro — Hospital/Tenant Isolation: Implementation & Verification Report

Companion to `TENANT_ISOLATION_DESIGN.md` (written first, before any code change) and the prior `FOUNDATION_FINAL_VERIFICATION_GATE.md`, which explicitly found tenant isolation **not implemented**. This report closes that gap and provides the cross-tenant test evidence the request required — no claim of completeness is made without it.

---

## 1. What was inspected before implementing

- **Authentication**: `authMiddleware.js` verifies a Firebase ID token and sets `req.user.uid`. No hospital concept existed anywhere in that path.
- **RBAC**: `resolveIdentity.js` looked up `req.user.uid` in `staff`/`patients` and attached `req.identity = {type, id, role, name, email}` — no `hospitalId`.
- **Schema**: confirmed zero `hospital_id`/`tenant` columns anywhere (re-confirmed the prior audit's finding directly).
- **Services/controllers**: every service queried by `id` alone or filtered by role — never by tenant.
- **Routes**: every mounted route already runs `authenticate` → `resolveIdentity` → `authorize(...)` before any handler, in that order, in every route file (re-verified, not assumed) — meaning the identity object was already the single point through which tenant scoping could be threaded without touching route-level middleware ordering.

This inspection is what produced the design in `TENANT_ISOLATION_DESIGN.md`, written and committed before any service/schema code was changed.

---

## 2. Requirement-by-requirement disposition

**1. Tenant identity determined only from authenticated server-side identity.**
`identity.service.js`'s `resolveIdentityByFirebaseUid` now also selects `hospital_id` from the same trusted `staff`/`patients` row it already used for `role`/`id` — the same DB lookup, one more column. `resolveIdentity.js` attaches it as `req.identity.hospitalId`. This is the only place `hospitalId` is ever set on a request.

**2. Never trust client-supplied `hospitalId`.**
No route, controller, or Zod validation schema accepts a `hospitalId` field from the client — confirmed by grep across every `validations/*.js` file (zero occurrences) and by every controller passing `req.identity.hospitalId` (never `req.body.hospitalId`, which doesn't exist) into its service call. Even if a client sent one, Zod's default `.parse()` behavior strips unrecognized keys — the same mechanism the prior audit's mass-assignment test already proved works.

**3. Tenant scoping applied to every tenant-owned query.**
Every service (`patient`, `billing`, `appointment`, `laboratory`, `hospital`) and the Pharmacy `Medicine` model now takes `hospitalId` as their first parameter and filter every `SELECT`/`UPDATE`/`DELETE` by it, and every `INSERT` sets it server-side. See §4 for the full list of files changed.

**4/5/6. Cross-hospital tests for patients, appointments, laboratory, pharmacy, billing, staff — both read and mutation — verified rejected.**
See §5. 21 new tests in `tests/tenant-isolation.test.js`, all passing, covering list/get/update/delete for every named domain plus cross-entity creation attacks (e.g., booking an appointment that links a same-hospital-valid patient with a different hospital's doctor).

**7. Regression tests added.** Done — see §5.

**8. Existing 44 foundation tests preserved.** All 44 still pass, unchanged, after the tenant-scoping rewrite (verified by full-suite rerun, not assumed). Existing tests didn't need to be touched because `testDb.js`'s seed helpers now default to one shared, automatically-provisioned "Test Hospital" — tests that don't care about multi-tenancy get a valid `hospital_id` transparently.

**9. Frontend not redesigned.** No frontend file was touched.

**10. Did not begin the next phase.** This report is the verification step itself, not a new feature.

---

## 3. Schema changes

New additive migration: `prisma/migrations/20260817000000_add_hospital_tenancy/migration.sql` (does not modify or replace the first migration). Adds:
- `hospitals` table (`id, name, code UNIQUE, is_active, timestamps`).
- `hospital_id` (`NOT NULL`, FK to `hospitals`) on `staff`, `departments`, `patients`, `medicines`, `appointments`, `lab_orders`, `invoices`.
- `hospital_id` (**nullable**) on `audit_logs` — an audit event can legitimately occur before identity resolves (e.g. a failed login), so this one column is intentionally not `NOT NULL`.
- Globally-unique constraints that don't make sense across tenants converted to per-hospital composite uniques: `staff(staff_code, email)`, `departments(name, code)`, `patients(patient_code)`, `lab_orders(order_code)`, `invoices(invoice_code)` are now `UNIQUE(hospital_id, ...)` instead of globally unique. `firebase_uid` stays globally unique on both `staff` and `patients` — Firebase Auth is one global identity provider in this architecture, so one Firebase account maps to exactly one platform identity in exactly one hospital.
- `invoice_items` deliberately has **no** `hospital_id` column — it's always accessed through its parent `invoice`, which is itself scoped; adding a redundant column here would invite the two getting out of sync.
- `Prescription`/`PrescriptionItem` remain unmodeled, same as the prior phase — scoping already-unreachable code (see §6) would protect nothing real.

**Migration safety, actually tested, not assumed**: the migration adds each `hospital_id` column as nullable first, **backfills every existing row** to a bootstrap "Default Hospital," then sets `NOT NULL` — this was specifically tested against a genuinely pre-existing row (inserted before the migration ran, simulating real pre-tenancy production data), and the backfill was confirmed to correctly assign it (`UPDATE 1`, verified via `SELECT`). This is not a claim verified only on an empty test database.

---

## 4. Application code changed

**Services** (all rewritten to take `hospitalId` as the first argument, filter every query by it, and verify cross-referenced entities belong to the same hospital before linking them):
`services/identity.service.js`, `services/patient.service.js`, `services/billing.service.js`, `services/appointment.service.js`, `services/laboratory.service.js`, `services/hospital.service.js`.

**Controllers** (updated to pass `req.identity.hospitalId`, never client input):
`controllers/patient.controller.js`, `controllers/billing.controller.js`, `controllers/appointment.controller.js`, `controllers/laboratory.controller.js`, `controllers/hospitalController.js`, and the medicine-catalog handlers in `controllers/pharmacyController.js`.

**Model** (extended, not rewritten — parameters added to existing method signatures):
`models/Medicine.js` — every method (`findAll`, `findById`, `create`, `update`, `delete`, `getCategories`, `getLowStock`) now takes `hospitalId` first.

**Middleware**: `middleware/resolveIdentity.js` — comment updated to document `hospitalId` as the tenant source of truth; no logic change needed since it already passes through whatever `identity.service.js` returns.

**Test infrastructure**: `tests/testDb.js` — added `seedHospital()`, `DEFAULT_HOSPITAL_ID` constant, and `seedStaff`/`seedPatient` now accept an optional `hospitalId` (defaulting to the shared test hospital so pre-existing tests need no changes). `prisma/seed.js` — updated to seed one demo hospital and scope every seeded row to it.

**One real bug found and fixed during tenant-isolation testing** (not a tenant-isolation defect itself, but discovered by it): `routes/pharmacyRoutes.js` had `DELETE /medicines/:medicineId` (a broken, already-documented prescription-medicine handler) registered **before** `DELETE /medicines/:id` (the working medicine-catalog delete handler). Both patterns are shape-identical, so Express always matched the first one — the working catalog-delete endpoint was **completely unreachable** regardless of tenant isolation. Found because the cross-tenant delete test got a `500` instead of the expected safe no-op. Fixed by renaming the shadowing route to `/prescription-medicines/:medicineId` (a pure routing change — the shadowed handler's internal logic, and its pre-existing defect, is untouched). This is the same "route/handler existence is not sufficient evidence of correctness" lesson from the prior audit, recurring — worth naming again rather than treating as a one-off.

---

## 5. Cross-tenant attack test evidence

`tests/tenant-isolation.test.js` — **21/21 passing**, seeds two real, separate hospitals (Hospital A, Hospital B) with their own admins, builds a full record set in Hospital A via the real API (not direct DB inserts — so every test exercises the actual code path an attacker would use), and attempts cross-tenant access as Hospital B's fully-valid, correctly-authenticated, correctly-RBAC'd admin:

| Domain | Read (list) | Read (by ID) | Mutation | Cross-entity create attack |
|---|---|---|---|---|
| Patients | ✓ filtered out | ✓ 404 | ✓ update & soft-delete both blocked, row unchanged (verified via direct DB read) | — |
| Appointments | ✓ filtered out | ✓ 404 | ✓ status-change blocked, row unchanged | ✓ can't create referencing Hospital A's patient; ✓ can't create in Hospital A using a Hospital B doctorId |
| Laboratory | ✓ filtered out | ✓ 404 | ✓ result-tampering blocked, row unchanged | ✓ can't create a lab order for Hospital A's patient |
| Billing | ✓ filtered out | ✓ 404 | ✓ status-change & void both blocked, row stays `DRAFT` | ✓ can't create an invoice for Hospital A's patient; ✓ summary aggregation doesn't leak amounts across hospitals |
| Staff/Department | ✓ filtered out | ✓ 404 | ✓ update & delete both blocked, row unchanged | ✓ can't assign Hospital A's staff to a department; ✓ can't set a Hospital B staff member as Hospital A's department head |
| Pharmacy (Medicine) | ✓ filtered out | ✓ 404 | ✓ update blocked, unchanged; delete is a safe no-op (verified `is_active` stays `true`) | — |

Every "row unchanged" claim above is verified by a **direct `SELECT` against the database** after the attempted mutation, not just by checking the HTTP status code — a test that only checked the status code could pass even if the mutation silently succeeded but returned the wrong code, so the tests read the actual row state.

A dedicated **regression test** at the end of the file confirms Hospital A's own admin retains full, normal access across every domain after all the above isolation checks ran — proving the fix blocks cross-tenant access without breaking same-tenant function.

**Full suite result**: `npm test` → **65/65 passing** (44 original + 21 new), run against a freshly-migrated real PostgreSQL 16 database, both migrations applied in sequence.

---

## 6. Explicit scope boundary — what is still NOT tenant-scoped, and why

- **`Prescription`/`PrescriptionItem`** (pharmacy prescription-creation): still unmodeled, same as the prior phase. This code path is unreachable today (documented broken import + schema mismatch, unchanged) — adding `hospital_id` to code nothing can execute would protect nothing real. If/when a dedicated Pharmacy-prescription remediation phase fixes the underlying defects, tenant scoping must be added at that time, not assumed to already exist.
- **`audit_logs.hospital_id` is nullable**: an audit event can occur before identity resolves (e.g. a failed authentication attempt has no valid identity at all, let alone a hospital). When identity *is* resolved, `hospital_id` is populated (via the same `req.identity.hospitalId` used everywhere else) — this was not separately tested with a dedicated assertion this pass and is noted as a minor coverage gap, not a defect.
- **`/doctors` backend**: still doesn't exist (unchanged from every prior report) — nothing to scope.
- **Multi-hospital *management*** (creating/editing hospitals themselves, a super-admin role that spans hospitals): out of scope for this request, which asked for isolation, not hospital administration. No route exists to create a `Hospital` row via the API — they're seeded directly. This is a legitimate future gap, not a defect: nothing in the current system needs to create hospitals at runtime yet.

---

## 7. Final statement

Hospital/tenant isolation is implemented and verified with actual cross-tenant attack test evidence across every domain the request named — patients, appointments, laboratory, pharmacy, billing, and staff — covering both read and mutation operations, with unauthorized cross-tenant requests confirmed rejected (`404`, chosen deliberately over `403` so a request never confirms another hospital's resource exists) and same-tenant function confirmed intact via a dedicated regression test. The 44 pre-existing foundation tests pass unchanged. One real, previously-undiscovered routing defect (a shadowed DELETE route) was found and fixed in the course of this work, with a regression test now covering the path that exposed it.

This is not being represented as "enterprise-ready" or as covering every possible tenancy concern (hospital administration/provisioning, per-tenant configuration, billing-plan-level tenant limits, etc. are all out of scope and untouched) — only that the specific gap identified in the Final Verification Gate — server-side hospital/tenant data isolation across the existing API — is now closed and evidenced, not merely claimed.
