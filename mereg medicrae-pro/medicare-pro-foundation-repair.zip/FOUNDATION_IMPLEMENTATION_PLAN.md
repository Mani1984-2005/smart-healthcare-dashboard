# MediCare Pro — Foundation Repair: Implementation Plan

Status when written: PLAN (pre-implementation). This document is written before any backend files are modified, per the requested implementation discipline.

## 1. Current Architecture (recap of verified forensics)

- `backend/server.js` is the only entry point that actually runs. It mounts `routes/patients.js` (raw `pg`, **no auth**) and `healthRoutes.js` only.
- `backend/routes/index.js` is a second, unused router aggregator (auth, patients-v2, pharmacy, health) — dead code today.
- `billingRoutes.js` → `billing.controller.js` — every handler is a stub returning `{ message: "... API" }`. Not mounted.
- `hospitalRoutes.js` → `hospitalController.js` — real logic, Mongoose-backed (`Department`, `Staff`). Not mounted.
- `pharmacyRoutes.js` → `pharmacyController.js` — real logic, raw-`pg`-backed (`Medicine`, `Prescription`). Not mounted by `server.js` (only reachable via the also-unmounted `routes/index.js`).
- Two DB technologies configured: `pg.Pool` (two separate files, `backend/config/db.js` and `backend/db.js`, with different connection configs — this is itself a bug) and `mongoose` (no visible connection bootstrap in the files inspected).
- `backend/models/Patient.js` is an empty file.
- `authMiddleware.js` (Firebase ID-token verification) is correct but applied to exactly one route (`/auth/me`) and nothing else.
- `auditMiddleware.js` and `utils/logger.js` (file-based JSON line logger, writes to `backend/logs/audit.log` and `app.log`) exist and are reasonably well-built, but `auditMiddleware` is never mounted in `server.js`.
- No RBAC, no validation library in use (`validations/billing.validation.js` is empty), no centralized error handler, no `.env.example`, no tests, no Prisma.

## 2. Target Architecture (this phase only)

```
Request
  → CORS / security headers / JSON body parsing
  → requestId middleware
  → authMiddleware (Firebase ID token → req.user)
  → auditMiddleware (logs mutating requests)
  → route
      → authorize(role/permission) middleware   [RBAC]
      → validate(schema) middleware
      → controller (thin — req/res only)
          → service (business logic)
              → Prisma Client → PostgreSQL
  → centralized error handler (consistent JSON shape, no leaks)
```

Single database technology: **PostgreSQL via Prisma**. Single mounted router entry point: `backend/routes/index.js`, imported by `server.js` (the duplicate, unmounted `patients.js` raw-SQL route is retired in favor of the Prisma-backed one).

## 3. Database Standard — Mongo/Mongoose Disposition

| Model | Classification | Plan |
|---|---|---|
| `Billing.js` (Mongoose) | Replaceable | New Prisma `Invoice`/`InvoiceItem` models replace it. Controller was a stub anyway — no data migration needed (nothing real was ever persisted through it). Old file kept under `backend/models/legacy/` for reference, not deleted. |
| `Department.js` (Mongoose) | Migration candidate | Real, working logic exists (`hospitalController.js`). Ported to Prisma `Department` model in this phase since it's small and Staff/Department are needed as FKs for future Doctor/Appointment work. |
| `Staff.js` (Mongoose) | Migration candidate | Same as Department — ported to Prisma `Staff` model. |
| `Medicine.js` / `Prescription.js` (raw `pg`, hand-written DDL) | Migration candidate | Working logic (`pharmacyController.js`). Schema is ported into Prisma as `Medicine` / `Prescription` models; hand-written `CREATE TABLE IF NOT EXISTS` calls are retired in favor of Prisma migrations. |
| `Patient.js` (empty) | Replaceable | New Prisma `Patient` model defined from scratch (§6 of the request). |

No Mongo data migration script is needed because no verified production data exists in these tables in this repository — they are development-stage stubs. This plan does **not** delete the old files; they move to `backend/models/legacy/` with a short header comment noting why, so history isn't silently lost.

## 4. Prisma Schema (this phase)

Models: `Patient`, `Staff`, `Department`, `Medicine`, `Prescription`, `Invoice`, `InvoiceItem`, `Appointment`, `LabOrder`, `AuditLog`, plus RBAC tables `Role` and a `role` field approach (see §5). All FKs, indexes, and timestamps included. Full schema is in `backend/prisma/schema.prisma` (created during implementation, not before).

## 5. RBAC Foundation

Minimum viable, extensible design for this phase:
- Fixed enum `Role` (`ADMIN, DOCTOR, STAFF, LAB, PHARMACY, BILLING, MANAGEMENT, PATIENT`) stored on a `Staff`/user-identity record and mirrored into the Firebase custom claims where available, falling back to a DB lookup by `firebaseUid`.
- `authorize(...allowedRoles)` middleware — declarative per-route, not hard-coded per-controller (`router.get('/', authenticate, authorize('ADMIN','BILLING'), controller)`).
- A small `permissions.js` module maps role → allowed actions per resource, so controllers can call `can(req.role, 'invoice:read')` for service-level checks where route-level isn't granular enough (e.g., a patient reading only their own record).
- Not building a full dynamic permission-editing admin UI in this phase — that's FUTURE.

## 6. Files To Change / Create (planned)

**Create:**
- `backend/prisma/schema.prisma`, `backend/prisma/migrations/**`
- `backend/lib/prisma.js` (singleton client)
- `backend/middleware/authorize.js` (RBAC)
- `backend/middleware/errorHandler.js`, `backend/middleware/notFound.js`
- `backend/middleware/validate.js` (generic Zod-schema-driven validator)
- `backend/middleware/requestId.js`
- `backend/services/patient.service.js`, `billing.service.js`, `appointment.service.js`, `laboratory.service.js`, `pharmacy.service.js`, `identity.service.js`, `audit.service.js`
- `backend/controllers/patient.controller.js`, `appointment.controller.js`, `laboratory.controller.js` (new — none existed)
- `backend/validations/patient.validation.js`, `billing.validation.js` (replace empty file), `appointment.validation.js`, `laboratory.validation.js`
- `backend/routes/patientRoutes.js` (rewritten — Prisma, protected), `appointmentRoutes.js`, `laboratoryRoutes.js`
- `backend/tests/**` (Node's built-in test runner)
- `.env.example` (root and `backend/`)
- `backend/prisma/seed.js`

**Modify:**
- `backend/server.js` — mount the single consolidated router, error handler, request-id, audit middleware, security headers, CORS allowlist from env.
- `backend/routes/index.js` — become the one real router aggregator.
- `backend/routes/billingRoutes.js`, `billing.controller.js` — real implementation.
- `backend/routes/pharmacyRoutes.js`, `pharmacyController.js` — ported to Prisma, `authenticate`/`authorize` added.
- `backend/routes/hospitalRoutes.js`, `hospitalController.js` — ported to Prisma, protected.
- `backend/middleware/auditMiddleware.js` — small extension to also accept structured domain audit calls from services.
- `package.json` (backend) — add `prisma`, `@prisma/client`, `zod`, `helmet`, `express-rate-limit`; add `test`, `prisma:migrate`, `prisma:generate`, `db:seed` scripts.

**Move (not delete):**
- `backend/models/*.js` (Mongoose/raw-pg) → `backend/models/legacy/*.js`

**Retire (superseded, not deleted from history — replaced by the Prisma-backed route of the same purpose):**
- `backend/routes/patients.js` (dead unauth route) — removed from `server.js` wiring; the file itself is deleted since it is unauthenticated and directly duplicated by the new `patientRoutes.js`, and keeping an unauthenticated PII route reachable-by-accident is a live security risk, not a historical artifact worth preserving. This is the one deletion in this plan, called out explicitly.

## 7. Migration Strategy

1. `prisma init` → configure `DATABASE_URL` from env.
2. Author `schema.prisma` for all models in §4.
3. `prisma migrate dev --name init_foundation` — generates and applies the first migration against a local dev Postgres instance, verified in this sandbox against a locally installed PostgreSQL 16 server.
4. `prisma/seed.js` — minimal seed (one of each role's staff record, one demo patient) for local dev/testing only, never run against production automatically.

## 8. Risks

- **Frontend breakage:** `Patients.tsx`/`patientStore` currently talk to the old unauthenticated shape. Once auth is enforced, the frontend will get 401s until it sends a real Firebase token — documented in the compatibility map (§17 of the report), not silently patched around.
- **Firebase env vars required:** `firebaseAdmin.js` throws at import time if `FIREBASE_PROJECT_ID/CLIENT_EMAIL/PRIVATE_KEY` are unset. Tests must mock/stub Firebase verification rather than requiring real credentials in CI.
- **No production DB access from this sandbox:** migrations here run against a locally installed, throwaway PostgreSQL instance for verification only. The generated migration SQL still needs to be run against the real target database by the team.
- **Scope discipline:** it would be easy to over-build Appointment/Laboratory here. Kept to persistence + minimal CRUD + auth only, per "do not build a giant system" instruction.

## 9. Explicitly Out of Scope This Phase

Payment/Razorpay/Stripe, WhatsApp/SMS/Email delivery, OTP delivery, Telemedicine, notification event bus, care coordination engine, location intelligence — none of these are touched.

---
Proceeding to implementation in small phases: (1) Prisma + schema + migration, (2) auth + RBAC middleware, (3) error handling + validation, (4) patient/billing/appointment/lab/pharmacy/hospital foundations wired through, (5) audit, (6) tests, (7) env/docs, (8) compatibility map + final report.
