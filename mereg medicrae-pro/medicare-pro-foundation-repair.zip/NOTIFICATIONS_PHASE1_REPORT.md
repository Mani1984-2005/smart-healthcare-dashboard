# MediCare Pro — Notifications, Phase 1: Implementation Report

Companion to `NOTIFICATIONS_PHASE1_PLAN.md` (written first). Scope, per that plan: event outbox + in-app notification delivery only — no email/SMS/WhatsApp/push, no OTP, no telemedicine, no care coordination/escalation, no queue technology, no template engine beyond fixed strings. This is exactly Phase 1 as defined in the original `MediCare-Pro-Communication-Architecture-Report.md`, nothing more.

## What was built

**Schema** (third additive migration, `20260817120000_add_notifications`): `notification_events` (the outbox — one row per domain event, `hospital_id`-scoped, `processed_at` marks completion) and `notifications` (what a recipient actually sees — `hospital_id`-scoped, exactly one of `recipient_staff_id`/`recipient_patient_id` set, enforced by a DB `CHECK` constraint, not just application logic).

**Event emission**, added as one additive call at the end of each existing write, exactly as the plan specified — no rewrites:
- `appointment.service.js` → `updateAppointmentStatus` emits `appointment.status_changed`
- `laboratory.service.js` → `recordResult` emits `lab_order.result_ready`
- `billing.service.js` → `createInvoice` emits `invoice.created` (after the transaction commits, not inside it — a notification failure must never roll back a real invoice)

**Recipient resolution**: a small, explicit per-event-type resolver in `notification.service.js` — not a generic rules engine. Every resolver query is itself `hospital_id`-scoped. A patient only ever receives a notification if they have a portal identity (`firebase_uid` set) — verified by a dedicated test that a portal-less patient's invoice generates zero orphaned notification rows.

**API**: `GET /api/notifications` (list mine, `unreadOnly` filter, tenant + recipient scoped automatically from `req.identity` — never from a query parameter naming a recipient), `PATCH /api/notifications/:id/read`.

**Failure isolation**: `emitEvent()` catches its own errors and never propagates into the caller — booking an appointment or creating an invoice succeeds even if notification delivery has a problem, mirroring the same principle already used for audit logging.

## Tenant and recipient safety — built in from the start, not retrofitted

Every table, query, and route in this phase follows the same rule as the rest of the system: `hospitalId` comes from `req.identity.hospitalId` only. Verified with the same rigor as the tenant-isolation freeze pass, not assumed to inherit it for free just because the pattern was followed:

- A Hospital B admin generates zero notifications from Hospital A's activity — tested directly against the API (0 rows returned).
- Every notification row's `hospital_id` was independently verified against the database to match the real event's hospital, not just checked via the API response shape.
- A Hospital B admin cannot mark a Hospital A notification as read by guessing/enumerating its UUID — `404`, row verified unchanged in the database.
- Patient B never sees a notification addressed to Patient A, even within the *same* hospital — recipient isolation is a separate, additional check from tenant isolation, and both are enforced (the `WHERE` clause filters on both `hospital_id` and the caller's own `recipient_*_id` column simultaneously).

## Test results

`tests/notifications.test.js` — **10/10 passing**: three end-to-end event→notification delivery tests (appointment, lab, billing), a mark-as-read test, three tenant-isolation tests, two recipient-isolation tests, and one baseline auth-required test.

**Full suite: 83/83 passing** (73 prior + 10 new), against a freshly-migrated real PostgreSQL 16 database with all three migrations applied in sequence. Server boot re-verified clean.

## What was deliberately not built

Per the plan and every prior report's scope discipline: no external providers, no OTP, no telemedicine, no care coordination/escalation engine, no consent model, no delivery-tracking/retry beyond the outbox's own `processed_at` marker, no admin/broadcast endpoints, and no instrumentation of Patient/Staff/Department creation (no clear "who gets notified" recipient exists for those yet without further design — adding events nobody consumes would be scope creep, not foundation work).

## Known limitations, stated plainly

- No worker/queue processes the outbox asynchronously — `emitEvent()` resolves recipients and delivers in-app notifications synchronously, in the same request, immediately after the underlying write. This matches "no queue infrastructure exists, don't introduce one just for this" from every prior report, but means notification delivery adds (small, in-process) latency to the three write paths it's attached to. Acceptable for Phase 1's in-app-only scope; would need revisiting if/when external providers are introduced.
- `notification_events` (the outbox table) is written but nothing currently re-reads it — it exists as the audit trail / future-reprocessing anchor the architecture report called for, not as an active queue. This is intentional for Phase 1, not an oversight.
