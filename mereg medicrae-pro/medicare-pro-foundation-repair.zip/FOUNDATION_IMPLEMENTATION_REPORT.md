# MediCare Pro — Foundation Repair: Implementation Report

Companion to `FOUNDATION_IMPLEMENTATION_PLAN.md` (written first) and `FRONTEND_COMPATIBILITY_MAP.md`. Everything below was implemented and tested in this session against a real, locally-installed PostgreSQL 16 instance (this sandbox's egress network doesn't reach a hosted database, so a throwaway local one was used for verification — see "Prisma toolchain" below for the one thing that genuinely couldn't be verified this way).

## Status classification (per the requested discipline)

- **FOUNDATION COMPLETE:** database consolidation, migration, auth wiring fix, RBAC middleware, Patient/Billing/Hospital(Staff+Department) real persistence, error handling, validation, audit logging, request IDs, security baseline (helmet/CORS/rate-limit), graceful shutdown, critical security tests (unauthenticated access denial, patient-isolation, RBAC boundaries) — all implemented and passing against a real database.
- **PARTIALLY COMPLETE:** Appointment and Laboratory foundations (persistence + minimal CRUD + auth exist; no conflict rules, reminders, or result-file handling — intentionally, per "do not build a giant system"). Pharmacy is authenticated/RBAC-protected but its prescription-creation path retains pre-existing defects, documented and not fixed.
- **NOT IMPLEMENTED:** Payment/Razorpay/Stripe, WhatsApp/SMS/Email, OTP delivery, Telemedicine, notification event bus, care coordination engine, location intelligence — none touched, per explicit instruction.
- **NOT VERIFIED:** Running `npx prisma migrate dev` / `prisma generate` against `schema.prisma` in a normal network environment (only the hand-authored, functionally-equivalent SQL was verified here — see below). Frontend behavior against the new backend (no frontend dev server was run this session; the compatibility map was built by reading the actual frontend service code, not by executing it).
- **FUTURE:** `/doctors` backend, generic appointment `PUT`/`DELETE`, `/laboratory` path alignment with the frontend's `/laboratory/tests`, dynamic/admin-editable permission model beyond the fixed `Role` enum, a real Prisma-generated client once network access allows it.

Nothing here is claimed as "Apollo/Practo level" or production-ready. This is a repaired, tested foundation — not a finished product.

---

## 1. Database Standard

**PostgreSQL is now the single database technology.** `backend/prisma/schema.prisma` is the canonical model. Mongoose is no longer used by anything reachable from the running app.

| Model | Disposition | Where it lives now |
|---|---|---|
| `Department`, `Staff` (Mongoose) | Migration candidate → migrated | Ported to Postgres tables `departments`/`staff`; original files moved to `backend/models/legacy/` with explanatory headers, not deleted |
| `Billing` (Mongoose) | Replaceable → replaced | New `invoices`/`invoice_items` tables; original stub controller replaced with real logic; old model moved to `legacy/` |
| `Patient` (empty file) | Replaceable → replaced | New `patients` table, real service |
| `Medicine`, `Prescription` (raw `pg`, hand-written DDL) | Reusable, kept in place | See §5 — deliberately **not** migrated to new Prisma-managed tables this phase for `Prescription`; `Medicine`'s schema was adopted as-is into the migration (see below) |

**mongoose was never even a declared dependency** in `backend/package.json` — confirming Department/Staff/Billing's Mongoose code could not have run in the shipped app before this phase.

### Two duplicate connection pools — fixed
`backend/config/db.js` and `backend/db.js` each built their own separate `pg.Pool` from different config sources. Both are now thin re-exports of one real pool in `backend/lib/db.js`, so existing imports (`import { getPool } from "../config/db.js"`, used by `Medicine.js`/`Prescription.js`) keep working unchanged, and there is exactly one pool at runtime.

## 2. Backend Architecture

Routes → Controllers → Services → `lib/db.js` (parameterized SQL) → PostgreSQL, consistently, for every domain touched this phase (Patient, Billing, Appointment, Laboratory, Hospital/Staff/Department). Controllers are thin (req/res only); business logic and queries live in `services/`.

## 3. Authentication — real bug found and fixed

`authMiddleware.js`/`config/firebaseAdmin.js` looked correct on inspection but **could not have worked at runtime**: under this project's `"type": "module"` (ESM) configuration, `import admin from "firebase-admin"` does not yield the classic `admin.apps` / `admin.credential.cert()` / `admin.auth()` namespace object that both files called — the ESM default export is missing those properties. Any request that reached `authenticate` would have thrown `TypeError: Cannot read properties of undefined`, regardless of whether valid Firebase credentials were configured. This was never caught before because no mounted route exercised it.

**Fixed** by switching to firebase-admin's modular ESM entry points (`firebase-admin/app`, `firebase-admin/auth`). Verified end-to-end: booted the server with a real (throwaway, locally-generated) RSA key, confirmed `Firebase Admin SDK initialised` logs correctly, and confirmed `authenticate` correctly rejects requests with no/invalid token.

A second, unrelated bug was found and fixed in the same pass: `dotenv.config()` was called after other modules (which read `process.env` at import time) had already been imported — ESM hoists imports, so this was a latent env-loading-order bug. Fixed by making `import "dotenv/config"` the very first line evaluated.

**Every protected route now actually requires authentication** — verified with a live `curl` against the running server (see §9) and with the automated test suite (§10).

## 4. RBAC Foundation

- `Role` enum: `ADMIN, DOCTOR, STAFF, LAB, PHARMACY, BILLING, MANAGEMENT, PATIENT`, stored on `staff.role` (or implied `PATIENT` for rows in `patients`).
- `services/identity.service.js` is the **one place** that maps a verified Firebase UID to a platform role (staff first, then patient) — controllers/services never query `firebase_uid` themselves.
- `middleware/resolveIdentity.js` runs after `authenticate` and attaches `req.identity = { type, id, role }`; rejects unrecognized or deactivated accounts.
- `middleware/authorize.js` provides declarative `authorize(...roles)` for route-level checks and `authorizeSelfOrRoles(...)` for "a patient may access their own record, certain staff roles may access any record" — used on `GET /patients/:id`.
- No role checks are hard-coded inside controllers; every check is a route-level middleware.

## 5. Routing — consolidated

`backend/routes/index.js` is now the **one** real router aggregator (`server.js` previously mounted a completely different, smaller set of routes than `routes/index.js` did — they were two independent, divergent entry points). `app.js` mounts `routes/index.js` under `/api`, plus a back-compat `/health` alias. The dead, unauthenticated `backend/routes/patients.js` (raw SQL, no auth) was **deleted** — the one explicit deletion in this phase, since an unauthenticated PII route reachable by accident is a live risk, not a historical artifact worth preserving via a `legacy/` move.

Billing and Hospital routes, which existed but were never mounted anywhere, are now mounted, authenticated, and RBAC-protected.

## 6. Patient Foundation

New `patients` table: identity, contact info, date of birth, gender, emergency contact, `is_active` (soft-delete flag), timestamps. Deliberately excludes clinical notes/diagnoses. `services/patient.service.js` + `controllers/patient.controller.js` + `routes/patientRoutes.js` provide list/get/create/update/deactivate, all authenticated, RBAC-checked (patients can only read their own record; only `ADMIN`/`STAFF` can create; only `ADMIN` can deactivate), and Zod-validated.

## 7. Billing Foundation

New `invoices`/`invoice_items` tables. `services/billing.service.js` replaces every stub handler in `billing.controller.js` with real logic: list (with patient/status filters), get by id (with items), create (transactional — invoice + items in one DB transaction via `withTransaction`), status update, void. Restricted to `ADMIN, BILLING, MANAGEMENT`.

## 8. Appointment Foundation (minimum viable, per instruction)

New `appointments` table: patient/doctor/department FKs, `scheduled_at`, status enum, reason. Create, list (filterable), get by id, status update, reschedule. **Deliberately does not implement** conflict detection, recurring appointments, or reminders (FUTURE). `GET /:id` is staff-only this phase — a patient-self-access check would need an ownership lookup (appointment → patient) that the generic `authorizeSelfOrRoles` helper doesn't support out of the box; building a one-off check for it was judged out of scope for "minimum viable."

## 9. Laboratory Foundation (minimum viable, per instruction)

New `lab_orders` table: patient/appointment/handler FKs, test name, status enum, result summary. Create, list, get by id, status update, record result. No file/attachment storage, no critical-value alerting (FUTURE). Restricted to `ADMIN, DOCTOR, LAB, MANAGEMENT`.

## 10. Pharmacy — normalized where safe, defects documented not fixed

`models/Medicine.js`'s existing schema (columns, types, indexes — including the GIN full-text index on `name`) was **adopted verbatim** into the real migration (previously, its `createTable()` method existed but was never invoked anywhere, so the table never actually existed at runtime). Its primary key is `SERIAL` (integer), not UUID — kept exactly as the existing code expects, rather than converting to UUID for consistency with the rest of this schema, specifically to avoid a silent type mismatch against `pharmacyController.js`'s existing, untouched query code.

**Known defect found, intentionally not fixed this phase** (fixing it would mean rebuilding pharmacyController's prescription logic, which the brief said not to do): `pharmacyController.js` does `import * as Prescription from "../models/Prescription.js"`, but `Prescription.js` only has a default export — so `Prescription.create`/`.findAll`/etc. are `undefined` at runtime, and separately, the controller passes a generated `prescription_id` string field that `Prescription.js`'s own schema (`id SERIAL`) has no column for. `pharmacyRoutes.js` is now mounted and protected (so the working medicine-catalog endpoints — list, get, create, update, delete, categories, low-stock, drug-interaction check, dosage suggestion — are reachable), but the prescription-creation endpoints will error if exercised, exactly as they would have before this phase. This is flagged for a dedicated remediation phase, not silently patched.

## 11. Audit Log Foundation

New `audit_logs` table (queryable, structured) + `services/audit.service.js`, which writes to both the new table and the pre-existing file-based JSON logger (`utils/logger.js`, kept as-is — it's reasonable and other tooling may depend on its file location). `middleware/auditMiddleware.js` was updated to pull actor identity from `req.identity` (previously referenced a `req.user.role` shape that nothing set) and to call the new structured audit service for every mutating (`POST/PUT/PATCH/DELETE`) request.

## 12. Error Handling

`lib/errors.js` defines an explicit error taxonomy (`ValidationError`, `AuthenticationError`, `AuthorizationError`, `NotFoundError`, `ConflictError`). `middleware/errorHandler.js` catches all of them centrally: known `AppError`s return their real status/code/message; everything else returns a generic `500` with **no stack trace, no raw database error, no secrets** in the response (stack traces are logged server-side only, and only outside production). Verified with an automated test that a duplicate-key Postgres error (`23505`) surfaces as a clean `409 CONFLICT`, not a raw `"duplicate key value violates unique constraint..."` message.

## 13. Validation

Zod schemas per domain in `backend/validations/`, applied via a generic `middleware/validate.js`. One real bug found and fixed while testing this: **Express 5 makes `req.query` a getter with no setter**, so the initial version of `validate.js` (`req.query = result.data`) threw `TypeError: Cannot set property query of #<IncomingMessage> which has only a getter` on every query-validated route. Fixed with `Object.defineProperty` to override the getter for validated/coerced query params, verified by re-running the full test suite after the fix (it had been silently causing every filtered `GET` — e.g., `GET /patients?search=...` — to 500).

## 14. Security Baseline

`helmet()`, environment-driven CORS allowlist (not `cors()` wide open), a baseline `express-rate-limit` (300 req/15min — a real per-identity policy is a future refinement, not built this phase), 1MB JSON body limit, request-ID propagation (`x-request-id`), and the auth/RBAC/audit/error-handling described above. PII protection is enforced at the route layer (RBAC) and the response layer (error handler never leaks raw data).

## 15. Environment Configuration

`.env.example` created for both `backend/` and the frontend root, documenting every variable actually read by the code (verified by grep, not guessed) with no real secrets committed.

## 16. Database Migrations — Prisma toolchain (NOT VERIFIED, documented honestly)

**This sandbox's network egress does not include `binaries.prisma.sh`**, so `npx prisma init` / `migrate dev` / `generate` fail with `403 Forbidden` when fetching Prisma's schema-engine/query-engine binaries — this is a hard sandbox limitation, not a code problem, verified directly (see the two failed attempts in this session's tool history).

Given that constraint, the approach taken was:
1. `backend/prisma/schema.prisma` is the **canonical, hand-authored Prisma schema** — written to be exactly what `npx prisma migrate dev` would consume in a normal network environment.
2. The equivalent SQL migration was **hand-authored to match it precisely** (`prisma/migrations/20260816120000_init_foundation/migration.sql`) and **actually applied and verified** against a real PostgreSQL 16 instance installed in this sandbox for that purpose. Every table, type, index, and constraint was confirmed to exist correctly via `\d` after applying it — including the `Medicine` id-type fix caught in the process (see §10).
3. Application code queries via parameterized `pg` (`lib/db.js`) rather than `@prisma/client`, because the Prisma Client's query engine has the same binary-download problem. The query patterns in every `services/*.js` file were written to map 1:1 onto what the equivalent Prisma Client call would look like, so swapping the internals of `lib/db.js` for `@prisma/client` in a normal network environment is intended to be a mechanical, low-risk change — **but this specific claim (the swap being low-risk) is itself unverified**, since it couldn't be executed here.

**Action needed from the team:** run `npx prisma generate` and `npx prisma migrate dev` (or `prisma migrate deploy` against the hand-written migration, which should apply cleanly since it was tested) in an environment with normal network access, and confirm the generated client's query shapes match what's documented above.

## 17. Testing

Node's built-in test runner (`node --experimental-test-module-mocks --test`, wired as `npm test`) — no new test framework dependency beyond `supertest` for HTTP assertions. Firebase verification is mocked via `node:test`'s experimental `mock.module` (`tests/mockAuth.js`), so tests don't need a real Firebase project — they simulate "a request signed by Firebase UID X" via a header, and real RBAC/identity resolution still runs against the real (test) database.

**Two test files, 24/24 passing**, exercising every domain built this phase against a real database:

`tests/security.test.js` (11 tests) — the specific cases requested:
- Unauthenticated request to `/patients` → **no patient data**, `401`.
- Authenticated-but-unregistered Firebase user → rejected, `401`.
- `PATIENT` role → forbidden from listing all patients, `403`.
- **Patient A cannot access Patient B's protected information** → `403`.
- Patient A **can** access their own record → `200`.
- `DOCTOR` can read but not create a patient (RBAC boundary) → `200` / `403`.
- Malformed create payload → `400 VALIDATION_ERROR` with field-level details.
- Unknown route → clean `404` JSON, not a stack trace.
- Duplicate-key DB constraint violation → clean `409 CONFLICT`, no raw Postgres error text in the response.

`tests/appointment-lab-hospital.test.js` (13 tests, added in a follow-up pass — these three services had been built but not yet exercised by any automated test) — Staff creation/listing and RBAC (admin-only), invalid-role rejection, Appointment creation/status-update/reschedule-validation/filtered-listing with RBAC (patient can't create, only staff can), Laboratory order creation/RBAC (billing role can't create a lab order)/result-recording/validation/404-on-unknown-id.

Two real bugs were found and fixed while building out this second test file:
1. **Shared connection pool across test files.** `node --test` runs multiple matched files in the same process, sharing the ESM module cache — so `lib/db.js`'s singleton pool was shared too. The first test file's teardown was calling `pool.end()`, silently breaking the *other* test file's database access mid-run with a misleading `"no PostgreSQL user name specified"` error. Fixed by not ending the pool in test teardown (the process exiting cleans up connections naturally) — documented inline in `tests/testDb.js` so it isn't reintroduced.
2. A local-only `.env` (never committed, git-ignored) was deleted during output packaging in the previous session and not recreated before continuing — surfaced as the same misleading Postgres auth error. Recreated for continued local verification; not a code defect, but worth naming since it produced an identical-looking symptom to bug #1 and cost real debugging time to tell apart.

Run with `npm test` from `backend/` (requires `DATABASE_URL` pointed at a real Postgres with the migration applied).

## 18. Frontend Compatibility

See `FRONTEND_COMPATIBILITY_MAP.md`. Headline finding: `patientService.js`, `billingService.js`, and `pharmacyService.js` already call paths/shapes that match the new backend almost exactly — the main blocker is that the frontend's current login flow doesn't produce a real Firebase ID token (per the pre-existing `MEDICARE_PRO_RUNTIME_AUDIT.md`), so every request will `401` until that's wired up. `appointmentService.js` and `laboratoryService.js` have smaller path/shape gaps, listed with specifics. `doctorService.js` has no backend counterpart — confirmed still FUTURE.

---

## Files created

`backend/prisma/schema.prisma`, `backend/prisma/migrations/20260816120000_init_foundation/migration.sql`, `backend/prisma/seed.js`, `backend/lib/db.js`, `backend/lib/errors.js`, `backend/app.js` (new — app factory split out of `server.js`), `backend/middleware/{requestId,errorHandler,validate,resolveIdentity,authorize}.js`, `backend/services/{identity,audit,patient,billing,hospital,appointment,laboratory}.service.js`, `backend/controllers/{patient,billing,appointment,laboratory}.controller.js`, `backend/routes/{appointmentRoutes,laboratoryRoutes}.js`, `backend/validations/{patient,appointment,laboratory}.validation.js`, `backend/tests/{mockAuth,testDb,security.test}.js`, `.env.example` (root and `backend/`), `FOUNDATION_IMPLEMENTATION_PLAN.md`, `FRONTEND_COMPATIBILITY_MAP.md`, this report.

## Files modified

`backend/server.js` (reduced to listen/shutdown only), `backend/config/db.js`, `backend/db.js` (both now re-export `lib/db.js`), `backend/config/firebaseAdmin.js`, `backend/middleware/authMiddleware.js` (ESM import fix), `backend/middleware/auditMiddleware.js` (identity-aware, structured), `backend/middleware/validate.js` (Express 5 `req.query` fix), `backend/routes/{index,patientRoutes,billingRoutes,hospitalRoutes,pharmacyRoutes}.js`, `backend/controllers/hospitalController.js`, `backend/validations/billing.validation.js` (was empty), `backend/package.json` (scripts + dependencies).

## Files moved (not deleted)

`backend/models/{Department,Staff,Billing,Patient}.js` → `backend/models/legacy/` with explanatory headers.

## Files deleted

`backend/routes/patients.js` — the one deletion in this phase, an unauthenticated raw-SQL PII route directly superseded by the new `patientRoutes.js`.

## Pre-existing dead files, now removed in this continuation pass

`backend/middleware/auth.js` and `backend/services/billingService.js` were both empty (0 bytes) and confirmed unreferenced anywhere in the codebase (verified by grep before deleting). Deleted as a trivial, zero-risk cleanup once confirmed dead — noted separately from the single deliberate deletion above (`routes/patients.js`) because these two carried no functional risk either way.

---

## Database changes

One migration, applied and verified: `20260816120000_init_foundation` — creates `departments, staff, patients, medicines, appointments, lab_orders, invoices, invoice_items, audit_logs` plus four enum types (`Role, AppointmentStatus, InvoiceStatus, LabOrderStatus`). No data migration was required for any of the replaced Mongo/empty models, since none had verified production data behind them.

## Security changes

Unauthenticated `/patients` closed. RBAC added everywhere. Firebase auth actually functional for the first time (bug fix, §3). Centralized error handling prevents leakage. Security headers, CORS allowlist, rate limiting, request-ID tracing, and structured audit logging added.

## Known limitations (explicit, not glossed over)

1. Prisma CLI/engine binaries could not be exercised in this sandbox (§16) — needs a run in a normal network environment before treating `@prisma/client` as live.
2. Pharmacy prescription-creation is still broken (§10), by design — not fixed this phase.
3. No frontend dev server was run this session; the compatibility map (§18) is based on static code reading, not an executed integration test against the live frontend.
4. Rate limiting is a flat global baseline, not per-identity or per-route tuned.
5. `authorizeSelfOrRoles` doesn't support "ownership via a different resource's foreign key" (e.g., patient-self access to their own appointment by appointment id) — noted inline in `appointmentRoutes.js` rather than special-cased.
6. Appointment `GET /:id` is staff-only this phase (see #5).
7. `Doctors` has no backend at all — confirmed FUTURE, unchanged from before this phase.

---

## Success criteria checklist (from the request)

- ✅ One authoritative database architecture
- ✅ PostgreSQL + Prisma (schema/migration authored and verified; client generation blocked by sandbox network — see §16)
- ✅ Protected API (verified: unauthenticated `/patients` → `401`, live and via automated test)
- ✅ Working authentication (bug found and fixed; verified end-to-end)
- ✅ RBAC foundation (role enum, middleware, route-level enforcement, tested)
- ✅ Real Patient persistence
- ✅ Real Billing/Invoice persistence
- ✅ Consistent routing (single mount point)
- ✅ Consistent validation (Zod, applied uniformly, one Express-5 bug found and fixed)
- ✅ Consistent errors (centralized, no leaks, tested)
- ✅ Audit foundation (structured table + service, wired into HTTP middleware)
- ✅ Secure environment configuration (`.env.example`, no secrets committed)
- ⚠️ Database migrations — SQL migration authored and verified against real Postgres; Prisma CLI itself not verified (sandbox network limitation, honestly disclosed)
- ✅ Tests for critical security boundaries (24/24 passing across two test files — 11 security-focused, 13 covering Appointment/Laboratory/Staff, added in a follow-up pass so every domain built this phase is actually exercised, not just Patient/Billing)
- ✅ Existing frontend remains understandable and recoverable (no frontend files touched; compatibility map documents exactly what would need to change and why)

This phase is complete enough to build Payment/Communication/Telemedicine/Care Coordination on top of, with the limitations above disclosed rather than hidden. Awaiting review before any further phase begins.
