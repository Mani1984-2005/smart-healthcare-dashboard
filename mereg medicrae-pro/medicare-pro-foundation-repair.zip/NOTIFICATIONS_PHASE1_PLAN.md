# MediCare Pro — Notifications, Phase 1: Implementation Plan

Written before code, per the discipline established in the Foundation Repair phase. Scoped to exactly what the original `MediCare-Pro-Communication-Architecture-Report.md` (§12, Phase 1) called MUST HAVE: **event foundation + in-app notification delivery only.** No email/SMS/WhatsApp/OTP/telemedicine/care-coordination — those remain explicitly future, per every prior report in this thread.

## 1. Why this scope, specifically

The original architecture report's Phase 1 recommendation, re-read fresh: *"Transactional outbox for Pharmacy, Billing, Hospital/Staff only (the domains with real backends). In-app notification delivery only... No external providers yet."* Since that report was written, Appointments and Laboratory also gained real backends (Foundation Repair phase), so they're included too. This plan does not expand scope beyond "event emission + in-app delivery" — no external providers, no escalation engine, no consent model, no templates beyond a fixed message per event type.

## 2. Tenant safety is not optional here

Every table and query in this phase must be `hospital_id`-scoped from the moment it's created — there is no "add tenant isolation later" for a brand-new domain being built *after* tenant isolation was frozen as foundational. `hospitalId` continues to come from exactly one place: `req.identity.hospitalId`, resolved server-side, never from client input.

## 3. Schema (additive third migration)

- `notification_events` (the outbox): `id, hospital_id, event_type, resource_type, resource_id, payload jsonb, created_at, processed_at nullable`. Written by the same service call that performs the underlying domain write — not a separate queue technology (no Redis/BullMQ this phase, consistent with every prior report's "no queue infrastructure exists, don't introduce it just for this").
- `notifications` (what a recipient actually sees): `id, hospital_id, recipient_staff_id nullable, recipient_patient_id nullable, event_type, title, body, resource_type, resource_id, is_read boolean, created_at`. Exactly one of `recipient_staff_id`/`recipient_patient_id` is set — a notification always belongs to exactly one hospital and exactly one recipient within it.

## 4. Event emission points (additive, not rewrites)

One line added at the end of each existing service call that already succeeds — matching the pattern the original architecture report specified for not rebuilding existing domains:
- `appointment.service.js`: `updateAppointmentStatus` → emit `appointment.status_changed`
- `laboratory.service.js`: `recordResult` → emit `lab_order.result_ready`
- `billing.service.js`: `createInvoice` → emit `invoice.created`

Deliberately NOT instrumenting Patient/Staff/Department creates this phase — those don't have an obvious "who gets notified" recipient yet without more design (patient self-service portal doesn't exist), and adding events nobody consumes yet is scope creep.

## 5. Recipient resolution (minimal, in-process, no policy engine)

A small, explicit resolver per event type — not a generic rules engine (that's Phase 4+ in the original report, "Care Coordination + Escalation," explicitly future):
- `appointment.status_changed` → notify the patient (if they have a portal identity) and the assigned doctor, if any.
- `lab_order.result_ready` → notify the ordering/handling staff member and the patient.
- `invoice.created` → notify the patient.

## 6. API surface

`GET /api/notifications` (list mine, tenant + recipient-scoped automatically from `req.identity`), `PATCH /api/notifications/:id/read`. No admin/broadcast endpoints this phase.

## 7. Test plan

- Tenant isolation for notifications specifically: a Hospital B recipient must never see a Hospital A notification, even one generated for "the same" event type.
- Recipient isolation: Patient A must never see a notification generated for Patient B, even within the same hospital.
- End-to-end: performing the underlying action (e.g. updating appointment status) actually produces the expected notification row(s) for the expected recipient(s), tenant-scoped.
- Full existing suite (73 tests) must still pass unchanged.

## 8. Explicitly out of scope this phase (unchanged from every prior report)

Email/SMS/WhatsApp/push, OTP, telemedicine, care coordination/escalation, consent management, templates beyond fixed strings, delivery tracking/retry, any queue technology beyond the outbox table itself.

Proceeding to implementation now.
