# MediCare Pro — Hospital/Tenant Isolation: Design & Plan

Written before touching code, per the request. Summarizes what's being changed and why.

## Current state (inspected)

- No `hospital_id`/tenant column exists anywhere in `schema.prisma`, the migration, or any service/controller — confirmed by the Final Verification Gate audit and re-confirmed here.
- `identity.service.js` resolves a Firebase UID to a `staff` or `patients` row and returns `{ type, id, role, name, email, isActive }` — no hospital context.
- Every service (`patient`, `billing`, `appointment`, `laboratory`, `hospital`) queries by `id` alone, or by role via RBAC — never by tenant.
- `Medicine`/`Prescription` (raw SQL, adopted from the pre-existing `models/Medicine.js`) also have no tenant column.

## Design

1. **New `Hospital` table** — `id, name, code (unique), is_active, timestamps`. Additive migration, not a rewrite of the existing one.
2. **`hospital_id` added to every tenant-owned table**: `staff`, `patients`, `departments`, `appointments`, `lab_orders`, `invoices`, `medicines`. Not added to `invoice_items` (child of `invoices`, always accessed through it) or `prescriptions`/`prescription_items` (already-broken, unreachable code path per the prior audit — scoping unreachable code doesn't protect anything real; noted as an explicit gap, not silently skipped).
3. **Tenant identity comes from exactly one place**: `identity.service.js`'s DB lookup, extended to also select `hospital_id`. `resolveIdentity` middleware attaches `req.identity.hospitalId`. No route, controller, or validation schema accepts `hospitalId` from the client — confirmed by keeping it out of every Zod schema (Zod's default `.parse()` behavior already strips unknown keys, proven by the mass-assignment test in the prior audit; this is re-verified for the new field specifically, not assumed).
4. **Every service function is extended to take `hospitalId` as its first argument** and:
   - `list`/`get`: filter `WHERE hospital_id = $hospitalId` in addition to any existing filter.
   - `get-by-id`/`update`/`delete`: filter `WHERE id = $id AND hospital_id = $hospitalId`. A cross-tenant request for a real ID in another hospital returns **404**, not 403 — deliberately, so a request never confirms that a resource exists in a hospital the caller doesn't belong to (standard multi-tenant practice: existence itself is tenant-scoped information).
   - `create`: `hospital_id` is always taken from `req.identity.hospitalId`, inserted server-side, never read from the request body.
   - Cross-entity creates (e.g., an Appointment referencing both a `patientId` and a `doctorId`) additionally verify **both** referenced rows belong to the caller's hospital before insert — otherwise a valid same-hospital admin could still link a real patient ID or staff ID belonging to a different hospital by guessing/enumerating UUIDs.
5. **`Medicine.js`'s existing query methods are extended** (parameters added, not rewritten) to accept and filter by `hospitalId` — this is foundation-level security work on the medicine catalog CRUD (already touched last phase for auth/RBAC), not the prescription business-logic rebuild that remains explicitly out of scope.
6. **Migration approach**: additive second migration (`20260817000000_add_hospital_tenancy`), not a rewrite of the first. Backfills existing rows to a bootstrap "Default Hospital" before making `hospital_id NOT NULL`, mirroring how this would have to be done against real populated data, not just a throwaway test DB.

## Test plan

For every domain in the request (patients, appointments, laboratory, pharmacy, billing, staff): seed two hospitals, seed a staff/patient identity in each, and verify:
- Hospital A's admin cannot list/read/update/delete Hospital B's records (404, not data leakage).
- Hospital A's admin cannot create a record that references a Hospital B entity (patient/doctor/department) even with a same-hospital-valid role.
- Hospital A's admin CAN fully operate on Hospital A's own records (regression — isolation must not break same-tenant function).
- The existing 44 foundation tests must still pass unchanged — they don't reference cross-hospital scenarios but do exercise every route this change touches, so they're the primary regression signal.

Proceeding to implementation now.
