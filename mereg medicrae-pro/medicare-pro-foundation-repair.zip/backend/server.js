import app from "./app.js";
import { logInfo } from "./utils/logger.js";

const PORT = process.env.PORT || 5000;

const server = app.listen(PORT, () => {
  logInfo("server_started", { port: PORT, env: process.env.NODE_ENV || "development" });
  // eslint-disable-next-line no-console
  console.log(`Server running on port ${PORT}`);
});

// Graceful shutdown — previously absent.
function shutdown(signal) {
  logInfo("server_shutdown_initiated", { signal });
  server.close(() => {
    logInfo("server_shutdown_complete", {});
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
