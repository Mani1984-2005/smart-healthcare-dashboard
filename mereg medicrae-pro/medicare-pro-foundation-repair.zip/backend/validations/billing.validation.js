import { z } from "zod";

const invoiceItemSchema = z.object({
  serviceName: z.string().trim().min(1).max(255),
  category: z.enum(["Consultation", "Lab", "Procedure", "Medicine", "Room", "Other"]).optional(),
  quantity: z.coerce.number().int().min(1).optional(),
  unitPrice: z.coerce.number().min(0),
});

export const createInvoiceSchema = z.object({
  patientId: z.string().uuid(),
  items: z.array(invoiceItemSchema).min(1),
});

export const updateInvoiceStatusSchema = z.object({
  status: z.enum(["DRAFT", "ISSUED", "PAID", "PARTIALLY_PAID", "VOID"]),
});

export const invoiceIdParamSchema = z.object({
  id: z.string().uuid(),
});

export const listInvoicesQuerySchema = z.object({
  patientId: z.string().uuid().optional(),
  status: z.enum(["DRAFT", "ISSUED", "PAID", "PARTIALLY_PAID", "VOID"]).optional(),
  page: z.coerce.number().int().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
});
