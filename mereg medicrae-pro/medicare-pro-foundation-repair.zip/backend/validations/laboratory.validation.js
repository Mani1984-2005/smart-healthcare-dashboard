import { z } from "zod";

export const createLabOrderSchema = z.object({
  patientId: z.string().uuid(),
  appointmentId: z.string().uuid().optional(),
  testName: z.string().trim().min(1).max(255),
});

export const updateLabOrderStatusSchema = z.object({
  status: z.enum(["ORDERED", "COLLECTED", "PROCESSING", "RESULT_READY", "REVIEWED", "REJECTED"]),
});

export const recordResultSchema = z.object({
  resultSummary: z.string().trim().min(1).max(2000),
});

export const labOrderIdParamSchema = z.object({
  id: z.string().uuid(),
});

export const listLabOrdersQuerySchema = z.object({
  patientId: z.string().uuid().optional(),
  status: z.enum(["ORDERED", "COLLECTED", "PROCESSING", "RESULT_READY", "REVIEWED", "REJECTED"]).optional(),
  page: z.coerce.number().int().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
});
