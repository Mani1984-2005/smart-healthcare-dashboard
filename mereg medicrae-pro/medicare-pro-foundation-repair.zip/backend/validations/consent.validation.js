import { z } from "zod";

export const grantConsentSchema = z.object({
  patientId: z.string().uuid(),
  purpose: z.enum(["TELEMEDICINE", "SMS_COMMUNICATION", "WHATSAPP_COMMUNICATION"]),
  relatedEventType: z.string().max(100).optional(),
  relatedEventId: z.string().max(100).optional(),
});

export const revokeConsentSchema = z.object({
  patientId: z.string().uuid(),
  purpose: z.enum(["TELEMEDICINE", "SMS_COMMUNICATION", "WHATSAPP_COMMUNICATION"]),
});

export const patientIdParamSchema = z.object({
  patientId: z.string().uuid(),
});
