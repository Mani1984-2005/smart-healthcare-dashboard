import { z } from "zod";

export const createPatientSchema = z.object({
  firstName: z.string().trim().min(1).max(255),
  lastName: z.string().trim().min(1).max(255),
  dateOfBirth: z.string().refine((v) => !Number.isNaN(Date.parse(v)), {
    message: "dateOfBirth must be a valid date",
  }),
  gender: z.string().max(50).optional(),
  phone: z.string().trim().min(5).max(30),
  email: z.string().email().optional(),
  emergencyContactName: z.string().max(255).optional(),
  emergencyContactPhone: z.string().max(30).optional(),
});

export const updatePatientSchema = createPatientSchema.partial();

export const listPatientsQuerySchema = z.object({
  search: z.string().max(255).optional(),
  page: z.coerce.number().int().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
});

export const patientIdParamSchema = z.object({
  id: z.string().uuid(),
});
