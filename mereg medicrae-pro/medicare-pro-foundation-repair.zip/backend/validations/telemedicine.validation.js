import { z } from "zod";

export const createSessionSchema = z.object({
  appointmentId: z.string().uuid(),
});

export const sessionIdParamSchema = z.object({
  id: z.string().uuid(),
});

export const validateTokenSchema = z.object({
  token: z.string().trim().min(32),
});
