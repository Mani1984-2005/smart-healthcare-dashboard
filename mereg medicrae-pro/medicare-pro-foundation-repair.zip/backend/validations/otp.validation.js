import { z } from "zod";

export const requestOtpSchema = z.object({
  phone: z.string().trim().min(5).max(30),
  purpose: z.enum(["LOGIN", "PHONE_VERIFICATION", "TELEMEDICINE_ACCESS"]),
});

export const verifyOtpSchema = z.object({
  phone: z.string().trim().min(5).max(30),
  purpose: z.enum(["LOGIN", "PHONE_VERIFICATION", "TELEMEDICINE_ACCESS"]),
  code: z.string().trim().length(6),
});
