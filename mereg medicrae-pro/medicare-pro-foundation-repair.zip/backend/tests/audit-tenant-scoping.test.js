import { test, before, after, mock } from "node:test";
import assert from "node:assert";
import { mockAuth } from "./mockAuth.js";
import { resetDb, seedStaff, closeDb } from "./testDb.js";
import { query } from "../lib/db.js";

// Regression test for a defect found during the Tenant Isolation Freeze
// Verification pass: audit_logs.hospital_id existed as a column (added by
// the tenant-isolation migration) but was never actually populated —
// auditMiddleware.js read actorStaffId/actorRole from req.identity but not
// req.identity.hospitalId, so every audit row, including ones for fully
// successful, correctly-identity-resolved requests, silently recorded NULL.
// Fixed in auditMiddleware.js/audit.service.js.

mockAuth(mock);
const { default: request } = await import("supertest");
const { default: app } = await import("../app.js");

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
let adminUid;

before(async () => {
  await resetDb();
  adminUid = "firebase-audit-regression-admin";
  await seedStaff({ role: "ADMIN", firebaseUid: adminUid });
});

after(async () => {
  await closeDb();
});

test("audit_logs: a successful, authenticated mutation records the caller's real hospital_id", async () => {
  await request(app)
    .post("/api/patients")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ firstName: "Audit", lastName: "Regression", dateOfBirth: "1990-01-01", phone: "5551234" });
  await wait(300); // audit write is fire-and-forget on res.on('finish', ...)

  const { rows } = await query(
    "SELECT hospital_id FROM audit_logs WHERE outcome = 'success' ORDER BY created_at DESC LIMIT 1"
  );
  assert.strictEqual(rows.length, 1);
  assert.ok(rows[0].hospital_id, "audit log for a successful, identity-resolved mutation must carry a real hospital_id, not null");
});

test("audit_logs: an unauthenticated request (no identity ever resolved) records null hospital_id, not a guess", async () => {
  await request(app).post("/api/patients").send({ firstName: "X" }); // no Authorization header
  await wait(300);

  const { rows } = await query(
    "SELECT hospital_id FROM audit_logs WHERE outcome = 'failure' ORDER BY created_at DESC LIMIT 1"
  );
  assert.strictEqual(rows.length, 1);
  assert.strictEqual(rows[0].hospital_id, null);
});
