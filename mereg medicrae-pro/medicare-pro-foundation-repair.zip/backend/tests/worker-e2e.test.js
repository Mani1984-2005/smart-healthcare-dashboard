import { test, before, after, mock } from "node:test";
import assert from "node:assert";
import { mockAuth } from "./mockAuth.js";
import { resetDb, seedHospital, seedStaff, closeDb } from "./testDb.js";
import { query } from "../lib/db.js";
import { getRedisConnection } from "../queue/communicationQueue.js";
import { enqueueCommunication } from "../services/communication.service.js";
import { startCommunicationWorker } from "../workers/communicationWorker.js";

mockAuth(mock);
await import("../app.js"); // ensures env/app wiring is loaded consistently with other test files

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

let hospitalA, staffId, worker;

before(async () => {
  await resetDb();
  hospitalA = await seedHospital({ name: "Worker E2E Hospital", code: "WRKE2E" });
  staffId = await seedStaff({ role: "DOCTOR", hospitalId: hospitalA });
  await query("UPDATE staff SET phone = '+15550300001' WHERE id = $1", [staffId]);
  worker = startCommunicationWorker();
  await wait(300); // let the worker finish connecting to Redis before enqueueing
});

after(async () => {
  await worker.close();
  await getRedisConnection().quit().catch(() => {});
  await closeDb();
});

test("[Worker E2E] a real job flows through Redis/BullMQ to the mock provider and delivery_attempts is updated to SENT", async () => {
  const attemptId = await enqueueCommunication({
    hospitalId: hospitalA,
    eventType: "appointment.status_changed",
    channel: "sms",
    recipientType: "staff",
    recipientStaffId: staffId,
    to: "+15550300001",
    correlationId: `worker-e2e-${Date.now()}`,
    templatePayload: { status: "CONFIRMED" },
  });

  let status = null;
  for (let i = 0; i < 20 && status !== "SENT"; i++) {
    await wait(200);
    const row = await query("SELECT status FROM delivery_attempts WHERE id = $1", [attemptId]);
    status = row.rows[0]?.status;
  }
  assert.strictEqual(status, "SENT", "the worker must have processed the job and updated delivery_attempts");
});

test("[Worker E2E] an unknown event type (no template) fails cleanly and is recorded as FAILED, not left QUEUED forever", async () => {
  const attemptId = await enqueueCommunication({
    hospitalId: hospitalA,
    eventType: "totally.unknown.event.type",
    channel: "sms",
    recipientType: "staff",
    recipientStaffId: staffId,
    to: "+15550300002",
    correlationId: `worker-e2e-unknown-${Date.now()}`,
  });

  let status = null;
  for (let i = 0; i < 20 && status !== "FAILED"; i++) {
    await wait(200);
    const row = await query("SELECT status FROM delivery_attempts WHERE id = $1", [attemptId]);
    status = row.rows[0]?.status;
  }
  assert.strictEqual(status, "FAILED");

  const row = await query("SELECT error FROM delivery_attempts WHERE id = $1", [attemptId]);
  assert.ok(/No template/.test(row.rows[0].error));
});
