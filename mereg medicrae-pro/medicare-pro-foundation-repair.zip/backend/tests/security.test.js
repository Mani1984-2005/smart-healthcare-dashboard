import { test, before, after, mock } from "node:test";
import assert from "node:assert";
import { mockAuth } from "./mockAuth.js";
import { resetDb, seedStaff, seedPatient, closeDb } from "./testDb.js";

mockAuth(mock);
const { default: request } = await import("supertest");
const { default: app } = await import("../app.js");

let adminUid, patientAUid, patientBUid, patientAId, patientBId, doctorUid;

before(async () => {
  await resetDb();
  adminUid = "firebase-admin-1";
  doctorUid = "firebase-doctor-1";
  patientAUid = "firebase-patient-a";
  patientBUid = "firebase-patient-b";
  await seedStaff({ role: "ADMIN", firebaseUid: adminUid });
  await seedStaff({ role: "DOCTOR", firebaseUid: doctorUid });
  patientAId = await seedPatient({ firebaseUid: patientAUid });
  patientBId = await seedPatient({ firebaseUid: patientBUid });
});

after(async () => {
  await closeDb();
});

test("unauthenticated request to /api/patients MUST NOT receive patient data", async () => {
  const res = await request(app).get("/api/patients");
  assert.strictEqual(res.status, 401);
  assert.strictEqual(res.body.success, false);
});

test("unauthenticated request to /api/patients/:id MUST NOT receive patient data", async () => {
  const res = await request(app).get(`/api/patients/${patientAId}`);
  assert.strictEqual(res.status, 401);
});

test("authenticated but unregistered Firebase user is rejected (identity resolution)", async () => {
  const res = await request(app)
    .get("/api/patients")
    .set("Authorization", "Bearer some-random-unregistered-uid");
  assert.strictEqual(res.status, 401);
});

test("admin (staff) can list patients", async () => {
  const res = await request(app).get("/api/patients").set("Authorization", `Bearer ${adminUid}`);
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.success, true);
  assert.ok(Array.isArray(res.body.patients));
});

test("patient role is forbidden from listing all patients (RBAC)", async () => {
  const res = await request(app).get("/api/patients").set("Authorization", `Bearer ${patientAUid}`);
  assert.strictEqual(res.status, 403);
});

test("Patient A cannot access Patient B's protected information", async () => {
  const res = await request(app)
    .get(`/api/patients/${patientBId}`)
    .set("Authorization", `Bearer ${patientAUid}`);
  assert.strictEqual(res.status, 403);
});

test("Patient A CAN access their own record", async () => {
  const res = await request(app)
    .get(`/api/patients/${patientAId}`)
    .set("Authorization", `Bearer ${patientAUid}`);
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.patient.id, patientAId);
});

test("doctor can read a patient record but cannot create a patient (RBAC boundary)", async () => {
  const readRes = await request(app)
    .get(`/api/patients/${patientAId}`)
    .set("Authorization", `Bearer ${doctorUid}`);
  assert.strictEqual(readRes.status, 200);

  const createRes = await request(app)
    .post("/api/patients")
    .set("Authorization", `Bearer ${doctorUid}`)
    .send({ firstName: "New", lastName: "Patient", dateOfBirth: "1995-01-01", phone: "5550111" });
  assert.strictEqual(createRes.status, 403);
});

test("admin can create a patient; validation rejects malformed payloads", async () => {
  const badRes = await request(app)
    .post("/api/patients")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ firstName: "" });
  assert.strictEqual(badRes.status, 400);
  assert.strictEqual(badRes.body.error.code, "VALIDATION_ERROR");

  const goodRes = await request(app)
    .post("/api/patients")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ firstName: "New", lastName: "Patient", dateOfBirth: "1995-01-01", phone: "5550111" });
  assert.strictEqual(goodRes.status, 201);
  assert.ok(goodRes.body.patient.id);
});

test("unknown route returns consistent 404 JSON shape, not a stack trace", async () => {
  const res = await request(app).get("/api/does-not-exist");
  assert.strictEqual(res.status, 404);
  assert.strictEqual(res.body.error.code, "NOT_FOUND");
});

test("database constraint violation surfaces as 409, not a raw DB error", async () => {
  // duplicate department code should violate a UNIQUE constraint
  await request(app)
    .post("/api/hospital/departments")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ name: "Cardiology", code: "CARD" });
  const res = await request(app)
    .post("/api/hospital/departments")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ name: "Cardiology 2", code: "CARD" });
  assert.strictEqual(res.status, 409);
  assert.strictEqual(res.body.error.code, "CONFLICT");
  assert.ok(!JSON.stringify(res.body).includes("duplicate key value")); // no raw DB error leaked
});
