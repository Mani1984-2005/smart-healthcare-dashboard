// Mocks middleware/authMiddleware.js so tests can simulate "a request from
// Firebase UID X" without needing a real Firebase project or valid ID
// tokens. Requires node's --experimental-test-module-mocks flag (see
// package.json test script).
//
// Usage in a test file:
//   import { mock } from "node:test";
//   import { mockAuth } from "./mockAuth.js";
//   mockAuth(mock);
//   // then send requests with header: Authorization: Bearer <any-uid>
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";

export function mockAuth(mock) {
  const target = pathToFileURL(resolve(import.meta.dirname, "../middleware/authMiddleware.js")).href;
  mock.module(target, {
    defaultExport: (req, res, next) => {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({ success: false, message: "Unauthorised: No Bearer token provided" });
      }
      const uid = authHeader.split("Bearer ")[1];
      req.user = { uid };
      next();
    },
  });
}
