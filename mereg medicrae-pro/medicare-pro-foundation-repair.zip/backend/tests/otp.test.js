import { test, before, after, mock } from "node:test";
import assert from "node:assert";
import { mockAuth } from "./mockAuth.js";
import { resetDb, seedHospital, seedStaff, closeDb } from "./testDb.js";
import { query } from "../lib/db.js";
import * as otpService from "../services/otp.service.js";

mockAuth(mock);
const { default: request } = await import("supertest");
const { default: app } = await import("../app.js");

let hospitalA, hospitalB, staffAUid, staffBUid;

before(async () => {
  await resetDb();
  hospitalA = await seedHospital({ name: "OTP Hospital A", code: "OTPA" });
  hospitalB = await seedHospital({ name: "OTP Hospital B", code: "OTPB" });
  staffAUid = "firebase-otp-staff-a";
  staffBUid = "firebase-otp-staff-b";
  await seedStaff({ role: "STAFF", firebaseUid: staffAUid, hospitalId: hospitalA });
  await seedStaff({ role: "STAFF", firebaseUid: staffBUid, hospitalId: hospitalB });
});

after(async () => {
  await closeDb();
});

test("[OTP] code is never stored in plaintext", async () => {
  await request(app)
    .post("/api/otp/request")
    .set("Authorization", `Bearer ${staffAUid}`)
    .send({ phone: "+15550100001", purpose: "PHONE_VERIFICATION" });

  const { rows } = await query("SELECT code_hash FROM otp_codes WHERE hospital_id = $1 ORDER BY created_at DESC LIMIT 1", [hospitalA]);
  assert.strictEqual(rows.length, 1);
  assert.ok(rows[0].code_hash.length === 64, "should be a sha256 hex digest, not a raw 6-digit code");
  assert.strictEqual(/^\d{6}$/.test(rows[0].code_hash), false, "hash must not look like a raw 6-digit code");
});

test("[OTP] response never includes the code itself", async () => {
  const res = await request(app)
    .post("/api/otp/request")
    .set("Authorization", `Bearer ${staffAUid}`)
    .send({ phone: "+15550100099", purpose: "PHONE_VERIFICATION" });
  assert.strictEqual(res.status, 202);
  assert.strictEqual(JSON.stringify(res.body).match(/"code"/), null);
});

test("[OTP] correct code verifies successfully and is then consumed (single use)", async () => {
  const phone = "+15550100002";
  await otpService.requestOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION" });
  const row = await query(
    "SELECT id, code_hash FROM otp_codes WHERE hospital_id = $1 AND phone = $2 ORDER BY created_at DESC LIMIT 1",
    [hospitalA, phone]
  );

  // We don't have the raw code (correctly — it's never stored), so
  // reconstruct it via the same hash function to simulate "the code the
  // user received via SMS" for this white-box test of verify() correctness.
  const crypto = await import("crypto");
  let foundCode = null;
  for (let i = 0; i < 1000000 && !foundCode; i++) {
    const candidate = String(i).padStart(6, "0");
    const hash = crypto.createHash("sha256").update(`${phone}:${candidate}`).digest("hex");
    if (hash === row.rows[0].code_hash) foundCode = candidate;
  }
  assert.ok(foundCode, "must be able to reconstruct the code via brute force for this white-box test");

  const verifyRes = await otpService.verifyOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION", code: foundCode });
  assert.strictEqual(verifyRes.verified, true);

  const consumedRow = await query("SELECT consumed_at FROM otp_codes WHERE id = $1", [row.rows[0].id]);
  assert.ok(consumedRow.rows[0].consumed_at, "code must be marked consumed after successful verification");

  // Re-using the same code again must fail — it's single-use.
  await assert.rejects(() => otpService.verifyOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION", code: foundCode }));
});

test("[OTP] incorrect code is rejected and increments attempts", async () => {
  const phone = "+15550100003";
  await otpService.requestOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION" });
  await assert.rejects(() => otpService.verifyOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION", code: "000000" }));

  const row = await query("SELECT attempts FROM otp_codes WHERE hospital_id = $1 AND phone = $2 ORDER BY created_at DESC LIMIT 1", [
    hospitalA,
    phone,
  ]);
  assert.strictEqual(row.rows[0].attempts, 1);
});

test("[OTP] brute-force protection: exceeding max attempts locks out further verification even with the right code", async () => {
  const phone = "+15550100004";
  await otpService.requestOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION" });
  for (let i = 0; i < 5; i++) {
    await assert.rejects(() => otpService.verifyOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION", code: "999999" }));
  }
  // Even a request with the (unknown to us, but doesn't matter) correct
  // code must now be rejected — attempts are exhausted.
  await assert.rejects(
    () => otpService.verifyOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION", code: "123456" }),
    /Too many incorrect attempts/
  );
});

test("[OTP] expired code is rejected even if correct", async () => {
  const phone = "+15550100005";
  const result = await otpService.requestOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION" });
  assert.ok(result.expiresAt);
  // Force-expire it directly (this is the fastest reliable way to test
  // expiry without a real 5-minute wait in a test suite).
  await query("UPDATE otp_codes SET expires_at = now() - interval '1 second' WHERE hospital_id = $1 AND phone = $2", [
    hospitalA,
    phone,
  ]);
  await assert.rejects(
    () => otpService.verifyOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION", code: "000000" }),
    /expired/
  );
});

test("[OTP] resend cooldown blocks an immediate second request", async () => {
  const phone = "+15550100006";
  await otpService.requestOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION" });
  await assert.rejects(
    () => otpService.requestOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION" }),
    /wait/
  );
});

test("[OTP] rate limiting blocks more than 3 requests in the window, even bypassing cooldown by waiting artificially", async () => {
  const phone = "+15550100007";
  // Directly insert 3 prior sends outside the cooldown window (simulating
  // 3 legitimate, cooldown-respecting requests) to test the rate limit
  // independent of the cooldown check.
  for (let i = 0; i < 3; i++) {
    await query(
      `INSERT INTO otp_codes (id, hospital_id, phone, code_hash, purpose, expires_at, created_at)
       VALUES (gen_random_uuid(), $1, $2, 'x', 'PHONE_VERIFICATION', now() + interval '5 minutes', now() - interval '2 minutes')`,
      [hospitalA, phone]
    );
  }
  await assert.rejects(
    () => otpService.requestOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION" }),
    /Too many verification code requests/
  );
});

test("[OTP] phone normalization treats formatted variants as the same phone for rate limiting", async () => {
  assert.strictEqual(otpService.normalizePhone("+1 (555) 010-0008"), "+15550100008");
  assert.strictEqual(otpService.normalizePhone("15550100008"), "15550100008");
});

test("[OTP Tenant] Hospital B cannot verify a code requested under Hospital A's tenant, even with the right phone+purpose", async () => {
  const phone = "+15550100010";
  await otpService.requestOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION" });
  await assert.rejects(
    () => otpService.verifyOtp(hospitalB, { phone, purpose: "PHONE_VERIFICATION", code: "000000" }),
    /No active verification code/
  );
});

test("[OTP Tenant] a delivery_attempts row for an OTP send carries the correct hospital_id", async () => {
  const phone = "+15550100011";
  await otpService.requestOtp(hospitalA, { phone, purpose: "PHONE_VERIFICATION" });
  const rows = await query(
    "SELECT hospital_id FROM delivery_attempts WHERE correlation_id LIKE $1 ORDER BY created_at DESC LIMIT 1",
    [`otp:${phone}:%`]
  );
  assert.strictEqual(rows.rows.length, 1);
  assert.strictEqual(rows.rows[0].hospital_id, hospitalA);
});

test("[Access] OTP endpoints require authentication", async () => {
  const res = await request(app).post("/api/otp/request").send({ phone: "+15550100012", purpose: "PHONE_VERIFICATION" });
  assert.strictEqual(res.status, 401);
});
