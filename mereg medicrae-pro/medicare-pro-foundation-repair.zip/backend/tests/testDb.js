// Test helper: seeds a minimal set of hospital/staff/patient rows into the
// local test database so RBAC/identity/tenant tests have real rows to
// resolve against.
import { randomUUID } from "crypto";
import { query, getPool } from "../lib/db.js";

// Fixed, well-known ID so existing tests that don't care about multi-tenancy
// (written before hospital/tenant isolation existed) keep working unchanged
// — they get a real, valid hospital_id without having to know or care about
// it. Tenant-isolation tests seed their OWN additional hospitals explicitly.
export const DEFAULT_HOSPITAL_ID = "00000000-0000-0000-0000-0000000000aa";

export async function resetDb() {
  await query(
    "TRUNCATE audit_logs, invoice_items, invoices, lab_orders, appointments, medicines, patients, staff, departments, hospitals RESTART IDENTITY CASCADE"
  );
  await query(`INSERT INTO hospitals (id, name, code) VALUES ($1, 'Test Hospital', 'TESTHOSP')`, [
    DEFAULT_HOSPITAL_ID,
  ]);
}

export async function seedHospital({ name, code } = {}) {
  const id = randomUUID();
  const suffix = id.slice(0, 8);
  await query(`INSERT INTO hospitals (id, name, code) VALUES ($1, $2, $3)`, [
    id,
    name ?? `Hospital ${suffix}`,
    code ?? `H${suffix}`.toUpperCase(),
  ]);
  return id;
}

export async function seedStaff({ role, firebaseUid, hospitalId = DEFAULT_HOSPITAL_ID }) {
  const id = randomUUID();
  await query(
    `INSERT INTO staff (id, hospital_id, staff_code, firebase_uid, name, email, role)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [id, hospitalId, `STF-${id.slice(0, 8)}`, firebaseUid, `Test ${role}`, `${id}@example.test`, role]
  );
  return id;
}

export async function seedPatient({ firebaseUid, hospitalId = DEFAULT_HOSPITAL_ID } = {}) {
  const id = randomUUID();
  await query(
    `INSERT INTO patients (id, hospital_id, patient_code, firebase_uid, first_name, last_name, date_of_birth, phone)
     VALUES ($1,$2,$3,$4,'Test','Patient','1990-01-01','5550100')`,
    [id, hospitalId, `PT-${id.slice(0, 8)}`, firebaseUid ?? null]
  );
  return id;
}

export async function closeDb() {
  // Deliberately does NOT call getPool().end() here. `node --test` can run
  // multiple test files in the same process, sharing the ESM module cache —
  // and therefore this module's singleton pool. Ending it in one file's
  // `after()` hook was closing the connection out from under other test
  // files running in the same process, causing spurious
  // "no PostgreSQL user name specified" failures. Letting the process exit
  // naturally cleans up connections; there's no per-file pool to close.
}
