import { test, before, after, mock } from "node:test";
import assert from "node:assert";
import { mockAuth } from "./mockAuth.js";
import { resetDb, seedHospital, seedStaff, seedPatient, closeDb } from "./testDb.js";
import { query } from "../lib/db.js";

mockAuth(mock);
const { default: request } = await import("supertest");
const { default: app } = await import("../app.js");

// Two separate hospitals, each with its own admin, and Hospital A additionally
// has a full set of records (patient, appointment, lab order, invoice,
// medicine, department, staff) that Hospital B must never be able to reach.
let hospitalA, hospitalB;
let adminAUid, adminBUid, doctorAUid;
let patientA, patientB;
let deptA, staffMemberA;
let appointmentA, labOrderA, invoiceA, medicineA;

before(async () => {
  await resetDb();

  hospitalA = await seedHospital({ name: "Hospital A", code: "HOSPA" });
  hospitalB = await seedHospital({ name: "Hospital B", code: "HOSPB" });

  adminAUid = "firebase-tenant-admin-a";
  adminBUid = "firebase-tenant-admin-b";
  doctorAUid = "firebase-tenant-doctor-a";

  await seedStaff({ role: "ADMIN", firebaseUid: adminAUid, hospitalId: hospitalA });
  await seedStaff({ role: "ADMIN", firebaseUid: adminBUid, hospitalId: hospitalB });
  await seedStaff({ role: "DOCTOR", firebaseUid: doctorAUid, hospitalId: hospitalA });

  patientA = await seedPatient({ hospitalId: hospitalA });
  patientB = await seedPatient({ hospitalId: hospitalB });

  // Build out a full record set inside Hospital A, all via the real API
  // (as Hospital A's own admin) so it exercises the same code paths an
  // attacker would use.
  const deptRes = await request(app)
    .post("/api/hospital/departments")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ name: "Cardiology", code: "CARD" });
  deptA = deptRes.body.department.id;

  const staffRes = await request(app)
    .post("/api/hospital/staff")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ staffCode: "STF-A-1", name: "Nurse A", email: "nurse.a@hospitala.test", role: "STAFF" });
  staffMemberA = staffRes.body.staff.id;

  const apptRes = await request(app)
    .post("/api/appointments")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, scheduledAt: "2026-11-01T09:00:00.000Z", reason: "Checkup" });
  appointmentA = apptRes.body.appointment.id;

  const labRes = await request(app)
    .post("/api/laboratory")
    .set("Authorization", `Bearer ${doctorAUid}`)
    .send({ patientId: patientA, testName: "Blood Panel" });
  labOrderA = labRes.body.labOrder.id;

  const invRes = await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, items: [{ serviceName: "Consultation", unitPrice: 100 }] });
  invoiceA = invRes.body.invoice.id;

  const medRes = await request(app)
    .post("/api/pharmacy/medicines")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ name: "Amoxicillin", category: "Antibiotic" });
  medicineA = medRes.body.medicine.id;
});

after(async () => {
  await closeDb();
});

// ---------------------------------------------------------------- Patients --

test("[Patients] Hospital B admin cannot list Hospital A's patients (list is tenant-filtered)", async () => {
  const res = await request(app).get("/api/patients").set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(res.status, 200);
  assert.ok(!res.body.patients.some((p) => p.id === patientA), "Hospital A's patient must not appear in Hospital B's list");
});

test("[Patients] Hospital B admin cannot read Hospital A's patient by ID (404, not data leak)", async () => {
  const res = await request(app).get(`/api/patients/${patientA}`).set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(res.status, 404);
  assert.strictEqual(res.body.patient, undefined);
});

test("[Patients] Hospital B admin cannot update Hospital A's patient (mutation blocked)", async () => {
  const res = await request(app)
    .put(`/api/patients/${patientA}`)
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ firstName: "Hijacked" });
  assert.strictEqual(res.status, 404);

  const row = await query("SELECT first_name FROM patients WHERE id = $1", [patientA]);
  assert.notStrictEqual(row.rows[0].first_name, "Hijacked", "cross-tenant update must not mutate the row");
});

test("[Patients] Hospital B admin cannot deactivate (soft-delete) Hospital A's patient", async () => {
  const res = await request(app).delete(`/api/patients/${patientA}`).set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(res.status, 404);

  const row = await query("SELECT is_active FROM patients WHERE id = $1", [patientA]);
  assert.strictEqual(row.rows[0].is_active, true, "cross-tenant delete must not mutate the row");
});

test("[Patients] Hospital A admin CAN still read/update their own patient (isolation must not break same-tenant access)", async () => {
  const readRes = await request(app).get(`/api/patients/${patientA}`).set("Authorization", `Bearer ${adminAUid}`);
  assert.strictEqual(readRes.status, 200);

  const updateRes = await request(app)
    .put(`/api/patients/${patientA}`)
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ firstName: "LegitimateUpdate" });
  assert.strictEqual(updateRes.status, 200);
  assert.strictEqual(updateRes.body.patient.firstName, "LegitimateUpdate");
});

// ------------------------------------------------------------- Appointments -

test("[Appointments] Hospital B admin cannot list or read Hospital A's appointment", async () => {
  const listRes = await request(app).get("/api/appointments").set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(listRes.status, 200);
  assert.ok(!listRes.body.appointments.some((a) => a.id === appointmentA));

  const getRes = await request(app).get(`/api/appointments/${appointmentA}`).set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(getRes.status, 404);
});

test("[Appointments] Hospital B admin cannot change status of Hospital A's appointment", async () => {
  const res = await request(app)
    .put(`/api/appointments/${appointmentA}/status`)
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ status: "CANCELLED" });
  assert.strictEqual(res.status, 404);

  const row = await query("SELECT status FROM appointments WHERE id = $1", [appointmentA]);
  assert.notStrictEqual(row.rows[0].status, "CANCELLED");
});

test("[Appointments] Hospital B admin CANNOT create an appointment referencing Hospital A's patient (cross-tenant entity link blocked)", async () => {
  const res = await request(app)
    .post("/api/appointments")
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ patientId: patientA, scheduledAt: "2026-11-02T09:00:00.000Z" });
  // Rejected because patientA does not belong to Hospital B — even though
  // adminB is a fully valid, correctly-scoped admin in their OWN hospital.
  assert.strictEqual(res.status, 404);
});

test("[Appointments] Hospital A admin CANNOT create an appointment for their own patient using a doctorId borrowed from Hospital B", async () => {
  const foreignDoctorRes = await request(app)
    .post("/api/hospital/staff")
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ staffCode: "STF-B-DOC", name: "Dr B", email: "dr.b@hospitalb.test", role: "DOCTOR" });
  const foreignDoctorId = foreignDoctorRes.body.staff.id;

  const res = await request(app)
    .post("/api/appointments")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, doctorId: foreignDoctorId, scheduledAt: "2026-11-03T09:00:00.000Z" });
  assert.strictEqual(res.status, 404, "a same-tenant-valid patient with a cross-tenant doctor must still be rejected");
});

// -------------------------------------------------------------- Laboratory --

test("[Laboratory] Hospital B admin cannot list, read, or update Hospital A's lab order", async () => {
  const listRes = await request(app).get("/api/laboratory").set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(listRes.status, 200);
  assert.ok(!listRes.body.labOrders.some((l) => l.id === labOrderA));

  const getRes = await request(app).get(`/api/laboratory/${labOrderA}`).set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(getRes.status, 404);

  const resultRes = await request(app)
    .put(`/api/laboratory/${labOrderA}/result`)
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ resultSummary: "Tampered result" });
  assert.strictEqual(resultRes.status, 404);

  const row = await query("SELECT result_summary FROM lab_orders WHERE id = $1", [labOrderA]);
  assert.notStrictEqual(row.rows[0].result_summary, "Tampered result");
});

test("[Laboratory] Hospital B admin cannot create a lab order for Hospital A's patient", async () => {
  const res = await request(app)
    .post("/api/laboratory")
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ patientId: patientA, testName: "Unauthorized Test" });
  assert.strictEqual(res.status, 404);
});

// ------------------------------------------------------------------ Billing --

test("[Billing] Hospital B admin cannot list, read, update, or void Hospital A's invoice", async () => {
  const listRes = await request(app).get("/api/billing/invoices").set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(listRes.status, 200);
  assert.ok(!listRes.body.invoices.some((i) => i.id === invoiceA));

  const getRes = await request(app).get(`/api/billing/invoices/${invoiceA}`).set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(getRes.status, 404);

  const updateRes = await request(app)
    .put(`/api/billing/invoices/${invoiceA}`)
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ status: "PAID" });
  assert.strictEqual(updateRes.status, 404);

  const voidRes = await request(app).delete(`/api/billing/invoices/${invoiceA}`).set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(voidRes.status, 404);

  const row = await query("SELECT status FROM invoices WHERE id = $1", [invoiceA]);
  assert.strictEqual(row.rows[0].status, "DRAFT", "cross-tenant mutation attempts must leave the invoice untouched");
});

test("[Billing] Hospital A's billing summary never includes Hospital B's invoices", async () => {
  await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ patientId: patientB, items: [{ serviceName: "Hospital B service", unitPrice: 9999 }] });

  const summaryA = await request(app).get("/api/billing/summary").set("Authorization", `Bearer ${adminAUid}`);
  assert.strictEqual(summaryA.status, 200);
  const draftEntry = summaryA.body.byStatus.find((s) => s.status === "DRAFT");
  // Hospital A has exactly one DRAFT invoice (invoiceA) at this point — if
  // Hospital B's 9999 invoice leaked in, the total would be far higher.
  assert.ok(draftEntry.total < 9999, "billing summary must not aggregate another hospital's invoice amounts");
});

test("[Billing] Hospital B admin cannot create an invoice for Hospital A's patient", async () => {
  const res = await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ patientId: patientA, items: [{ serviceName: "Unauthorized charge", unitPrice: 500 }] });
  assert.strictEqual(res.status, 404);
});

// -------------------------------------------------------------------- Staff --

test("[Staff] Hospital B admin cannot list, read, update, or delete Hospital A's staff/department", async () => {
  const listRes = await request(app).get("/api/hospital/staff").set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(listRes.status, 200);
  assert.ok(!listRes.body.staff.some((s) => s.id === staffMemberA));

  const getRes = await request(app).get(`/api/hospital/staff/${staffMemberA}`).set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(getRes.status, 404);

  const updateRes = await request(app)
    .put(`/api/hospital/staff/${staffMemberA}`)
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ name: "Hijacked Name" });
  assert.strictEqual(updateRes.status, 404);

  const deleteRes = await request(app).delete(`/api/hospital/staff/${staffMemberA}`).set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(deleteRes.status, 404);

  const deptListRes = await request(app).get("/api/hospital/departments").set("Authorization", `Bearer ${adminBUid}`);
  assert.ok(!deptListRes.body.departments.some((d) => d.id === deptA));

  const deptGetRes = await request(app).get(`/api/hospital/departments/${deptA}`).set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(deptGetRes.status, 404);

  const row = await query("SELECT name FROM staff WHERE id = $1", [staffMemberA]);
  assert.notStrictEqual(row.rows[0].name, "Hijacked Name");
});

test("[Staff] Hospital B admin cannot assign Hospital A's staff to a department (cross-tenant, either direction)", async () => {
  const res = await request(app)
    .post("/api/hospital/assign-staff")
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ staffId: staffMemberA, departmentId: deptA });
  assert.notStrictEqual(res.status, 200);
});

test("[Staff] Hospital A admin cannot set a department head to a staff member from Hospital B", async () => {
  const foreignStaffRes = await request(app)
    .post("/api/hospital/staff")
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ staffCode: "STF-B-2", name: "Foreign Staff", email: "foreign@hospitalb.test", role: "STAFF" });
  const foreignStaffId = foreignStaffRes.body.staff.id;

  const res = await request(app)
    .put(`/api/hospital/departments/${deptA}`)
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ headStaffId: foreignStaffId });
  assert.strictEqual(res.status, 404, "assigning a cross-tenant staff member as department head must be rejected");
});

// ------------------------------------------------------------------ Pharmacy --

test("[Pharmacy] Hospital B admin cannot list or read Hospital A's medicine catalog entry", async () => {
  const listRes = await request(app).get("/api/pharmacy/medicines").set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(listRes.status, 200);
  assert.ok(!listRes.body.medicines.some((m) => m.id === medicineA));

  const getRes = await request(app).get(`/api/pharmacy/medicines/${medicineA}`).set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(getRes.status, 404);
});

test("[Pharmacy] Hospital B admin cannot update or delete Hospital A's medicine", async () => {
  const updateRes = await request(app)
    .put(`/api/pharmacy/medicines/${medicineA}`)
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ name: "Tampered Medicine Name" });
  assert.strictEqual(updateRes.status, 404);

  const deleteRes = await request(app).delete(`/api/pharmacy/medicines/${medicineA}`).set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(deleteRes.status, 200); // pharmacyController returns 200 regardless (soft-delete semantics)

  const row = await query("SELECT name, is_active FROM medicines WHERE id = $1", [medicineA]);
  assert.notStrictEqual(row.rows[0].name, "Tampered Medicine Name");
  assert.strictEqual(row.rows[0].is_active, true, "cross-tenant delete must be a no-op, medicine must remain active");
});

test("[Pharmacy] Hospital A's low-stock and category views never include Hospital B's medicines", async () => {
  await request(app)
    .post("/api/pharmacy/medicines")
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ name: "HospitalB-Only-Medicine", category: "UNIQUE_CATEGORY_B", stock_qty: 1, reorder_level: 100 });

  const categoriesRes = await request(app).get("/api/pharmacy/categories").set("Authorization", `Bearer ${adminAUid}`);
  assert.ok(!categoriesRes.body.categories.includes("UNIQUE_CATEGORY_B"));

  const lowStockRes = await request(app).get("/api/pharmacy/medicines/low-stock").set("Authorization", `Bearer ${adminAUid}`);
  assert.ok(!lowStockRes.body.medicines.some((m) => m.name === "HospitalB-Only-Medicine"));
});

// --------------------------------------------------------- Full regression --

test("[Regression] Hospital A admin retains full normal access across every domain after all isolation checks", async () => {
  const patients = await request(app).get("/api/patients").set("Authorization", `Bearer ${adminAUid}`);
  assert.strictEqual(patients.status, 200);
  assert.ok(patients.body.patients.some((p) => p.id === patientA));

  const appts = await request(app).get("/api/appointments").set("Authorization", `Bearer ${adminAUid}`);
  assert.ok(appts.body.appointments.some((a) => a.id === appointmentA));

  const labs = await request(app).get("/api/laboratory").set("Authorization", `Bearer ${doctorAUid}`);
  assert.ok(labs.body.labOrders.some((l) => l.id === labOrderA));

  const invoices = await request(app).get("/api/billing/invoices").set("Authorization", `Bearer ${adminAUid}`);
  assert.ok(invoices.body.invoices.some((i) => i.id === invoiceA));

  const meds = await request(app).get("/api/pharmacy/medicines").set("Authorization", `Bearer ${adminAUid}`);
  assert.ok(meds.body.medicines.some((m) => m.id === medicineA));

  const staffList = await request(app).get("/api/hospital/staff").set("Authorization", `Bearer ${adminAUid}`);
  assert.ok(staffList.body.staff.some((s) => s.id === staffMemberA));
});
