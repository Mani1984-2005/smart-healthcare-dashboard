import { test, before, after, mock } from "node:test";
import assert from "node:assert";
import { mockAuth } from "./mockAuth.js";
import { resetDb, seedStaff, seedPatient, closeDb } from "./testDb.js";

mockAuth(mock);
const { default: request } = await import("supertest");
const { default: app } = await import("../app.js");

let adminUid, doctorUid, labUid, patientUid, patientId;

before(async () => {
  await resetDb();
  adminUid = "firebase-admin-2";
  doctorUid = "firebase-doctor-2";
  labUid = "firebase-lab-2";
  patientUid = "firebase-patient-2";
  await seedStaff({ role: "ADMIN", firebaseUid: adminUid });
  await seedStaff({ role: "DOCTOR", firebaseUid: doctorUid });
  await seedStaff({ role: "LAB", firebaseUid: labUid });
  patientId = await seedPatient({ firebaseUid: patientUid });
});

after(async () => {
  await closeDb();
});

// ---------------------------------------------------------------- Staff ----

test("admin can create and list staff", async () => {
  const createRes = await request(app)
    .post("/api/hospital/staff")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ staffCode: "STF-TEST-1", name: "Nurse Joy", email: "nurse.joy@medicarepro.test", role: "STAFF" });
  assert.strictEqual(createRes.status, 201);
  assert.strictEqual(createRes.body.staff.role, "STAFF");

  const listRes = await request(app).get("/api/hospital/staff").set("Authorization", `Bearer ${adminUid}`);
  assert.strictEqual(listRes.status, 200);
  assert.ok(listRes.body.staff.length >= 4); // 3 seeded + 1 created here
});

test("non-admin (doctor) is forbidden from the hospital admin routes", async () => {
  const res = await request(app).get("/api/hospital/staff").set("Authorization", `Bearer ${doctorUid}`);
  assert.strictEqual(res.status, 403);
});

test("creating staff with an invalid role is rejected, not silently accepted", async () => {
  const res = await request(app)
    .post("/api/hospital/staff")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ staffCode: "STF-BAD", name: "Bad Role", email: "bad.role@medicarepro.test", role: "SUPERUSER" });
  assert.strictEqual(res.status, 409);
});

// --------------------------------------------------------- Appointments ----

let appointmentId;

test("admin can create an appointment for a patient", async () => {
  const res = await request(app)
    .post("/api/appointments")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ patientId, scheduledAt: "2026-09-01T10:00:00.000Z", reason: "Annual checkup" });
  assert.strictEqual(res.status, 201);
  assert.strictEqual(res.body.appointment.status, "SCHEDULED");
  appointmentId = res.body.appointment.id;
});

test("patient role cannot create an appointment (RBAC)", async () => {
  const res = await request(app)
    .post("/api/appointments")
    .set("Authorization", `Bearer ${patientUid}`)
    .send({ patientId, scheduledAt: "2026-09-01T10:00:00.000Z" });
  assert.strictEqual(res.status, 403);
});

test("doctor can update appointment status", async () => {
  const res = await request(app)
    .put(`/api/appointments/${appointmentId}/status`)
    .set("Authorization", `Bearer ${doctorUid}`)
    .send({ status: "CONFIRMED" });
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.appointment.status, "CONFIRMED");
});

test("rescheduling requires a valid date/time (validation)", async () => {
  const res = await request(app)
    .put(`/api/appointments/${appointmentId}/reschedule`)
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ scheduledAt: "not-a-date" });
  assert.strictEqual(res.status, 400);
});

test("appointment can be listed filtered by patientId", async () => {
  const res = await request(app)
    .get(`/api/appointments?patientId=${patientId}`)
    .set("Authorization", `Bearer ${adminUid}`);
  assert.strictEqual(res.status, 200);
  assert.ok(res.body.appointments.length >= 1);
  assert.ok(res.body.appointments.every((a) => a.patientId === patientId));
});

// ------------------------------------------------------------- Laboratory --

let labOrderId;

test("lab staff can create a lab order", async () => {
  const res = await request(app)
    .post("/api/laboratory")
    .set("Authorization", `Bearer ${labUid}`)
    .send({ patientId, testName: "Complete Blood Count" });
  assert.strictEqual(res.status, 201);
  assert.strictEqual(res.body.labOrder.status, "ORDERED");
  labOrderId = res.body.labOrder.id;
});

test("billing role cannot create a lab order (RBAC)", async () => {
  const billingStaffUid = "firebase-billing-2";
  await seedStaff({ role: "BILLING", firebaseUid: billingStaffUid });
  const res = await request(app)
    .post("/api/laboratory")
    .set("Authorization", `Bearer ${billingStaffUid}`)
    .send({ patientId, testName: "Lipid Panel" });
  assert.strictEqual(res.status, 403);
});

test("recording a lab result moves status to RESULT_READY", async () => {
  const res = await request(app)
    .put(`/api/laboratory/${labOrderId}/result`)
    .set("Authorization", `Bearer ${labUid}`)
    .send({ resultSummary: "All values within normal range." });
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.labOrder.status, "RESULT_READY");
  assert.strictEqual(res.body.labOrder.resultSummary, "All values within normal range.");
});

test("empty resultSummary is rejected by validation", async () => {
  const res = await request(app)
    .put(`/api/laboratory/${labOrderId}/result`)
    .set("Authorization", `Bearer ${labUid}`)
    .send({ resultSummary: "" });
  assert.strictEqual(res.status, 400);
});

test("unknown lab order id returns 404, not a raw DB error", async () => {
  const res = await request(app)
    .get("/api/laboratory/00000000-0000-0000-0000-000000000000")
    .set("Authorization", `Bearer ${labUid}`);
  assert.strictEqual(res.status, 404);
  assert.strictEqual(res.body.error.code, "NOT_FOUND");
});
