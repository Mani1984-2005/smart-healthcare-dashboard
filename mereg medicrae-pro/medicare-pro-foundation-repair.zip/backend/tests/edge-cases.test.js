import { test, before, after, mock } from "node:test";
import assert from "node:assert";
import { mockAuth } from "./mockAuth.js";
import { resetDb, seedStaff, seedPatient, closeDb } from "./testDb.js";
import { query } from "../lib/db.js";

mockAuth(mock);
const { default: request } = await import("supertest");
const { default: app } = await import("../app.js");

let adminUid, patientId;

before(async () => {
  await resetDb();
  adminUid = "firebase-admin-3";
  await seedStaff({ role: "ADMIN", firebaseUid: adminUid });
  patientId = await seedPatient();
});

after(async () => {
  await closeDb();
});

// ------------------------------------------------------- Malformed input --

test("malformed JSON body returns 400 INVALID_JSON, not 500", async () => {
  const res = await request(app)
    .post("/api/patients")
    .set("Authorization", `Bearer ${adminUid}`)
    .set("Content-Type", "application/json")
    .send("{bad json");
  assert.strictEqual(res.status, 400);
  assert.strictEqual(res.body.error.code, "INVALID_JSON");
});

test("oversized JSON body returns 413, not 500", async () => {
  const res = await request(app)
    .post("/api/patients")
    .set("Authorization", `Bearer ${adminUid}`)
    .set("Content-Type", "application/json")
    .send({ firstName: "A".repeat(2_000_000) });
  assert.strictEqual(res.status, 413);
  assert.strictEqual(res.body.error.code, "PAYLOAD_TOO_LARGE");
});

test("invalid UUID in path param returns 400, not 500 or a raw DB error", async () => {
  const res = await request(app)
    .get("/api/patients/not-a-uuid")
    .set("Authorization", `Bearer ${adminUid}`);
  assert.strictEqual(res.status, 400);
  assert.strictEqual(res.body.error.code, "VALIDATION_ERROR");
});

test("unknown/well-formed-but-nonexistent UUID returns 404, not 500", async () => {
  const res = await request(app)
    .get("/api/patients/00000000-0000-0000-0000-000000000000")
    .set("Authorization", `Bearer ${adminUid}`);
  assert.strictEqual(res.status, 404);
});

// -------------------------------------------------------- SQL injection ---

test("SQL-injection-shaped search string is treated as a literal value, not executed", async () => {
  const res = await request(app)
    .get("/api/patients")
    .set("Authorization", `Bearer ${adminUid}`)
    .query({ search: "'; DROP TABLE patients; --" });
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.patients.length, 0); // no match, table untouched

  const stillExists = await query("SELECT to_regclass('public.patients') AS reg");
  assert.strictEqual(stillExists.rows[0].reg, "patients");
});

// -------------------------------------------------------- Mass assignment -

test("client-supplied id/role-like fields in create body are ignored (no mass assignment)", async () => {
  const forgedId = "11111111-1111-1111-1111-111111111111";
  const res = await request(app)
    .post("/api/patients")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({
      firstName: "Mass",
      lastName: "Assign",
      dateOfBirth: "1990-01-01",
      phone: "5559999",
      id: forgedId,
      role: "ADMIN",
      isActive: false, // also not a createPatientSchema field
    });
  assert.strictEqual(res.status, 201);
  assert.notStrictEqual(res.body.patient.id, forgedId, "server must generate its own id, not accept a client-supplied one");
  assert.strictEqual(res.body.patient.isActive, true, "unvalidated fields must not pass through to the insert");
});

// ---------------------------------------------------- Invalid enums/dates -

test("invalid appointment status enum value is rejected with 400, not silently accepted", async () => {
  const apptRes = await request(app)
    .post("/api/appointments")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ patientId, scheduledAt: "2026-10-01T09:00:00.000Z" });
  assert.strictEqual(apptRes.status, 201);

  const res = await request(app)
    .put(`/api/appointments/${apptRes.body.appointment.id}/status`)
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ status: "TOTALLY_NOT_A_STATUS" });
  assert.strictEqual(res.status, 400);
});

test("invalid date string for appointment scheduling is rejected with 400", async () => {
  const res = await request(app)
    .post("/api/appointments")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ patientId, scheduledAt: "not-a-real-date" });
  assert.strictEqual(res.status, 400);
});

// -------------------------------------------------- Invalid monetary data -

test("negative unit price on an invoice item is rejected with 400", async () => {
  const res = await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ patientId, items: [{ serviceName: "Consultation", unitPrice: -50 }] });
  assert.strictEqual(res.status, 400);
});

test("invoice with zero items is rejected with 400, not accepted as an empty invoice", async () => {
  const res = await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ patientId, items: [] });
  assert.strictEqual(res.status, 400);
});

test("invalid invoice status enum value is rejected", async () => {
  const createRes = await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ patientId, items: [{ serviceName: "Consultation", unitPrice: 100 }] });
  assert.strictEqual(createRes.status, 201);

  const res = await request(app)
    .put(`/api/billing/invoices/${createRes.body.invoice.id}`)
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ status: "NOT_A_REAL_STATUS" });
  assert.strictEqual(res.status, 400);
});

// ------------------------------------------------------------ Unexpected --

test("unexpected/extra fields in a valid request are silently stripped, not stored", async () => {
  const res = await request(app)
    .post("/api/patients")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({
      firstName: "Extra",
      lastName: "Fields",
      dateOfBirth: "1990-01-01",
      phone: "5551234",
      someRandomUnknownField: "should not persist",
    });
  assert.strictEqual(res.status, 201);
  assert.strictEqual(res.body.patient.someRandomUnknownField, undefined);
});

// -------------------------------------------------- Referential integrity -

test("deleting a staff member who heads a department fails safely (409), not an unhandled 500", async () => {
  const deptRes = await request(app)
    .post("/api/hospital/departments")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ name: "Radiology", code: "RAD" });
  assert.strictEqual(deptRes.status, 201);

  const staffRes = await request(app)
    .post("/api/hospital/staff")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ staffCode: "STF-HEAD-1", name: "Dr Head", email: "dr.head@medicarepro.test", role: "DOCTOR" });
  assert.strictEqual(staffRes.status, 201);

  const assignHeadRes = await request(app)
    .put(`/api/hospital/departments/${deptRes.body.department.id}`)
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ headStaffId: staffRes.body.staff.id });
  assert.strictEqual(assignHeadRes.status, 200);

  const deleteRes = await request(app)
    .delete(`/api/hospital/staff/${staffRes.body.staff.id}`)
    .set("Authorization", `Bearer ${adminUid}`);
  // The real question this test asks: does the server crash (500) or handle
  // the FK constraint cleanly? Either a clean 409 (blocked, correct) or a
  // 200 (if the service nulls the reference first) is acceptable — a 500 is
  // not.
  assert.notStrictEqual(deleteRes.status, 500);
});

// ------------------------------------------- Previously-untested routes ---

test("GET /auth/me returns the caller's own decoded identity, not another user's", async () => {
  const res = await request(app).get("/api/auth/me").set("Authorization", `Bearer ${adminUid}`);
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.user.uid, adminUid);
});

test("PUT /patients/:id updates allowed fields only", async () => {
  const createRes = await request(app)
    .post("/api/patients")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ firstName: "Before", lastName: "Update", dateOfBirth: "1990-01-01", phone: "5550001" });
  const id = createRes.body.patient.id;

  const updateRes = await request(app)
    .put(`/api/patients/${id}`)
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ firstName: "After" });
  assert.strictEqual(updateRes.status, 200);
  assert.strictEqual(updateRes.body.patient.firstName, "After");
  assert.strictEqual(updateRes.body.patient.lastName, "Update"); // untouched field preserved
});

test("DELETE /patients/:id is admin-only and soft-deletes (is_active=false), not a hard delete", async () => {
  const createRes = await request(app)
    .post("/api/patients")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ firstName: "ToDeactivate", lastName: "X", dateOfBirth: "1990-01-01", phone: "5550002" });
  const id = createRes.body.patient.id;

  const staffUid = "firebase-staff-for-delete-test";
  await seedStaff({ role: "STAFF", firebaseUid: staffUid });
  const forbiddenRes = await request(app).delete(`/api/patients/${id}`).set("Authorization", `Bearer ${staffUid}`);
  assert.strictEqual(forbiddenRes.status, 403);

  const deleteRes = await request(app).delete(`/api/patients/${id}`).set("Authorization", `Bearer ${adminUid}`);
  assert.strictEqual(deleteRes.status, 200);

  const row = await query("SELECT is_active FROM patients WHERE id = $1", [id]);
  assert.strictEqual(row.rows[0].is_active, false);
  assert.strictEqual(row.rows.length, 1, "soft-delete must not hard-delete the row");
});

test("GET /billing/summary returns aggregate counts grouped by status", async () => {
  await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ patientId, items: [{ serviceName: "Summary Test", unitPrice: 100 }] });

  const res = await request(app).get("/api/billing/summary").set("Authorization", `Bearer ${adminUid}`);
  assert.strictEqual(res.status, 200);
  assert.ok(Array.isArray(res.body.byStatus));
  assert.ok(res.body.byStatus.some((s) => s.status === "DRAFT" && s.count >= 1));
});

test("DELETE /billing/invoices/:id voids the invoice rather than deleting the row", async () => {
  const createRes = await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminUid}`)
    .send({ patientId, items: [{ serviceName: "Void Test", unitPrice: 100 }] });
  const id = createRes.body.invoice.id;

  const res = await request(app).delete(`/api/billing/invoices/${id}`).set("Authorization", `Bearer ${adminUid}`);
  assert.strictEqual(res.status, 200);

  const row = await query("SELECT status FROM invoices WHERE id = $1", [id]);
  assert.strictEqual(row.rows[0].status, "VOID");
  assert.strictEqual(row.rows.length, 1);
});

test("Pharmacy medicine catalog: admin can create, list, and read a medicine; DOCTOR cannot create", async () => {
  const pharmacyUid = "firebase-pharmacy-1";
  await seedStaff({ role: "PHARMACY", firebaseUid: pharmacyUid });
  const doctorUidLocal = "firebase-doctor-pharmacy-test";
  await seedStaff({ role: "DOCTOR", firebaseUid: doctorUidLocal });

  const createRes = await request(app)
    .post("/api/pharmacy/medicines")
    .set("Authorization", `Bearer ${pharmacyUid}`)
    .send({ name: "Paracetamol", category: "Analgesic", unit_price: 5, stock_qty: 100 });
  assert.strictEqual(createRes.status, 201);

  const forbiddenRes = await request(app)
    .post("/api/pharmacy/medicines")
    .set("Authorization", `Bearer ${doctorUidLocal}`)
    .send({ name: "Ibuprofen" });
  assert.strictEqual(forbiddenRes.status, 403);

  const listRes = await request(app).get("/api/pharmacy/medicines").set("Authorization", `Bearer ${doctorUidLocal}`);
  assert.strictEqual(listRes.status, 200);
});

test("Pharmacy medicine catalog is unreachable without authentication", async () => {
  const res = await request(app).get("/api/pharmacy/medicines");
  assert.strictEqual(res.status, 401);
});
