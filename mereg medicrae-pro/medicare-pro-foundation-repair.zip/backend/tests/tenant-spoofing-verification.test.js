import { test, before, after, mock } from "node:test";
import assert from "node:assert";
import { mockAuth } from "./mockAuth.js";
import { resetDb, seedHospital, seedStaff, seedPatient, closeDb } from "./testDb.js";
import { query } from "../lib/db.js";

mockAuth(mock);
const { default: request } = await import("supertest");
const { default: app } = await import("../app.js");

let hospitalA, hospitalB, adminAUid, patientA;

before(async () => {
  await resetDb();
  hospitalA = await seedHospital({ name: "Spoof Test Hospital A", code: "SPOOFA" });
  hospitalB = await seedHospital({ name: "Spoof Test Hospital B", code: "SPOOFB" });
  adminAUid = "firebase-spoof-admin-a";
  await seedStaff({ role: "ADMIN", firebaseUid: adminAUid, hospitalId: hospitalA });
  patientA = await seedPatient({ hospitalId: hospitalA });
});

after(async () => {
  await closeDb();
});

test("[Spoof] hospitalId in request BODY is ignored on patient create", async () => {
  const res = await request(app)
    .post("/api/patients")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({
      firstName: "Spoofed",
      lastName: "Body",
      dateOfBirth: "1990-01-01",
      phone: "5551000",
      hospitalId: hospitalB, // attacker tries to plant this row in Hospital B
    });
  assert.strictEqual(res.status, 201);
  const row = await query("SELECT hospital_id FROM patients WHERE id = $1", [res.body.patient.id]);
  assert.strictEqual(row.rows[0].hospital_id, hospitalA, "server must ignore client-supplied hospitalId and use the caller's own");
});

test("[Spoof] hospitalId in QUERY STRING does not change which hospital's patients are listed", async () => {
  const res = await request(app)
    .get("/api/patients")
    .set("Authorization", `Bearer ${adminAUid}`)
    .query({ hospitalId: hospitalB, search: "" });
  assert.strictEqual(res.status, 200);
  // Every returned patient must still belong to Hospital A (the caller's
  // real, server-resolved tenant) regardless of the query string.
  const ids = res.body.patients.map((p) => p.id);
  assert.ok(ids.includes(patientA), "Hospital A's own patient must still be visible");
  const rows = await query("SELECT id FROM patients WHERE hospital_id = $1", [hospitalB]);
  const hospitalBPatientIds = rows.rows.map((r) => r.id);
  assert.ok(!ids.some((id) => hospitalBPatientIds.includes(id)), "no Hospital B patient may appear");
});

test("[Spoof] X-Hospital-Id / X-Tenant-Id custom headers are not honored", async () => {
  const res = await request(app)
    .get("/api/patients")
    .set("Authorization", `Bearer ${adminAUid}`)
    .set("X-Hospital-Id", hospitalB)
    .set("X-Tenant-Id", hospitalB);
  assert.strictEqual(res.status, 200);
  // If custom headers were honored, this admin (a real Hospital A admin)
  // would either error out (identity mismatch) or start seeing Hospital B
  // data. Neither should happen — the response must be identical to a
  // request without those headers: Hospital A's own data only.
  const ids = res.body.patients.map((p) => p.id);
  assert.ok(ids.includes(patientA));
});

test("[Spoof] hospitalId as a URL path segment has no route and cannot be used to select a tenant", async () => {
  // Confirms there is no alternate, tenant-selecting route shape like
  // /api/hospitals/:hospitalId/patients that would let a hospitalId in the
  // URL itself pick the tenant.
  const res = await request(app)
    .get(`/api/hospitals/${hospitalB}/patients`)
    .set("Authorization", `Bearer ${adminAUid}`);
  assert.strictEqual(res.status, 404);
});

test("[Spoof] a forged custom JWT-shaped claim in req.user (simulated) is never read for tenant scoping", async () => {
  // resolveIdentity.js reads ONLY req.user.uid (verified by static analysis:
  // zero other req.user.* references exist in the codebase). This test
  // proves it dynamically: even if the decoded token carried extra fields
  // an attacker fully controls (which Firebase's own verifyIdToken would
  // never allow for another user's token, but we test the code's behavior
  // regardless of that upstream guarantee), the app must still resolve
  // hospitalId from the database row, not from the token payload. Our
  // mockAuth sets req.user = { uid }, i.e. NO other claims at all — if the
  // app secretly depended on e.g. req.user.hospitalId, this request would
  // fail with an error (undefined.hospitalId) rather than succeed
  // correctly scoped. It succeeds, which proves the token payload is not
  // where hospitalId comes from.
  const res = await request(app).get(`/api/patients/${patientA}`).set("Authorization", `Bearer ${adminAUid}`);
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.patient.id, patientA);
});

test("[Spoof] a user cannot change their effective hospital by re-sending requests with a different hospital's real staff firebaseUid they don't own", async () => {
  // This isn't really "changing your own hospital" (impossible by design,
  // since hospitalId isn't client input at all) — it's the adjacent check:
  // does presenting SOMEONE ELSE's uid (which requires forging their
  // Firebase token, i.e. is exactly what Firebase token verification
  // exists to prevent) let you assume their hospital? Verified at the
  // authentication layer, not the tenant layer: an invalid/unowned token
  // is rejected before resolveIdentity or any hospital logic ever runs.
  const res = await request(app).get("/api/patients").set("Authorization", "Bearer not-a-real-signed-token");
  // (mockAuth intercepts this in tests, but exercises the same code path
  // real Firebase verification failure would: identity never resolves to
  // anyone, hospital is never determined, request is rejected.)
  assert.notStrictEqual(res.status, 200);
});
