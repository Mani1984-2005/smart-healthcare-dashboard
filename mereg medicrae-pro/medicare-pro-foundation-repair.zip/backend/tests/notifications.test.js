import { test, before, after, mock } from "node:test";
import assert from "node:assert";
import { mockAuth } from "./mockAuth.js";
import { resetDb, seedHospital, seedStaff, seedPatient, closeDb } from "./testDb.js";
import { query } from "../lib/db.js";

mockAuth(mock);
const { default: request } = await import("supertest");
const { default: app } = await import("../app.js");

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

let hospitalA, hospitalB;
let adminAUid, doctorAUid, adminBUid;
let patientAUid, patientA;

before(async () => {
  await resetDb();
  hospitalA = await seedHospital({ name: "Notif Hospital A", code: "NOTIFA" });
  hospitalB = await seedHospital({ name: "Notif Hospital B", code: "NOTIFB" });

  adminAUid = "firebase-notif-admin-a";
  doctorAUid = "firebase-notif-doctor-a";
  adminBUid = "firebase-notif-admin-b";
  patientAUid = "firebase-notif-patient-a";

  await seedStaff({ role: "ADMIN", firebaseUid: adminAUid, hospitalId: hospitalA });
  await seedStaff({ role: "DOCTOR", firebaseUid: doctorAUid, hospitalId: hospitalA });
  await seedStaff({ role: "ADMIN", firebaseUid: adminBUid, hospitalId: hospitalB });

  // Only a patient with a firebase_uid (a portal identity) is eligible to
  // receive a patient-addressed notification — patientA has one, so the
  // resolver in notification.service.js should pick them up.
  patientA = await seedPatient({ firebaseUid: patientAUid, hospitalId: hospitalA });
});

after(async () => {
  await closeDb();
});

// ------------------------------------------------------------ End-to-end --

test("[E2E] updating an appointment's status creates a notification for the assigned doctor and the patient", async () => {
  const apptRes = await request(app)
    .post("/api/appointments")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, scheduledAt: "2026-12-01T09:00:00.000Z" });
  const apptId = apptRes.body.appointment.id;

  const doctorRow = await query("SELECT id FROM staff WHERE firebase_uid = $1", [doctorAUid]);
  const doctorId = doctorRow.rows[0].id;

  await request(app)
    .put(`/api/appointments/${apptId}/status`)
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ status: "CONFIRMED" });

  // No doctor was assigned on create, so re-run with a doctor assigned via
  // a second appointment to exercise the doctor-recipient path too.
  const apptRes2 = await request(app)
    .post("/api/appointments")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, doctorId, scheduledAt: "2026-12-02T09:00:00.000Z" });
  const apptId2 = apptRes2.body.appointment.id;

  await request(app)
    .put(`/api/appointments/${apptId2}/status`)
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ status: "CONFIRMED" });
  await wait(200);

  const patientNotifs = await request(app)
    .get("/api/notifications")
    .set("Authorization", `Bearer ${patientAUid}`);
  assert.strictEqual(patientNotifs.status, 200);
  assert.ok(
    patientNotifs.body.notifications.some((n) => n.eventType === "appointment.status_changed" && n.resourceId === apptId2),
    "patient must receive a notification for their own appointment status change"
  );

  const doctorNotifs = await request(app)
    .get("/api/notifications")
    .set("Authorization", `Bearer ${doctorAUid}`);
  assert.ok(
    doctorNotifs.body.notifications.some((n) => n.eventType === "appointment.status_changed" && n.resourceId === apptId2),
    "the assigned doctor must receive a notification when their appointment's status changes"
  );
});

test("[E2E] recording a lab result creates a notification for the handling staff member and the patient", async () => {
  const labRes = await request(app)
    .post("/api/laboratory")
    .set("Authorization", `Bearer ${doctorAUid}`)
    .send({ patientId: patientA, testName: "Metabolic Panel" });
  const labId = labRes.body.labOrder.id;

  await request(app)
    .put(`/api/laboratory/${labId}/result`)
    .set("Authorization", `Bearer ${doctorAUid}`)
    .send({ resultSummary: "Normal" });
  await wait(200);

  const patientNotifs = await request(app).get("/api/notifications").set("Authorization", `Bearer ${patientAUid}`);
  assert.ok(patientNotifs.body.notifications.some((n) => n.eventType === "lab_order.result_ready" && n.resourceId === labId));
});

test("[E2E] creating an invoice notifies the patient", async () => {
  const invRes = await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, items: [{ serviceName: "Consultation", unitPrice: 150 }] });
  await wait(200);

  const patientNotifs = await request(app).get("/api/notifications").set("Authorization", `Bearer ${patientAUid}`);
  assert.ok(
    patientNotifs.body.notifications.some(
      (n) => n.eventType === "invoice.created" && n.resourceId === invRes.body.invoice.id
    )
  );
});

test("[E2E] mark-as-read updates is_read and is reflected on next list", async () => {
  const invRes = await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, items: [{ serviceName: "Follow-up", unitPrice: 50 }] });
  await wait(200);

  const listRes = await request(app).get("/api/notifications").set("Authorization", `Bearer ${patientAUid}`);
  const notif = listRes.body.notifications.find((n) => n.resourceId === invRes.body.invoice.id);
  assert.ok(notif);
  assert.strictEqual(notif.isRead, false);

  const markRes = await request(app)
    .patch(`/api/notifications/${notif.id}/read`)
    .set("Authorization", `Bearer ${patientAUid}`);
  assert.strictEqual(markRes.status, 200);
  assert.strictEqual(markRes.body.notification.isRead, true);

  const unreadOnly = await request(app)
    .get("/api/notifications")
    .set("Authorization", `Bearer ${patientAUid}`)
    .query({ unreadOnly: true });
  assert.ok(!unreadOnly.body.notifications.some((n) => n.id === notif.id));
});

// ------------------------------------------------------- Tenant isolation --

test("[Tenant] Hospital B's admin never receives a notification generated by Hospital A's activity", async () => {
  await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, items: [{ serviceName: "Cross-tenant check", unitPrice: 999 }] });
  await wait(200);

  const bNotifs = await request(app).get("/api/notifications").set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(bNotifs.status, 200);
  assert.strictEqual(bNotifs.body.notifications.length, 0, "Hospital B admin must see zero notifications from Hospital A's activity");
});

test("[Tenant] a notification row's hospital_id always matches the event's real hospital, verified in the database directly", async () => {
  const invRes = await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, items: [{ serviceName: "DB-level check", unitPrice: 10 }] });
  await wait(200);

  const rows = await query("SELECT hospital_id FROM notifications WHERE resource_id = $1", [invRes.body.invoice.id]);
  assert.ok(rows.rows.length > 0);
  assert.ok(rows.rows.every((r) => r.hospital_id === hospitalA));
});

test("[Tenant] a Hospital B admin cannot mark a Hospital A notification as read by guessing its ID", async () => {
  const invRes = await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, items: [{ serviceName: "Guess ID check", unitPrice: 10 }] });
  await wait(200);

  const patientNotifs = await request(app).get("/api/notifications").set("Authorization", `Bearer ${patientAUid}`);
  const notif = patientNotifs.body.notifications.find((n) => n.resourceId === invRes.body.invoice.id);
  assert.ok(notif);

  const res = await request(app)
    .patch(`/api/notifications/${notif.id}/read`)
    .set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(res.status, 404);

  const row = await query("SELECT is_read FROM notifications WHERE id = $1", [notif.id]);
  assert.strictEqual(row.rows[0].is_read, false, "cross-tenant mark-as-read must not mutate the row");
});

// ---------------------------------------------------- Recipient isolation --

test("[Recipient] Patient B never sees a notification addressed to Patient A, even within the same hospital", async () => {
  const patientBUid = "firebase-notif-patient-b";
  await seedPatient({ firebaseUid: patientBUid, hospitalId: hospitalA });

  await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, items: [{ serviceName: "Recipient isolation check", unitPrice: 25 }] });
  await wait(200);

  const patientBNotifs = await request(app).get("/api/notifications").set("Authorization", `Bearer ${patientBUid}`);
  assert.strictEqual(patientBNotifs.status, 200);
  assert.strictEqual(
    patientBNotifs.body.notifications.filter((n) => n.eventType === "invoice.created").length,
    0,
    "Patient B must not see a notification generated for Patient A's invoice"
  );
});

test("[Recipient] a patient with no portal identity (no firebaseUid) generates no orphaned notification", async () => {
  const noPortalPatientId = await seedPatient({ hospitalId: hospitalA }); // no firebaseUid
  const invRes = await request(app)
    .post("/api/billing/invoices")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: noPortalPatientId, items: [{ serviceName: "No portal", unitPrice: 5 }] });
  await wait(200);

  const rows = await query("SELECT * FROM notifications WHERE resource_id = $1", [invRes.body.invoice.id]);
  assert.strictEqual(rows.rows.length, 0, "a patient with no portal identity has nowhere to deliver an in-app notification");
});

// ------------------------------------------------------------------ RBAC --

test("[Access] notifications endpoint requires authentication like every other route", async () => {
  const res = await request(app).get("/api/notifications");
  assert.strictEqual(res.status, 401);
});
