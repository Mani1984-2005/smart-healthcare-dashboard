import { test, before, after, mock } from "node:test";
import assert from "node:assert";
import { mockAuth } from "./mockAuth.js";
import { resetDb, seedHospital, seedStaff, seedPatient, closeDb } from "./testDb.js";
import { query } from "../lib/db.js";
import * as consentService from "../services/consent.service.js";

mockAuth(mock);
const { default: request } = await import("supertest");
const { default: app } = await import("../app.js");

let hospitalA, hospitalB, adminAUid, adminBUid, patientA, appointmentA;

before(async () => {
  await resetDb();
  hospitalA = await seedHospital({ name: "Tele Hospital A", code: "TELEA" });
  hospitalB = await seedHospital({ name: "Tele Hospital B", code: "TELEB" });
  adminAUid = "firebase-tele-admin-a";
  adminBUid = "firebase-tele-admin-b";
  await seedStaff({ role: "ADMIN", firebaseUid: adminAUid, hospitalId: hospitalA });
  await seedStaff({ role: "ADMIN", firebaseUid: adminBUid, hospitalId: hospitalB });
  patientA = await seedPatient({ hospitalId: hospitalA });

  const apptRes = await request(app)
    .post("/api/appointments")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, scheduledAt: "2026-12-15T09:00:00.000Z" });
  appointmentA = apptRes.body.appointment.id;
});

after(async () => {
  await closeDb();
});

test("[Telemedicine] session creation is blocked without prior consent", async () => {
  const res = await request(app)
    .post("/api/telemedicine/sessions")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ appointmentId: appointmentA });
  assert.strictEqual(res.status, 400);
  assert.ok(/consent/i.test(res.body.error.message));
});

test("[Telemedicine] session creation succeeds once consent is granted, and returns a link with a token not equal to any stored value", async () => {
  await consentService.grantConsent(hospitalA, { type: "staff", id: null, role: "ADMIN" }, {
    patientId: patientA,
    purpose: "TELEMEDICINE",
  });

  const res = await request(app)
    .post("/api/telemedicine/sessions")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ appointmentId: appointmentA });
  assert.strictEqual(res.status, 201);
  assert.ok(res.body.link.includes(res.body.session.id));
  assert.strictEqual(res.body.session.status, "PENDING");

  const row = await query("SELECT token_hash FROM consultation_sessions WHERE id = $1", [res.body.session.id]);
  assert.ok(!res.body.link.includes(row.rows[0].token_hash), "the raw token in the link must not equal the stored hash");
});

test("[Telemedicine] token stored is a hash, not plaintext", async () => {
  const row = await query("SELECT token_hash FROM consultation_sessions ORDER BY created_at DESC LIMIT 1");
  assert.strictEqual(row.rows[0].token_hash.length, 64); // sha256 hex digest
});

let sessionId, rawToken;

test("[Telemedicine] a valid token successfully validates the session", async () => {
  await consentService.grantConsent(hospitalA, { type: "staff", id: null, role: "ADMIN" }, {
    patientId: patientA,
    purpose: "TELEMEDICINE",
  });
  const createRes = await request(app)
    .post("/api/telemedicine/sessions")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ appointmentId: appointmentA });
  sessionId = createRes.body.session.id;
  rawToken = new URL(createRes.body.link).searchParams.get("token");

  const validateRes = await request(app)
    .post(`/api/telemedicine/sessions/${sessionId}/validate`)
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ token: rawToken });
  assert.strictEqual(validateRes.status, 200);
});

test("[Telemedicine] an incorrect token is rejected (unauthorized access prevention)", async () => {
  const res = await request(app)
    .post(`/api/telemedicine/sessions/${sessionId}/validate`)
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ token: "0".repeat(64) });
  assert.strictEqual(res.status, 403);
});

test("[Telemedicine] an expired link is rejected even with the correct token", async () => {
  await query("UPDATE consultation_sessions SET expires_at = now() - interval '1 second' WHERE id = $1", [sessionId]);
  const res = await request(app)
    .post(`/api/telemedicine/sessions/${sessionId}/validate`)
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ token: rawToken });
  assert.strictEqual(res.status, 403);
  assert.ok(/expired/i.test(res.body.error.message));
});

test("[Telemedicine] start/end lifecycle transitions correctly", async () => {
  await consentService.grantConsent(hospitalA, { type: "staff", id: null, role: "ADMIN" }, {
    patientId: patientA,
    purpose: "TELEMEDICINE",
  });
  const createRes = await request(app)
    .post("/api/telemedicine/sessions")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ appointmentId: appointmentA });
  const id = createRes.body.session.id;

  const startRes = await request(app).post(`/api/telemedicine/sessions/${id}/start`).set("Authorization", `Bearer ${adminAUid}`);
  assert.strictEqual(startRes.status, 200);
  assert.strictEqual(startRes.body.session.status, "ACTIVE");

  const endRes = await request(app).post(`/api/telemedicine/sessions/${id}/end`).set("Authorization", `Bearer ${adminAUid}`);
  assert.strictEqual(endRes.status, 200);
  assert.strictEqual(endRes.body.session.status, "ENDED");

  // Cannot start an already-ended session again.
  const restartRes = await request(app).post(`/api/telemedicine/sessions/${id}/start`).set("Authorization", `Bearer ${adminAUid}`);
  assert.strictEqual(restartRes.status, 404);
});

test("[Telemedicine Tenant] Hospital B cannot create a session for Hospital A's appointment", async () => {
  await consentService.grantConsent(hospitalA, { type: "staff", id: null, role: "ADMIN" }, {
    patientId: patientA,
    purpose: "TELEMEDICINE",
  });
  const res = await request(app)
    .post("/api/telemedicine/sessions")
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ appointmentId: appointmentA });
  assert.strictEqual(res.status, 404);
});

test("[Telemedicine Tenant] Hospital B cannot validate a token for a session created under Hospital A, even with the correct raw token", async () => {
  const createRes = await request(app)
    .post("/api/telemedicine/sessions")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ appointmentId: appointmentA });
  const id = createRes.body.session.id;
  const token = new URL(createRes.body.link).searchParams.get("token");

  const res = await request(app)
    .post(`/api/telemedicine/sessions/${id}/validate`)
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ token });
  assert.strictEqual(res.status, 403, "the correct token must still fail validation outside its own tenant scope");
});

test("[Telemedicine] no medical information appears in the queued SMS message body", async () => {
  const { renderTemplate } = await import("../services/messageTemplates.js");
  const body = renderTemplate("telemedicine.link_ready", { link: "https://medicarepro.example/consult/abc?token=xyz" });
  assert.ok(!/diagnos|medicat|potassium|lab result|prescription/i.test(body));
  assert.ok(body.includes("https://"));
});
