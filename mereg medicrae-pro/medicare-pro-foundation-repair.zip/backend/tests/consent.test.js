import { test, before, after, mock } from "node:test";
import assert from "node:assert";
import { mockAuth } from "./mockAuth.js";
import { resetDb, seedHospital, seedStaff, seedPatient, closeDb } from "./testDb.js";
import { query } from "../lib/db.js";

mockAuth(mock);
const { default: request } = await import("supertest");
const { default: app } = await import("../app.js");

let hospitalA, hospitalB, adminAUid, adminBUid, patientA;

before(async () => {
  await resetDb();
  hospitalA = await seedHospital({ name: "Consent Hospital A", code: "CONSA" });
  hospitalB = await seedHospital({ name: "Consent Hospital B", code: "CONSB" });
  adminAUid = "firebase-consent-admin-a";
  adminBUid = "firebase-consent-admin-b";
  await seedStaff({ role: "ADMIN", firebaseUid: adminAUid, hospitalId: hospitalA });
  await seedStaff({ role: "ADMIN", firebaseUid: adminBUid, hospitalId: hospitalB });
  patientA = await seedPatient({ hospitalId: hospitalA });
});

after(async () => {
  await closeDb();
});

test("[Consent] granting consent records purpose, patient, status, timestamp, and version", async () => {
  const res = await request(app)
    .post("/api/consent/grant")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, purpose: "TELEMEDICINE" });
  assert.strictEqual(res.status, 201);
  assert.strictEqual(res.body.consent.status, "GRANTED");
  assert.strictEqual(res.body.consent.purpose, "TELEMEDICINE");
  assert.strictEqual(res.body.consent.version, 1);
  assert.ok(res.body.consent.createdAt);
});

test("[Consent] is auditable — an audit_logs row exists for the grant", async () => {
  const rows = await query(
    "SELECT * FROM audit_logs WHERE action = 'CONSENT_GRANTED' AND hospital_id = $1 ORDER BY created_at DESC LIMIT 1",
    [hospitalA]
  );
  assert.strictEqual(rows.rows.length, 1);
  assert.strictEqual(rows.rows[0].outcome, "success");
});

test("[Consent] revoking increments version and is auditable", async () => {
  const res = await request(app)
    .post("/api/consent/revoke")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, purpose: "TELEMEDICINE" });
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.consent.status, "REVOKED");

  const auditRows = await query("SELECT * FROM audit_logs WHERE action = 'CONSENT_REVOKED' AND hospital_id = $1", [hospitalA]);
  assert.strictEqual(auditRows.rows.length, 1);
});

test("[Consent] re-granting after revocation creates a new version, not a mutation of the old one", async () => {
  await request(app)
    .post("/api/consent/grant")
    .set("Authorization", `Bearer ${adminAUid}`)
    .send({ patientId: patientA, purpose: "TELEMEDICINE" });
  const rows = await query(
    "SELECT version, status FROM consents WHERE hospital_id = $1 AND patient_id = $2 AND purpose = 'TELEMEDICINE' ORDER BY version",
    [hospitalA, patientA]
  );
  assert.strictEqual(rows.rows.length, 2); // v1 (granted, then revoked via UPDATE) + v2 (new grant row)
  assert.strictEqual(rows.rows[0].version, 1);
  assert.strictEqual(rows.rows[0].status, "REVOKED");
  assert.strictEqual(rows.rows[1].version, 2);
  assert.strictEqual(rows.rows[1].status, "GRANTED");
});

test("[Consent Tenant] Hospital B admin cannot grant/revoke/read consent for Hospital A's patient", async () => {
  const grantRes = await request(app)
    .post("/api/consent/grant")
    .set("Authorization", `Bearer ${adminBUid}`)
    .send({ patientId: patientA, purpose: "SMS_COMMUNICATION" });
  assert.strictEqual(grantRes.status, 404);

  const listRes = await request(app)
    .get(`/api/consent/patient/${patientA}`)
    .set("Authorization", `Bearer ${adminBUid}`);
  assert.strictEqual(listRes.status, 404, "cross-tenant read must return 404 (patient not found in this hospital), matching every other cross-entity check in this codebase");
});

test("[Consent] patient can grant/view their own consent", async () => {
  const patientBUid = "firebase-consent-patient-self";
  const selfPatientId = await seedPatient({ firebaseUid: patientBUid, hospitalId: hospitalA });

  const grantRes = await request(app)
    .post("/api/consent/grant")
    .set("Authorization", `Bearer ${patientBUid}`)
    .send({ patientId: selfPatientId, purpose: "SMS_COMMUNICATION" });
  assert.strictEqual(grantRes.status, 201);

  const listRes = await request(app)
    .get(`/api/consent/patient/${selfPatientId}`)
    .set("Authorization", `Bearer ${patientBUid}`);
  assert.strictEqual(listRes.status, 200);
});

test("[Consent] patient cannot grant consent on behalf of another patient", async () => {
  const otherPatient = await seedPatient({ hospitalId: hospitalA });
  const attackerUid = "firebase-consent-attacker";
  await seedPatient({ firebaseUid: attackerUid, hospitalId: hospitalA });

  const res = await request(app)
    .post("/api/consent/grant")
    .set("Authorization", `Bearer ${attackerUid}`)
    .send({ patientId: otherPatient, purpose: "SMS_COMMUNICATION" });
  assert.strictEqual(res.status, 403);
});
