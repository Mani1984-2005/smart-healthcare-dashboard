// Local development / test seed ONLY. Never run automatically against a
// staging or production database — there is no safeguard here beyond this
// comment, so wire this into CI/CD deliberately, not by default.
//
// Updated for hospital/tenant isolation: seeds one demo hospital and scopes
// every row to it, since hospital_id is now NOT NULL everywhere.
import { randomUUID } from "crypto";
import { query, getPool } from "../lib/db.js";

async function seed() {
  const hospitalId = randomUUID();
  await query(
    `INSERT INTO hospitals (id, name, code)
     VALUES ($1, 'MediCare Pro Demo Hospital', 'DEMO')
     ON CONFLICT (code) DO NOTHING`,
    [hospitalId]
  );
  // ON CONFLICT DO NOTHING means a re-run won't tell us the real id if the
  // hospital already existed — look it up either way so the rest of the
  // seed is scoped correctly on repeat runs.
  const { rows: hospitalRows } = await query(`SELECT id FROM hospitals WHERE code = 'DEMO'`);
  const resolvedHospitalId = hospitalRows[0].id;

  const departmentId = randomUUID();
  await query(
    `INSERT INTO departments (id, hospital_id, name, code, description)
     VALUES ($1, $2, 'General Medicine', 'GENMED', 'Default seed department')
     ON CONFLICT (hospital_id, code) DO NOTHING`,
    [departmentId, resolvedHospitalId]
  );

  const roles = ["ADMIN", "DOCTOR", "STAFF", "LAB", "PHARMACY", "BILLING", "MANAGEMENT"];
  for (const role of roles) {
    await query(
      `INSERT INTO staff (id, hospital_id, staff_code, name, email, role, department_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (hospital_id, email) DO NOTHING`,
      [
        randomUUID(),
        resolvedHospitalId,
        `SEED-${role}`,
        `Seed ${role}`,
        `seed.${role.toLowerCase()}@medicarepro.test`,
        role,
        departmentId,
      ]
    );
  }

  await query(
    `INSERT INTO patients (id, hospital_id, patient_code, first_name, last_name, date_of_birth, phone)
     VALUES ($1, $2, 'SEED-PT-001', 'Demo', 'Patient', '1990-01-01', '5550100')
     ON CONFLICT (hospital_id, patient_code) DO NOTHING`,
    [randomUUID(), resolvedHospitalId]
  );

  // eslint-disable-next-line no-console
  console.log("Seed complete: 1 hospital, 1 department, 7 staff (one per role), 1 demo patient.");
}

seed()
  .catch((err) => {
    // eslint-disable-next-line no-console
    console.error("Seed failed:", err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await getPool().end();
  });
