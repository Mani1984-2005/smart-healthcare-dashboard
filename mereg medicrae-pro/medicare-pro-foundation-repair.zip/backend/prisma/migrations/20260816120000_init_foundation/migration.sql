-- MediCare Pro Foundation Repair — initial schema
-- Hand-authored to match backend/prisma/schema.prisma exactly (see that file's
-- header comment for why `prisma migrate dev` could not generate this in the
-- sandbox). Applied and verified against a local PostgreSQL 16 instance.

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TYPE "Role" AS ENUM ('ADMIN', 'DOCTOR', 'STAFF', 'LAB', 'PHARMACY', 'BILLING', 'MANAGEMENT', 'PATIENT');
CREATE TYPE "AppointmentStatus" AS ENUM ('SCHEDULED', 'CONFIRMED', 'CHECKED_IN', 'COMPLETED', 'CANCELLED', 'NO_SHOW');
CREATE TYPE "InvoiceStatus" AS ENUM ('DRAFT', 'ISSUED', 'PAID', 'PARTIALLY_PAID', 'VOID');
CREATE TYPE "LabOrderStatus" AS ENUM ('ORDERED', 'COLLECTED', 'PROCESSING', 'RESULT_READY', 'REVIEWED', 'REJECTED');

CREATE TABLE "departments" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "name" TEXT NOT NULL UNIQUE,
  "code" TEXT NOT NULL UNIQUE,
  "description" TEXT,
  "floor" TEXT,
  "head_staff_id" UUID,
  "is_active" BOOLEAN NOT NULL DEFAULT TRUE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE "staff" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "staff_code" TEXT NOT NULL UNIQUE,
  "firebase_uid" TEXT UNIQUE,
  "name" TEXT NOT NULL,
  "email" TEXT NOT NULL UNIQUE,
  "role" "Role" NOT NULL,
  "department_id" UUID REFERENCES "departments"("id"),
  "is_active" BOOLEAN NOT NULL DEFAULT TRUE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE "departments"
  ADD CONSTRAINT "departments_head_staff_id_fkey"
  FOREIGN KEY ("head_staff_id") REFERENCES "staff"("id");

CREATE TABLE "patients" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "patient_code" TEXT NOT NULL UNIQUE,
  "firebase_uid" TEXT UNIQUE,
  "first_name" TEXT NOT NULL,
  "last_name" TEXT NOT NULL,
  "date_of_birth" DATE NOT NULL,
  "gender" TEXT,
  "phone" TEXT NOT NULL,
  "email" TEXT,
  "emergency_contact_name" TEXT,
  "emergency_contact_phone" TEXT,
  "is_active" BOOLEAN NOT NULL DEFAULT TRUE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX "patients_last_name_first_name_idx" ON "patients" ("last_name", "first_name");

-- Matches the pre-existing backend/models/Medicine.js schema exactly (adopted,
-- not redesigned). NOTE (fixed during the Foundation Final Verification Gate
-- audit): the first version of this migration incorrectly added NOT NULL to
-- unit_price/stock_qty/reorder_level/requires_rx/is_active. Medicine.js's own
-- create() explicitly inserts `undefined` (-> SQL NULL) for any field the
-- caller omits, which bypasses a column DEFAULT — Medicine.js's own
-- createTable() therefore declares these columns nullable-with-default, not
-- NOT NULL. The stricter version silently broke createMedicine() for any
-- caller that omits stock_qty/reorder_level/etc, which pharmacyController's
-- own createMedicine handler does. Relaxed to match Medicine.js exactly.
CREATE TABLE "medicines" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "generic_name" TEXT,
  "brand" TEXT,
  "category" TEXT,
  "form" TEXT,
  "strength" TEXT,
  "manufacturer" TEXT,
  "unit_price" DECIMAL(10,2) DEFAULT 0,
  "stock_qty" INTEGER DEFAULT 0,
  "reorder_level" INTEGER DEFAULT 10,
  "requires_rx" BOOLEAN DEFAULT TRUE,
  "description" TEXT,
  "side_effects" TEXT,
  "contraindications" TEXT,
  "is_active" BOOLEAN DEFAULT TRUE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX "idx_medicines_name" ON "medicines" USING GIN (to_tsvector('english', "name"));
CREATE INDEX "idx_medicines_category" ON "medicines" ("category");
CREATE INDEX "idx_medicines_is_active" ON "medicines" ("is_active");

CREATE TABLE "appointments" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "patient_id" UUID NOT NULL REFERENCES "patients"("id"),
  "doctor_id" UUID REFERENCES "staff"("id"),
  "department_id" UUID,
  "scheduled_at" TIMESTAMPTZ NOT NULL,
  "status" "AppointmentStatus" NOT NULL DEFAULT 'SCHEDULED',
  "reason" TEXT,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX "appointments_patient_id_idx" ON "appointments" ("patient_id");
CREATE INDEX "appointments_doctor_id_scheduled_at_idx" ON "appointments" ("doctor_id", "scheduled_at");

CREATE TABLE "lab_orders" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "order_code" TEXT NOT NULL UNIQUE,
  "patient_id" UUID NOT NULL REFERENCES "patients"("id"),
  "appointment_id" UUID REFERENCES "appointments"("id"),
  "handled_by_id" UUID REFERENCES "staff"("id"),
  "test_name" TEXT NOT NULL,
  "status" "LabOrderStatus" NOT NULL DEFAULT 'ORDERED',
  "result_summary" TEXT,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX "lab_orders_patient_id_idx" ON "lab_orders" ("patient_id");

CREATE TABLE "invoices" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "invoice_code" TEXT NOT NULL UNIQUE,
  "patient_id" UUID NOT NULL REFERENCES "patients"("id"),
  "status" "InvoiceStatus" NOT NULL DEFAULT 'DRAFT',
  "total_amount" DECIMAL(10,2) NOT NULL DEFAULT 0,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX "invoices_patient_id_idx" ON "invoices" ("patient_id");

CREATE TABLE "invoice_items" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "invoice_id" UUID NOT NULL REFERENCES "invoices"("id") ON DELETE CASCADE,
  "service_name" TEXT NOT NULL,
  "category" TEXT NOT NULL DEFAULT 'Other',
  "quantity" INTEGER NOT NULL DEFAULT 1,
  "unit_price" DECIMAL(10,2) NOT NULL,
  "amount" DECIMAL(10,2) NOT NULL
);

CREATE TABLE "audit_logs" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "actor_staff_id" UUID REFERENCES "staff"("id"),
  "actor_role" TEXT,
  "action" TEXT NOT NULL,
  "resource_type" TEXT NOT NULL,
  "resource_id" TEXT,
  "outcome" TEXT NOT NULL,
  "request_id" TEXT,
  "ip" TEXT,
  "metadata" JSONB,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX "audit_logs_resource_type_resource_id_idx" ON "audit_logs" ("resource_type", "resource_id");
CREATE INDEX "audit_logs_actor_staff_id_idx" ON "audit_logs" ("actor_staff_id");
