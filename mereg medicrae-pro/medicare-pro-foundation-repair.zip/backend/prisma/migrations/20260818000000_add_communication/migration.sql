-- MediCare Pro — Notifications Final: external communication foundation
-- Additive migration. Applied and verified against a local PostgreSQL 16
-- instance in this session.

ALTER TABLE "notification_events" ADD COLUMN "priority" TEXT NOT NULL DEFAULT 'NORMAL';

-- Staff had no phone number column — needed for SMS/WhatsApp delivery to
-- staff (e.g. a doctor notified of an appointment change). Nullable: not
-- every staff member needs external notification.
ALTER TABLE "staff" ADD COLUMN "phone" TEXT;

CREATE TABLE "delivery_attempts" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "hospital_id" UUID NOT NULL REFERENCES "hospitals"("id"),
  "event_id" UUID REFERENCES "notification_events"("id"),
  "recipient_type" TEXT NOT NULL,
  "recipient_staff_id" UUID REFERENCES "staff"("id"),
  "recipient_patient_id" UUID REFERENCES "patients"("id"),
  "channel" TEXT NOT NULL,
  "provider" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'QUEUED',
  "error" TEXT,
  "correlation_id" TEXT NOT NULL,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX "idx_delivery_attempts_hospital_id" ON "delivery_attempts" ("hospital_id");
CREATE INDEX "idx_delivery_attempts_correlation_id" ON "delivery_attempts" ("correlation_id");
CREATE INDEX "idx_delivery_attempts_event_id" ON "delivery_attempts" ("event_id");

-- OTP codes are stored HASHED, never plaintext. phone is stored normalized
-- (E.164-ish, digits with leading +) so rate-limiting/lookup is consistent.
CREATE TABLE "otp_codes" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "hospital_id" UUID NOT NULL REFERENCES "hospitals"("id"),
  "phone" TEXT NOT NULL,
  "code_hash" TEXT NOT NULL,
  "purpose" TEXT NOT NULL,
  "attempts" INTEGER NOT NULL DEFAULT 0,
  "max_attempts" INTEGER NOT NULL DEFAULT 5,
  "expires_at" TIMESTAMPTZ NOT NULL,
  "consumed_at" TIMESTAMPTZ,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX "idx_otp_codes_hospital_phone" ON "otp_codes" ("hospital_id", "phone", "created_at" DESC);

-- Consultation link tokens are stored HASHED (same reasoning as OTP) — the
-- raw token is only ever returned once, at creation, to be embedded in the
-- SMS/WhatsApp link. Validating an incoming token hashes it and compares.
CREATE TABLE "consultation_sessions" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "hospital_id" UUID NOT NULL REFERENCES "hospitals"("id"),
  "appointment_id" UUID NOT NULL REFERENCES "appointments"("id"),
  "token_hash" TEXT NOT NULL UNIQUE,
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "expires_at" TIMESTAMPTZ NOT NULL,
  "started_at" TIMESTAMPTZ,
  "ended_at" TIMESTAMPTZ,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX "idx_consultation_sessions_hospital_id" ON "consultation_sessions" ("hospital_id");
CREATE INDEX "idx_consultation_sessions_appointment_id" ON "consultation_sessions" ("appointment_id");

CREATE TABLE "consents" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "hospital_id" UUID NOT NULL REFERENCES "hospitals"("id"),
  "patient_id" UUID NOT NULL REFERENCES "patients"("id"),
  "purpose" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'GRANTED',
  "version" INTEGER NOT NULL DEFAULT 1,
  "related_event_type" TEXT,
  "related_event_id" TEXT,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX "idx_consents_hospital_patient_purpose" ON "consents" ("hospital_id", "patient_id", "purpose");
