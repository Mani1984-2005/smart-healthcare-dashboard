-- MediCare Pro — Hospital/Tenant Isolation
-- Additive migration (does not modify or replace 20260816120000_init_foundation).
-- Applied and verified against a local PostgreSQL 16 instance in this session.
--
-- Approach: add hospital_id as NULLABLE first, backfill every existing row to
-- a bootstrap "Default Hospital", THEN set NOT NULL + FK. This mirrors what a
-- real migration against populated production data would have to do — a
-- straight `ADD COLUMN ... NOT NULL` with no default would fail outright on
-- any table with existing rows.

CREATE TABLE "hospitals" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "name" TEXT NOT NULL,
  "code" TEXT NOT NULL UNIQUE,
  "is_active" BOOLEAN NOT NULL DEFAULT TRUE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Bootstrap hospital so pre-existing rows (from before tenancy existed) have
-- somewhere to belong. In a real deployment with real multi-hospital data,
-- an operator would instead run a deliberate backfill mapping existing rows
-- to their real hospitals — this default is a safe, honest fallback for a
-- single-tenant history, not a claim that it's the "correct" assignment.
INSERT INTO "hospitals" ("id", "name", "code")
VALUES ('00000000-0000-0000-0000-000000000001', 'Default Hospital', 'DEFAULT');

-- --- staff -------------------------------------------------------------
ALTER TABLE "staff" ADD COLUMN "hospital_id" UUID;
UPDATE "staff" SET "hospital_id" = '00000000-0000-0000-0000-000000000001' WHERE "hospital_id" IS NULL;
ALTER TABLE "staff" ALTER COLUMN "hospital_id" SET NOT NULL;
ALTER TABLE "staff" ADD CONSTRAINT "staff_hospital_id_fkey" FOREIGN KEY ("hospital_id") REFERENCES "hospitals"("id");
-- staff_code/email were globally UNIQUE before; now scoped per hospital.
ALTER TABLE "staff" DROP CONSTRAINT IF EXISTS "staff_staff_code_key";
ALTER TABLE "staff" DROP CONSTRAINT IF EXISTS "staff_email_key";
ALTER TABLE "staff" ADD CONSTRAINT "staff_hospital_id_staff_code_key" UNIQUE ("hospital_id", "staff_code");
ALTER TABLE "staff" ADD CONSTRAINT "staff_hospital_id_email_key" UNIQUE ("hospital_id", "email");
CREATE INDEX "idx_staff_hospital_id" ON "staff" ("hospital_id");

-- --- departments ---------------------------------------------------------
ALTER TABLE "departments" ADD COLUMN "hospital_id" UUID;
UPDATE "departments" SET "hospital_id" = '00000000-0000-0000-0000-000000000001' WHERE "hospital_id" IS NULL;
ALTER TABLE "departments" ALTER COLUMN "hospital_id" SET NOT NULL;
ALTER TABLE "departments" ADD CONSTRAINT "departments_hospital_id_fkey" FOREIGN KEY ("hospital_id") REFERENCES "hospitals"("id");
ALTER TABLE "departments" DROP CONSTRAINT IF EXISTS "departments_name_key";
ALTER TABLE "departments" DROP CONSTRAINT IF EXISTS "departments_code_key";
ALTER TABLE "departments" ADD CONSTRAINT "departments_hospital_id_name_key" UNIQUE ("hospital_id", "name");
ALTER TABLE "departments" ADD CONSTRAINT "departments_hospital_id_code_key" UNIQUE ("hospital_id", "code");
CREATE INDEX "idx_departments_hospital_id" ON "departments" ("hospital_id");

-- --- patients --------------------------------------------------------------
ALTER TABLE "patients" ADD COLUMN "hospital_id" UUID;
UPDATE "patients" SET "hospital_id" = '00000000-0000-0000-0000-000000000001' WHERE "hospital_id" IS NULL;
ALTER TABLE "patients" ALTER COLUMN "hospital_id" SET NOT NULL;
ALTER TABLE "patients" ADD CONSTRAINT "patients_hospital_id_fkey" FOREIGN KEY ("hospital_id") REFERENCES "hospitals"("id");
ALTER TABLE "patients" DROP CONSTRAINT IF EXISTS "patients_patient_code_key";
ALTER TABLE "patients" ADD CONSTRAINT "patients_hospital_id_patient_code_key" UNIQUE ("hospital_id", "patient_code");
DROP INDEX IF EXISTS "patients_last_name_first_name_idx";
CREATE INDEX "idx_patients_hospital_id_name" ON "patients" ("hospital_id", "last_name", "first_name");

-- --- medicines ---------------------------------------------------------
ALTER TABLE "medicines" ADD COLUMN "hospital_id" UUID;
UPDATE "medicines" SET "hospital_id" = '00000000-0000-0000-0000-000000000001' WHERE "hospital_id" IS NULL;
ALTER TABLE "medicines" ALTER COLUMN "hospital_id" SET NOT NULL;
ALTER TABLE "medicines" ADD CONSTRAINT "medicines_hospital_id_fkey" FOREIGN KEY ("hospital_id") REFERENCES "hospitals"("id");
CREATE INDEX "idx_medicines_hospital_id" ON "medicines" ("hospital_id");

-- --- appointments --------------------------------------------------------
ALTER TABLE "appointments" ADD COLUMN "hospital_id" UUID;
UPDATE "appointments" SET "hospital_id" = '00000000-0000-0000-0000-000000000001' WHERE "hospital_id" IS NULL;
ALTER TABLE "appointments" ALTER COLUMN "hospital_id" SET NOT NULL;
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_hospital_id_fkey" FOREIGN KEY ("hospital_id") REFERENCES "hospitals"("id");
DROP INDEX IF EXISTS "appointments_patient_id_idx";
DROP INDEX IF EXISTS "appointments_doctor_id_scheduled_at_idx";
CREATE INDEX "idx_appointments_hospital_id_patient_id" ON "appointments" ("hospital_id", "patient_id");
CREATE INDEX "idx_appointments_hospital_id_doctor_id_scheduled_at" ON "appointments" ("hospital_id", "doctor_id", "scheduled_at");

-- --- lab_orders ----------------------------------------------------------
ALTER TABLE "lab_orders" ADD COLUMN "hospital_id" UUID;
UPDATE "lab_orders" SET "hospital_id" = '00000000-0000-0000-0000-000000000001' WHERE "hospital_id" IS NULL;
ALTER TABLE "lab_orders" ALTER COLUMN "hospital_id" SET NOT NULL;
ALTER TABLE "lab_orders" ADD CONSTRAINT "lab_orders_hospital_id_fkey" FOREIGN KEY ("hospital_id") REFERENCES "hospitals"("id");
ALTER TABLE "lab_orders" DROP CONSTRAINT IF EXISTS "lab_orders_order_code_key";
ALTER TABLE "lab_orders" ADD CONSTRAINT "lab_orders_hospital_id_order_code_key" UNIQUE ("hospital_id", "order_code");
DROP INDEX IF EXISTS "lab_orders_patient_id_idx";
CREATE INDEX "idx_lab_orders_hospital_id_patient_id" ON "lab_orders" ("hospital_id", "patient_id");

-- --- invoices ------------------------------------------------------------
ALTER TABLE "invoices" ADD COLUMN "hospital_id" UUID;
UPDATE "invoices" SET "hospital_id" = '00000000-0000-0000-0000-000000000001' WHERE "hospital_id" IS NULL;
ALTER TABLE "invoices" ALTER COLUMN "hospital_id" SET NOT NULL;
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_hospital_id_fkey" FOREIGN KEY ("hospital_id") REFERENCES "hospitals"("id");
ALTER TABLE "invoices" DROP CONSTRAINT IF EXISTS "invoices_invoice_code_key";
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_hospital_id_invoice_code_key" UNIQUE ("hospital_id", "invoice_code");
DROP INDEX IF EXISTS "invoices_patient_id_idx";
CREATE INDEX "idx_invoices_hospital_id_patient_id" ON "invoices" ("hospital_id", "patient_id");

-- --- audit_logs (nullable — see schema.prisma comment) --------------------
ALTER TABLE "audit_logs" ADD COLUMN "hospital_id" UUID REFERENCES "hospitals"("id");
CREATE INDEX "idx_audit_logs_hospital_id" ON "audit_logs" ("hospital_id");
