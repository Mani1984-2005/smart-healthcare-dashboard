-- MediCare Pro — Notifications Phase 1 (event outbox + in-app delivery)
-- Additive migration. Does not modify prior migrations. Applied and
-- verified against a local PostgreSQL 16 instance in this session.

CREATE TABLE "notification_events" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "hospital_id" UUID NOT NULL REFERENCES "hospitals"("id"),
  "event_type" TEXT NOT NULL,
  "resource_type" TEXT NOT NULL,
  "resource_id" TEXT NOT NULL,
  "payload" JSONB,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "processed_at" TIMESTAMPTZ
);
CREATE INDEX "idx_notification_events_hospital_id" ON "notification_events" ("hospital_id");
CREATE INDEX "idx_notification_events_processed_at" ON "notification_events" ("processed_at") WHERE "processed_at" IS NULL;

CREATE TABLE "notifications" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "hospital_id" UUID NOT NULL REFERENCES "hospitals"("id"),
  "recipient_staff_id" UUID REFERENCES "staff"("id"),
  "recipient_patient_id" UUID REFERENCES "patients"("id"),
  "event_type" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "body" TEXT,
  "resource_type" TEXT NOT NULL,
  "resource_id" TEXT NOT NULL,
  "is_read" BOOLEAN NOT NULL DEFAULT FALSE,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT "notifications_exactly_one_recipient" CHECK (
    (("recipient_staff_id" IS NOT NULL)::int + ("recipient_patient_id" IS NOT NULL)::int) = 1
  )
);
CREATE INDEX "idx_notifications_hospital_staff" ON "notifications" ("hospital_id", "recipient_staff_id", "created_at" DESC);
CREATE INDEX "idx_notifications_hospital_patient" ON "notifications" ("hospital_id", "recipient_patient_id", "created_at" DESC);
