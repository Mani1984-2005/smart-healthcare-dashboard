import * as appointmentService from "../services/appointment.service.js";

export async function list(req, res, next) {
  try {
    const result = await appointmentService.listAppointments(req.identity.hospitalId, req.query);
    res.json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
}

export async function getById(req, res, next) {
  try {
    const appointment = await appointmentService.getAppointmentById(req.identity.hospitalId, req.params.id);
    res.json({ success: true, appointment });
  } catch (err) {
    next(err);
  }
}

export async function create(req, res, next) {
  try {
    const appointment = await appointmentService.createAppointment(req.identity.hospitalId, req.body);
    res.status(201).json({ success: true, appointment });
  } catch (err) {
    next(err);
  }
}

export async function updateStatus(req, res, next) {
  try {
    const appointment = await appointmentService.updateAppointmentStatus(
      req.identity.hospitalId,
      req.params.id,
      req.body.status
    );
    res.json({ success: true, appointment });
  } catch (err) {
    next(err);
  }
}

export async function reschedule(req, res, next) {
  try {
    const appointment = await appointmentService.rescheduleAppointment(
      req.identity.hospitalId,
      req.params.id,
      req.body.scheduledAt
    );
    res.json({ success: true, appointment });
  } catch (err) {
    next(err);
  }
}
