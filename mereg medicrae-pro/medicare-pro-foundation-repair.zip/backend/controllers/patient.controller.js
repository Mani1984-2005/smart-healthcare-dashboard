import * as patientService from "../services/patient.service.js";

// hospitalId comes ONLY from req.identity (set by resolveIdentity from a
// server-side DB lookup) — never from req.body/req.query/req.params.
export async function list(req, res, next) {
  try {
    const result = await patientService.listPatients(req.identity.hospitalId, req.query);
    res.json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
}

export async function getById(req, res, next) {
  try {
    const patient = await patientService.getPatientById(req.identity.hospitalId, req.params.id);
    res.json({ success: true, patient });
  } catch (err) {
    next(err);
  }
}

export async function create(req, res, next) {
  try {
    const patient = await patientService.createPatient(req.identity.hospitalId, req.body);
    res.status(201).json({ success: true, patient });
  } catch (err) {
    next(err);
  }
}

export async function update(req, res, next) {
  try {
    const patient = await patientService.updatePatient(req.identity.hospitalId, req.params.id, req.body);
    res.json({ success: true, patient });
  } catch (err) {
    next(err);
  }
}

export async function deactivate(req, res, next) {
  try {
    await patientService.deactivatePatient(req.identity.hospitalId, req.params.id);
    res.json({ success: true, message: "Patient deactivated" });
  } catch (err) {
    next(err);
  }
}
