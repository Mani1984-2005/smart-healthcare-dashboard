import * as consentService from "../services/consent.service.js";

export async function grant(req, res, next) {
  try {
    const consent = await consentService.grantConsent(req.identity.hospitalId, req.identity, req.body);
    res.status(201).json({ success: true, consent });
  } catch (err) {
    next(err);
  }
}

export async function revoke(req, res, next) {
  try {
    const consent = await consentService.revokeConsent(req.identity.hospitalId, req.identity, req.body);
    res.json({ success: true, consent });
  } catch (err) {
    next(err);
  }
}

export async function listForPatient(req, res, next) {
  try {
    const consents = await consentService.listConsentsForPatient(req.identity.hospitalId, req.params.patientId);
    res.json({ success: true, consents });
  } catch (err) {
    next(err);
  }
}
