import * as labService from "../services/laboratory.service.js";

export async function list(req, res, next) {
  try {
    const result = await labService.listLabOrders(req.identity.hospitalId, req.query);
    res.json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
}

export async function getById(req, res, next) {
  try {
    const labOrder = await labService.getLabOrderById(req.identity.hospitalId, req.params.id);
    res.json({ success: true, labOrder });
  } catch (err) {
    next(err);
  }
}

export async function create(req, res, next) {
  try {
    const labOrder = await labService.createLabOrder(req.identity.hospitalId, req.body);
    res.status(201).json({ success: true, labOrder });
  } catch (err) {
    next(err);
  }
}

export async function updateStatus(req, res, next) {
  try {
    const labOrder = await labService.updateLabOrderStatus(
      req.identity.hospitalId,
      req.params.id,
      req.body.status,
      req.identity?.type === "staff" ? req.identity.id : null
    );
    res.json({ success: true, labOrder });
  } catch (err) {
    next(err);
  }
}

export async function recordResult(req, res, next) {
  try {
    const labOrder = await labService.recordResult(req.identity.hospitalId, req.params.id, req.body.resultSummary);
    res.json({ success: true, labOrder });
  } catch (err) {
    next(err);
  }
}
