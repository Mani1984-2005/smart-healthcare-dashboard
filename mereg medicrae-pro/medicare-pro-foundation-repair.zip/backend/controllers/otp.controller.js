import * as otpService from "../services/otp.service.js";

export async function request(req, res, next) {
  try {
    const result = await otpService.requestOtp(req.identity.hospitalId, req.body);
    // Never return the code itself in the response — delivered via SMS only.
    res.status(202).json({ success: true, message: "Verification code sent", ...result });
  } catch (err) {
    next(err);
  }
}

export async function verify(req, res, next) {
  try {
    const result = await otpService.verifyOtp(req.identity.hospitalId, req.body);
    res.json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
}
