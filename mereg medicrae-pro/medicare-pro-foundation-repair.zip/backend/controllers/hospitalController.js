// Ported from Mongoose (never-runnable — "mongoose" was not even a declared
// backend dependency) onto the Postgres tables defined in
// backend/prisma/schema.prisma. See FOUNDATION_IMPLEMENTATION_REPORT.md.
// Tenant-scoped (see TENANT_ISOLATION_REPORT.md) — every call passes
// req.identity.hospitalId, never a client-supplied value.
import * as hospitalService from "../services/hospital.service.js";

export async function getDashboard(req, res, next) {
  try {
    const dashboard = await hospitalService.getDashboard(req.identity.hospitalId);
    res.json({ success: true, ...dashboard });
  } catch (error) {
    next(error);
  }
}

export async function getDepartments(req, res, next) {
  try {
    const departments = await hospitalService.listDepartments(req.identity.hospitalId);
    res.json({ success: true, departments });
  } catch (error) {
    next(error);
  }
}

export async function getDepartmentById(req, res, next) {
  try {
    const department = await hospitalService.getDepartmentById(req.identity.hospitalId, req.params.id);
    res.json({ success: true, department });
  } catch (error) {
    next(error);
  }
}

export async function createDepartment(req, res, next) {
  try {
    const department = await hospitalService.createDepartment(req.identity.hospitalId, req.body);
    res.status(201).json({ success: true, department });
  } catch (error) {
    next(error);
  }
}

export async function updateDepartment(req, res, next) {
  try {
    const department = await hospitalService.updateDepartment(req.identity.hospitalId, req.params.id, req.body);
    res.json({ success: true, department });
  } catch (error) {
    next(error);
  }
}

export async function deleteDepartment(req, res, next) {
  try {
    await hospitalService.deleteDepartment(req.identity.hospitalId, req.params.id);
    res.json({ success: true, message: "Department deleted" });
  } catch (error) {
    next(error);
  }
}

export async function getStaff(req, res, next) {
  try {
    const staff = await hospitalService.listStaff(req.identity.hospitalId);
    res.json({ success: true, staff });
  } catch (error) {
    next(error);
  }
}

export async function getStaffById(req, res, next) {
  try {
    const staff = await hospitalService.getStaffById(req.identity.hospitalId, req.params.id);
    res.json({ success: true, staff });
  } catch (error) {
    next(error);
  }
}

export async function createStaff(req, res, next) {
  try {
    const staff = await hospitalService.createStaff(req.identity.hospitalId, req.body);
    res.status(201).json({ success: true, staff });
  } catch (error) {
    next(error);
  }
}

export async function updateStaff(req, res, next) {
  try {
    const staff = await hospitalService.updateStaff(req.identity.hospitalId, req.params.id, req.body);
    res.json({ success: true, staff });
  } catch (error) {
    next(error);
  }
}

export async function deleteStaff(req, res, next) {
  try {
    await hospitalService.deleteStaff(req.identity.hospitalId, req.params.id);
    res.json({ success: true, message: "Staff deleted" });
  } catch (error) {
    next(error);
  }
}

export async function assignStaffToDepartment(req, res, next) {
  try {
    const { staffId, departmentId } = req.body;
    const staff = await hospitalService.assignStaffToDepartment(req.identity.hospitalId, staffId, departmentId);
    res.json({ success: true, message: "Staff assigned to department", staff });
  } catch (error) {
    next(error);
  }
}
