import * as billingService from "../services/billing.service.js";

export async function getSummary(req, res, next) {
  try {
    const summary = await billingService.getSummary(req.identity.hospitalId);
    res.json({ success: true, ...summary });
  } catch (err) {
    next(err);
  }
}

export async function getInvoices(req, res, next) {
  try {
    const result = await billingService.listInvoices(req.identity.hospitalId, req.query);
    res.json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
}

export async function getInvoiceById(req, res, next) {
  try {
    const invoice = await billingService.getInvoiceById(req.identity.hospitalId, req.params.id);
    res.json({ success: true, invoice });
  } catch (err) {
    next(err);
  }
}

export async function createInvoice(req, res, next) {
  try {
    const invoice = await billingService.createInvoice(req.identity.hospitalId, req.body);
    res.status(201).json({ success: true, invoice });
  } catch (err) {
    next(err);
  }
}

export async function updateInvoice(req, res, next) {
  try {
    const invoice = await billingService.updateInvoiceStatus(req.identity.hospitalId, req.params.id, req.body.status);
    res.json({ success: true, invoice });
  } catch (err) {
    next(err);
  }
}

export async function deleteInvoice(req, res, next) {
  try {
    await billingService.voidInvoice(req.identity.hospitalId, req.params.id);
    res.json({ success: true, message: "Invoice voided" });
  } catch (err) {
    next(err);
  }
}
