import * as notificationService from "../services/notification.service.js";
import { NotFoundError } from "../lib/errors.js";

export async function list(req, res, next) {
  try {
    const result = await notificationService.listMyNotifications(req.identity.hospitalId, req.identity, req.query);
    res.json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
}

export async function markRead(req, res, next) {
  try {
    const notification = await notificationService.markAsRead(req.identity.hospitalId, req.identity, req.params.id);
    if (!notification) throw new NotFoundError("Notification not found");
    res.json({ success: true, notification });
  } catch (err) {
    next(err);
  }
}
