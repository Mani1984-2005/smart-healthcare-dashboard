import * as telemedicineService from "../services/telemedicine.service.js";

export async function create(req, res, next) {
  try {
    const { session, link } = await telemedicineService.createConsultationSession(
      req.identity.hospitalId,
      req.identity,
      req.body
    );
    // The link (containing the raw token) is returned once, to the
    // authenticated staff member who created it — the same value is also
    // queued for SMS delivery to the patient. It is never logged.
    res.status(201).json({ success: true, session, link });
  } catch (err) {
    next(err);
  }
}

export async function validateToken(req, res, next) {
  try {
    const session = await telemedicineService.validateConsultationToken(
      req.identity.hospitalId,
      req.params.id,
      req.body.token
    );
    res.json({ success: true, session });
  } catch (err) {
    next(err);
  }
}

export async function start(req, res, next) {
  try {
    const session = await telemedicineService.startConsultation(req.identity.hospitalId, req.params.id);
    res.json({ success: true, session });
  } catch (err) {
    next(err);
  }
}

export async function end(req, res, next) {
  try {
    const session = await telemedicineService.endConsultation(req.identity.hospitalId, req.params.id);
    res.json({ success: true, session });
  } catch (err) {
    next(err);
  }
}
