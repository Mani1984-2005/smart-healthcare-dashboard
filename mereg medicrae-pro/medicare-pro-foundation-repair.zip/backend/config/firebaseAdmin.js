// FOUNDATION REPAIR FIX: the previous version of this file did
// `import admin from "firebase-admin"` and then called `admin.apps`,
// `admin.credential.cert(...)`, and (in authMiddleware.js) `admin.auth()`.
// Under this project's `"type": "module"` (ESM) configuration, firebase-admin
// v14's default export does NOT carry those CJS-namespace properties — it is
// a partial object missing `.apps`, `.credential`, and `.auth`. This meant
// Firebase auth verification would throw ("Cannot read properties of
// undefined") the moment it was actually exercised, regardless of whether
// valid credentials were configured. It was never caught because no mounted
// route exercised `authenticate` before this phase.
//
// Fixed by using firebase-admin's modular ESM entry points, which are the
// officially supported way to use this SDK under ESM.
import { initializeApp, getApps, cert } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";

const { FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY } = process.env;

if (!FIREBASE_PROJECT_ID || !FIREBASE_CLIENT_EMAIL || !FIREBASE_PRIVATE_KEY) {
  console.error(
    "Firebase Admin: Missing required environment variables. " +
      "Ensure FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, and FIREBASE_PRIVATE_KEY are set."
  );
  throw new Error("Missing Firebase Admin environment variables");
}

// Initialise only once
if (!getApps().length) {
  initializeApp({
    credential: cert({
      projectId: FIREBASE_PROJECT_ID,
      clientEmail: FIREBASE_CLIENT_EMAIL,
      privateKey: FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n"),
    }),
  });

  console.log("Firebase Admin SDK initialised");
}

const auth = getAuth();
export default auth;
