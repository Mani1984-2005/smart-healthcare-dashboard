// Re-exports the single, consolidated pool from lib/db.js.
// This file previously created its OWN separate `pg.Pool` (configured from
// PG_HOST/PG_PORT/PG_USER/... env vars) while backend/db.js created a
// SECOND, differently-configured pool (from DATABASE_URL). Having two pools
// with two different config sources was a foundation-repair finding (see
// FOUNDATION_IMPLEMENTATION_REPORT.md, "Database standard"). Both files now
// point at the one real pool so nothing importing from either old path
// breaks, and there is exactly one connection pool at runtime.
export { getPool, default } from "../lib/db.js";
