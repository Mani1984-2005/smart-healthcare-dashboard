import { randomUUID } from "crypto";
import { query } from "../lib/db.js";
import { NotFoundError, ValidationError } from "../lib/errors.js";
import { recordAuditEvent } from "./audit.service.js";

const VALID_PURPOSES = ["TELEMEDICINE", "SMS_COMMUNICATION", "WHATSAPP_COMMUNICATION"];

function toPublicConsent(row) {
  return {
    id: row.id,
    patientId: row.patient_id,
    purpose: row.purpose,
    status: row.status,
    version: row.version,
    relatedEventType: row.related_event_type,
    relatedEventId: row.related_event_id,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

// TENANT SCOPING: hospitalId always first. Every consent record is
// auditable (via the same recordAuditEvent used everywhere else in this
// system) — consent changes are exactly the kind of event the audit trail
// exists for.
export async function grantConsent(hospitalId, actorIdentity, { patientId, purpose, relatedEventType, relatedEventId }) {
  if (!VALID_PURPOSES.includes(purpose)) {
    throw new ValidationError(`purpose must be one of: ${VALID_PURPOSES.join(", ")}`);
  }
  const patientCheck = await query("SELECT id FROM patients WHERE id = $1 AND hospital_id = $2", [patientId, hospitalId]);
  if (!patientCheck.rows[0]) throw new NotFoundError("Patient not found");

  const existing = await query(
    "SELECT version FROM consents WHERE hospital_id = $1 AND patient_id = $2 AND purpose = $3 ORDER BY version DESC LIMIT 1",
    [hospitalId, patientId, purpose]
  );
  const nextVersion = existing.rows[0] ? existing.rows[0].version + 1 : 1;

  const { rows } = await query(
    `INSERT INTO consents (id, hospital_id, patient_id, purpose, status, version, related_event_type, related_event_id)
     VALUES ($1,$2,$3,$4,'GRANTED',$5,$6,$7) RETURNING *`,
    [randomUUID(), hospitalId, patientId, purpose, nextVersion, relatedEventType ?? null, relatedEventId ?? null]
  );

  await recordAuditEvent({
    hospitalId,
    actorStaffId: actorIdentity?.type === "staff" ? actorIdentity.id : null,
    actorRole: actorIdentity?.role ?? null,
    action: "CONSENT_GRANTED",
    resourceType: "consents",
    resourceId: rows[0].id,
    outcome: "success",
    metadata: { patientId, purpose, version: nextVersion },
  });

  return toPublicConsent(rows[0]);
}

export async function revokeConsent(hospitalId, actorIdentity, { patientId, purpose }) {
  const { rows } = await query(
    `UPDATE consents SET status = 'REVOKED', updated_at = now()
     WHERE hospital_id = $1 AND patient_id = $2 AND purpose = $3 AND status = 'GRANTED'
     RETURNING *`,
    [hospitalId, patientId, purpose]
  );
  if (!rows[0]) throw new NotFoundError("No active consent found to revoke");

  await recordAuditEvent({
    hospitalId,
    actorStaffId: actorIdentity?.type === "staff" ? actorIdentity.id : null,
    actorRole: actorIdentity?.role ?? null,
    action: "CONSENT_REVOKED",
    resourceType: "consents",
    resourceId: rows[0].id,
    outcome: "success",
    metadata: { patientId, purpose },
  });

  return toPublicConsent(rows[0]);
}

// Used by other services (telemedicine) to check a prerequisite — always
// hospital-scoped, always checks the CURRENT (latest version) status.
export async function hasActiveConsent(hospitalId, patientId, purpose) {
  const { rows } = await query(
    `SELECT status FROM consents WHERE hospital_id = $1 AND patient_id = $2 AND purpose = $3
     ORDER BY version DESC LIMIT 1`,
    [hospitalId, patientId, purpose]
  );
  return rows[0]?.status === "GRANTED";
}

export async function listConsentsForPatient(hospitalId, patientId) {
  // Same cross-entity tenant check used everywhere else in this codebase
  // (appointment/lab/invoice creation all verify the referenced patient
  // belongs to the caller's hospital before proceeding) — found missing
  // here during testing: without it, a cross-tenant caller got a silent
  // empty array (200) instead of a clean 404, which is inconsistent with
  // how every other "look up by another entity's id" path in this system
  // behaves.
  const patientCheck = await query("SELECT id FROM patients WHERE id = $1 AND hospital_id = $2", [patientId, hospitalId]);
  if (!patientCheck.rows[0]) throw new NotFoundError("Patient not found");

  const { rows } = await query(
    "SELECT * FROM consents WHERE hospital_id = $1 AND patient_id = $2 ORDER BY purpose, version DESC",
    [hospitalId, patientId]
  );
  return rows.map(toPublicConsent);
}
