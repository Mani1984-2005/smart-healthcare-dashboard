import { randomUUID } from "crypto";
import { query } from "../lib/db.js";
import { NotFoundError } from "../lib/errors.js";
import { emitEvent } from "./notification.service.js";

// Minimum viable Appointment persistence — booking + status only.
// Deliberately does NOT implement scheduling conflict rules, reminders, or
// recurring appointments. Those are FUTURE, per "do not build a giant
// appointment system in this phase."
//
// TENANT SCOPING: hospitalId is always the first argument, sourced only
// from req.identity.hospitalId. Create additionally verifies that the
// referenced patient AND doctor (when provided) both belong to the same
// hospital as the caller — otherwise a valid same-hospital admin could
// still link a real patient or staff UUID from a different hospital by
// guessing/enumerating IDs, even though the appointment row itself would
// carry the caller's own hospital_id.

function toPublicAppointment(row) {
  return {
    id: row.id,
    patientId: row.patient_id,
    doctorId: row.doctor_id,
    departmentId: row.department_id,
    scheduledAt: row.scheduled_at,
    status: row.status,
    reason: row.reason,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function listAppointments(hospitalId, { patientId, doctorId, status, page = 1, limit = 20 } = {}) {
  const params = [hospitalId];
  const conditions = ["hospital_id = $1"];
  if (patientId) {
    params.push(patientId);
    conditions.push(`patient_id = $${params.length}`);
  }
  if (doctorId) {
    params.push(doctorId);
    conditions.push(`doctor_id = $${params.length}`);
  }
  if (status) {
    params.push(status);
    conditions.push(`status = $${params.length}`);
  }
  const where = `WHERE ${conditions.join(" AND ")}`;
  const offset = (page - 1) * limit;
  params.push(limit, offset);

  const { rows } = await query(
    `SELECT * FROM appointments ${where} ORDER BY scheduled_at ASC LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params
  );
  return { appointments: rows.map(toPublicAppointment) };
}

export async function getAppointmentById(hospitalId, id) {
  const { rows } = await query(`SELECT * FROM appointments WHERE id = $1 AND hospital_id = $2`, [id, hospitalId]);
  if (!rows[0]) throw new NotFoundError("Appointment not found");
  return toPublicAppointment(rows[0]);
}

export async function createAppointment(hospitalId, data) {
  const patientCheck = await query(`SELECT id FROM patients WHERE id = $1 AND hospital_id = $2`, [
    data.patientId,
    hospitalId,
  ]);
  if (!patientCheck.rows[0]) {
    throw new NotFoundError("Patient not found");
  }

  if (data.doctorId) {
    const doctorCheck = await query(`SELECT id FROM staff WHERE id = $1 AND hospital_id = $2`, [
      data.doctorId,
      hospitalId,
    ]);
    if (!doctorCheck.rows[0]) {
      throw new NotFoundError("Doctor not found");
    }
  }

  const { rows } = await query(
    `INSERT INTO appointments (id, hospital_id, patient_id, doctor_id, department_id, scheduled_at, reason)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [
      randomUUID(),
      hospitalId,
      data.patientId,
      data.doctorId ?? null,
      data.departmentId ?? null,
      data.scheduledAt,
      data.reason ?? null,
    ]
  );
  return toPublicAppointment(rows[0]);
}

const VALID_STATUSES = ["SCHEDULED", "CONFIRMED", "CHECKED_IN", "COMPLETED", "CANCELLED", "NO_SHOW"];

export async function updateAppointmentStatus(hospitalId, id, status) {
  if (!VALID_STATUSES.includes(status)) {
    throw new NotFoundError(`status must be one of: ${VALID_STATUSES.join(", ")}`);
  }
  const { rows } = await query(
    `UPDATE appointments SET status = $1, updated_at = now() WHERE id = $2 AND hospital_id = $3 RETURNING *`,
    [status, id, hospitalId]
  );
  if (!rows[0]) throw new NotFoundError("Appointment not found");
  const appointment = toPublicAppointment(rows[0]);

  // Notification emission — additive, after the write already succeeded.
  // Never awaited-and-thrown into the caller; emitEvent handles its own
  // errors (see notification.service.js).
  emitEvent({
    hospitalId,
    eventType: "appointment.status_changed",
    resourceType: "appointments",
    resourceId: appointment.id,
    payload: { patientId: appointment.patientId, doctorId: appointment.doctorId, status: appointment.status },
  });

  return appointment;
}

export async function rescheduleAppointment(hospitalId, id, scheduledAt) {
  const { rows } = await query(
    `UPDATE appointments SET scheduled_at = $1, updated_at = now() WHERE id = $2 AND hospital_id = $3 RETURNING *`,
    [scheduledAt, id, hospitalId]
  );
  if (!rows[0]) throw new NotFoundError("Appointment not found");
  return toPublicAppointment(rows[0]);
}
