import { randomUUID, randomBytes, createHash } from "crypto";
import { query } from "../lib/db.js";
import { NotFoundError, ValidationError, AuthorizationError } from "../lib/errors.js";
import { hasActiveConsent } from "./consent.service.js";
import { enqueueCommunication } from "./communication.service.js";
import { emitEvent } from "./notification.service.js";

const LINK_TTL_MINUTES = 30;

function hashToken(token) {
  return createHash("sha256").update(token).digest("hex");
}

function toPublicSession(row) {
  return {
    id: row.id,
    appointmentId: row.appointment_id,
    status: row.status,
    expiresAt: row.expires_at,
    startedAt: row.started_at,
    endedAt: row.ended_at,
    createdAt: row.created_at,
  };
}

// TENANT SCOPING: hospitalId always first, and the appointment referenced
// must belong to the same hospital (same cross-entity check pattern as
// appointment.service.js's own create()).
//
// Consent prerequisite: enforced here, not left to the caller — a
// consultation link is never issued without an active TELEMEDICINE consent
// for that patient. This is what "consent must gate telemedicine" means
// structurally, not just as a documented expectation.
export async function createConsultationSession(hospitalId, actorIdentity, { appointmentId }) {
  const apptResult = await query(
    "SELECT id, patient_id, doctor_id FROM appointments WHERE id = $1 AND hospital_id = $2",
    [appointmentId, hospitalId]
  );
  const appointment = apptResult.rows[0];
  if (!appointment) throw new NotFoundError("Appointment not found");

  const consented = await hasActiveConsent(hospitalId, appointment.patient_id, "TELEMEDICINE");
  if (!consented) {
    throw new ValidationError("Patient has not granted telemedicine consent for this appointment");
  }

  const rawToken = randomBytes(32).toString("hex");
  const tokenHash = hashToken(rawToken);
  const expiresAt = new Date(Date.now() + LINK_TTL_MINUTES * 60 * 1000);

  const { rows } = await query(
    `INSERT INTO consultation_sessions (id, hospital_id, appointment_id, token_hash, status, expires_at)
     VALUES ($1,$2,$3,$4,'PENDING',$5) RETURNING *`,
    [randomUUID(), hospitalId, appointmentId, tokenHash, expiresAt]
  );
  const session = toPublicSession(rows[0]);

  // The raw token is returned ONLY here, once, to be embedded in the link
  // sent via SMS/WhatsApp — it is never persisted in plaintext (token_hash
  // only) and never included in the in-app notification body (which is
  // visible in a dashboard that might be viewed on a shared/public screen —
  // the link itself is exactly the kind of "secure" delivery the brief
  // asks for, not something to also duplicate into a less-guarded channel).
  const link = `https://medicarepro.example/consult/${session.id}?token=${rawToken}`;

  const patientRow = await query("SELECT phone, firebase_uid FROM patients WHERE id = $1", [appointment.patient_id]);
  if (patientRow.rows[0]?.firebase_uid) {
    await enqueueCommunication({
      hospitalId,
      eventType: "telemedicine.link_ready",
      channel: "sms",
      recipientType: "patient",
      recipientPatientId: appointment.patient_id,
      to: patientRow.rows[0]?.phone,
      correlationId: `telemedicine:${session.id}:patient`,
      templatePayload: { link },
      priority: "HIGH",
    });
  }

  // Doctor gets the in-app + phone-first notification path already built —
  // reuse it rather than duplicating delivery logic.
  await emitEvent({
    hospitalId,
    eventType: "appointment.status_changed", // reuses the existing, already-tested template — a dedicated doctor-facing telemedicine template is not named as required by the brief beyond "doctor notification"
    resourceType: "consultation_sessions",
    resourceId: session.id,
    payload: { patientId: appointment.patient_id, doctorId: appointment.doctor_id, status: "TELEMEDICINE_READY" },
    priority: "HIGH",
  });

  return { session, link };
}

// Validates an incoming token against the stored hash — never compares
// plaintext-to-plaintext. Tenant-scoped: a token can only validate within
// the hospital it was issued for.
export async function validateConsultationToken(hospitalId, sessionId, rawToken) {
  const tokenHash = hashToken(rawToken);
  const { rows } = await query(
    "SELECT * FROM consultation_sessions WHERE id = $1 AND hospital_id = $2",
    [sessionId, hospitalId]
  );
  const session = rows[0];
  if (!session || session.token_hash !== tokenHash) {
    throw new AuthorizationError("Invalid or unauthorized consultation link");
  }
  if (new Date(session.expires_at) < new Date()) {
    throw new AuthorizationError("This consultation link has expired");
  }
  if (session.status === "ENDED") {
    throw new AuthorizationError("This consultation has already ended");
  }
  return toPublicSession(session);
}

export async function startConsultation(hospitalId, sessionId) {
  const { rows } = await query(
    `UPDATE consultation_sessions SET status = 'ACTIVE', started_at = now()
     WHERE id = $1 AND hospital_id = $2 AND status = 'PENDING' RETURNING *`,
    [sessionId, hospitalId]
  );
  if (!rows[0]) throw new NotFoundError("Consultation session not found or not in a startable state");
  return toPublicSession(rows[0]);
}

export async function endConsultation(hospitalId, sessionId) {
  const { rows } = await query(
    `UPDATE consultation_sessions SET status = 'ENDED', ended_at = now()
     WHERE id = $1 AND hospital_id = $2 AND status = 'ACTIVE' RETURNING *`,
    [sessionId, hospitalId]
  );
  if (!rows[0]) throw new NotFoundError("Consultation session not found or not active");
  return toPublicSession(rows[0]);
}
