import { randomUUID } from "crypto";
import { query } from "../lib/db.js";
import { NotFoundError } from "../lib/errors.js";
import { emitEvent } from "./notification.service.js";

// Minimum viable Laboratory persistence — order + status + result summary
// only. No result-file storage, no critical-value alerting, no device
// integration. Those are FUTURE.
//
// TENANT SCOPING: hospitalId is always the first argument, sourced only
// from req.identity.hospitalId. Create verifies the referenced patient
// belongs to the same hospital.

function generateOrderCode() {
  return `LAB-${Date.now().toString(36).toUpperCase()}`;
}

function toPublicLabOrder(row) {
  return {
    id: row.id,
    orderCode: row.order_code,
    patientId: row.patient_id,
    appointmentId: row.appointment_id,
    handledById: row.handled_by_id,
    testName: row.test_name,
    status: row.status,
    resultSummary: row.result_summary,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function listLabOrders(hospitalId, { patientId, status, page = 1, limit = 20 } = {}) {
  const params = [hospitalId];
  const conditions = ["hospital_id = $1"];
  if (patientId) {
    params.push(patientId);
    conditions.push(`patient_id = $${params.length}`);
  }
  if (status) {
    params.push(status);
    conditions.push(`status = $${params.length}`);
  }
  const where = `WHERE ${conditions.join(" AND ")}`;
  const offset = (page - 1) * limit;
  params.push(limit, offset);

  const { rows } = await query(
    `SELECT * FROM lab_orders ${where} ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params
  );
  return { labOrders: rows.map(toPublicLabOrder) };
}

export async function getLabOrderById(hospitalId, id) {
  const { rows } = await query(`SELECT * FROM lab_orders WHERE id = $1 AND hospital_id = $2`, [id, hospitalId]);
  if (!rows[0]) throw new NotFoundError("Lab order not found");
  return toPublicLabOrder(rows[0]);
}

export async function createLabOrder(hospitalId, data) {
  const patientCheck = await query(`SELECT id FROM patients WHERE id = $1 AND hospital_id = $2`, [
    data.patientId,
    hospitalId,
  ]);
  if (!patientCheck.rows[0]) {
    throw new NotFoundError("Patient not found");
  }

  if (data.appointmentId) {
    const apptCheck = await query(`SELECT id FROM appointments WHERE id = $1 AND hospital_id = $2`, [
      data.appointmentId,
      hospitalId,
    ]);
    if (!apptCheck.rows[0]) {
      throw new NotFoundError("Appointment not found");
    }
  }

  const { rows } = await query(
    `INSERT INTO lab_orders (id, hospital_id, order_code, patient_id, appointment_id, test_name)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [randomUUID(), hospitalId, generateOrderCode(), data.patientId, data.appointmentId ?? null, data.testName]
  );
  return toPublicLabOrder(rows[0]);
}

const VALID_STATUSES = ["ORDERED", "COLLECTED", "PROCESSING", "RESULT_READY", "REVIEWED", "REJECTED"];

export async function updateLabOrderStatus(hospitalId, id, status, handledById) {
  if (!VALID_STATUSES.includes(status)) {
    throw new NotFoundError(`status must be one of: ${VALID_STATUSES.join(", ")}`);
  }
  const { rows } = await query(
    `UPDATE lab_orders SET status = $1, handled_by_id = COALESCE($2, handled_by_id), updated_at = now()
     WHERE id = $3 AND hospital_id = $4 RETURNING *`,
    [status, handledById ?? null, id, hospitalId]
  );
  if (!rows[0]) throw new NotFoundError("Lab order not found");
  return toPublicLabOrder(rows[0]);
}

export async function recordResult(hospitalId, id, resultSummary) {
  const { rows } = await query(
    `UPDATE lab_orders SET result_summary = $1, status = 'RESULT_READY', updated_at = now()
     WHERE id = $2 AND hospital_id = $3 RETURNING *`,
    [resultSummary, id, hospitalId]
  );
  if (!rows[0]) throw new NotFoundError("Lab order not found");
  const labOrder = toPublicLabOrder(rows[0]);

  emitEvent({
    hospitalId,
    eventType: "lab_order.result_ready",
    resourceType: "lab_orders",
    resourceId: labOrder.id,
    payload: { patientId: labOrder.patientId, handledById: labOrder.handledById },
  });

  return labOrder;
}
