import { query } from "../lib/db.js";

// Resolves a verified Firebase UID to the platform identity behind it.
// This is deliberately the ONE place that decides "who is this token for" —
// controllers and other services should never query staff/patients by
// firebase_uid directly, so this rule only has to be correct in one place.
//
// TENANT IDENTITY: hospitalId is resolved here, from the same trusted DB row
// as role/id, and nowhere else. This is the single source of truth for
// "which hospital is this request scoped to" — no route, controller, or
// validation schema accepts hospitalId from the client (see
// TENANT_ISOLATION_DESIGN.md).
export async function resolveIdentityByFirebaseUid(firebaseUid) {
  const staffResult = await query(
    `SELECT id, hospital_id, role, name, email, is_active FROM staff WHERE firebase_uid = $1 LIMIT 1`,
    [firebaseUid]
  );
  if (staffResult.rows.length > 0) {
    const row = staffResult.rows[0];
    return {
      type: "staff",
      id: row.id,
      hospitalId: row.hospital_id,
      role: row.role,
      name: row.name,
      email: row.email,
      isActive: row.is_active,
    };
  }

  const patientResult = await query(
    `SELECT id, hospital_id, first_name, last_name, email, is_active FROM patients WHERE firebase_uid = $1 LIMIT 1`,
    [firebaseUid]
  );
  if (patientResult.rows.length > 0) {
    const row = patientResult.rows[0];
    return {
      type: "patient",
      id: row.id,
      hospitalId: row.hospital_id,
      role: "PATIENT",
      name: `${row.first_name} ${row.last_name}`,
      email: row.email,
      isActive: row.is_active,
    };
  }

  return null;
}
