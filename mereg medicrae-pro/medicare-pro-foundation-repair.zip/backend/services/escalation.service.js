import { randomUUID } from "crypto";
import { query } from "../lib/db.js";
import { getCommunicationQueue } from "../queue/communicationQueue.js";
import { enqueueCommunication } from "./communication.service.js";

// Fixed, configured ladder — NOT a general-purpose rules engine, per the
// brief's own boundary ("execute configured communication rules only," not
// build a rule editor). Priority levels: LOW/NORMAL/HIGH/CRITICAL exist on
// every notification_event (see notification.service.js); this module is
// specifically the CRITICAL ladder: immediate SMS -> (if unacknowledged
// within a window) escalation SMS to a backup recipient -> (if still
// unacknowledged) a voice call.
//
// "Acknowledgement" reuses the existing notifications.is_read flag — no
// separate acknowledgement mechanism was introduced, since the brief didn't
// ask for one distinct from "did the recipient see it," and reusing it
// keeps this additive rather than a parallel tracking system.
const ACK_WINDOW_MS = 5 * 60 * 1000; // 5 minutes — configurable via env in a real deployment; fixed here for a testable default

async function insertEscalationNotification({ hospitalId, recipientStaffId, recipientPatientId, eventType, resourceType, resourceId, title, body }) {
  const id = randomUUID();
  await query(
    `INSERT INTO notifications
      (id, hospital_id, recipient_staff_id, recipient_patient_id, event_type, title, body, resource_type, resource_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
    [id, hospitalId, recipientStaffId ?? null, recipientPatientId ?? null, eventType, title, body, resourceType, resourceId]
  );
  return id;
}

// Entry point for a CRITICAL event. primaryRecipient/backupRecipient are
// { staffId, phone } — resolved by the CALLER within its own hospital-scoped
// query (this function does not itself resolve recipients from a generic
// event payload, keeping recipient trust at the same level as every other
// tenant-scoped write in this system).
export async function triggerCriticalEscalation(hospitalId, {
  eventType,
  resourceType,
  resourceId,
  primaryRecipient,
  backupRecipient = null,
  ackWindowMs = ACK_WINDOW_MS,
}) {
  const notificationId = await insertEscalationNotification({
    hospitalId,
    recipientStaffId: primaryRecipient.staffId,
    eventType,
    resourceType,
    resourceId,
    title: "Critical alert",
    body: "An item requires your immediate attention.",
  });

  await enqueueCommunication({
    hospitalId,
    eventType: "escalation.critical",
    channel: "sms",
    recipientType: "staff",
    recipientStaffId: primaryRecipient.staffId,
    to: primaryRecipient.phone,
    correlationId: `escalation:${resourceId}:primary`,
    priority: "CRITICAL",
  });

  if (backupRecipient) {
    await getCommunicationQueue().add(
      "escalation-check",
      {
        step: "sms_backup",
        hospitalId,
        notificationId,
        eventType,
        resourceType,
        resourceId,
        backupRecipient,
        ackWindowMs,
      },
      { delay: ackWindowMs, jobId: `escalation_${resourceId}_step1`, priority: 10 }
    );
  }

  return { notificationId };
}

// Called by the worker when an "escalation-check" job fires (see
// workers/communicationWorker.js). Checks whether the primary alert was
// acknowledged (is_read) — if so, the ladder stops. If not, executes the
// next configured step.
export async function handleEscalationCheck(job) {
  const { step, hospitalId, notificationId, eventType, resourceType, resourceId, backupRecipient, ackWindowMs } = job;

  const { rows } = await query("SELECT is_read FROM notifications WHERE id = $1 AND hospital_id = $2", [
    notificationId,
    hospitalId,
  ]);
  if (!rows[0] || rows[0].is_read) {
    return { escalated: false, reason: "acknowledged" };
  }

  if (step === "sms_backup") {
    await enqueueCommunication({
      hospitalId,
      eventType: "escalation.critical_backup",
      channel: "sms",
      recipientType: "staff",
      recipientStaffId: backupRecipient.staffId,
      to: backupRecipient.phone,
      correlationId: `escalation:${resourceId}:backup`,
      priority: "CRITICAL",
    });

    // Next rung: voice call, only if a voice-capable step was configured.
    await getCommunicationQueue().add(
      "escalation-check",
      { step: "voice_backup", hospitalId, notificationId, eventType, resourceType, resourceId, backupRecipient, ackWindowMs },
      { delay: ackWindowMs, jobId: `escalation_${resourceId}_step2`, priority: 10 }
    );
    return { escalated: true, step: "sms_backup" };
  }

  if (step === "voice_backup") {
    await enqueueCommunication({
      hospitalId,
      eventType: "escalation.critical_backup",
      channel: "voice",
      recipientType: "staff",
      recipientStaffId: backupRecipient.staffId,
      to: backupRecipient.phone,
      correlationId: `escalation:${resourceId}:voice`,
      priority: "CRITICAL",
    });
    return { escalated: true, step: "voice_backup" };
  }

  return { escalated: false, reason: "unknown_step" };
}
