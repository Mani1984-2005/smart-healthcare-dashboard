import { randomInt, createHash } from "crypto";
import { query } from "../lib/db.js";
import { ValidationError, AuthenticationError } from "../lib/errors.js";
import { enqueueCommunication } from "./communication.service.js";

const OTP_LENGTH = 6;
const OTP_TTL_MINUTES = 5;
const MAX_ATTEMPTS = 5;
const RESEND_COOLDOWN_SECONDS = 60;
const RATE_LIMIT_WINDOW_MINUTES = 15;
const RATE_LIMIT_MAX_SENDS = 3;

// Normalizes a phone number to a consistent, comparable form (digits only,
// leading + preserved) — not full E.164 validation (that needs a real
// phone-number library and country-code data this phase doesn't add), but
// enough that "+1 555-010-0000" and "15550100000" resolve to the same
// lookup key rather than silently being treated as different phones.
export function normalizePhone(raw) {
  if (!raw) return raw;
  const trimmed = raw.trim();
  const hasPlus = trimmed.startsWith("+");
  const digits = trimmed.replace(/\D/g, "");
  return hasPlus ? `+${digits}` : digits;
}

function generateOtp() {
  return String(randomInt(0, 1_000_000)).padStart(OTP_LENGTH, "0");
}

function hashOtp(code, phone) {
  // Salted with the phone number so two different phones that happen to
  // generate the same 6-digit code don't produce identical hashes.
  return createHash("sha256").update(`${phone}:${code}`).digest("hex");
}

// TENANT SCOPING: hospitalId is always the first argument. Rate limiting
// and cooldown are scoped per (hospitalId, phone) — the same phone number
// in two different hospitals (e.g. a shared family member registered at
// both) is rate-limited independently, matching how every other tenant
// boundary in this system works.
export async function requestOtp(hospitalId, { phone, purpose }) {
  const normalizedPhone = normalizePhone(phone);
  if (!normalizedPhone) throw new ValidationError("A valid phone number is required");
  if (!purpose) throw new ValidationError("purpose is required");

  const recent = await query(
    `SELECT created_at FROM otp_codes
     WHERE hospital_id = $1 AND phone = $2 AND purpose = $3
     ORDER BY created_at DESC LIMIT 1`,
    [hospitalId, normalizedPhone, purpose]
  );
  if (recent.rows[0]) {
    const secondsSinceLast = (Date.now() - new Date(recent.rows[0].created_at).getTime()) / 1000;
    if (secondsSinceLast < RESEND_COOLDOWN_SECONDS) {
      throw new ValidationError(
        `Please wait ${Math.ceil(RESEND_COOLDOWN_SECONDS - secondsSinceLast)}s before requesting another code`
      );
    }
  }

  const windowStart = new Date(Date.now() - RATE_LIMIT_WINDOW_MINUTES * 60 * 1000);
  const windowCount = await query(
    `SELECT COUNT(*) FROM otp_codes WHERE hospital_id = $1 AND phone = $2 AND purpose = $3 AND created_at > $4`,
    [hospitalId, normalizedPhone, purpose, windowStart]
  );
  if (parseInt(windowCount.rows[0].count, 10) >= RATE_LIMIT_MAX_SENDS) {
    throw new ValidationError("Too many verification code requests. Please try again later.");
  }

  const code = generateOtp();
  const codeHash = hashOtp(code, normalizedPhone);
  const expiresAt = new Date(Date.now() + OTP_TTL_MINUTES * 60 * 1000);

  await query(
    `INSERT INTO otp_codes (id, hospital_id, phone, code_hash, purpose, max_attempts, expires_at)
     VALUES (gen_random_uuid(), $1, $2, $3, $4, $5, $6)`,
    [hospitalId, normalizedPhone, codeHash, purpose, MAX_ATTEMPTS, expiresAt]
  );

  // Delivered via SMS. The plaintext code is passed only to the queue
  // payload (in-memory / Redis job data) for template rendering — never
  // written to otp_codes (hash only) and never written through
  // utils/logger.js's app/audit logs. The MockProvider's own console.log of
  // the message body is a test-environment convenience specific to that
  // provider, disclosed plainly in NOTIFICATIONS_FINAL_COMPLETION_REPORT.md
  // rather than treated as acceptable production behavior.
  await enqueueCommunication({
    hospitalId,
    eventType: "otp.requested",
    channel: "sms",
    recipientType: "external", // OTP is requested by phone number directly, not tied to a resolved staff/patient row
    to: normalizedPhone,
    correlationId: `otp:${normalizedPhone}:${Date.now()}`,
    templatePayload: { code },
    priority: "HIGH",
  });

  return { expiresAt, resendCooldownSeconds: RESEND_COOLDOWN_SECONDS };
}

export async function verifyOtp(hospitalId, { phone, purpose, code }) {
  const normalizedPhone = normalizePhone(phone);
  const { rows } = await query(
    `SELECT * FROM otp_codes
     WHERE hospital_id = $1 AND phone = $2 AND purpose = $3 AND consumed_at IS NULL
     ORDER BY created_at DESC LIMIT 1`,
    [hospitalId, normalizedPhone, purpose]
  );
  const record = rows[0];

  if (!record) {
    throw new AuthenticationError("No active verification code for this phone number");
  }
  if (new Date(record.expires_at) < new Date()) {
    throw new AuthenticationError("Verification code has expired");
  }
  if (record.attempts >= record.max_attempts) {
    throw new AuthenticationError("Too many incorrect attempts. Please request a new code.");
  }

  const submittedHash = hashOtp(code, normalizedPhone);
  if (submittedHash !== record.code_hash) {
    await query(`UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1`, [record.id]);
    throw new AuthenticationError("Incorrect verification code");
  }

  await query(`UPDATE otp_codes SET consumed_at = now() WHERE id = $1`, [record.id]);
  return { verified: true };
}
