import { randomUUID } from "crypto";
import { query } from "../lib/db.js";
import { NotFoundError, ConflictError } from "../lib/errors.js";

// TENANT SCOPING: hospitalId is always the first argument, sourced only
// from req.identity.hospitalId. Every query below filters by it. Department
// head-staff assignment additionally verifies the staff member belongs to
// the same hospital as the department.

function toPublicDepartment(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    code: row.code,
    description: row.description,
    floor: row.floor,
    headStaffId: row.head_staff_id,
    isActive: row.is_active,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function toPublicStaff(row) {
  if (!row) return null;
  return {
    id: row.id,
    staffCode: row.staff_code,
    name: row.name,
    email: row.email,
    role: row.role,
    departmentId: row.department_id,
    isActive: row.is_active,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function getDashboard(hospitalId) {
  const [departments, staff] = await Promise.all([
    query(`SELECT * FROM departments WHERE hospital_id = $1 ORDER BY created_at DESC`, [hospitalId]),
    query(`SELECT * FROM staff WHERE hospital_id = $1 ORDER BY created_at DESC`, [hospitalId]),
  ]);

  const staffRows = staff.rows;
  return {
    counts: {
      departments: departments.rows.length,
      staff: staffRows.length,
      doctors: staffRows.filter((s) => s.role === "DOCTOR").length,
      admins: staffRows.filter((s) => s.role === "ADMIN").length,
    },
    departments: departments.rows.map(toPublicDepartment),
    staff: staffRows.map(toPublicStaff),
  };
}

export async function listDepartments(hospitalId) {
  const { rows } = await query(`SELECT * FROM departments WHERE hospital_id = $1 ORDER BY created_at DESC`, [
    hospitalId,
  ]);
  return rows.map(toPublicDepartment);
}

export async function getDepartmentById(hospitalId, id) {
  const { rows } = await query(`SELECT * FROM departments WHERE id = $1 AND hospital_id = $2`, [id, hospitalId]);
  if (!rows[0]) throw new NotFoundError("Department not found");
  return toPublicDepartment(rows[0]);
}

export async function createDepartment(hospitalId, data) {
  try {
    const { rows } = await query(
      `INSERT INTO departments (id, hospital_id, name, code, description, floor)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [randomUUID(), hospitalId, data.name, data.code, data.description ?? null, data.floor ?? null]
    );
    return toPublicDepartment(rows[0]);
  } catch (err) {
    if (err.code === "23505") throw new ConflictError("A department with this name or code already exists");
    throw err;
  }
}

export async function updateDepartment(hospitalId, id, data) {
  // If reassigning headStaffId, the staff member must belong to this
  // hospital too — otherwise a department in Hospital A could be pointed at
  // a real staff UUID belonging to Hospital B.
  if (data.headStaffId !== undefined && data.headStaffId !== null) {
    const staffCheck = await query(`SELECT id FROM staff WHERE id = $1 AND hospital_id = $2`, [
      data.headStaffId,
      hospitalId,
    ]);
    if (!staffCheck.rows[0]) {
      throw new NotFoundError("Staff member not found");
    }
  }

  const allowed = [
    ["name", "name"],
    ["code", "code"],
    ["description", "description"],
    ["floor", "floor"],
    ["headStaffId", "head_staff_id"],
    ["isActive", "is_active"],
  ];
  const fields = [];
  const values = [];
  for (const [key, column] of allowed) {
    if (data[key] !== undefined) {
      values.push(data[key]);
      fields.push(`${column} = $${values.length}`);
    }
  }
  if (!fields.length) return getDepartmentById(hospitalId, id);
  values.push(id, hospitalId);
  const { rows } = await query(
    `UPDATE departments SET ${fields.join(", ")}, updated_at = now()
     WHERE id = $${values.length - 1} AND hospital_id = $${values.length} RETURNING *`,
    values
  );
  if (!rows[0]) throw new NotFoundError("Department not found");
  return toPublicDepartment(rows[0]);
}

export async function deleteDepartment(hospitalId, id) {
  const { rows } = await query(`DELETE FROM departments WHERE id = $1 AND hospital_id = $2 RETURNING id`, [
    id,
    hospitalId,
  ]);
  if (!rows[0]) throw new NotFoundError("Department not found");
  await query(`UPDATE staff SET department_id = NULL WHERE department_id = $1`, [id]);
}

export async function listStaff(hospitalId) {
  const { rows } = await query(`SELECT * FROM staff WHERE hospital_id = $1 ORDER BY created_at DESC`, [hospitalId]);
  return rows.map(toPublicStaff);
}

export async function getStaffById(hospitalId, id) {
  const { rows } = await query(`SELECT * FROM staff WHERE id = $1 AND hospital_id = $2`, [id, hospitalId]);
  if (!rows[0]) throw new NotFoundError("Staff not found");
  return toPublicStaff(rows[0]);
}

const VALID_ROLES = ["ADMIN", "DOCTOR", "STAFF", "LAB", "PHARMACY", "BILLING", "MANAGEMENT"];

export async function createStaff(hospitalId, data) {
  if (!VALID_ROLES.includes(data.role)) {
    throw new ConflictError(`role must be one of: ${VALID_ROLES.join(", ")}`);
  }
  if (data.departmentId) {
    const deptCheck = await query(`SELECT id FROM departments WHERE id = $1 AND hospital_id = $2`, [
      data.departmentId,
      hospitalId,
    ]);
    if (!deptCheck.rows[0]) {
      throw new NotFoundError("Department not found");
    }
  }
  try {
    const { rows } = await query(
      `INSERT INTO staff (id, hospital_id, staff_code, name, email, role, department_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [randomUUID(), hospitalId, data.staffCode, data.name, data.email, data.role, data.departmentId ?? null]
    );
    return toPublicStaff(rows[0]);
  } catch (err) {
    if (err.code === "23505") throw new ConflictError("A staff member with this code or email already exists");
    throw err;
  }
}

export async function updateStaff(hospitalId, id, data) {
  if (data.departmentId !== undefined && data.departmentId !== null) {
    const deptCheck = await query(`SELECT id FROM departments WHERE id = $1 AND hospital_id = $2`, [
      data.departmentId,
      hospitalId,
    ]);
    if (!deptCheck.rows[0]) {
      throw new NotFoundError("Department not found");
    }
  }

  const allowed = [
    ["staffCode", "staff_code"],
    ["name", "name"],
    ["email", "email"],
    ["role", "role"],
    ["departmentId", "department_id"],
    ["isActive", "is_active"],
  ];
  const fields = [];
  const values = [];
  for (const [key, column] of allowed) {
    if (data[key] !== undefined) {
      values.push(data[key]);
      fields.push(`${column} = $${values.length}`);
    }
  }
  if (!fields.length) return getStaffById(hospitalId, id);
  values.push(id, hospitalId);
  const { rows } = await query(
    `UPDATE staff SET ${fields.join(", ")}, updated_at = now()
     WHERE id = $${values.length - 1} AND hospital_id = $${values.length} RETURNING *`,
    values
  );
  if (!rows[0]) throw new NotFoundError("Staff not found");
  return toPublicStaff(rows[0]);
}

export async function deleteStaff(hospitalId, id) {
  try {
    const { rows } = await query(`DELETE FROM staff WHERE id = $1 AND hospital_id = $2 RETURNING id`, [
      id,
      hospitalId,
    ]);
    if (!rows[0]) throw new NotFoundError("Staff not found");
  } catch (err) {
    // Found during the Foundation Final Verification Gate audit: deleting a
    // staff member who is the recorded head of a department violated the
    // departments.head_staff_id foreign key and surfaced as an unhandled
    // 500. Fixed there; preserved here since tenant scoping doesn't change
    // this constraint.
    if (err.code === "23503") {
      throw new ConflictError(
        "This staff member cannot be deleted while they are assigned as a department head. Reassign the department first."
      );
    }
    throw err;
  }
}

export async function assignStaffToDepartment(hospitalId, staffId, departmentId) {
  await getStaffById(hospitalId, staffId);
  await getDepartmentById(hospitalId, departmentId);
  const { rows } = await query(
    `UPDATE staff SET department_id = $1, updated_at = now() WHERE id = $2 AND hospital_id = $3 RETURNING *`,
    [departmentId, staffId, hospitalId]
  );
  return toPublicStaff(rows[0]);
}
