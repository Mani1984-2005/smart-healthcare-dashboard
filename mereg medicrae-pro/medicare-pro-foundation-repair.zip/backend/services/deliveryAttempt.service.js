import { randomUUID } from "crypto";
import { query } from "../lib/db.js";

// Tenant-scoped record of every external delivery attempt: recipient,
// channel, provider, status, timestamp, error, correlation/event ID,
// hospital_id — exactly the fields the brief requires.
export async function recordDeliveryAttempt({
  hospitalId,
  eventId = null,
  recipientType,
  recipientStaffId = null,
  recipientPatientId = null,
  channel,
  provider,
  status,
  error = null,
  correlationId,
}) {
  const id = randomUUID();
  await query(
    `INSERT INTO delivery_attempts
      (id, hospital_id, event_id, recipient_type, recipient_staff_id, recipient_patient_id,
       channel, provider, status, error, correlation_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
    [id, hospitalId, eventId, recipientType, recipientStaffId, recipientPatientId, channel, provider, status, error, correlationId]
  );
  return id;
}

export async function updateDeliveryAttemptStatus(id, status, error = null) {
  await query(`UPDATE delivery_attempts SET status = $1, error = $2, updated_at = now() WHERE id = $3`, [
    status,
    error,
    id,
  ]);
}

// Tenant-scoped read, used by tests and would back a future admin view.
export async function listDeliveryAttempts(hospitalId, { correlationId } = {}) {
  const params = [hospitalId];
  const conditions = ["hospital_id = $1"];
  if (correlationId) {
    params.push(correlationId);
    conditions.push(`correlation_id = $${params.length}`);
  }
  const { rows } = await query(
    `SELECT * FROM delivery_attempts WHERE ${conditions.join(" AND ")} ORDER BY created_at DESC`,
    params
  );
  return rows;
}
