import { query } from "../lib/db.js";
import { logAuditEvent } from "../utils/logger.js";

// Writes to BOTH the queryable audit_logs table (for compliance queries like
// "show every change to patient X") and the existing file-based JSON logger
// (kept as-is — it's a reasonable operational log and other tooling may
// already depend on its file location). This function is the single place
// that should be called for domain-level audit events; HTTP-level audit
// (auditMiddleware) calls it too, so both paths converge here.
export async function recordAuditEvent({
  hospitalId = null,
  actorStaffId = null,
  actorRole = null,
  action,
  resourceType,
  resourceId = null,
  outcome = "success",
  requestId = null,
  ip = null,
  metadata = null,
}) {
  logAuditEvent({
    hospitalId,
    actorStaffId,
    actorRole,
    action,
    resourceType,
    resourceId,
    outcome,
    requestId,
    ip,
    metadata,
  });

  try {
    await query(
      `INSERT INTO audit_logs
        (hospital_id, actor_staff_id, actor_role, action, resource_type, resource_id, outcome, request_id, ip, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [
        hospitalId,
        actorStaffId,
        actorRole,
        action,
        resourceType,
        resourceId,
        outcome,
        requestId,
        ip,
        metadata ? JSON.stringify(metadata) : null,
      ]
    );
  } catch (err) {
    // Audit logging must never take down the request it's observing.
    // The file-based log above still captured the event.
    // eslint-disable-next-line no-console
    console.error("Failed to write audit_logs row:", err.message);
  }
}
