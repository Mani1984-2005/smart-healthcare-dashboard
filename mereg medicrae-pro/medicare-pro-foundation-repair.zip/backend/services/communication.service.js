import { getCommunicationQueue, communicationJobId } from "../queue/communicationQueue.js";
import { recordDeliveryAttempt } from "./deliveryAttempt.service.js";
import { getProvider } from "../providers/index.js";

const BACKOFF_MS = 2000;
const MAX_RETRIES = 3;

// The one place any domain service (appointment, laboratory, billing, OTP,
// telemedicine, consent, escalation) reaches to send something externally.
// Records a QUEUED delivery_attempt immediately (so "we tried" is durable
// even if the process crashes before the worker picks the job up), then
// enqueues the actual send as a BullMQ job — the HTTP/provider call itself
// always happens in the worker process, never inline in an API request.
export async function enqueueCommunication({
  hospitalId,
  eventId = null,
  eventType,
  channel,
  recipientType,
  recipientStaffId = null,
  recipientPatientId = null,
  to,
  correlationId,
  templatePayload = {},
  priority = "NORMAL",
  delayMs = 0,
  jobIdSuffix = null,
}) {
  if (!to) {
    // No phone number to deliver to (e.g. a staff member with no phone on
    // file) — record why, but do not throw. External delivery is
    // best-effort/additive; the in-app notification (Phase 1) already
    // covers this recipient.
    await recordDeliveryAttempt({
      hospitalId,
      eventId,
      recipientType,
      recipientStaffId,
      recipientPatientId,
      channel,
      provider: "none",
      status: "SKIPPED_NO_RECIPIENT",
      error: "No phone number on file for this recipient",
      correlationId,
    });
    return null;
  }

  const provider = getProvider(channel);
  const deliveryAttemptId = await recordDeliveryAttempt({
    hospitalId,
    eventId,
    recipientType,
    recipientStaffId,
    recipientPatientId,
    channel,
    provider: provider.name,
    status: "QUEUED",
    correlationId,
  });

  const jobId = communicationJobId({ eventId: eventId || correlationId, channel, suffix: jobIdSuffix });

  await getCommunicationQueue().add(
    "deliver",
    {
      deliveryAttemptId,
      hospitalId,
      eventType,
      channel,
      to,
      correlationId,
      templatePayload,
    },
    {
      jobId, // idempotency: re-adding the same jobId is a no-op in BullMQ
      delay: delayMs,
      priority: { LOW: 40, NORMAL: 30, HIGH: 20, CRITICAL: 10 }[priority] ?? 30,
      attempts: MAX_RETRIES,
      backoff: { type: "exponential", delay: BACKOFF_MS },
      removeOnComplete: 100,
      removeOnFail: false, // failed jobs stay visible as the dead-letter view
    }
  );

  return deliveryAttemptId;
}
