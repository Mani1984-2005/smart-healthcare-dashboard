// Fixed-string templates only — no dynamic clinical/PHI fields are ever
// interpolated into an external message body. This is the enforcement
// mechanism for the brief's privacy requirement: not a runtime filter that
// could be bypassed, but the simple fact that these functions have no
// clinical data in scope to interpolate in the first place. Compare to
// notification.service.js's FIXED_MESSAGES for the in-app center, which
// (being inside the authenticated dashboard) does include e.g. an
// appointment status word — that distinction is deliberate: in-app is
// behind authentication, SMS/WhatsApp is not.
export const EXTERNAL_TEMPLATES = {
  "appointment.status_changed": () =>
    "MediCare Pro: There is an update to your appointment. Please check your MediCare Pro account for details.",
  "lab_order.result_ready": () =>
    "MediCare Pro: An important health update is available. Please securely review it using your MediCare Pro account.",
  "invoice.created": () =>
    "MediCare Pro: A new invoice is available on your MediCare Pro account.",
  "otp.requested": ({ code }) => `Your MediCare Pro verification code is ${code}. It expires in 5 minutes.`,
  "telemedicine.link_ready": ({ link }) =>
    `MediCare Pro: Your telemedicine consultation link is ready: ${link}`,
  "escalation.critical": () =>
    "MediCare Pro: URGENT — an item requires your immediate attention. Please check your MediCare Pro account now.",
  "escalation.critical_backup": () =>
    "MediCare Pro: URGENT (ESCALATED) — an unacknowledged critical item requires immediate attention.",
};

export function renderTemplate(eventType, payload = {}) {
  const builder = EXTERNAL_TEMPLATES[eventType];
  if (!builder) {
    // Fail closed: an unrecognized event type gets no external message
    // rather than a guessed/generic one that might leak something later if
    // this function is ever extended carelessly.
    return null;
  }
  return builder(payload);
}
