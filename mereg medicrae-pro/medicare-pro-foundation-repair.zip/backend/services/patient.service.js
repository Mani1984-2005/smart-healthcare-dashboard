import { randomUUID } from "crypto";
import { query } from "../lib/db.js";
import { NotFoundError, ConflictError } from "../lib/errors.js";

function generatePatientCode() {
  return `PT-${Date.now().toString(36).toUpperCase()}`;
}

function toPublicPatient(row) {
  if (!row) return null;
  return {
    id: row.id,
    patientCode: row.patient_code,
    firstName: row.first_name,
    lastName: row.last_name,
    dateOfBirth: row.date_of_birth,
    gender: row.gender,
    phone: row.phone,
    email: row.email,
    emergencyContactName: row.emergency_contact_name,
    emergencyContactPhone: row.emergency_contact_phone,
    isActive: row.is_active,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

// TENANT SCOPING: hospitalId is always the first argument, always sourced
// from req.identity.hospitalId by the controller — never from request body,
// query, or params. Every query below filters by it.
export async function listPatients(hospitalId, { search = "", page = 1, limit = 20 } = {}) {
  const offset = (page - 1) * limit;
  const params = [hospitalId];
  const conditions = ["hospital_id = $1", "is_active = TRUE"];

  if (search) {
    params.push(`%${search}%`);
    conditions.push(
      `(first_name ILIKE $${params.length} OR last_name ILIKE $${params.length} OR patient_code ILIKE $${params.length} OR phone ILIKE $${params.length})`
    );
  }
  const where = `WHERE ${conditions.join(" AND ")}`;

  params.push(limit, offset);
  const [rows, count] = await Promise.all([
    query(
      `SELECT * FROM patients ${where} ORDER BY last_name, first_name LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    ),
    query(`SELECT COUNT(*) FROM patients ${where}`, params.slice(0, params.length - 2)),
  ]);

  return {
    patients: rows.rows.map(toPublicPatient),
    total: parseInt(count.rows[0].count, 10),
    page: Number(page),
    limit: Number(limit),
  };
}

// A cross-tenant lookup (real ID, wrong hospital) returns NotFoundError
// (404), not a 403 — deliberately, so a request never confirms that a
// patient exists in a hospital the caller doesn't belong to. See
// TENANT_ISOLATION_DESIGN.md.
export async function getPatientById(hospitalId, id) {
  const { rows } = await query(`SELECT * FROM patients WHERE id = $1 AND hospital_id = $2`, [id, hospitalId]);
  if (!rows[0]) throw new NotFoundError("Patient not found");
  return toPublicPatient(rows[0]);
}

export async function createPatient(hospitalId, data) {
  const patientCode = generatePatientCode();
  try {
    const { rows } = await query(
      `INSERT INTO patients
        (id, hospital_id, patient_code, first_name, last_name, date_of_birth, gender, phone, email,
         emergency_contact_name, emergency_contact_phone)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
       RETURNING *`,
      [
        randomUUID(),
        hospitalId,
        patientCode,
        data.firstName,
        data.lastName,
        data.dateOfBirth,
        data.gender ?? null,
        data.phone,
        data.email ?? null,
        data.emergencyContactName ?? null,
        data.emergencyContactPhone ?? null,
      ]
    );
    return toPublicPatient(rows[0]);
  } catch (err) {
    if (err.code === "23505") {
      throw new ConflictError("A patient with this identifier already exists");
    }
    throw err;
  }
}

export async function updatePatient(hospitalId, id, data) {
  const allowed = [
    ["firstName", "first_name"],
    ["lastName", "last_name"],
    ["dateOfBirth", "date_of_birth"],
    ["gender", "gender"],
    ["phone", "phone"],
    ["email", "email"],
    ["emergencyContactName", "emergency_contact_name"],
    ["emergencyContactPhone", "emergency_contact_phone"],
  ];
  const fields = [];
  const values = [];
  for (const [key, column] of allowed) {
    if (data[key] !== undefined) {
      values.push(data[key]);
      fields.push(`${column} = $${values.length}`);
    }
  }
  if (!fields.length) return getPatientById(hospitalId, id);

  values.push(id, hospitalId);
  const { rows } = await query(
    `UPDATE patients SET ${fields.join(", ")}, updated_at = now()
     WHERE id = $${values.length - 1} AND hospital_id = $${values.length} RETURNING *`,
    values
  );
  if (!rows[0]) throw new NotFoundError("Patient not found");
  return toPublicPatient(rows[0]);
}

// Soft delete only — patient records are never hard-deleted.
export async function deactivatePatient(hospitalId, id) {
  const { rows } = await query(
    `UPDATE patients SET is_active = FALSE, updated_at = now() WHERE id = $1 AND hospital_id = $2 RETURNING id`,
    [id, hospitalId]
  );
  if (!rows[0]) throw new NotFoundError("Patient not found");
}
