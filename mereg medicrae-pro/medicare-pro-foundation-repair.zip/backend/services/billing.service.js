import { randomUUID } from "crypto";
import { withTransaction, query } from "../lib/db.js";
import { NotFoundError, ValidationError } from "../lib/errors.js";
import { emitEvent } from "./notification.service.js";

function generateInvoiceCode() {
  return `INV-${Date.now().toString(36).toUpperCase()}`;
}

function toPublicInvoice(row, items = []) {
  return {
    id: row.id,
    invoiceCode: row.invoice_code,
    patientId: row.patient_id,
    status: row.status,
    totalAmount: Number(row.total_amount),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    items: items.map((i) => ({
      id: i.id,
      serviceName: i.service_name,
      category: i.category,
      quantity: i.quantity,
      unitPrice: Number(i.unit_price),
      amount: Number(i.amount),
    })),
  };
}

// TENANT SCOPING: hospitalId is always the first argument, sourced only from
// req.identity.hospitalId. Every query filters invoices by it directly;
// invoice_items are scoped transitively (always fetched by invoice_id after
// the parent invoice's tenant has already been checked) — see schema.prisma
// comment on InvoiceItem for why it has no hospital_id column of its own.
export async function listInvoices(hospitalId, { patientId, status, page = 1, limit = 20 } = {}) {
  const params = [hospitalId];
  const conditions = ["hospital_id = $1"];
  if (patientId) {
    params.push(patientId);
    conditions.push(`patient_id = $${params.length}`);
  }
  if (status) {
    params.push(status);
    conditions.push(`status = $${params.length}`);
  }
  const where = `WHERE ${conditions.join(" AND ")}`;
  const offset = (page - 1) * limit;
  params.push(limit, offset);

  const { rows } = await query(
    `SELECT * FROM invoices ${where} ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params
  );
  return { invoices: rows.map((r) => toPublicInvoice(r, [])) };
}

export async function getInvoiceById(hospitalId, id) {
  const { rows } = await query(`SELECT * FROM invoices WHERE id = $1 AND hospital_id = $2`, [id, hospitalId]);
  if (!rows[0]) throw new NotFoundError("Invoice not found");
  const { rows: items } = await query(`SELECT * FROM invoice_items WHERE invoice_id = $1`, [id]);
  return toPublicInvoice(rows[0], items);
}

export async function getSummary(hospitalId) {
  const { rows } = await query(
    `SELECT status, COUNT(*)::int AS count, COALESCE(SUM(total_amount), 0) AS total
     FROM invoices WHERE hospital_id = $1 GROUP BY status`,
    [hospitalId]
  );
  return {
    byStatus: rows.map((r) => ({ status: r.status, count: r.count, total: Number(r.total) })),
  };
}

export async function createInvoice(hospitalId, { patientId, items = [] }) {
  if (!Array.isArray(items) || items.length === 0) {
    throw new ValidationError("At least one invoice item is required");
  }

  return withTransaction(async (client) => {
    // Cross-entity tenant check: the patient this invoice is being created
    // for must belong to the SAME hospital as the caller. Without this, a
    // valid Hospital A billing admin could create an invoice referencing a
    // real Hospital B patient UUID (guessed or enumerated) — the invoice
    // itself would carry hospital_id=A, but would illegitimately link to
    // Hospital B's patient data. This is the check that closes that gap.
    const patientCheck = await client.query(
      `SELECT id FROM patients WHERE id = $1 AND hospital_id = $2`,
      [patientId, hospitalId]
    );
    if (!patientCheck.rows[0]) {
      throw new NotFoundError("Patient not found");
    }

    const invoiceId = randomUUID();
    const invoiceCode = generateInvoiceCode();
    const totalAmount = items.reduce(
      (sum, item) => sum + Number(item.unitPrice) * Number(item.quantity ?? 1),
      0
    );

    const { rows } = await client.query(
      `INSERT INTO invoices (id, hospital_id, invoice_code, patient_id, status, total_amount)
       VALUES ($1, $2, $3, $4, 'DRAFT', $5) RETURNING *`,
      [invoiceId, hospitalId, invoiceCode, patientId, totalAmount]
    );

    const savedItems = [];
    for (const item of items) {
      const quantity = Number(item.quantity ?? 1);
      const unitPrice = Number(item.unitPrice);
      const amount = quantity * unitPrice;
      const { rows: itemRows } = await client.query(
        `INSERT INTO invoice_items (id, invoice_id, service_name, category, quantity, unit_price, amount)
         VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
        [randomUUID(), invoiceId, item.serviceName, item.category ?? "Other", quantity, unitPrice, amount]
      );
      savedItems.push(itemRows[0]);
    }

    return toPublicInvoice(rows[0], savedItems);
  }).then((invoice) => {
    // Notification emission — after the transaction has committed
    // successfully. Never propagated into the caller on failure.
    emitEvent({
      hospitalId,
      eventType: "invoice.created",
      resourceType: "invoices",
      resourceId: invoice.id,
      payload: { patientId: invoice.patientId, totalAmount: invoice.totalAmount },
    });
    return invoice;
  });
}

export async function updateInvoiceStatus(hospitalId, id, status) {
  const allowed = ["DRAFT", "ISSUED", "PAID", "PARTIALLY_PAID", "VOID"];
  if (!allowed.includes(status)) {
    throw new ValidationError(`status must be one of: ${allowed.join(", ")}`);
  }
  const { rows } = await query(
    `UPDATE invoices SET status = $1, updated_at = now() WHERE id = $2 AND hospital_id = $3 RETURNING *`,
    [status, id, hospitalId]
  );
  if (!rows[0]) throw new NotFoundError("Invoice not found");
  return getInvoiceById(hospitalId, id);
}

export async function voidInvoice(hospitalId, id) {
  const { rows } = await query(
    `UPDATE invoices SET status = 'VOID', updated_at = now() WHERE id = $1 AND hospital_id = $2 RETURNING id`,
    [id, hospitalId]
  );
  if (!rows[0]) throw new NotFoundError("Invoice not found");
}
