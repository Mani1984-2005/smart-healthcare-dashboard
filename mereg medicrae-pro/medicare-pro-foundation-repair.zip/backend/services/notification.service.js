import { randomUUID } from "crypto";
import { query } from "../lib/db.js";
import { enqueueCommunication } from "./communication.service.js";

// Phase 1 (in-app) + Notifications Final (external, phone-first) service.
// See NOTIFICATIONS_PHASE1_PLAN.md and NOTIFICATIONS_FINAL_PLAN.md. Every
// function here is tenant-scoped: the caller always supplies hospitalId
// (sourced from req.identity.hospitalId upstream, same as every other
// domain), and every write includes it.
//
// emitEvent() does three things now, in order: (1) writes the outbox row,
// (2) delivers in-app notifications synchronously (unchanged from Phase 1),
// (3) enqueues external SMS/WhatsApp jobs onto the real BullMQ queue for
// phone-eligible recipients of phone-first event types — the actual
// provider call happens in workers/communicationWorker.js, a separate
// process, never inline here.

const FIXED_MESSAGES = {
  "appointment.status_changed": (payload) => ({
    title: "Appointment status updated",
    body: `Appointment status changed to ${payload.status}.`,
  }),
  "lab_order.result_ready": () => ({
    title: "Lab result ready",
    body: "A lab result is ready for review.",
  }),
  "invoice.created": (payload) => ({
    title: "New invoice",
    body: `An invoice for $${Number(payload.totalAmount ?? 0).toFixed(2)} has been created.`,
  }),
};

// Event types that trigger external (SMS/WhatsApp) delivery in addition to
// the in-app center — the "phone-first" set named in the brief.
const PHONE_FIRST_EVENTS = new Set(["appointment.status_changed", "lab_order.result_ready", "invoice.created"]);

async function insertNotification({ hospitalId, recipientStaffId, recipientPatientId, eventType, resourceType, resourceId, payload }) {
  const messageBuilder = FIXED_MESSAGES[eventType];
  const { title, body } = messageBuilder ? messageBuilder(payload || {}) : { title: eventType, body: null };
  await query(
    `INSERT INTO notifications
      (id, hospital_id, recipient_staff_id, recipient_patient_id, event_type, title, body, resource_type, resource_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
    [randomUUID(), hospitalId, recipientStaffId ?? null, recipientPatientId ?? null, eventType, title, body, resourceType, resourceId]
  );
}

// Minimal, explicit per-event-type recipient resolution — NOT a generic
// policy/rules engine (that's future Care Coordination work). Every
// resolver here queries WITHIN the given hospitalId only. Returns phone
// numbers too (needed for the external/phone-first delivery step below) —
// a recipient with no phone on file simply gets `phone: null`, handled
// gracefully by communication.service.js (SKIPPED_NO_RECIPIENT, not an error).
async function resolveRecipients(hospitalId, eventType, payload) {
  const recipients = []; // { recipientStaffId, phone } | { recipientPatientId, phone }

  if (eventType === "appointment.status_changed") {
    if (payload.patientId) {
      const p = await query("SELECT id, phone FROM patients WHERE id = $1 AND hospital_id = $2 AND firebase_uid IS NOT NULL", [payload.patientId, hospitalId]);
      if (p.rows[0]) recipients.push({ recipientPatientId: p.rows[0].id, phone: p.rows[0].phone });
    }
    if (payload.doctorId) {
      const d = await query("SELECT id, phone FROM staff WHERE id = $1 AND hospital_id = $2", [payload.doctorId, hospitalId]);
      if (d.rows[0]) recipients.push({ recipientStaffId: d.rows[0].id, phone: d.rows[0].phone });
    }
  }

  if (eventType === "lab_order.result_ready") {
    if (payload.handledById) {
      const s = await query("SELECT id, phone FROM staff WHERE id = $1 AND hospital_id = $2", [payload.handledById, hospitalId]);
      if (s.rows[0]) recipients.push({ recipientStaffId: s.rows[0].id, phone: s.rows[0].phone });
    }
    if (payload.patientId) {
      const p = await query("SELECT id, phone FROM patients WHERE id = $1 AND hospital_id = $2 AND firebase_uid IS NOT NULL", [payload.patientId, hospitalId]);
      if (p.rows[0]) recipients.push({ recipientPatientId: p.rows[0].id, phone: p.rows[0].phone });
    }
  }

  if (eventType === "invoice.created") {
    if (payload.patientId) {
      const p = await query("SELECT id, phone FROM patients WHERE id = $1 AND hospital_id = $2 AND firebase_uid IS NOT NULL", [payload.patientId, hospitalId]);
      if (p.rows[0]) recipients.push({ recipientPatientId: p.rows[0].id, phone: p.rows[0].phone });
    }
  }

  return recipients;
}

// Called by existing services immediately after their own write succeeds.
// Never throws into the caller — a notification failure must not roll back
// or fail the underlying domain action (booking an appointment must succeed
// even if notification delivery has a problem). Errors are logged, not
// propagated — mirrors the same "audit must never take down the request"
// principle already used in services/audit.service.js.
export async function emitEvent({ hospitalId, eventType, resourceType, resourceId, payload, priority = "NORMAL" }) {
  try {
    const eventId = randomUUID();
    await query(
      `INSERT INTO notification_events (id, hospital_id, event_type, resource_type, resource_id, payload, priority)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [eventId, hospitalId, eventType, resourceType, resourceId, payload ? JSON.stringify(payload) : null, priority]
    );

    const recipients = await resolveRecipients(hospitalId, eventType, payload || {});
    for (const recipient of recipients) {
      await insertNotification({ hospitalId, eventType, resourceType, resourceId, payload, ...recipient });

      if (PHONE_FIRST_EVENTS.has(eventType)) {
        const recipientType = recipient.recipientStaffId ? "staff" : "patient";
        await enqueueCommunication({
          hospitalId,
          eventId,
          eventType,
          channel: "sms",
          recipientType,
          recipientStaffId: recipient.recipientStaffId ?? null,
          recipientPatientId: recipient.recipientPatientId ?? null,
          to: recipient.phone,
          correlationId: `${eventId}:${recipient.recipientStaffId || recipient.recipientPatientId}`,
          templatePayload: payload || {},
          priority,
        });
      }
    }

    await query(`UPDATE notification_events SET processed_at = now() WHERE id = $1`, [eventId]);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error("emitEvent failed (notification delivery, not the underlying action):", err.message);
  }
}

function toPublicNotification(row) {
  return {
    id: row.id,
    eventType: row.event_type,
    title: row.title,
    body: row.body,
    resourceType: row.resource_type,
    resourceId: row.resource_id,
    isRead: row.is_read,
    createdAt: row.created_at,
  };
}

// Tenant + recipient scoped: identity is always { hospitalId, type, id } —
// a staff member only ever sees their own staff-addressed notifications, a
// patient only their own patient-addressed ones, within their own hospital.
export async function listMyNotifications(hospitalId, identity, { unreadOnly = false, page = 1, limit = 20 } = {}) {
  const recipientColumn = identity.type === "staff" ? "recipient_staff_id" : "recipient_patient_id";
  const params = [hospitalId, identity.id];
  const conditions = ["hospital_id = $1", `${recipientColumn} = $2`];
  if (unreadOnly) conditions.push("is_read = FALSE");
  const where = `WHERE ${conditions.join(" AND ")}`;
  const offset = (page - 1) * limit;
  params.push(limit, offset);

  const { rows } = await query(
    `SELECT * FROM notifications ${where} ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params
  );
  return { notifications: rows.map(toPublicNotification) };
}

export async function markAsRead(hospitalId, identity, notificationId) {
  const recipientColumn = identity.type === "staff" ? "recipient_staff_id" : "recipient_patient_id";
  const { rows } = await query(
    `UPDATE notifications SET is_read = TRUE
     WHERE id = $1 AND hospital_id = $2 AND ${recipientColumn} = $3 RETURNING *`,
    [notificationId, hospitalId, identity.id]
  );
  return rows[0] ? toPublicNotification(rows[0]) : null;
}
