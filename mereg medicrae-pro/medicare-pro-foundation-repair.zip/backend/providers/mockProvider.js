// Channel adapter abstraction. Every provider (mock or real) implements the
// same shape: send({ to, body }) -> { providerMessageId, status }.
// Business logic never imports a specific vendor SDK — only this interface,
// selected by env var. See providers/index.js for selection logic.
//
// DEVELOPMENT/TEST default: MockProvider. It never makes a network call and
// never sends a real message — it logs and returns a synthetic success,
// exactly per the brief's "do not send real messages unless explicitly
// configured and approved" requirement. This sandbox never sets real
// provider credentials, so MockProvider is the only adapter actually
// exercised or verified here.

export class MockProvider {
  constructor(channel) {
    this.channel = channel;
    this.name = `mock-${channel}`;
  }

  async send({ to, body, correlationId }) {
    // eslint-disable-next-line no-console
    console.log(`[MockProvider:${this.channel}] to=${to} correlationId=${correlationId} body="${body}"`);
    return {
      providerMessageId: `mock-${this.channel}-${correlationId}`,
      status: "SENT",
    };
  }
}

// A forced-failure mock, used only by tests to exercise retry/dead-letter
// behavior without needing a real provider outage.
export class FailingMockProvider {
  constructor(channel) {
    this.channel = channel;
    this.name = `failing-mock-${channel}`;
  }

  async send() {
    const err = new Error("Simulated provider failure");
    err.isProviderFailure = true;
    throw err;
  }
}
