import { MockProvider } from "./mockProvider.js";
import { TwilioSmsAdapter, TwilioVoiceAdapter } from "./twilioAdapter.js";

// Selects a provider per channel from environment configuration. Mock is
// the default for every channel — a real provider requires an explicit env
// var AND real credentials, neither of which this sandbox ever sets. This
// is the one place a real vendor SDK/adapter would be wired in; nothing
// else in the codebase should import a vendor adapter directly.
//
// TENANT-AWARE STRUCTURE: getProvider() takes hospitalId so that, in a real
// multi-hospital deployment where different hospitals contract with
// different SMS vendors, per-hospital provider config can be looked up here
// without changing any calling code. In THIS environment every hospital
// resolves to the same env-configured (mock) provider — there is no
// per-hospital credential store built this phase (that would be a config-
// management feature beyond "provider abstraction," and isn't named in the
// brief). This is flagged explicitly, not silently assumed away.
export function getProvider(channel /* , hospitalId */) {
  const envVar = { sms: "SMS_PROVIDER", whatsapp: "WHATSAPP_PROVIDER", voice: "VOICE_PROVIDER" }[channel];
  const mode = process.env[envVar] || "mock";

  if (mode === "mock") {
    return new MockProvider(channel);
  }

  if (mode === "twilio") {
    const config = {
      accountSid: process.env.TWILIO_ACCOUNT_SID,
      authToken: process.env.TWILIO_AUTH_TOKEN,
      fromNumber: process.env.TWILIO_FROM_NUMBER,
    };
    if (channel === "sms") return new TwilioSmsAdapter(config);
    if (channel === "whatsapp") return new TwilioSmsAdapter({ ...config, whatsapp: true });
    if (channel === "voice") return new TwilioVoiceAdapter({ ...config, twimlUrl: process.env.TWILIO_VOICE_TWIML_URL });
  }

  throw new Error(`Unknown provider mode "${mode}" for channel "${channel}"`);
}
