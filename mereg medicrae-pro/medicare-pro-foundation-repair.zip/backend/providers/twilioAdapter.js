// Twilio-shaped SMS/WhatsApp adapter — real REST API call shape (Basic Auth
// with Account SID/Auth Token, form-encoded POST to the Messages resource).
//
// HONESTY NOTE (do not remove): this adapter's HTTP call has never been
// executed against Twilio's real API in this environment. This sandbox's
// network egress is restricted to an explicit domain allowlist that does
// NOT include api.twilio.com — so even with real credentials, this code
// cannot be exercised here. It is included because the brief asks for a
// "replaceable provider layer... structurally real, not hard-coded to one
// vendor" — this is that structure, not a verified integration. See
// NOTIFICATIONS_FINAL_COMPLETION_REPORT.md, "Provider verification status."
export class TwilioSmsAdapter {
  constructor({ accountSid, authToken, fromNumber, whatsapp = false } = {}) {
    if (!accountSid || !authToken || !fromNumber) {
      throw new Error(
        "TwilioSmsAdapter requires TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_FROM_NUMBER"
      );
    }
    this.accountSid = accountSid;
    this.authToken = authToken;
    this.fromNumber = fromNumber;
    this.whatsapp = whatsapp;
    this.name = whatsapp ? "twilio-whatsapp" : "twilio-sms";
  }

  async send({ to, body }) {
    const url = `https://api.twilio.com/2010-04-01/Accounts/${this.accountSid}/Messages.json`;
    const params = new URLSearchParams({
      To: this.whatsapp ? `whatsapp:${to}` : to,
      From: this.whatsapp ? `whatsapp:${this.fromNumber}` : this.fromNumber,
      Body: body,
    });

    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Basic ${Buffer.from(`${this.accountSid}:${this.authToken}`).toString("base64")}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params.toString(),
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const err = new Error(data.message || `Twilio API error (${response.status})`);
      err.providerResponse = data;
      throw err;
    }
    return { providerMessageId: data.sid, status: "SENT" };
  }
}

// Voice calls follow the same shape (Twilio Calls resource) — same honesty
// note applies: structurally real, never executed against a live network
// here.
export class TwilioVoiceAdapter {
  constructor({ accountSid, authToken, fromNumber, twimlUrl } = {}) {
    if (!accountSid || !authToken || !fromNumber || !twimlUrl) {
      throw new Error(
        "TwilioVoiceAdapter requires TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER, and TWILIO_VOICE_TWIML_URL"
      );
    }
    this.accountSid = accountSid;
    this.authToken = authToken;
    this.fromNumber = fromNumber;
    this.twimlUrl = twimlUrl;
    this.name = "twilio-voice";
  }

  async send({ to }) {
    const url = `https://api.twilio.com/2010-04-01/Accounts/${this.accountSid}/Calls.json`;
    const params = new URLSearchParams({ To: to, From: this.fromNumber, Url: this.twimlUrl });

    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Basic ${Buffer.from(`${this.accountSid}:${this.authToken}`).toString("base64")}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params.toString(),
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const err = new Error(data.message || `Twilio API error (${response.status})`);
      err.providerResponse = data;
      throw err;
    }
    return { providerMessageId: data.sid, status: "SENT" };
  }
}
