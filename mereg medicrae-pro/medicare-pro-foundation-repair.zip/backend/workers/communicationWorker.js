import "dotenv/config";
import { Worker } from "bullmq";
import { getRedisConnection } from "../queue/communicationQueue.js";
import { getProvider } from "../providers/index.js";
import { renderTemplate } from "../services/messageTemplates.js";
import { updateDeliveryAttemptStatus } from "../services/deliveryAttempt.service.js";
import { handleEscalationCheck } from "../services/escalation.service.js";

// Runs in a SEPARATE process from the API server (started via `node
// workers/communicationWorker.js` or imported and started explicitly in
// tests) — communication work never runs inline inside an HTTP request.
// This is what makes "a failed SMS never rolls back an appointment" true
// structurally, not just by convention: by the time this worker even sees
// the job, the appointment/invoice/lab-order write has already committed
// and the API response has already been sent.
export function startCommunicationWorker() {
  const worker = new Worker(
    "communication",
    async (job) => {
      if (job.name === "escalation-check") {
        return handleEscalationCheck(job.data);
      }

      const { deliveryAttemptId, channel, to, eventType, templatePayload } = job.data;
      const provider = getProvider(channel);
      const body = renderTemplate(eventType, templatePayload);

      if (!body) {
        await updateDeliveryAttemptStatus(deliveryAttemptId, "FAILED", `No template for event type "${eventType}"`);
        throw new Error(`No template for event type "${eventType}"`);
      }

      try {
        const result = await provider.send({ to, body, correlationId: job.data.correlationId });
        await updateDeliveryAttemptStatus(deliveryAttemptId, result.status || "SENT");
        return result;
      } catch (err) {
        await updateDeliveryAttemptStatus(deliveryAttemptId, "FAILED", err.message);
        throw err; // re-throw so BullMQ applies its retry/backoff policy
      }
    },
    { connection: getRedisConnection(), concurrency: 5 }
  );

  worker.on("failed", (job, err) => {
    if (job && job.attemptsMade >= job.opts.attempts) {
      // Exhausted all retries — BullMQ leaves it in the failed set
      // (removeOnFail: false at enqueue time), which is this system's
      // dead-letter view. No second custom dead-letter table.
      // eslint-disable-next-line no-console
      console.error(`[communicationWorker] job ${job.id} dead-lettered after ${job.attemptsMade} attempts:`, err.message);
    }
  });

  return worker;
}

// Allow running as a standalone process: `node workers/communicationWorker.js`
if (process.argv[1] && process.argv[1].endsWith("communicationWorker.js")) {
  startCommunicationWorker();
  // eslint-disable-next-line no-console
  console.log("Communication worker started.");
}
