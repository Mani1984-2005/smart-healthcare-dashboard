import { Queue } from "bullmq";
import IORedis from "ioredis";

// Single Redis connection + single BullMQ queue for all external
// communication work (SMS/WhatsApp/voice + escalation delay jobs). This is
// the first and only queue infrastructure in this codebase — no prior
// Redis/BullMQ existed (confirmed across every earlier phase of this
// project), so this is not a "second competing" architecture.
let connection;
let queue;

export function getRedisConnection() {
  if (!connection) {
    connection = new IORedis(process.env.REDIS_URL || "redis://localhost:6379", {
      maxRetriesPerRequest: null, // required by BullMQ
    });
  }
  return connection;
}

export function getCommunicationQueue() {
  if (!queue) {
    queue = new Queue("communication", { connection: getRedisConnection() });
  }
  return queue;
}

// Idempotency: the BullMQ job ID is derived from event_id + channel (+ an
// optional suffix for escalation steps), so re-enqueueing the "same" piece
// of work (e.g. a retry at the caller level, not BullMQ's own retry) is a
// no-op rather than a duplicate delivery — BullMQ rejects a second add()
// with a job ID that already exists in the queue.
//
// BullMQ/Redis job IDs cannot contain ":" (it throws "Custom Id cannot
// contain :" — Bull uses colons as its own internal Redis key delimiter).
// correlationId values elsewhere in this codebase DO use colons (they're
// human-readable audit strings, e.g. "escalation:<id>:primary") — this
// function is the one place that sanitizes for BullMQ's constraint,
// keeping correlationId's own colon-based format untouched everywhere else.
export function communicationJobId({ eventId, channel, suffix }) {
  return [eventId, channel, suffix]
    .filter(Boolean)
    .join("--")
    .replace(/:/g, "_");
}
