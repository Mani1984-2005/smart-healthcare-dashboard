// LEGACY — Mongoose model, superseded by the Prisma-modeled Postgres table
// of the same purpose (see backend/prisma/schema.prisma). Kept here for
// reference only; not imported by any active route/controller after the
// Foundation Repair phase. See FOUNDATION_IMPLEMENTATION_REPORT.md.

// backend/models/Department.js
import mongoose from "mongoose";

const DepartmentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, unique: true },
    code: { type: String, required: true, trim: true, unique: true },
    description: { type: String, default: "" },
    floor: { type: String, default: "" },
    headStaff: { type: mongoose.Schema.Types.ObjectId, ref: "Staff", default: null },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export default mongoose.model("Department", DepartmentSchema);
