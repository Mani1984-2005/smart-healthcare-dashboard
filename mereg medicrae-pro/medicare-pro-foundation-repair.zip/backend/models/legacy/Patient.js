// LEGACY — Mongoose model, superseded by the Prisma-modeled Postgres table
// of the same purpose (see backend/prisma/schema.prisma). Kept here for
// reference only; not imported by any active route/controller after the
// Foundation Repair phase. See FOUNDATION_IMPLEMENTATION_REPORT.md.

