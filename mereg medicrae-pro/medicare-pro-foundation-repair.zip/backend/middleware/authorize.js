import { AuthorizationError, AuthenticationError } from "../lib/errors.js";

// Declarative, per-route RBAC — never hard-code role checks inside
// controllers. Usage: router.get('/', authenticate, resolveIdentity,
// authorize('ADMIN', 'BILLING'), controller)
export function authorize(...allowedRoles) {
  return (req, res, next) => {
    if (!req.identity) {
      return next(new AuthenticationError());
    }
    if (!allowedRoles.includes(req.identity.role)) {
      return next(
        new AuthorizationError(
          `Role '${req.identity.role}' is not permitted to perform this action`
        )
      );
    }
    next();
  };
}

// For endpoints where a PATIENT may access only their own record, but staff
// in `staffRoles` may access any patient's record. Requires :patientId (or
// :id, configurable) route param.
export function authorizeSelfOrRoles(staffRoles, paramName = "id") {
  return (req, res, next) => {
    if (!req.identity) {
      return next(new AuthenticationError());
    }
    const { role, id } = req.identity;
    const targetId = req.params[paramName];

    if (role === "PATIENT" && id === targetId) {
      return next();
    }
    if (staffRoles.includes(role)) {
      return next();
    }
    return next(new AuthorizationError());
  };
}
