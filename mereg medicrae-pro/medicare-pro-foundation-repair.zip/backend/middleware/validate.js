import { ValidationError } from "../lib/errors.js";

// Usage: router.post('/', validate({ body: schema }), controller)
// `source` is one of 'body' | 'query' | 'params'.
export default function validate(schemas) {
  return (req, res, next) => {
    for (const source of Object.keys(schemas)) {
      const result = schemas[source].safeParse(req[source]);
      if (!result.success) {
        const details = result.error.issues.map((issue) => ({
          path: issue.path.join("."),
          message: issue.message,
        }));
        return next(new ValidationError("Validation failed", details));
      }
      if (source === "query") {
        // Express 5 makes req.query a getter with no setter (it's derived
        // from req.url on read), so a plain `req.query = ...` throws
        // "Cannot set property query of #<IncomingMessage> which has only a
        // getter". Overriding the property descriptor is the supported way
        // to substitute the validated/coerced value.
        Object.defineProperty(req, "query", { value: result.data, writable: true, configurable: true });
      } else {
        req[source] = result.data;
      }
    }
    next();
  };
}
