import { recordAuditEvent } from "../services/audit.service.js";

function getActor(req) {
  // req.identity is set by resolveIdentity middleware (runs after auth).
  // Falls back gracefully if this route has no identity resolution (e.g. a
  // request that failed auth before reaching here).
  //
  // FOUND DURING TENANT-ISOLATION FREEZE VERIFICATION: hospitalId was never
  // read here or passed through to recordAuditEvent, even though
  // audit_logs.hospital_id has existed (as a nullable column) since the
  // tenant-isolation migration — every audit row, including successful,
  // fully-identity-resolved requests, was silently recording NULL. Fixed by
  // reading it from the same req.identity object actorStaffId/actorRole
  // already come from.
  const identity = req.identity;
  return {
    hospitalId: identity ? identity.hospitalId : null,
    actorStaffId: identity && identity.type === "staff" ? identity.id : null,
    actorRole: identity ? identity.role : "unauthenticated",
  };
}

function getRequestMeta(req) {
  return {
    method: req.method,
    path: req.originalUrl || req.url,
    ip: req.ip,
    userAgent: req.headers["user-agent"] || "",
    requestId: req.requestId || req.headers["x-request-id"] || "",
  };
}

function auditMiddleware(req, res, next) {
  res.on("finish", () => {
    const statusCode = res.statusCode;
    const action =
      req.method === "POST"
        ? "CREATE"
        : req.method === "PUT" || req.method === "PATCH"
        ? "UPDATE"
        : req.method === "DELETE"
        ? "DELETE"
        : "READ";

    if (["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) {
      const actor = getActor(req);
      const reqMeta = getRequestMeta(req);
      recordAuditEvent({
        hospitalId: actor.hospitalId,
        actorStaffId: actor.actorStaffId,
        actorRole: actor.actorRole,
        action,
        resourceType: (req.baseUrl || "unknown").replace(/^\//, ""),
        resourceId: req.params?.id || req.body?.id || null,
        outcome: statusCode >= 400 ? "failure" : "success",
        requestId: reqMeta.requestId,
        ip: reqMeta.ip,
        metadata: { statusCode, method: reqMeta.method, path: reqMeta.path },
      }).catch(() => {
        /* recordAuditEvent already logs failures internally */
      });
    }
  });
  next();
}

export default auditMiddleware;
