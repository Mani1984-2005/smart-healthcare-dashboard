import { resolveIdentityByFirebaseUid } from "../services/identity.service.js";
import { AuthenticationError } from "../lib/errors.js";

// Must run AFTER authMiddleware (which verifies the Firebase token and sets
// req.user). Attaches req.identity = { type, id, hospitalId, role, name, email }.
//
// A verified Firebase token alone is not enough to authorize anything in
// this system — it only proves *who signed in*, not *what platform role they
// hold* or *which hospital they belong to*. That mapping lives in Postgres
// (staff/patients), not in the token, and req.identity.hospitalId is the
// ONLY value any service should ever treat as tenant identity — never a
// client-supplied hospitalId from body/query/params (there isn't one; no
// route or validation schema accepts it).
export default async function resolveIdentity(req, res, next) {
  try {
    if (!req.user || !req.user.uid) {
      throw new AuthenticationError("No authenticated user on request");
    }

    const identity = await resolveIdentityByFirebaseUid(req.user.uid);

    if (!identity) {
      throw new AuthenticationError(
        "This account is not registered in MediCare Pro"
      );
    }
    if (!identity.isActive) {
      throw new AuthenticationError("This account has been deactivated");
    }

    req.identity = identity;
    next();
  } catch (err) {
    next(err);
  }
}
