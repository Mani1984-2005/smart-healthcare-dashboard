import { logError } from "../utils/logger.js";

export function notFound(req, res) {
  res.status(404).json({
    success: false,
    error: { code: "NOT_FOUND", message: "Route not found" },
    requestId: req.requestId,
  });
}

// Recognizes specific, well-understood body-parser (express.json()) failure
// modes and maps them to safe, correct 4xx responses instead of falling
// through to a generic 500. Found during the Foundation Final Verification
// Gate audit: malformed JSON and oversized payloads were both surfacing as
// unexplained 500s — technically not wrong (nothing crashed, no data was
// exposed), but violates "no malformed request should become an unexplained
// 500." Deliberately allow-list based (checking err.type against known
// body-parser values) rather than trusting err.status blindly, since a
// blanket "use whatever status the thrown error claims" would let an
// unrelated library that happens to set `.status` masquerade as a client
// error and hide a real server bug behind a 4xx.
function classifyBodyParserError(err) {
  if (err.type === "entity.parse.failed") {
    return { statusCode: 400, code: "INVALID_JSON", message: "Request body is not valid JSON" };
  }
  if (err.type === "entity.too.large") {
    return { statusCode: 413, code: "PAYLOAD_TOO_LARGE", message: "Request body exceeds the size limit" };
  }
  if (err.type === "encoding.unsupported") {
    return { statusCode: 415, code: "UNSUPPORTED_MEDIA_TYPE", message: "Unsupported request body encoding" };
  }
  return null;
}

// Recognizes raw PostgreSQL error codes that leak through when a service
// method doesn't (or, per Murphy's law, someday won't) catch them
// explicitly. This is defense-in-depth, not a replacement for handling
// known cases at the service layer with a specific message (see
// hospital.service.js's deleteStaff for an example) — those specific
// handlers give a better message; this generic fallback just guarantees
// that *any* constraint violation reaches the client as a clean 4xx instead
// of a raw database error wrapped in a 500.
function classifyPostgresError(err) {
  if (err.code === "23505") {
    return { statusCode: 409, code: "CONFLICT", message: "This record conflicts with an existing one" };
  }
  if (err.code === "23503") {
    return { statusCode: 409, code: "CONFLICT", message: "This action is blocked by a related record" };
  }
  if (err.code === "23502") {
    return { statusCode: 400, code: "VALIDATION_ERROR", message: "A required field was missing" };
  }
  if (err.code === "22P02") {
    // invalid_text_representation — e.g. a malformed UUID/enum value that
    // slipped past Zod validation (or a route with no validation on that
    // field) and hit Postgres directly.
    return { statusCode: 400, code: "VALIDATION_ERROR", message: "One or more values were not in the expected format" };
  }
  return null;
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  const isAppError = Boolean(err.isAppError);
  const bodyParserError = !isAppError ? classifyBodyParserError(err) : null;
  const postgresError = !isAppError && !bodyParserError ? classifyPostgresError(err) : null;
  const known = bodyParserError || postgresError;

  const statusCode = isAppError ? err.statusCode : known ? known.statusCode : 500;
  const code = isAppError ? err.code : known ? known.code : "INTERNAL_ERROR";
  const message = isAppError ? err.message : known ? known.message : "An unexpected error occurred";

  // Log full detail server-side only. Never send stack traces, raw database
  // errors, or secrets to the client.
  logError("request_failed", {
    requestId: req.requestId,
    path: req.originalUrl,
    method: req.method,
    statusCode,
    code,
    message: err.message,
    stack: process.env.NODE_ENV === "production" ? undefined : err.stack,
  });

  const body = {
    success: false,
    error: { code, message },
    requestId: req.requestId,
  };

  if (isAppError && err.details) {
    body.error.details = err.details;
  }

  res.status(statusCode).json(body);
}

