// FOUNDATION REPAIR FIX: config/firebaseAdmin.js now exports the Auth
// instance directly (see that file's header comment) rather than the CJS
// `admin` namespace object, so this calls `auth.verifyIdToken(...)`
// directly instead of `admin.auth().verifyIdToken(...)`.
import auth from "../config/firebaseAdmin.js";

const authenticate = async (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({
      success: false,
      message: "Unauthorised: No Bearer token provided",
    });
  }

  const idToken = authHeader.split("Bearer ")[1];

  try {
    const decodedToken = await auth.verifyIdToken(idToken);
    req.user = decodedToken; // attach decoded claims to request
    next();
  } catch (error) {
    console.error("Firebase token verification failed:", error.message);

    return res.status(401).json({
      success: false,
      message: "Unauthorised: Invalid or expired token",
    });
  }
};

export default authenticate;
