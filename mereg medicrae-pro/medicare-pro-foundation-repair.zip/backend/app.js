// Express app factory — separated from server.js so tests can import the
// app directly (via supertest) without binding a real port or triggering
// process-level listen/shutdown wiring. server.js is the only file that
// calls app.listen().
import "dotenv/config";

import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

import routes from "./routes/index.js";
import healthRoutes from "./routes/healthRoutes.js";
import requestId from "./middleware/requestId.js";
import auditMiddleware from "./middleware/auditMiddleware.js";
import { notFound, errorHandler } from "./middleware/errorHandler.js";

const app = express();

app.use(helmet());

const corsOrigins = (process.env.CORS_ORIGINS || "http://localhost:5173")
  .split(",")
  .map((o) => o.trim())
  .filter(Boolean);
app.use(cors({ origin: corsOrigins, credentials: true }));

app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 300,
    standardHeaders: true,
    legacyHeaders: false,
  })
);

app.use(express.json({ limit: "1mb" }));
app.use(requestId);
app.use(auditMiddleware);

app.get("/", (req, res) => {
  res.json({ success: true, message: "MediCare Pro Backend Running" });
});

// Single consolidated router entry point (see routes/index.js). The
// previously-separate, unauthenticated `./routes/patients.js` raw-SQL route
// has been removed — it is superseded by the Prisma-schema-shaped,
// authenticated /api/patients routes below.
app.use("/api", routes);

// Back-compat alias — some earlier frontend code may call /health directly
// rather than /api/health. Both remain available.
app.use("/health", healthRoutes);

app.use(notFound);
app.use(errorHandler);

export default app;
