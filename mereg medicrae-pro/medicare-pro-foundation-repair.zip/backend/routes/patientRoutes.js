import express from "express";
import authenticate from "../middleware/authMiddleware.js";
import resolveIdentity from "../middleware/resolveIdentity.js";
import { authorize, authorizeSelfOrRoles } from "../middleware/authorize.js";
import validate from "../middleware/validate.js";
import * as patientController from "../controllers/patient.controller.js";
import {
  createPatientSchema,
  updatePatientSchema,
  listPatientsQuerySchema,
  patientIdParamSchema,
} from "../validations/patient.validation.js";

const router = express.Router();

const CLINICAL_STAFF = ["ADMIN", "DOCTOR", "STAFF", "LAB", "PHARMACY", "BILLING", "MANAGEMENT"];

router.use(authenticate, resolveIdentity);

router.get(
  "/",
  authorize(...CLINICAL_STAFF),
  validate({ query: listPatientsQuerySchema }),
  patientController.list
);

router.get(
  "/:id",
  validate({ params: patientIdParamSchema }),
  authorizeSelfOrRoles(CLINICAL_STAFF, "id"),
  patientController.getById
);

router.post(
  "/",
  authorize("ADMIN", "STAFF"),
  validate({ body: createPatientSchema }),
  patientController.create
);

router.put(
  "/:id",
  authorize("ADMIN", "STAFF", "DOCTOR"),
  validate({ params: patientIdParamSchema, body: updatePatientSchema }),
  patientController.update
);

router.delete(
  "/:id",
  authorize("ADMIN"),
  validate({ params: patientIdParamSchema }),
  patientController.deactivate
);

export default router;
