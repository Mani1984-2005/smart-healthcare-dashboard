import express from "express";
const router = express.Router();
import * as billingController from "../controllers/billing.controller.js";
import authenticate from "../middleware/authMiddleware.js";
import resolveIdentity from "../middleware/resolveIdentity.js";
import { authorize } from "../middleware/authorize.js";
import validate from "../middleware/validate.js";
import {
  createInvoiceSchema,
  updateInvoiceStatusSchema,
  invoiceIdParamSchema,
  listInvoicesQuerySchema,
} from "../validations/billing.validation.js";

const BILLING_ROLES = ["ADMIN", "BILLING", "MANAGEMENT"];

router.use(authenticate, resolveIdentity, authorize(...BILLING_ROLES));

router.get("/summary", billingController.getSummary);
router.get("/invoices", validate({ query: listInvoicesQuerySchema }), billingController.getInvoices);
router.get("/invoices/:id", validate({ params: invoiceIdParamSchema }), billingController.getInvoiceById);
router.post("/invoices", validate({ body: createInvoiceSchema }), billingController.createInvoice);
router.put(
  "/invoices/:id",
  validate({ params: invoiceIdParamSchema, body: updateInvoiceStatusSchema }),
  billingController.updateInvoice
);
router.delete("/invoices/:id", validate({ params: invoiceIdParamSchema }), billingController.deleteInvoice);

export default router;
