import express from "express";
import authenticate from "../middleware/authMiddleware.js";
import resolveIdentity from "../middleware/resolveIdentity.js";
import { authorize } from "../middleware/authorize.js";
import validate from "../middleware/validate.js";
import * as telemedicineController from "../controllers/telemedicine.controller.js";
import { createSessionSchema, sessionIdParamSchema, validateTokenSchema } from "../validations/telemedicine.validation.js";

const CLINICAL_STAFF = ["ADMIN", "DOCTOR", "STAFF", "MANAGEMENT"];
const router = express.Router();
router.use(authenticate, resolveIdentity);

router.post("/sessions", authorize(...CLINICAL_STAFF), validate({ body: createSessionSchema }), telemedicineController.create);
// Token validation is intentionally open to ANY authenticated identity
// (staff or patient) — the token itself, not the caller's role, is the
// access control here (the whole point of a secure link). Unauthorized
// access prevention is enforced by validateConsultationToken's hash
// comparison + expiry + tenant check, not by an RBAC role gate.
router.post(
  "/sessions/:id/validate",
  validate({ params: sessionIdParamSchema, body: validateTokenSchema }),
  telemedicineController.validateToken
);
router.post("/sessions/:id/start", authorize(...CLINICAL_STAFF), validate({ params: sessionIdParamSchema }), telemedicineController.start);
router.post("/sessions/:id/end", authorize(...CLINICAL_STAFF), validate({ params: sessionIdParamSchema }), telemedicineController.end);

export default router;
