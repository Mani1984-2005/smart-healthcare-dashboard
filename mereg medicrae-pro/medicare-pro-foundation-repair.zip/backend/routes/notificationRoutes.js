import express from "express";
import authenticate from "../middleware/authMiddleware.js";
import resolveIdentity from "../middleware/resolveIdentity.js";
import validate from "../middleware/validate.js";
import * as notificationController from "../controllers/notification.controller.js";
import { listNotificationsQuerySchema, notificationIdParamSchema } from "../validations/notification.validation.js";

// No authorize(...roles) here — every authenticated identity (staff of any
// role, or patient) may read their OWN notifications. RBAC in the
// traditional sense doesn't apply to "my own inbox"; tenant + recipient
// scoping (enforced inside notification.service.js from req.identity) is
// the real access control for this route.
const router = express.Router();

router.use(authenticate, resolveIdentity);

router.get("/", validate({ query: listNotificationsQuerySchema }), notificationController.list);
router.patch("/:id/read", validate({ params: notificationIdParamSchema }), notificationController.markRead);

export default router;
