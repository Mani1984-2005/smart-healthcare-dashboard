import express from "express";
import authenticate from "../middleware/authMiddleware.js";
import resolveIdentity from "../middleware/resolveIdentity.js";
import { authorize } from "../middleware/authorize.js";
import validate from "../middleware/validate.js";
import * as labController from "../controllers/laboratory.controller.js";
import {
  createLabOrderSchema,
  updateLabOrderStatusSchema,
  recordResultSchema,
  labOrderIdParamSchema,
  listLabOrdersQuerySchema,
} from "../validations/laboratory.validation.js";

const router = express.Router();
const LAB_STAFF = ["ADMIN", "DOCTOR", "LAB", "MANAGEMENT"];

router.use(authenticate, resolveIdentity, authorize(...LAB_STAFF));

router.get("/", validate({ query: listLabOrdersQuerySchema }), labController.list);
router.get("/:id", validate({ params: labOrderIdParamSchema }), labController.getById);
router.post("/", validate({ body: createLabOrderSchema }), labController.create);
router.put(
  "/:id/status",
  validate({ params: labOrderIdParamSchema, body: updateLabOrderStatusSchema }),
  labController.updateStatus
);
router.put(
  "/:id/result",
  validate({ params: labOrderIdParamSchema, body: recordResultSchema }),
  labController.recordResult
);

export default router;
