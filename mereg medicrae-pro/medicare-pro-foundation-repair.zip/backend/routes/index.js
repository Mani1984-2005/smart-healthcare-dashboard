import express from "express";
const router = express.Router();

// This is now the ONE real router aggregator. Every API route is mounted
// here, and server.js imports only this file — previously server.js and
// this file were two independent, divergent mount points (see
// FOUNDATION_IMPLEMENTATION_REPORT.md, "Routing").
import authRoutes from "./authRoutes.js";
import patientRoutes from "./patientRoutes.js";
import billingRoutes from "./billingRoutes.js";
import appointmentRoutes from "./appointmentRoutes.js";
import laboratoryRoutes from "./laboratoryRoutes.js";
import pharmacyRoutes from "./pharmacyRoutes.js";
import hospitalRoutes from "./hospitalRoutes.js";
import notificationRoutes from "./notificationRoutes.js";
import otpRoutes from "./otpRoutes.js";
import consentRoutes from "./consentRoutes.js";
import telemedicineRoutes from "./telemedicineRoutes.js";
import healthRoutes from "./healthRoutes.js";

router.use("/auth", authRoutes);
router.use("/patients", patientRoutes);
router.use("/billing", billingRoutes);
router.use("/appointments", appointmentRoutes);
router.use("/laboratory", laboratoryRoutes);
router.use("/pharmacy", pharmacyRoutes);
router.use("/hospital", hospitalRoutes);
router.use("/notifications", notificationRoutes);
router.use("/otp", otpRoutes);
router.use("/consent", consentRoutes);
router.use("/telemedicine", telemedicineRoutes);
router.use("/health", healthRoutes);

router.get("/", (req, res) => {
  res.json({
    success: true,
    message: "MediCare Pro API",
    availableRoutes: [
      "/auth",
      "/patients",
      "/billing",
      "/appointments",
      "/laboratory",
      "/pharmacy",
      "/hospital",
      "/notifications",
      "/otp",
      "/consent",
      "/telemedicine",
      "/health",
    ],
  });
});

export default router;
