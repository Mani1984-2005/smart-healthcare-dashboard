import express from "express";
import authenticate from "../middleware/authMiddleware.js";
import resolveIdentity from "../middleware/resolveIdentity.js";
import validate from "../middleware/validate.js";
import * as otpController from "../controllers/otp.controller.js";
import { requestOtpSchema, verifyOtpSchema } from "../validations/otp.validation.js";

// OTP requires an authenticated MediCare Pro identity (staff or patient) —
// this is "verify a phone number for an already-known account," not an
// anonymous/pre-signup OTP flow (which isn't named in the brief). Tenant
// scoping (req.identity.hospitalId) applies exactly as everywhere else.
const router = express.Router();
router.use(authenticate, resolveIdentity);

router.post("/request", validate({ body: requestOtpSchema }), otpController.request);
router.post("/verify", validate({ body: verifyOtpSchema }), otpController.verify);

export default router;
