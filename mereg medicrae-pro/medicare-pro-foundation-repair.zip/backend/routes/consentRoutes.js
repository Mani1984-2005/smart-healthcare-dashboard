import express from "express";
import authenticate from "../middleware/authMiddleware.js";
import resolveIdentity from "../middleware/resolveIdentity.js";
import { authorizeSelfOrRoles } from "../middleware/authorize.js";
import validate from "../middleware/validate.js";
import * as consentController from "../controllers/consent.controller.js";
import { grantConsentSchema, revokeConsentSchema, patientIdParamSchema } from "../validations/consent.validation.js";

const CLINICAL_STAFF = ["ADMIN", "DOCTOR", "STAFF", "MANAGEMENT"];
const router = express.Router();
router.use(authenticate, resolveIdentity);

// A patient may grant/revoke their OWN consent; the listed staff roles may
// record it on a patient's behalf (e.g. captured verbally at check-in).
// Reuses the same authorizeSelfOrRoles pattern already proven in
// patientRoutes.js — patientId in the body, not a route param here, so a
// thin inline check does the "self" comparison instead of the generic
// helper (which expects a route param).
function authorizeConsentActor(req, res, next) {
  if (req.identity.type === "patient" && req.identity.id === req.body.patientId) return next();
  if (CLINICAL_STAFF.includes(req.identity.role)) return next();
  return res.status(403).json({ success: false, error: { code: "AUTHORIZATION_ERROR", message: "Not permitted" } });
}

router.post("/grant", validate({ body: grantConsentSchema }), authorizeConsentActor, consentController.grant);
router.post("/revoke", validate({ body: revokeConsentSchema }), authorizeConsentActor, consentController.revoke);
router.get(
  "/patient/:patientId",
  validate({ params: patientIdParamSchema }),
  authorizeSelfOrRoles(CLINICAL_STAFF, "patientId"),
  consentController.listForPatient
);

export default router;
