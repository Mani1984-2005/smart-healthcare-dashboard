import express from "express";
import authenticate from "../middleware/authMiddleware.js";
import resolveIdentity from "../middleware/resolveIdentity.js";
import { authorize } from "../middleware/authorize.js";
import validate from "../middleware/validate.js";
import * as appointmentController from "../controllers/appointment.controller.js";
import {
  createAppointmentSchema,
  updateAppointmentStatusSchema,
  rescheduleAppointmentSchema,
  appointmentIdParamSchema,
  listAppointmentsQuerySchema,
} from "../validations/appointment.validation.js";

const router = express.Router();
const CLINICAL_STAFF = ["ADMIN", "DOCTOR", "STAFF", "MANAGEMENT"];

router.use(authenticate, resolveIdentity);

router.get("/", authorize(...CLINICAL_STAFF), validate({ query: listAppointmentsQuerySchema }), appointmentController.list);
// NOTE: patient-self access to their own appointment (by appointment id, not
// patient id) needs an ownership lookup that authorizeSelfOrRoles doesn't
// support out of the box — deferred to the future patient self-service
// portal rather than building a one-off check here. Staff-only for now.
router.get("/:id", validate({ params: appointmentIdParamSchema }), authorize(...CLINICAL_STAFF), appointmentController.getById);
router.post("/", authorize("ADMIN", "STAFF"), validate({ body: createAppointmentSchema }), appointmentController.create);
router.put(
  "/:id/status",
  authorize("ADMIN", "STAFF", "DOCTOR"),
  validate({ params: appointmentIdParamSchema, body: updateAppointmentStatusSchema }),
  appointmentController.updateStatus
);
router.put(
  "/:id/reschedule",
  authorize("ADMIN", "STAFF"),
  validate({ params: appointmentIdParamSchema, body: rescheduleAppointmentSchema }),
  appointmentController.reschedule
);

export default router;
