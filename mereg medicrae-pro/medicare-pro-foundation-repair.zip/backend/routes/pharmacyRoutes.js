import express from "express";
import * as pharmacy from "../controllers/pharmacyController.js";
import authenticate from "../middleware/authMiddleware.js";
import resolveIdentity from "../middleware/resolveIdentity.js";
import { authorize } from "../middleware/authorize.js";

// NOTE (Foundation Repair phase): this router now enforces authentication and
// role authorization, which it did not before. The controller/model logic
// underneath (pharmacyController.js, models/Medicine.js, models/Prescription.js)
// is UNCHANGED except for the medicines table now being created by a real
// migration instead of a never-invoked createTable() call.
//
// KNOWN DEFECT, NOT FIXED THIS PHASE: pharmacyController's prescription
// endpoints (createPrescription, getAllPrescriptions, getByPatient,
// getPrescriptionById, updateStatus, deletePrescription,
// deletePrescriptionMedicine) depend on models/Prescription.js, which is
// imported as `import * as Prescription from "../models/Prescription.js"`
// against a file that only has a default export — Prescription.<method> is
// therefore undefined at runtime, and separately the controller passes a
// generated `prescription_id` string field that the model's own schema
// (`id SERIAL`) doesn't have a column for. These routes are mounted (so the
// working medicine-catalog endpoints are reachable) but will error if
// exercised. See FOUNDATION_IMPLEMENTATION_REPORT.md.
const router = express.Router();
const PHARMACY_STAFF = ["ADMIN", "PHARMACY", "DOCTOR", "MANAGEMENT"];

router.use(authenticate, resolveIdentity, authorize(...PHARMACY_STAFF));

router.get("/drug-list", pharmacy.getDrugList);
router.post("/check-interactions", pharmacy.checkInteractions);
router.get("/dosage-suggestion", pharmacy.getDosageSuggestion);
router.post("/prescriptions", pharmacy.createPrescription);
router.get("/prescriptions", pharmacy.getAllPrescriptions);
router.get("/prescriptions/patient/:patientId", pharmacy.getByPatient);
router.get("/prescriptions/:rxId", pharmacy.getPrescriptionById);
router.patch("/prescriptions/:rxId/status", pharmacy.updateStatus);
router.delete("/prescriptions/:rxId", pharmacy.deletePrescription);
// Renamed from the original "/medicines/:medicineId" — found during tenant-
// isolation testing that this route, registered before the medicine-catalog
// "/medicines/:id" DELETE route below, was SHADOWING it: Express matches the
// first registered route with a matching pattern, and both patterns were
// identical shapes (a static prefix + one param), so DELETE
// /pharmacy/medicines/<id> always hit this (broken, see file header)
// prescription-medicine handler and the catalog's deleteMedicine was
// completely unreachable. Pure routing fix — deletePrescriptionMedicine's
// internal logic (and its pre-existing defect) is untouched.
router.delete("/prescription-medicines/:medicineId", pharmacy.deletePrescriptionMedicine);
router.get("/medicines", pharmacy.listMedicines);
router.get("/medicines/low-stock", pharmacy.getLowStock);
router.get("/medicines/:id", pharmacy.getMedicine);
router.get("/categories", pharmacy.getCategories);
router.post("/medicines", authorize("ADMIN", "PHARMACY"), pharmacy.createMedicine);
router.put("/medicines/:id", authorize("ADMIN", "PHARMACY"), pharmacy.updateMedicine);
router.delete("/medicines/:id", authorize("ADMIN", "PHARMACY"), pharmacy.deleteMedicine);
export default router;
