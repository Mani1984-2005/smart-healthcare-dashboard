# MediCare Pro — Notifications & Communication: Final Feature Plan

Written before code, per the discipline used in every prior phase. This is the last feature-development task before feature freeze, per the request.

## 1. Honest starting point

- No Redis/BullMQ infrastructure existed anywhere in this codebase before this task — confirmed by grep and by every prior report. The brief says "use the existing... do not create a second competing queue architecture if one already exists" — since none exists, this task **creates the first and only one**, not a second. Redis 7 and BullMQ were installed fresh in this session (`apt-get install redis-server`, `npm install bullmq ioredis`) and verified running (`redis-cli ping` → `PONG`).
- No external SMS/WhatsApp/voice provider credentials exist or will be used. Per the brief's own instruction (§12), a **mock provider is the default and only provider actually exercised** in this implementation. Twilio-shaped adapter interfaces are built so a real provider is a credential-and-adapter swap, not a rewrite — but no real adapter is claimed as verified against a real vendor, because it wasn't and can't be in this sandbox.
- Phase 1 (event outbox + in-app notifications) already exists and passes 83/83 tests. This task extends it additively.

## 2. Architecture

```
Existing domain write (appointment/lab/billing/OTP/telemedicine/consent event)
      ↓ (unchanged from Phase 1 — additive call after the write commits)
notification_events (outbox, hospital_id-scoped)   [existing table, reused]
      ↓
Phase-1 in-app notification (existing, unchanged)
      ↓ (NEW)
BullMQ queue ("communication") ← Redis
      ↓
Communication worker (separate process entry point, not inline in the API request)
      ↓
Provider abstraction (ChannelAdapter interface)
      ↓
MockProvider (default, always used in this sandbox) | TwilioSmsAdapter / TwilioWhatsAppAdapter / VoiceAdapter (real HTTP-calling code, structurally complete, gated by env credentials that are never set here — see §12 disposition)
      ↓
delivery_attempts (hospital_id-scoped: recipient, type, provider, status, timestamp, error, correlation/event ID)
```

A failed external delivery **never** rolls back the domain write that triggered it — the queue job runs asynchronously, after commit, exactly like Phase 1's in-app notification already does.

## 3. What gets built, scoped to the brief's numbered sections

1. **Provider abstraction** — `ChannelAdapter` interface, `MockProvider` (logs + records a delivery attempt, never makes a network call), `TwilioSmsAdapter`/`TwilioWhatsAppAdapter`/`VoiceAdapter` stubs (real Twilio REST call shape, behind `SMS_PROVIDER=twilio` env selection that this sandbox never sets). `delivery_attempts` table: recipient, type, provider, status, timestamp, error, correlation/event ID, hospital_id.
2. **OTP** — `otp_codes` table (hashed code only, never plaintext), generation (crypto-random 6-digit), expiry (5 min), max attempts (5), rate limiting (max 3 sends per phone per 15 min), resend cooldown (60s), invalidation on success, phone normalization (E.164-ish), tenant-scoped, delivered via the SMS channel (mock provider in this environment).
3. **Telemedicine communication** — `consultation_sessions` table: appointment-linked, secure random token (not the appointment ID itself), expiry, `PENDING/ACTIVE/ENDED/EXPIRED` states, consent-prerequisite check before link issuance, tenant-scoped, notifies patient+doctor via existing notification service + SMS/WhatsApp link (no clinical content in the message body, per §8).
4. **Consent** — `consents` table: patient, hospital, purpose (enum: `TELEMEDICINE`, `SMS_COMMUNICATION`, `WHATSAPP_COMMUNICATION`), status (`GRANTED`/`REVOKED`), timestamp, version, linked request/event where applicable, tenant-scoped, revocable.
5. **Escalation engine** — priority levels on `notification_events` (`LOW/NORMAL/HIGH/CRITICAL`), a minimal rule table (not a general rules engine): `CRITICAL` → immediate SMS job; if no acknowledgement within a configured window → escalation SMS to a backup recipient; if still unacknowledged → voice-call job (mock provider). Explicitly **not** clinical decision-making — purely "who gets contacted, by which channel, in what order," matching the brief's own boundary.
6. **Queue** — BullMQ `communication` queue backed by Redis, a worker process (`workers/communicationWorker.js`, run separately from the API server — not inline), retry with exponential backoff, dead-letter (BullMQ's built-in failed-job list, inspected via a small admin query, not a second custom table), idempotency (job ID derived from `event_id + channel`, so a re-queued job doesn't double-delay), delivery-status tracking via `delivery_attempts`.
7. **Phone-first policy** — every external-facing event (appointment status change, lab result ready, invoice created, OTP, critical alerts, telemedicine link) gets an SMS/WhatsApp job queued in addition to (not instead of) the existing in-app notification — the dashboard notification center is not the only channel for these events anymore.
8. **Healthcare privacy** — message templates for every event type contain **zero PHI** — generic "an update is available, check your secure link" phrasing only, enforced by the templates themselves (fixed strings, no dynamic clinical fields interpolated into SMS/WhatsApp bodies) rather than by a runtime filter that could be bypassed.
9. **Tenant isolation** — every new table (`delivery_attempts`, `otp_codes`, `consultation_sessions`, `consents`) gets `hospital_id NOT NULL` from day one, exactly like every table in the tenant-isolation freeze. Provider **configuration** is also tenant-aware structurally (a `hospital_id`-keyed config lookup point exists), even though in this sandbox every hospital resolves to the same mock provider — tested explicitly with cross-tenant attack tests, same rigor as the freeze pass.
10. **Existing integration** — additive hooks into `appointment.service.js`, `laboratory.service.js`, `billing.service.js` (already emit Phase-1 events; extended to also enqueue a communication job), plus new emission points for OTP, telemedicine, and consent events. No existing module rewritten.

## 4. Explicitly NOT implemented, and why

- **Real Twilio (or any vendor) integration verified against a live account** — no credentials exist or will be requested; the adapters are structurally real but untested against a real API, and the final report will say so plainly, not imply otherwise.
- **Voice IVR call flow content** — a voice "channel" is modeled and queued exactly like SMS, but its "provider" in this sandbox is the same mock — no real telephony integration exists to build against.
- **General-purpose escalation rule engine** — only the fixed SMS→escalation→voice ladder described in §5 above; no UI or API for hospitals to define arbitrary custom rules (that's explicitly the brief's own boundary: "execute configured communication rules only," not build a rule *editor*).
- Anything not named in the brief: no new dashboards, no new AI features, no analytics, no unrelated workflows — per §14 of the brief itself.

## 5. Test plan

Unit (OTP generation/hashing/expiry math, template rendering with zero PHI), integration (event → queue → worker → provider → delivery_attempts, end to end against real Redis/Postgres), tenant isolation (cross-hospital OTP/consent/consultation/delivery-attempt access, explicit attacks matching the freeze-pass rigor), recipient isolation, provider failure handling (mock provider forced to fail → retry → eventual dead-letter, verified via BullMQ job state), idempotency (same event enqueued twice → one delivery attempt, not two), failure isolation (a forced provider failure must not affect the underlying domain write — verified by checking the appointment/invoice/lab row committed successfully regardless), full existing regression suite (83 tests) re-run unchanged.

Proceeding to implementation now.
