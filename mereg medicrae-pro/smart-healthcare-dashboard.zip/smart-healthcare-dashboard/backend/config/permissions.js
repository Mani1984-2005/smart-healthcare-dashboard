// Server-side role→permission matrix.
//
// The frontend (src/app/routes.tsx) already gates whole pages by role — this
// matrix uses that as the baseline for *read* access per module (a role that
// can't see a page shouldn't be able to read its data either), then adds the
// write/delete granularity the frontend doesn't have, based on real hospital
// role responsibilities:
//   - Registration/front-desk work (creating patients, booking appointments,
//     billing) belongs to RECEPTIONIST/BILLING, not clinical roles.
//   - Only DOCTOR (or ADMIN) can write a prescription.
//   - Only PHARMACIST (or ADMIN) manages medicine inventory.
//   - Destructive deletes are ADMIN-only everywhere.
//   - PATIENT has ZERO permissions in this matrix, not just no writes. The
//     patients/appointments/contacts tables have no row-level ownership
//     column linking a record to a Firebase uid, and none of the list
//     endpoints filter by requester — granting PATIENT any read permission
//     here would mean one patient could see every other patient's records,
//     appointments, or next-of-kin contact notes. A real "my own record
//     only" self-service API is a separate, larger feature (needs ownership
//     columns + per-request filtering) and isn't safe to fake partially.
//     See backend/README.md.

export const ROLES = {
  ADMIN: "ADMIN",
  DOCTOR: "DOCTOR",
  NURSE: "NURSE",
  RECEPTIONIST: "RECEPTIONIST",
  LAB_TECHNICIAN: "LAB_TECHNICIAN",
  PHARMACIST: "PHARMACIST",
  BILLING: "BILLING",
  PATIENT: "PATIENT",
};

const { ADMIN, DOCTOR, NURSE, RECEPTIONIST, LAB_TECHNICIAN, PHARMACIST, BILLING, PATIENT } = ROLES;

// resource:action -> roles allowed to perform it
export const ROLE_PERMISSIONS = {
  "patients:read": [ADMIN, DOCTOR, NURSE, RECEPTIONIST],
  "patients:create": [ADMIN, RECEPTIONIST],
  "patients:update": [ADMIN, DOCTOR, NURSE, RECEPTIONIST],
  "patients:delete": [ADMIN],

  "doctors:read": [ADMIN, DOCTOR, NURSE, RECEPTIONIST],
  "doctors:create": [ADMIN],
  "doctors:update": [ADMIN],
  "doctors:delete": [ADMIN],

  "appointments:read": [ADMIN, DOCTOR, NURSE, RECEPTIONIST],
  "appointments:create": [ADMIN, RECEPTIONIST, DOCTOR, NURSE],
  "appointments:update": [ADMIN, RECEPTIONIST, DOCTOR, NURSE],
  "appointments:delete": [ADMIN, RECEPTIONIST],

  "laboratory:read": [ADMIN, LAB_TECHNICIAN, DOCTOR, NURSE],
  "laboratory:create": [ADMIN, DOCTOR, LAB_TECHNICIAN],
  "laboratory:update": [ADMIN, LAB_TECHNICIAN, DOCTOR],
  "laboratory:delete": [ADMIN],

  "pharmacy_medicines:read": [ADMIN, PHARMACIST, DOCTOR, NURSE],
  "pharmacy_medicines:create": [ADMIN, PHARMACIST],
  "pharmacy_medicines:update": [ADMIN, PHARMACIST],
  "pharmacy_medicines:delete": [ADMIN],

  "prescriptions:read": [ADMIN, PHARMACIST, DOCTOR, NURSE],
  "prescriptions:create": [ADMIN, DOCTOR],
  "prescriptions:update": [ADMIN, DOCTOR, PHARMACIST],
  "prescriptions:delete": [ADMIN],

  "billing:read": [ADMIN, BILLING, RECEPTIONIST],
  "billing:create": [ADMIN, BILLING, RECEPTIONIST],
  "billing:update": [ADMIN, BILLING, RECEPTIONIST],
  "billing:delete": [ADMIN, BILLING],

  "contacts:read": [ADMIN, DOCTOR, NURSE, RECEPTIONIST, LAB_TECHNICIAN, PHARMACIST, BILLING],
  "contacts:create": [ADMIN, RECEPTIONIST],
  "contacts:update": [ADMIN, RECEPTIONIST],
  "contacts:delete": [ADMIN, RECEPTIONIST],

  "admin:read": [ADMIN],
  "admin:create": [ADMIN],
  "admin:update": [ADMIN],
  "admin:delete": [ADMIN],
};

/**
 * Pure function — no I/O, easy to unit test. Returns false for an unknown
 * permission string (fail closed, not open).
 */
export function hasPermission(role, permission) {
  const allowedRoles = ROLE_PERMISSIONS[permission];
  if (!allowedRoles) return false;
  return allowedRoles.includes(role);
}
