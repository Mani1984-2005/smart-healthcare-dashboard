import pkg from "pg";
import dotenv from "dotenv";

dotenv.config();

const { Pool } = pkg;

let pool;

/**
 * The single Postgres connection pool for the whole backend.
 * Consolidates what used to be two separate, conflicting pool setups
 * (backend/db.js using DATABASE_URL, backend/config/db.js using discrete
 * PG_* vars) into one. Supports either: DATABASE_URL takes priority when set
 * (typical for hosted Postgres), otherwise falls back to discrete PG_* vars.
 */
export function getPool() {
  if (!pool) {
    pool = process.env.DATABASE_URL
      ? new Pool({ connectionString: process.env.DATABASE_URL, max: 20, idleTimeoutMillis: 30000, connectionTimeoutMillis: 5000 })
      : new Pool({
          host: process.env.PG_HOST || "localhost",
          port: parseInt(process.env.PG_PORT || "5432", 10),
          database: process.env.PG_DATABASE || "medicare_pro",
          user: process.env.PG_USER || "postgres",
          password: process.env.PG_PASSWORD || "postgres",
          max: 20,
          idleTimeoutMillis: 30000,
          connectionTimeoutMillis: 5000,
        });
  }
  return pool;
}

export default getPool();
