import { initializeApp, cert, getApps } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";

const { FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY } = process.env;

const isConfigured = Boolean(FIREBASE_PROJECT_ID && FIREBASE_CLIENT_EMAIL && FIREBASE_PRIVATE_KEY);

if (!isConfigured) {
  console.warn(
    "Firebase Admin: FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, and FIREBASE_PRIVATE_KEY are not set. " +
      "Authenticated routes (/api/auth/me and anything using the authenticate middleware) will return 503 until these are configured. " +
      "The rest of the API is unaffected."
  );
} else if (!getApps().length) {
  initializeApp({
    credential: cert({
      projectId: FIREBASE_PROJECT_ID,
      clientEmail: FIREBASE_CLIENT_EMAIL,
      privateKey: FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n"),
    }),
  });
  console.log("Firebase Admin SDK initialised");
}

export const firebaseConfigured = isConfigured;

/**
 * Returns the Firebase Auth admin instance. Only call this when
 * firebaseConfigured is true — getAuth() throws if no app was initialized.
 */
export function getFirebaseAuth() {
  return getAuth();
}
