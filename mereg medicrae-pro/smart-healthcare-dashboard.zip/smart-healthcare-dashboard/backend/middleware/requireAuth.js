import authenticate from "./authMiddleware.js";
import { firebaseConfigured } from "../config/firebaseAdmin.js";

/**
 * Gate for mutating routes (POST/PUT/PATCH/DELETE).
 *
 * If Firebase Admin isn't configured, this is a no-op — the app runs open,
 * same as it does today, so a local/demo deployment isn't broken by this
 * middleware existing. Once FIREBASE_* env vars are set, every route using
 * this middleware requires a valid Firebase ID token.
 *
 * This checks the token is valid — it does NOT yet check the resolved
 * hospital role has permission for the specific action. Per-route role
 * authorization (e.g. "only ADMIN can delete a department") is the next
 * layer to build on top of this, not something this middleware does.
 */
export default function requireAuth(req, res, next) {
  if (!firebaseConfigured) return next();
  return authenticate(req, res, next);
}
