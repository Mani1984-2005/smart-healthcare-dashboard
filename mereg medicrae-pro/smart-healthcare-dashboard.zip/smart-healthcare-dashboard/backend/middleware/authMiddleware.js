import { firebaseConfigured, getFirebaseAuth } from "../config/firebaseAdmin.js";
import { resolveHospitalUser } from "../db/userResolution.js";

const authenticate = async (req, res, next) => {
  if (!firebaseConfigured) {
    return res.status(503).json({
      success: false,
      message: "Authentication isn't configured on this server yet (missing Firebase Admin credentials).",
    });
  }

  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({
      success: false,
      message: "Unauthorised: No Bearer token provided",
    });
  }

  const idToken = authHeader.split("Bearer ")[1];

  let decodedToken;
  try {
    decodedToken = await getFirebaseAuth().verifyIdToken(idToken);
  } catch (error) {
    console.error("Firebase token verification failed:", error.message);
    return res.status(401).json({
      success: false,
      message: "Unauthorised: Invalid or expired token",
    });
  }

  // Authentication succeeded (valid Firebase identity). Now resolve
  // authorization: does this email correspond to a real hospital account,
  // and which hospital/role does it carry? Firebase proves identity only.
  let hospitalUser;
  try {
    hospitalUser = await resolveHospitalUser(decodedToken.email);
  } catch (error) {
    console.error("Hospital user resolution failed:", error.message);
    return res.status(500).json({ success: false, message: "Unable to resolve hospital account." });
  }

  if (!hospitalUser.role) {
    return res.status(403).json({
      success: false,
      message: "This email isn't registered with the hospital as staff or a patient. Contact an administrator.",
    });
  }

  req.user = { ...decodedToken, role: hospitalUser.role, hospitalId: hospitalUser.hospitalId, patientId: hospitalUser.patientId ?? null };
  next();
};

export default authenticate;
