import { firebaseConfigured } from "../config/firebaseAdmin.js";
import { hasPermission } from "../config/permissions.js";

/**
 * requirePermission("patients:delete") — must run after requireAuth on the
 * same route/router, since it reads req.user.role that requireAuth's
 * underlying authenticate() call attaches.
 *
 * Same demo-mode no-op as requireAuth: if Firebase isn't configured, this
 * is a no-op, so a local/demo deployment isn't broken by this middleware
 * existing. Once configured, every route using this requires the resolved
 * role to have the named permission — 403 if not.
 */
export default function requirePermission(permission) {
  return (req, res, next) => {
    if (!firebaseConfigured) return next();

    if (!req.user?.role) {
      // Should be unreachable if requireAuth ran first on this route (it
      // would have already rejected with 401/403/503) — fail closed anyway.
      return res.status(401).json({ success: false, message: "Unauthorised: no authenticated user context." });
    }

    if (!hasPermission(req.user.role, permission)) {
      return res.status(403).json({ success: false, message: `Forbidden: your role (${req.user.role}) doesn't have permission "${permission}".` });
    }

    next();
  };
}
