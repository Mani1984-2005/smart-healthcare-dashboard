import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import pool from "../config/db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Applied in order. Each file is idempotent (CREATE TABLE IF NOT EXISTS /
// ADD COLUMN IF NOT EXISTS / etc), so re-running this is always safe.
const MIGRATIONS = ["schema.sql", "migration_002_row_level_auth.sql"];

async function migrate() {
  for (const file of MIGRATIONS) {
    const filePath = path.join(__dirname, file);
    const sql = fs.readFileSync(filePath, "utf8");
    console.log(`Applying backend/db/${file} ...`);
    try {
      await pool.query(sql);
      console.log(`  ${file} applied successfully.`);
    } catch (error) {
      console.error(`  ${file} failed:`, error.message);
      process.exitCode = 1;
      break;
    }
  }
  await pool.end();
}

migrate();
