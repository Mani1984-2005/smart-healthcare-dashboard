import pool from "../config/db.js";
import { logError } from "../utils/logger.js";

export async function query(text, params = []) {
  try {
    return await pool.query(text, params);
  } catch (error) {
    logError("db_query_failed", { error: error.message, statement: text });
    throw error;
  }
}

export function newId(prefix) {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${Math.floor(Math.random() * 1000)}`;
}
