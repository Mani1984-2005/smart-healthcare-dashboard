-- MediCare Pro — Migration 002: hospital/tenant scaffolding + row-level
-- ownership bridge columns.
--
-- Context: the schema (schema.sql / "migration 001") was built for exactly
-- one hospital — hospital_profile has a hard CHECK (id = 1). This migration
-- adds real multi-tenant scaffolding (a hospitals table + hospital_id FK on
-- every domain table) without assuming multi-hospital UI/workflow exists
-- yet — every existing and new row defaults to the one hospital this app
-- has always represented, so this is non-destructive and changes no
-- currently-visible behavior by itself. Query-level enforcement (actually
-- filtering by hospital_id) is a separate, application-layer change — see
-- backend/ARCHITECTURE.md.
--
-- Also adds the minimum columns needed for row-level patient ownership:
--   - doctors.email: bridges a clinical `doctors` row to the login identity
--     in `staff` (both are matched by email elsewhere in the app; doctors
--     had no email column at all, so a logged-in doctor could not
--     previously be linked to their own doctors-table row for scoping).
--   - patients.primary_doctor_email: explicit "assigned doctor" for a
--     patient. Nullable — most existing patients won't have one set, and
--     the app already treats "any doctor with an appointment/lab
--     order/prescription for this patient" as care-team access (derived
--     from existing relations, no new table needed for that case).
--
-- Run with: node backend/db/migrate.js (applies schema.sql, then this file)

CREATE TABLE IF NOT EXISTS hospitals (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO hospitals (id, name)
VALUES ('HOSP-1', 'MediCare Pro Hospital')
ON CONFLICT (id) DO NOTHING;

DO $$
DECLARE
  tbl TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY['patients', 'doctors', 'staff', 'departments', 'appointments', 'invoices', 'lab_tests', 'medicines', 'prescriptions', 'contacts', 'service_charges']
  LOOP
    EXECUTE format('ALTER TABLE %I ADD COLUMN IF NOT EXISTS hospital_id TEXT REFERENCES hospitals(id)', tbl);
    EXECUTE format('UPDATE %I SET hospital_id = %L WHERE hospital_id IS NULL', tbl, 'HOSP-1');
    EXECUTE format('ALTER TABLE %I ALTER COLUMN hospital_id SET NOT NULL', tbl);
    EXECUTE format('ALTER TABLE %I ALTER COLUMN hospital_id SET DEFAULT %L', tbl, 'HOSP-1');
    EXECUTE format('CREATE INDEX IF NOT EXISTS idx_%s_hospital ON %I(hospital_id)', tbl, tbl);
  END LOOP;
END $$;

ALTER TABLE doctors ADD COLUMN IF NOT EXISTS email TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS idx_doctors_email ON doctors(email) WHERE email IS NOT NULL;

ALTER TABLE patients ADD COLUMN IF NOT EXISTS primary_doctor_email TEXT;

-- appointments/lab_tests/prescriptions previously only stored doctor_name
-- as a bare display string with no foreign key relationship at all — that
-- can't safely back row-level "is this doctor on this patient's care team"
-- checks (two doctors can share a name; it's not a reliable identity link).
-- doctor_email is the new authoritative link for authorization purposes;
-- doctor_name is kept as-is for display. Nullable and best-effort backfilled
-- from doctors.email where the existing name happens to match exactly —
-- rows that don't match stay NULL and simply won't grant care-team access
-- via that route (fails closed, not open).
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS doctor_email TEXT;
ALTER TABLE lab_tests ADD COLUMN IF NOT EXISTS doctor_email TEXT;
ALTER TABLE prescriptions ADD COLUMN IF NOT EXISTS doctor_email TEXT;

UPDATE appointments a SET doctor_email = d.email FROM doctors d WHERE a.doctor_email IS NULL AND a.doctor_name = d.name AND d.email IS NOT NULL;
UPDATE lab_tests l SET doctor_email = d.email FROM doctors d WHERE l.doctor_email IS NULL AND l.doctor_name = d.name AND d.email IS NOT NULL;
UPDATE prescriptions p SET doctor_email = d.email FROM doctors d WHERE p.doctor_email IS NULL AND p.doctor_name = d.name AND d.email IS NOT NULL;
