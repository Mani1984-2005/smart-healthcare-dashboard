import { query } from "./query.js";

/**
 * Firebase only proves identity (uid, email) — it has no concept of a
 * hospital role or hospital membership. Roles and hospital scope live in
 * the staff table (managed via the Admin panel) and the patients table.
 * We resolve both by matching the verified token's email against those
 * tables, staff first.
 *
 * An email matching neither returns { role: null, hospitalId: null } — this
 * deliberately does NOT auto-provision unknown emails with hospital access.
 * Callers must treat a null role as "no authorization", not as a
 * default/guest role.
 */
export async function resolveHospitalUser(email) {
  if (!email) return { role: null, hospitalId: null };

  const staffMatch = await query("SELECT role, hospital_id FROM staff WHERE email = $1 AND status = 'Active' LIMIT 1", [email]);
  if (staffMatch.rows.length > 0) {
    return { role: staffMatch.rows[0].role, hospitalId: staffMatch.rows[0].hospital_id };
  }

  const patientMatch = await query("SELECT id, hospital_id FROM patients WHERE email = $1 LIMIT 1", [email]);
  if (patientMatch.rows.length > 0) {
    return { role: "PATIENT", hospitalId: patientMatch.rows[0].hospital_id, patientId: patientMatch.rows[0].id };
  }

  return { role: null, hospitalId: null };
}
