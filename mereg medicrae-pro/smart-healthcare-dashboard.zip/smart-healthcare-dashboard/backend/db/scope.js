// Row-level and hospital-scope SQL fragment builders, shared across
// controllers. Centralized so the same rules apply everywhere instead of
// each controller inventing its own WHERE clause.
//
// Every fragment returns { clause, params } where `clause` is a SQL
// fragment using $N placeholders starting at `paramStart`, ready to be
// spliced into a WHERE clause with `AND`.

/**
 * Hospital/tenant isolation — every row must belong to the requester's
 * hospital. This applies to every role, including ADMIN: an admin at
 * Hospital A must never see Hospital B's data. There is currently only one
 * hospital seeded (HOSP-1), so this is inert in practice today, but it's
 * real, enforced SQL, not a placeholder — the moment a second hospital
 * exists, this is what keeps them apart.
 */
export function hospitalScope(column, hospitalId, paramStart) {
  return { clause: `${column} = $${paramStart}`, params: [hospitalId] };
}

/**
 * Row-level patient scope for roles that must NOT see every patient in the
 * hospital: DOCTOR and NURSE only see patients they have an actual
 * relationship with — the explicit primary_doctor_email assignment, or any
 * patient they've had an appointment/lab order/prescription for (derived
 * from existing relations, not a separate care-team table). ADMIN and
 * RECEPTIONIST are hospital-scoped only (front-desk/administrative
 * override) — they need full visibility to register and schedule patients.
 *
 * Returns null for roles that should use hospital scope only (no
 * additional row-level restriction).
 */
export function patientCareTeamScope(user, paramStart) {
  if (user.role !== "DOCTOR" && user.role !== "NURSE") return null;
  return {
    clause: `(
      p.primary_doctor_email = $${paramStart}
      OR EXISTS (SELECT 1 FROM appointments a WHERE a.patient_id = p.id AND a.doctor_email = $${paramStart})
      OR EXISTS (SELECT 1 FROM lab_tests l WHERE l.patient_id = p.id AND l.doctor_email = $${paramStart})
      OR EXISTS (SELECT 1 FROM prescriptions rx WHERE rx.patient_id = p.id AND rx.doctor_email = $${paramStart})
    )`,
    params: [user.email],
  };
}

/**
 * True if this patient row (by id) belongs to the requesting user
 * themself — the PATIENT role's one legitimate access path, since PATIENT
 * has no general patients:read permission (see config/permissions.js).
 */
export function isOwnPatientRecord(user, patientId) {
  return Boolean(user.role === "PATIENT" && user.patientId && user.patientId === patientId);
}

/**
 * Row-level appointment scope: DOCTOR only sees appointments where they are
 * the assigned doctor (appointments.doctor_email, resolved server-side at
 * write time — see appointmentsController.js). NURSE is deliberately NOT
 * restricted here — there is no schema column linking a nurse to specific
 * appointments (no ward/shift assignment concept exists anywhere in this
 * database), and inventing one to fake a narrower scope would be exactly
 * the unnecessary complexity this pass is supposed to avoid. NURSE and
 * RECEPTIONIST/ADMIN all get hospital-scope only for appointments — that's
 * a real, current limitation, not an oversight; see ARCHITECTURE.md.
 *
 * Returns null for roles that should use hospital scope only.
 */
export function appointmentOwnerScope(user, paramStart) {
  if (user.role !== "DOCTOR") return null;
  return { clause: `doctor_email = $${paramStart}`, params: [user.email] };
}

/**
 * Row-level lab test scope: DOCTOR only sees/modifies tests they
 * personally ordered (lab_tests.doctor_email). LAB_TECHNICIAN is
 * deliberately NOT restricted — their actual job is to process the whole
 * lab queue for their hospital, not just one doctor's orders, so
 * narrowing their access would break the real workflow, not secure it.
 * NURSE/ADMIN also stay hospital-scoped only, same reasoning as
 * appointmentOwnerScope above.
 */
export function labTestOwnerScope(user, paramStart) {
  if (user.role !== "DOCTOR") return null;
  return { clause: `doctor_email = $${paramStart}`, params: [user.email] };
}

/**
 * Row-level prescription scope: DOCTOR only sees/modifies prescriptions
 * they personally wrote (prescriptions.doctor_email). PHARMACIST is
 * deliberately NOT restricted — same reasoning as LAB_TECHNICIAN in
 * labTestOwnerScope: a pharmacist's real job is to fill/dispense any
 * prescription for their hospital, not just one doctor's patients.
 * NURSE/ADMIN also stay hospital-scoped only.
 */
export function prescriptionOwnerScope(user, paramStart) {
  if (user.role !== "DOCTOR") return null;
  return { clause: `doctor_email = $${paramStart}`, params: [user.email] };
}
