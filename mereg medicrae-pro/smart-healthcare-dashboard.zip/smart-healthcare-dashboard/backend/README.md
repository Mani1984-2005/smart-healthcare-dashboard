# MediCare Pro — Backend

> **Phase status: COMPLETE — row-level care-team scoping module closed
> (Patients, Appointments, Laboratory, Pharmacy Prescriptions — 55/55
> tests).**
> One remaining limitation: no live PostgreSQL instance was reachable in
> this build environment, so tenant/row-level query logic is unit- and
> code-verified but **not integration-tested against a real database**.
> See ARCHITECTURE.md's "Verification status" note and the Known Gaps
> section below before starting the next phase.

Consolidated on PostgreSQL. One connection pool (`config/db.js`), one schema
(`db/schema.sql`), one controller/route pair per domain, and a real
authentication + authorization layer (Firebase Admin for identity,
PostgreSQL for hospital role resolution, a server-side permission matrix
for enforcement).

## Setup

```bash
cp .env.example .env
# fill in PG_* (or DATABASE_URL) for your Postgres instance
# fill in FIREBASE_PROJECT_ID / FIREBASE_CLIENT_EMAIL / FIREBASE_PRIVATE_KEY
# to enable real auth — see "Authentication modes" below
npm install
node db/migrate.js   # applies db/schema.sql, then db/migration_002_row_level_auth.sql
npm run dev           # or: npm start
```

`app.js` builds the Express app; `server.js` is the actual entry point — it
adds one production safety check (see below) and calls `.listen()`. Tests
import `app.js` directly so they can issue real requests without a running
process or a live database.

## Authentication modes

**Demo mode** (no `FIREBASE_*` env vars set): every route is open — no
token required, anyone can call any endpoint. This is intentional for local
development, and it's loud about it: the server logs `Running in DEMO
MODE...` on boot, and the frontend's Login page shows an explicit "Demo
mode — no real authentication" banner. `NODE_ENV=production` combined with
missing Firebase config makes the server **refuse to start** (exit 1) —
demo convenience can never silently become a production bypass.

**Configured mode** (`FIREBASE_*` env vars set): every route under `/api/*`
(except `/api/auth/login`, which verifies the token itself) requires a
valid Firebase ID token via `Authorization: Bearer <token>`, AND the
token's email must match an `Active` row in `staff` or any row in
`patients` — Firebase proves identity, not hospital role, so the role is
resolved server-side from PostgreSQL on every request. An email matching
neither table gets `403`, not silent guest access.

## Authorization (RBAC + row-level)

`config/permissions.js` is the resource:action permission matrix.
`middleware/requirePermission.js` enforces it per-route. On top of that,
every domain table has a `hospital_id` column (migration 002) and every
controller filters/scopes by it server-side — real hospital/tenant
isolation, not frontend filtering. **Patients** additionally has row-level
care-team scoping (a DOCTOR/NURSE with `patients:read` does not receive
every patient in the hospital, only ones they have an actual relationship
with) and a PATIENT self-access exception (read your own record without a
blanket permission). See `ARCHITECTURE.md` for the full design and
reasoning, and the matrix there for what row-level scoping does and
doesn't cover per domain.

The matrix intentionally grants **PATIENT zero blanket permissions** in the
general staff-facing API — see the comment block at the top of
`permissions.js` for why: most list endpoints don't filter by requester,
and there's no ownership infrastructure for domains other than patients
yet. A real "patient self-service" API beyond reading their own patient
record is a separate, larger feature. The frontend's route table
(`src/app/routes.tsx`) was updated to match — PATIENT no longer sees the
Appointments nav item, since showing it would just lead to a page full of
403 errors.

## Routes

All mounted under `/api`: `/patients`, `/doctors`, `/appointments`,
`/billing` (invoices + summary), `/laboratory` (tests), `/pharmacy`
(medicines + prescriptions), `/contacts`, `/admin` (hospital profile,
departments, service charges, staff), `/auth/login`, `/auth/me`, `/health`.

Every mutating request (`POST`/`PUT`/`PATCH`/`DELETE`) is written to the
audit log via `middleware/auditMiddleware.js`, including the actor's
resolved uid and role when authenticated.

## Tests

No test framework could be installed in the sandbox this was built in (npm
registry returned 403 for `jest`/`supertest`) — tests use Node's built-in
`node:test` and `node:http` instead, hitting the real Express app with real
HTTP requests. No mocking of the auth/permission logic itself.

```bash
npm test              # everything (two process runs — see below)
npm run test:unit       # config/permissions.js + db/scope.js pure logic, no server
npm run test:demo       # integration tests, Firebase deliberately unconfigured
npm run test:configured # integration tests, Firebase configured with a
                         # locally-generated test RSA key (NOT a real
                         # Firebase project — see note below)
```

Current count: 55 tests, 55 passing (33 unit — permissions + scope logic,
12 demo-mode integration, 10 configured-mode integration). Run `npm test`
for the authoritative live number.

`test:demo` and `test:configured` run as separate `node --test` invocations
because `config/firebaseAdmin.js` reads its env vars once at import time —
a single process can't be "unconfigured" and "configured" at once.

**What `test:configured` can and can't prove:** it generates a real RSA
keypair at runtime and sets it as `FIREBASE_PRIVATE_KEY`, which is enough
to get past Firebase Admin's credential parsing and genuinely exercise
`verifyIdToken()` — so it can prove "missing token → 401", "malformed
token → 401", and that the server doesn't crash when Firebase Admin
actually initializes (a real bug found and fixed while building this — see
below). It **cannot** prove "valid token → 200 with the right role",
because that requires a token signed by a real Firebase project that
Google's servers will vouch for, which this sandbox doesn't have. That
path is genuinely untested — not skipped quietly, tracked as BLOCKED.

## Known gaps — not solved by this pass

- **No live Postgres in the sandbox this was built in.** `apt-get install
  postgresql` returns 403 through the network proxy. Every controller was
  syntax-checked and boot-tested (confirmed real HTTP requests reach the
  right handler and fail cleanly with a DB-unreachable JSON error), but
  actual CRUD against a live database — and therefore real role resolution
  end-to-end — hasn't been exercised.
- **No real Firebase project available.** See the tests section above —
  the "valid token" path is untested by necessity, not by choice.
- **Patient self-service is minimal, not absent.** PATIENT can now read
  their own patient record (`GET /api/patients/:id` where the id matches
  their resolved `patientId`) — but has no access to their own
  appointments, lab results, prescriptions, or invoices via the API yet.
  Those would need the same per-domain "is this requester's own record"
  treatment patients got, which this pass didn't extend everywhere.
- **Row-level scoping now covers Patients, Appointments, Laboratory, and
  Pharmacy prescriptions** (DOCTOR only for the latter three). Medicine
  inventory, Billing, and Contacts remain hospital-scoped (tenant
  isolation, real and enforced) but not further row-level restricted —
  none of them are individually-owned clinical records the way
  appointments/lab/prescriptions are, so there's nothing to extend the
  pattern to without inventing a relationship that doesn't exist.
- **NURSE has no row-level restriction anywhere.** **LAB_TECHNICIAN and
  PHARMACIST also have none**, for Laboratory and Prescriptions
  respectively — all deliberate, documented limitations (a lab tech
  processes the whole queue, a pharmacist dispenses for the whole
  hospital, there's no schema concept of a nurse-to-appointment/ward
  assignment), not oversights. See `db/scope.js`'s comments on
  `appointmentOwnerScope`/`labTestOwnerScope`/`prescriptionOwnerScope`.
- **`doctor_email` backfill is best-effort.** Migration 002 populates it by
  matching `doctor_name` to `doctors.name` exactly — a doctor whose stored
  name doesn't match precisely (typo, "Dr." prefix inconsistency, etc.)
  keeps `doctor_email = NULL` for their existing rows, which fails closed
  (no care-team access granted via that row) rather than open. New rows
  created going forward resolve `doctor_email` server-side at write time.
- **`hospital_profile` is still a global singleton**, not per-hospital —
  see `ARCHITECTURE.md`'s "Known architectural debt" note.
- **Row-level SQL fragments are unit-tested (`tests/scope.test.js`), not
  integration-tested against a live database** — that requires the same
  live-Postgres access this whole pass has been blocked on. The *shape* of
  the authorization logic is verified; a live query actually returning the
  right rows is not.
