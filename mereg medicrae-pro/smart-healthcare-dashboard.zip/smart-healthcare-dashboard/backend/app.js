import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import healthRoutes from "./routes/healthRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import patientRoutes from "./routes/patients.js";
import doctorRoutes from "./routes/doctors.js";
import appointmentRoutes from "./routes/appointments.js";
import billingRoutes from "./routes/billingRoutes.js";
import laboratoryRoutes from "./routes/laboratory.js";
import pharmacyRoutes from "./routes/pharmacy.js";
import contactsRoutes from "./routes/contacts.js";
import adminRoutes from "./routes/admin.js";
import auditMiddleware from "./middleware/auditMiddleware.js";
import { logError } from "./utils/logger.js";

dotenv.config();

// This file builds and exports the configured Express app WITHOUT calling
// .listen() — that's server.js's job. Splitting it this way lets tests
// (backend/tests/*.test.js) import the real app and issue real HTTP
// requests against it without needing a listening process or a live
// database for the auth/authorization checks that don't require one.

const app = express();

app.use(cors());
app.use(express.json());
app.use(auditMiddleware);

app.get("/", (req, res) => {
  res.send("MediCare Pro Backend Running 🚀");
});

app.use("/health", healthRoutes);
app.use("/api/health", healthRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/patients", patientRoutes);
app.use("/api/doctors", doctorRoutes);
app.use("/api/appointments", appointmentRoutes);
app.use("/api/billing", billingRoutes);
app.use("/api/laboratory", laboratoryRoutes);
app.use("/api/pharmacy", pharmacyRoutes);
app.use("/api/contacts", contactsRoutes);
app.use("/api/admin", adminRoutes);

// Express 5 forwards rejected promises from async route handlers here automatically.
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  logError("unhandled_request_error", { error: err.message, path: req.originalUrl });
  res.status(err.status || 500).json({ message: err.message || "Internal server error" });
});

export default app;
