// Pure unit tests for row-level/hospital scope SQL-fragment builders —
// no server, no DB, no Firebase. These test the SHAPE of the authorization
// logic (who gets which fragment), not a live query result — that half
// requires a real Postgres instance this sandbox doesn't have (see
// scope-integration notes in demoMode/configuredMode test files and the
// final report's BLOCKED items).
import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { hospitalScope, patientCareTeamScope, isOwnPatientRecord, appointmentOwnerScope, labTestOwnerScope, prescriptionOwnerScope } from "../db/scope.js";

describe("hospitalScope", () => {
  test("produces a parameterized clause, never inlines the value", () => {
    const { clause, params } = hospitalScope("p.hospital_id", "HOSP-1", 1);
    assert.equal(clause, "p.hospital_id = $1");
    assert.deepEqual(params, ["HOSP-1"]);
    assert.equal(clause.includes("HOSP-1"), false, "hospital id must be a bound param, never string-interpolated into SQL");
  });
});

describe("patientCareTeamScope", () => {
  test("returns null for ADMIN — hospital-scope only, no additional row-level restriction", () => {
    assert.equal(patientCareTeamScope({ role: "ADMIN", email: "admin@hospital.example" }, 2), null);
  });

  test("returns null for RECEPTIONIST — administrative override, sees all patients in-hospital", () => {
    assert.equal(patientCareTeamScope({ role: "RECEPTIONIST", email: "front-desk@hospital.example" }, 2), null);
  });

  test("returns a restrictive clause for DOCTOR", () => {
    const scope = patientCareTeamScope({ role: "DOCTOR", email: "doc@hospital.example" }, 2);
    assert.notEqual(scope, null);
    assert.ok(scope.clause.includes("primary_doctor_email"));
    assert.ok(scope.clause.includes("appointments"));
    assert.deepEqual(scope.params, ["doc@hospital.example"]);
  });

  test("returns a restrictive clause for NURSE", () => {
    const scope = patientCareTeamScope({ role: "NURSE", email: "nurse@hospital.example" }, 2);
    assert.notEqual(scope, null);
  });

  test("REGRESSION: a doctor's own email is never string-interpolated into the SQL fragment itself", () => {
    const scope = patientCareTeamScope({ role: "DOCTOR", email: "'; DROP TABLE patients; --" }, 2);
    assert.equal(scope.clause.includes("DROP TABLE"), false, "care-team email must be a bound param, never inlined — SQL injection check");
    assert.deepEqual(scope.params, ["'; DROP TABLE patients; --"]);
  });
});

describe("isOwnPatientRecord", () => {
  test("true when a PATIENT's resolved patientId matches the requested id", () => {
    assert.equal(isOwnPatientRecord({ role: "PATIENT", patientId: "P-1001" }, "P-1001"), true);
  });

  test("false when a PATIENT requests a DIFFERENT patient's id (the core IDOR case)", () => {
    assert.equal(isOwnPatientRecord({ role: "PATIENT", patientId: "P-1001" }, "P-9999"), false);
  });

  test("false for non-PATIENT roles even if ids happen to match — this helper is PATIENT-only self-access, not a general shortcut", () => {
    assert.equal(isOwnPatientRecord({ role: "DOCTOR", patientId: null }, "P-1001"), false);
  });

  test("false when a PATIENT has no resolved patientId at all (defensive — should be unreachable, but must fail closed)", () => {
    assert.equal(isOwnPatientRecord({ role: "PATIENT", patientId: null }, "P-1001"), false);
  });
});

describe("appointmentOwnerScope", () => {
  test("returns null for ADMIN — hospital-scope only", () => {
    assert.equal(appointmentOwnerScope({ role: "ADMIN", email: "admin@hospital.example" }, 2), null);
  });

  test("returns null for RECEPTIONIST — needs to schedule for any doctor", () => {
    assert.equal(appointmentOwnerScope({ role: "RECEPTIONIST", email: "front-desk@hospital.example" }, 2), null);
  });

  test("returns null for NURSE — documented limitation, no schema column backs a narrower nurse scope (see db/scope.js comment)", () => {
    assert.equal(appointmentOwnerScope({ role: "NURSE", email: "nurse@hospital.example" }, 2), null);
  });

  test("returns a restrictive clause for DOCTOR, parameterized not inlined", () => {
    const scope = appointmentOwnerScope({ role: "DOCTOR", email: "doc@hospital.example" }, 2);
    assert.notEqual(scope, null);
    assert.equal(scope.clause, "doctor_email = $2");
    assert.deepEqual(scope.params, ["doc@hospital.example"]);
    assert.equal(scope.clause.includes("doc@hospital.example"), false, "email must be a bound param, never inlined");
  });
});

describe("labTestOwnerScope", () => {
  test("returns null for ADMIN — hospital-scope only", () => {
    assert.equal(labTestOwnerScope({ role: "ADMIN", email: "admin@hospital.example" }, 2), null);
  });

  test("returns null for LAB_TECHNICIAN — processes the whole lab queue, not one doctor's orders", () => {
    assert.equal(labTestOwnerScope({ role: "LAB_TECHNICIAN", email: "tech@hospital.example" }, 2), null);
  });

  test("returns null for NURSE — same documented limitation as appointments", () => {
    assert.equal(labTestOwnerScope({ role: "NURSE", email: "nurse@hospital.example" }, 2), null);
  });

  test("returns a restrictive clause for DOCTOR, parameterized not inlined", () => {
    const scope = labTestOwnerScope({ role: "DOCTOR", email: "doc@hospital.example" }, 2);
    assert.notEqual(scope, null);
    assert.equal(scope.clause, "doctor_email = $2");
    assert.deepEqual(scope.params, ["doc@hospital.example"]);
  });
});

describe("prescriptionOwnerScope", () => {
  test("returns null for ADMIN — hospital-scope only", () => {
    assert.equal(prescriptionOwnerScope({ role: "ADMIN", email: "admin@hospital.example" }, 2), null);
  });

  test("returns null for PHARMACIST — dispenses any prescription in the hospital, not one doctor's patients", () => {
    assert.equal(prescriptionOwnerScope({ role: "PHARMACIST", email: "pharmacist@hospital.example" }, 2), null);
  });

  test("returns null for NURSE — same documented limitation as appointments/lab", () => {
    assert.equal(prescriptionOwnerScope({ role: "NURSE", email: "nurse@hospital.example" }, 2), null);
  });

  test("returns a restrictive clause for DOCTOR, parameterized not inlined", () => {
    const scope = prescriptionOwnerScope({ role: "DOCTOR", email: "doc@hospital.example" }, 2);
    assert.notEqual(scope, null);
    assert.equal(scope.clause, "doctor_email = $2");
    assert.deepEqual(scope.params, ["doc@hospital.example"]);
  });
});
