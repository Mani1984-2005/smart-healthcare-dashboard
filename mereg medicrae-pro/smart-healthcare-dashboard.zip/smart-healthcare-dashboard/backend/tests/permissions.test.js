// Pure unit tests for the permission matrix — no server, no DB, no Firebase.
import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { hasPermission, ROLE_PERMISSIONS, ROLES } from "../config/permissions.js";

describe("hasPermission", () => {
  test("ADMIN has every defined permission", () => {
    for (const permission of Object.keys(ROLE_PERMISSIONS)) {
      assert.equal(hasPermission(ROLES.ADMIN, permission), true, `ADMIN should have ${permission}`);
    }
  });

  test("PATIENT has zero permissions in the general staff-facing API (no row-level ownership scoping exists yet — see permissions.js header)", () => {
    for (const [permission, roles] of Object.entries(ROLE_PERMISSIONS)) {
      assert.equal(roles.includes(ROLES.PATIENT), false, `PATIENT should not have ${permission} — no endpoint filters by requester, so any grant here would leak other patients' data`);
    }
  });

  test("REGRESSION: contacts:read excludes PATIENT (contact records include other patients' next-of-kin/insurance notes, unfiltered by the controller)", () => {
    assert.equal(hasPermission(ROLES.PATIENT, "contacts:read"), false);
  });

  test("REGRESSION: appointments:read excludes PATIENT (listAppointments returns every patient's appointments, unfiltered by the controller)", () => {
    assert.equal(hasPermission(ROLES.PATIENT, "appointments:read"), false);
  });

  test("unknown permission string denies everyone (fail closed)", () => {
    assert.equal(hasPermission(ROLES.ADMIN, "nonexistent:action"), false);
    assert.equal(hasPermission(ROLES.DOCTOR, "totally:made:up"), false);
  });

  test("unknown role denies (fail closed)", () => {
    assert.equal(hasPermission("NOT_A_REAL_ROLE", "patients:read"), false);
  });

  test("only ADMIN can delete a department (admin:delete)", () => {
    assert.deepEqual(ROLE_PERMISSIONS["admin:delete"], [ROLES.ADMIN]);
  });

  test("only ADMIN or DOCTOR can create a prescription", () => {
    assert.deepEqual(ROLE_PERMISSIONS["prescriptions:create"].sort(), [ROLES.ADMIN, ROLES.DOCTOR].sort());
  });

  test("RECEPTIONIST cannot delete patients", () => {
    assert.equal(hasPermission(ROLES.RECEPTIONIST, "patients:delete"), false);
  });

  test("RECEPTIONIST can create patients (front-desk registration)", () => {
    assert.equal(hasPermission(ROLES.RECEPTIONIST, "patients:create"), true);
  });

  test("PHARMACIST cannot delete medicines but ADMIN can", () => {
    assert.equal(hasPermission(ROLES.PHARMACIST, "pharmacy_medicines:delete"), false);
    assert.equal(hasPermission(ROLES.ADMIN, "pharmacy_medicines:delete"), true);
  });
});
