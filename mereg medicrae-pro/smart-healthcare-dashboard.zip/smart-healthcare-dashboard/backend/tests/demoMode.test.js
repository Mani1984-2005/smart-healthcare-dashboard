// Integration tests against the REAL Express app, run with Firebase Admin
// UNCONFIGURED (no FIREBASE_* env vars) — i.e. demo mode. Must be run as
// its own process (not combined with configuredMode.test.js) because
// firebaseAdmin.js reads process.env once at import time.
//
// Run with: node --test backend/tests/demoMode.test.js
import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";

let server;
let baseUrl;

before(async () => {
  assert.equal(process.env.FIREBASE_PROJECT_ID, undefined, "This test file must run without Firebase env vars set — see configuredMode.test.js for the configured case.");
  const { default: app } = await import("../app.js");
  server = createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  baseUrl = `http://localhost:${server.address().port}`;
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
});

describe("demo mode (Firebase unconfigured)", () => {
  test("GET / is open and returns 200", async () => {
    const res = await fetch(`${baseUrl}/`);
    assert.equal(res.status, 200);
  });

  test("GET /health is open regardless of auth config", async () => {
    const res = await fetch(`${baseUrl}/health`);
    assert.equal(res.status, 200);
  });

  test("GET /api/auth/me returns 503 (auth genuinely not configured, not silently allowed)", async () => {
    const res = await fetch(`${baseUrl}/api/auth/me`);
    assert.equal(res.status, 503);
    const body = await res.json();
    assert.equal(body.success, false);
  });

  test("POST /api/auth/login returns 503, not a fabricated success", async () => {
    const res = await fetch(`${baseUrl}/api/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ idToken: "anything" }) });
    assert.equal(res.status, 503);
  });

  test("REGRESSION: GET /api/patients with no Authorization header reaches business logic (not blocked by auth) — demo mode must stay open", async () => {
    const res = await fetch(`${baseUrl}/api/patients`);
    // No live Postgres in this environment, so the real failure mode here is
    // a 500 from the DB layer — the point of this assertion is what it is
    // NOT: 401/403/503 would mean requireAuth/requirePermission incorrectly
    // activated in demo mode, which is exactly the regression class this
    // project already hit once (Firebase Admin crashing on import).
    assert.notEqual(res.status, 401);
    assert.notEqual(res.status, 403);
    assert.notEqual(res.status, 503);
  });

  test("REGRESSION: GET /api/doctors is independently unaffected by /api/patients' router config", async () => {
    const res = await fetch(`${baseUrl}/api/doctors`);
    assert.notEqual(res.status, 401);
    assert.notEqual(res.status, 403);
    assert.notEqual(res.status, 503);
  });

  test("REGRESSION: DELETE /api/admin/departments/:id (most sensitive route) is also open in demo mode, not silently 403'd or silently 200'd without reaching the DB", async () => {
    const res = await fetch(`${baseUrl}/api/admin/departments/fake-id`, { method: "DELETE" });
    assert.notEqual(res.status, 401);
    assert.notEqual(res.status, 403);
  });

  test("REGRESSION: GET /api/patients in demo mode fails at the DB layer, not on req.user.hospitalId being undefined (row-level scoping added in migration 002 must not crash when there's no authenticated user)", async () => {
    const res = await fetch(`${baseUrl}/api/patients`);
    const body = await res.json();
    assert.ok(
      body.message && !body.message.toLowerCase().includes("undefined") && !body.message.toLowerCase().includes("cannot read"),
      `Expected a DB-connection-style error, got: ${body.message}`
    );
  });

  test("REGRESSION: GET /api/patients/:id in demo mode also doesn't crash on req.user", async () => {
    const res = await fetch(`${baseUrl}/api/patients/some-id`);
    const body = await res.json();
    assert.ok(
      !body.message || (!body.message.toLowerCase().includes("undefined") && !body.message.toLowerCase().includes("cannot read")),
      `Expected a 404 or DB-connection-style error, got: ${body.message}`
    );
  });

  test("REGRESSION: GET /api/appointments in demo mode doesn't crash on req.user (appointmentOwnerScope added this session)", async () => {
    const res = await fetch(`${baseUrl}/api/appointments`);
    const body = await res.json();
    assert.ok(
      body.message && !body.message.toLowerCase().includes("undefined") && !body.message.toLowerCase().includes("cannot read"),
      `Expected a DB-connection-style error, got: ${body.message}`
    );
  });

  test("REGRESSION: GET /api/laboratory/tests in demo mode doesn't crash on req.user (labTestOwnerScope added this session)", async () => {
    const res = await fetch(`${baseUrl}/api/laboratory/tests`);
    const body = await res.json();
    assert.ok(
      body.message && !body.message.toLowerCase().includes("undefined") && !body.message.toLowerCase().includes("cannot read"),
      `Expected a DB-connection-style error, got: ${body.message}`
    );
  });

  test("REGRESSION: GET /api/pharmacy/prescriptions in demo mode doesn't crash on req.user (prescriptionOwnerScope added this session)", async () => {
    const res = await fetch(`${baseUrl}/api/pharmacy/prescriptions`);
    const body = await res.json();
    assert.ok(
      body.message && !body.message.toLowerCase().includes("undefined") && !body.message.toLowerCase().includes("cannot read"),
      `Expected a DB-connection-style error, got: ${body.message}`
    );
  });
});
