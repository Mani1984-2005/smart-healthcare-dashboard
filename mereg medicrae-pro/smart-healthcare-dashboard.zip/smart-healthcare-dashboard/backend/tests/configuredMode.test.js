// Integration tests against the REAL Express app, run WITH Firebase Admin
// configured (using a locally-generated, syntactically valid RSA key — NOT
// a real Firebase project, so this can only test rejection paths: missing
// token, malformed token, and 403 role-resolution failure. It genuinely
// cannot test "valid token -> 200", since that requires signing a token
// that Google's public certs for a real project would accept, which needs
// a real Firebase project this sandbox does not have. That case is BLOCKED,
// not skipped or faked — see the final report.
//
// Run with: node --test backend/tests/configuredMode.test.js
import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { generateKeyPairSync } from "node:crypto";

let server;
let baseUrl;

before(async () => {
  const { privateKey } = generateKeyPairSync("rsa", { modulusLength: 2048, privateKeyEncoding: { type: "pkcs8", format: "pem" } });
  process.env.FIREBASE_PROJECT_ID = "test-project";
  process.env.FIREBASE_CLIENT_EMAIL = "test@test-project.iam.gserviceaccount.com";
  process.env.FIREBASE_PRIVATE_KEY = privateKey.replace(/\n/g, "\\n");

  const { default: app } = await import("../app.js");
  server = createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  baseUrl = `http://localhost:${server.address().port}`;
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
});

describe("configured mode (Firebase Admin initialized)", () => {
  test("REGRESSION: server boots without throwing when Firebase env vars ARE set (previously crashed — see report)", () => {
    // If we got this far, before() didn't throw. Explicit assertion for clarity in output.
    assert.ok(server.listening);
  });

  test("GET / is still open (unauthenticated routes unaffected by auth being configured)", async () => {
    const res = await fetch(`${baseUrl}/`);
    assert.equal(res.status, 200);
  });

  test("GET /api/auth/me with no Authorization header -> 401", async () => {
    const res = await fetch(`${baseUrl}/api/auth/me`);
    assert.equal(res.status, 401);
  });

  test("GET /api/auth/me with malformed Bearer token -> 401, not 500", async () => {
    const res = await fetch(`${baseUrl}/api/auth/me`, { headers: { Authorization: "Bearer not-a-real-token" } });
    assert.equal(res.status, 401);
    const body = await res.json();
    assert.equal(body.success, false);
  });

  test("POST /api/auth/login with garbage idToken -> 401", async () => {
    const res = await fetch(`${baseUrl}/api/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ idToken: "garbage" }) });
    assert.equal(res.status, 401);
  });

  test("POST /api/auth/login with no idToken -> 400", async () => {
    const res = await fetch(`${baseUrl}/api/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({}) });
    assert.equal(res.status, 400);
  });

  test("GET /api/patients with no Authorization header -> 401 (requireAuth genuinely active once configured)", async () => {
    const res = await fetch(`${baseUrl}/api/patients`);
    assert.equal(res.status, 401);
  });

  test("REGRESSION: GET /api/doctors independently requires auth too (not just /api/patients)", async () => {
    const res = await fetch(`${baseUrl}/api/doctors`);
    assert.equal(res.status, 401);
  });

  test("DELETE /api/admin/departments/:id with no Authorization header -> 401, not 200 and not silently allowed", async () => {
    const res = await fetch(`${baseUrl}/api/admin/departments/fake-id`, { method: "DELETE" });
    assert.equal(res.status, 401);
  });

  test("POST /api/billing/invoices with no Authorization header -> 401", async () => {
    const res = await fetch(`${baseUrl}/api/billing/invoices`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    assert.equal(res.status, 401);
  });
});
