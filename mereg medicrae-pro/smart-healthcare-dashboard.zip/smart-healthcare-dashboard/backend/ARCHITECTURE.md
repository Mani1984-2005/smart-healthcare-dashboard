# MediCare Pro — Security Architecture

> **Phase status: COMPLETE — row-level care-team scoping module closed.**
> Appointments, Laboratory, and Pharmacy Prescriptions all have DOCTOR-only
> row-level scoping on top of the previously frozen Patients
> implementation. This closes the row-level scoping thread: the three
> domains with a real per-doctor ownership relationship are done; the
> remaining domains (medicine inventory, Billing, Contacts, Admin) have no
> analogous doctor-ownership relationship to scope by, so they stay
> hospital-scoped only by design, not by omission. Authentication, RBAC,
> hospital/tenant isolation, and row-level patient/appointment/lab/
> prescription scoping are implemented and pass all 55 automated tests
> plus full lint/type-check/syntax/boot regression. **Real PostgreSQL
> multi-hospital isolation testing is still pending** — no live database
> was reachable in the environment this was built in, so the query-level
> tenant/row-level logic is unit- and code-verified, not
> integration-verified against a live instance. See "Verification status"
> further down before treating any isolation claim as database-tested.

This documents the authentication, authorization, and data-isolation model
as it actually exists in this repository — not an aspirational target.
Every claim here was checked against code; see backend/README.md's Tests
section for what's genuinely verified vs. blocked by sandbox limitations.

## Authentication flow

```
Firebase Login (frontend, firebase/auth)
  -> Firebase ID Token
  -> Authorization: Bearer <token> header (src/services/api.js)
  -> Express (middleware/authMiddleware.js)
  -> Firebase Admin verifies the token (config/firebaseAdmin.js)
  -> db/userResolution.js resolves the hospital account by email
  -> req.user = { uid, email, role, hospitalId, patientId }
  -> route handler
```

Firebase establishes **identity only**. Every request re-resolves **role**
and **hospital** from PostgreSQL — nothing about authorization is trusted
from the token itself or from anything the client sends.

## Authorization flow

```
requireAuth (middleware/requireAuth.js)
  -> is there a valid session at all?
requirePermission("resource:action") (middleware/requirePermission.js)
  -> does req.user.role have this permission? (config/permissions.js)
Row-level check (inside the controller, e.g. patientsController.js)
  -> hospital_id match (tenant isolation)
  -> care-team match, where applicable (row-level ownership)
```

Three layers, each independent: a request can pass authentication, fail
permission (403), or pass permission and still fail the row-level check
(404 for a cross-hospital record — deliberately not 403, so a valid
patient ID belonging to a different hospital doesn't confirm its own
existence; see Requirement 5 notes below).

## Row-level authorization

**Patients** is the one domain with real per-record ownership logic, per
the explicit requirement that `patients:read` must not mean "read every
patient in the hospital":

- **ADMIN, RECEPTIONIST**: hospital-scoped only. Full visibility across
  their hospital's patients (administrative/front-desk override — they
  need this to register and schedule anyone).
- **DOCTOR, NURSE**: hospital-scoped AND restricted to patients they have
  an actual relationship with: `patients.primary_doctor_email` matches
  their email, OR they have an appointment/lab order/prescription on
  record for that patient (derived from existing relations — see
  `db/scope.js`'s `patientCareTeamScope`).
- **PATIENT**: no general `patients:read` permission at all. The one
  exception is reading their own record (`GET /api/patients/:id` where
  `:id` matches `req.user.patientId`) — a row-level decision made inside
  the controller, not a blanket permission grant.

Every other domain (doctors, medicine inventory, billing, contacts, admin)
is **hospital-scoped only** — no further row-level restriction.
**Appointments, Laboratory, and prescriptions (within Pharmacy)** now have
partial row-level scoping too (added in follow-up increments, same overall
session): DOCTOR only sees/modifies appointments, lab tests, and
prescriptions where they're the assigned/ordering/prescribing doctor.
NURSE/ADMIN/RECEPTIONIST remain hospital-scoped for appointments;
NURSE/ADMIN/**LAB_TECHNICIAN** remain hospital-scoped for lab tests; and
NURSE/ADMIN/**PHARMACIST** remain hospital-scoped for prescriptions —
because a lab technician processes the whole lab queue and a pharmacist
dispenses any prescription for their hospital, not just one doctor's
patients. Restricting them would break the actual workflow, not secure
it. See the matrix below for the reasoning per remaining domain.

## Hospital / tenant isolation

Every domain table has a `hospital_id` column (migration 002). Every
list/read query filters by `req.user.hospitalId`; every create sets
`hospital_id` from `req.user.hospitalId` server-side — **never** from the
request body (accepting a client-supplied `hospital_id` would let any user
assign data to a hospital that isn't their own). Every update/delete loads
the existing row first and checks its `hospital_id` before proceeding.

There is currently exactly one hospital seeded (`HOSP-1`) — this was a
single-hospital application before this pass (`hospital_profile` has a
hard `CHECK (id = 1)`). The isolation logic is real, enforced SQL, but its
practical effect today is zero, because there's nothing to isolate *from*
yet. It's there so that adding a second hospital later is a data-entry
operation, not another security migration.

**Known architectural debt, not fixed in this pass**: `hospital_profile`
(branding: name/address/phone/tagline) is still a global singleton, not
per-hospital. A real second hospital would need that table restructured.

## Permission model

`config/permissions.js` — a static `{ "resource:action": [roles] }` map.
Pure data, unit-tested directly (`tests/permissions.test.js`), enforced by
`middleware/requirePermission.js`. See the matrix below for the full
current grant set.

## Audit logging

`middleware/auditMiddleware.js`, applied globally in `app.js`. Logs actor
(`uid`, resolved `role`), action, resource, resource ID (where determinable
from the URL), timestamp, and response status, for every mutating request.
Never logs the Authorization header, the ID token, or Firebase credentials.
Fixed this pass: it previously read `req.user.id`/`req.user._id`, which
don't exist on the shape `authMiddleware.js` actually sets (`.uid`) — every
authenticated action was silently logging as "anonymous".

## Security boundaries — what this does and doesn't protect against

**Verification status for every claim below**: the authorization logic
(which SQL clause gets built for which role, which HTTP status gets
returned for which condition) is implemented and unit/regression-tested
against the real Express app and pure-function logic. **None of it has
been integration-tested against a live PostgreSQL instance** — this
sandbox has no reachable Postgres (see README.md's Known Gaps). That means
the *code paths* that produce tenant isolation and row-level scoping are
verified; a live query against real multi-hospital data actually returning
only the correct rows is NOT verified end-to-end. Treat every "protects
against" item below as **implemented and code-verified**, not
**database-integration-verified**, until that testing happens against a
real instance.

- **By design, protects against**: an authenticated user with insufficient
  permission calling an endpoint directly (403 — verified live), a user
  from Hospital A reading or writing Hospital B's data (404, tenant
  isolation — query logic verified by code review and unit tests, NOT
  verified against a live database), a doctor/nurse listing or reading a
  patient outside their care team (403/absent from list — same caveat), a
  patient reading another patient's record by guessing/enumerating IDs
  (404 — same caveat), demo mode silently running in production
  (`server.js` refuses to start — verified live).
- **Does NOT yet protect against**: a doctor's *write* access to billing
  records outside their own involvement, or the medicine inventory itself
  (not patient data, no row-level concept applies there by design) — this
  pass covered `patients.js` fully and `appointments.js`/`laboratory.js`/
  the prescriptions half of `pharmacyController.js` partially (DOCTOR only;
  other roles unrestricted by design, see above). The mechanical
  hospital-scoping applied to Billing/Contacts/Admin/medicine-inventory
  does not add row-level restriction beyond tenant isolation. A confirmed,
  tested "valid real Firebase token" path (blocked on not having a real
  Firebase project — see
  backend/README.md).
