import { query, newId } from "../db/query.js";
import { logCRUD } from "../utils/logger.js";

function toApi(row) {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    subType: row.sub_type,
    phone: row.phone,
    email: row.email,
    address: row.address,
    department: row.department,
    availability: row.availability,
    emergencyPriority: row.emergency_priority,
    location: row.location,
    notes: row.notes,
    lastContacted: row.last_contacted,
    hospitalId: row.hospital_id,
  };
}

export async function listContacts(req, res) {
  if (!req.user) {
    const result = await query("SELECT * FROM contacts ORDER BY created_at DESC");
    return res.json(result.rows.map(toApi));
  }
  const result = await query("SELECT * FROM contacts WHERE hospital_id = $1 ORDER BY created_at DESC", [req.user.hospitalId]);
  res.json(result.rows.map(toApi));
}

export async function getContactById(req, res) {
  const result = await query("SELECT * FROM contacts WHERE id = $1", [req.params.id]);
  if (result.rows.length === 0) return res.status(404).json({ message: "Contact not found" });
  const contact = result.rows[0];
  if (req.user && contact.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Contact not found" });
  }
  res.json(toApi(contact));
}

export async function createContact(req, res) {
  const { name, category, subType, phone, email, address, department, availability, emergencyPriority, location, notes } = req.body;
  if (!name || !category) return res.status(400).json({ message: "name and category are required" });

  const id = newId("C");
  const hospitalId = req.user?.hospitalId || "HOSP-1";
  const inserted = await query(
    `INSERT INTO contacts (id, name, category, sub_type, phone, email, address, department, availability, emergency_priority, location, notes, hospital_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
    [id, name, category, subType ?? null, phone ?? null, email ?? null, address ?? null, department ?? null, availability ?? null, emergencyPriority ?? "Normal", location ?? null, notes ?? null, hospitalId]
  );
  logCRUD({ entity: "contact", action: "CREATE", actor: req.user?.uid || "unknown", hospitalId, after: inserted.rows[0] });
  res.status(201).json(toApi(inserted.rows[0]));
}

export async function updateContact(req, res) {
  const existing = await query("SELECT * FROM contacts WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Contact not found" });
  const current = existing.rows[0];
  if (req.user && current.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Contact not found" });
  }

  const { name, category, subType, phone, email, address, department, availability, emergencyPriority, location, notes, lastContacted } = req.body;
  const updated = await query(
    `UPDATE contacts SET name=$1, category=$2, sub_type=$3, phone=$4, email=$5, address=$6, department=$7, availability=$8, emergency_priority=$9, location=$10, notes=$11, last_contacted=$12, updated_at=now()
     WHERE id=$13 RETURNING *`,
    [
      name ?? current.name,
      category ?? current.category,
      subType ?? current.sub_type,
      phone ?? current.phone,
      email ?? current.email,
      address ?? current.address,
      department ?? current.department,
      availability ?? current.availability,
      emergencyPriority ?? current.emergency_priority,
      location ?? current.location,
      notes ?? current.notes,
      lastContacted ?? current.last_contacted,
      req.params.id,
    ]
  );
  logCRUD({ entity: "contact", action: "UPDATE", actor: req.user?.uid || "unknown", before: current, after: updated.rows[0] });
  res.json(toApi(updated.rows[0]));
}

export async function markContacted(req, res) {
  const existing = await query("SELECT * FROM contacts WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Contact not found" });
  if (req.user && existing.rows[0].hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Contact not found" });
  }
  const result = await query("UPDATE contacts SET last_contacted = CURRENT_DATE, updated_at = now() WHERE id = $1 RETURNING *", [req.params.id]);
  res.json(toApi(result.rows[0]));
}

export async function deleteContact(req, res) {
  const existing = await query("SELECT * FROM contacts WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Contact not found" });
  if (req.user && existing.rows[0].hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Contact not found" });
  }
  await query("DELETE FROM contacts WHERE id = $1", [req.params.id]);
  logCRUD({ entity: "contact", action: "DELETE", actor: req.user?.uid || "unknown", before: existing.rows[0] });
  res.json({ success: true });
}
