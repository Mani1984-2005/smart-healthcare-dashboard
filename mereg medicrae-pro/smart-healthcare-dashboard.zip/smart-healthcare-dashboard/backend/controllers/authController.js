import { firebaseConfigured, getFirebaseAuth } from "../config/firebaseAdmin.js";
import { resolveHospitalUser } from "../db/userResolution.js";

async function buildUserResponse(decodedToken) {
  const { uid, email, name, picture } = decodedToken;
  const hospitalUser = await resolveHospitalUser(email);
  return { uid, email: email ?? null, name: name ?? null, picture: picture ?? null, role: hospitalUser.role, hospitalId: hospitalUser.hospitalId };
}

export async function login(req, res) {
  if (!firebaseConfigured) {
    return res.status(503).json({ success: false, message: "Authentication isn't configured on this server yet (missing Firebase Admin credentials)." });
  }
  const { idToken } = req.body;
  if (!idToken) return res.status(400).json({ success: false, message: "idToken is required" });

  let decodedToken;
  try {
    decodedToken = await getFirebaseAuth().verifyIdToken(idToken);
  } catch (error) {
    return res.status(401).json({ success: false, message: "Invalid or expired token." });
  }

  const user = await buildUserResponse(decodedToken);
  if (!user.role) {
    return res.status(403).json({ success: false, message: "This email isn't registered with the hospital as staff or a patient. Contact an administrator." });
  }
  res.status(200).json({ success: true, user });
}

export async function me(req, res) {
  // req.user was already populated (role + hospitalId) by the authenticate
  // middleware — if we got here, it's already known-good. Shape the
  // response the same way login() does rather than leaking raw JWT claims.
  const { uid, email, name, picture, role, hospitalId } = req.user;
  res.status(200).json({ success: true, user: { uid, email: email ?? null, name: name ?? null, picture: picture ?? null, role, hospitalId } });
}
