import { query, newId } from "../db/query.js";
import { logCRUD } from "../utils/logger.js";
import { hasPermission } from "../config/permissions.js";
import { patientCareTeamScope, isOwnPatientRecord } from "../db/scope.js";

function toApi(row) {
  return {
    id: row.id,
    fullName: row.full_name,
    age: row.age,
    gender: row.gender,
    phone: row.phone,
    email: row.email,
    bloodGroup: row.blood_group,
    address: row.address,
    medicalHistory: row.medical_history || [],
    registrationDate: row.registration_date,
    status: row.status,
    hospitalId: row.hospital_id,
    primaryDoctorEmail: row.primary_doctor_email ?? null,
  };
}

/**
 * List is always hospital-scoped (tenant isolation, every role including
 * ADMIN). DOCTOR/NURSE additionally only see patients they actually have a
 * relationship with — a doctor with patients:read must not receive every
 * patient in the hospital, only their own care-team's. ADMIN/RECEPTIONIST
 * see every patient in-hospital (administrative/front-desk override).
 */
export async function listPatients(req, res) {
  if (!req.user) {
    // Demo mode (Firebase unconfigured): requireAuth is a no-op and there's
    // no authenticated identity to scope by. Preserve prior open behavior
    // rather than crash on req.user.hospitalId being undefined.
    const result = await query("SELECT * FROM patients ORDER BY created_at DESC");
    return res.json(result.rows.map(toApi));
  }

  const params = [req.user.hospitalId];
  let sql = "SELECT p.* FROM patients p WHERE p.hospital_id = $1";

  const careTeam = patientCareTeamScope(req.user, params.length + 1);
  if (careTeam) {
    sql += ` AND ${careTeam.clause}`;
    params.push(...careTeam.params);
  }

  sql += " ORDER BY p.created_at DESC";
  const result = await query(sql, params);
  res.json(result.rows.map(toApi));
}

/**
 * Not gated by requirePermission("patients:read") at the router level —
 * PATIENT has no general patients:read permission (see permissions.js) but
 * DOES have the right to read their OWN record. That's a row-level
 * decision this handler makes itself, after requireAuth has established
 * who the requester is.
 */
export async function getPatientById(req, res) {
  const result = await query("SELECT * FROM patients WHERE id = $1", [req.params.id]);
  if (result.rows.length === 0) return res.status(404).json({ message: "Patient not found" });
  const patient = result.rows[0];

  if (!req.user) {
    // Demo mode — no authenticated identity to apply row-level rules to.
    return res.json(toApi(patient));
  }

  if (isOwnPatientRecord(req.user, patient.id)) {
    return res.json(toApi(patient));
  }

  if (!hasPermission(req.user.role, "patients:read")) {
    return res.status(403).json({ message: "Forbidden: you don't have permission to read patient records." });
  }
  if (patient.hospital_id !== req.user.hospitalId) {
    // Same response as "not found" — confirming a patient ID exists in a
    // different hospital is itself an information leak (IDOR-adjacent).
    return res.status(404).json({ message: "Patient not found" });
  }
  if ((req.user.role === "DOCTOR" || req.user.role === "NURSE") && patient.primary_doctor_email !== req.user.email) {
    const careTeamMatch = await query(
      `SELECT 1
       WHERE EXISTS (SELECT 1 FROM appointments WHERE patient_id = $1 AND doctor_email = $2)
          OR EXISTS (SELECT 1 FROM lab_tests WHERE patient_id = $1 AND doctor_email = $2)
          OR EXISTS (SELECT 1 FROM prescriptions WHERE patient_id = $1 AND doctor_email = $2)`,
      [patient.id, req.user.email]
    );
    if (careTeamMatch.rows.length === 0) {
      return res.status(403).json({ message: "Forbidden: you're not on this patient's care team." });
    }
  }

  res.json(toApi(patient));
}

export async function createPatient(req, res) {
  const { fullName, age, gender, phone, email, bloodGroup, address, medicalHistory, status, primaryDoctorEmail } = req.body;
  if (!fullName) return res.status(400).json({ message: "fullName is required" });

  const id = newId("P");
  // hospital_id is ALWAYS taken from the authenticated user's own resolved
  // hospital, never from the request body — accepting a client-supplied
  // hospital_id here would let any user assign a patient to a hospital
  // that isn't their own (a mass-assignment / tenant-isolation bypass).
  // In demo mode (no req.user) there's no authenticated hospital to use,
  // so this falls back to the single seeded hospital — matches the schema's
  // NOT NULL hospital_id default and demo mode's existing single-hospital reality.
  const hospitalId = req.user?.hospitalId || "HOSP-1";
  const result = await query(
    `INSERT INTO patients (id, full_name, age, gender, phone, email, blood_group, address, medical_history, status, hospital_id, primary_doctor_email)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
    [id, fullName, age ?? null, gender ?? null, phone ?? null, email ?? null, bloodGroup ?? null, address ?? null, medicalHistory ?? [], status ?? "Active", hospitalId, primaryDoctorEmail ?? null]
  );
  logCRUD({ entity: "patient", action: "CREATE", actor: req.user?.uid || "unknown", hospitalId, after: result.rows[0] });
  res.status(201).json(toApi(result.rows[0]));
}

async function loadAuthorizedPatientForWrite(req, res) {
  const existing = await query("SELECT * FROM patients WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) {
    res.status(404).json({ message: "Patient not found" });
    return null;
  }
  const patient = existing.rows[0];

  if (!req.user) {
    // Demo mode — no authenticated identity to apply hospital/care-team rules to.
    return patient;
  }

  if (patient.hospital_id !== req.user.hospitalId) {
    res.status(404).json({ message: "Patient not found" });
    return null;
  }
  if ((req.user.role === "DOCTOR" || req.user.role === "NURSE") && patient.primary_doctor_email !== req.user.email) {
    const careTeamMatch = await query(
      `SELECT 1
       WHERE EXISTS (SELECT 1 FROM appointments WHERE patient_id = $1 AND doctor_email = $2)
          OR EXISTS (SELECT 1 FROM lab_tests WHERE patient_id = $1 AND doctor_email = $2)
          OR EXISTS (SELECT 1 FROM prescriptions WHERE patient_id = $1 AND doctor_email = $2)`,
      [patient.id, req.user.email]
    );
    if (careTeamMatch.rows.length === 0) {
      res.status(403).json({ message: "Forbidden: you're not on this patient's care team." });
      return null;
    }
  }
  return patient;
}

export async function updatePatient(req, res) {
  const current = await loadAuthorizedPatientForWrite(req, res);
  if (!current) return; // response already sent

  const { fullName, age, gender, phone, email, bloodGroup, address, medicalHistory, status, primaryDoctorEmail } = req.body;
  const result = await query(
    `UPDATE patients SET full_name=$1, age=$2, gender=$3, phone=$4, email=$5, blood_group=$6, address=$7, medical_history=$8, status=$9, primary_doctor_email=$10, updated_at=now()
     WHERE id=$11 RETURNING *`,
    [
      fullName ?? current.full_name,
      age ?? current.age,
      gender ?? current.gender,
      phone ?? current.phone,
      email ?? current.email,
      bloodGroup ?? current.blood_group,
      address ?? current.address,
      medicalHistory ?? current.medical_history,
      status ?? current.status,
      primaryDoctorEmail ?? current.primary_doctor_email,
      req.params.id,
    ]
  );
  logCRUD({ entity: "patient", action: "UPDATE", actor: req.user?.uid || "unknown", hospitalId: req.user?.hospitalId || null, before: current, after: result.rows[0] });
  res.json(toApi(result.rows[0]));
}

export async function deletePatient(req, res) {
  const current = await loadAuthorizedPatientForWrite(req, res);
  if (!current) return;

  await query("DELETE FROM patients WHERE id = $1", [req.params.id]);
  logCRUD({ entity: "patient", action: "DELETE", actor: req.user?.uid || "unknown", hospitalId: req.user?.hospitalId || null, before: current });
  res.json({ success: true });
}
