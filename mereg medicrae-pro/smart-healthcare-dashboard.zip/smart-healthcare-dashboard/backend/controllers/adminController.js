import { query, newId } from "../db/query.js";
import { logCRUD } from "../utils/logger.js";

// ---- Hospital profile (single row) ----
//
// NOTE — architectural debt, documented rather than silently fixed: this
// table is a global singleton (id=1 CHECK), predating migration 002's
// `hospitals` table. In a real multi-hospital deployment this branding
// info (name/address/phone/tagline) would need to move onto a per-hospital
// row instead of being one global record. Left as-is for this pass — see
// backend/ARCHITECTURE.md.

function profileToApi(row) {
  return {
    name: row.name,
    registrationNo: row.registration_no,
    address: row.address,
    emergencyPhone: row.emergency_phone,
    tagline: row.tagline,
  };
}

export async function getProfile(req, res) {
  const result = await query("SELECT * FROM hospital_profile WHERE id = 1");
  res.json(profileToApi(result.rows[0]));
}

export async function updateProfile(req, res) {
  const { name, registrationNo, address, emergencyPhone, tagline } = req.body;
  const result = await query(
    `UPDATE hospital_profile SET name=$1, registration_no=$2, address=$3, emergency_phone=$4, tagline=$5, updated_at=now() WHERE id = 1 RETURNING *`,
    [name, registrationNo, address, emergencyPhone, tagline]
  );
  logCRUD({ entity: "hospital_profile", action: "UPDATE", actor: req.user?.uid || "unknown", after: result.rows[0] });
  res.json(profileToApi(result.rows[0]));
}

// ---- Departments ----

function departmentToApi(row) {
  return { id: row.id, name: row.name, headDoctor: row.head_doctor, description: row.description, hospitalId: row.hospital_id };
}

export async function listDepartments(req, res) {
  if (!req.user) {
    const result = await query("SELECT * FROM departments ORDER BY name");
    return res.json(result.rows.map(departmentToApi));
  }
  const result = await query("SELECT * FROM departments WHERE hospital_id = $1 ORDER BY name", [req.user.hospitalId]);
  res.json(result.rows.map(departmentToApi));
}

export async function createDepartment(req, res) {
  const { name, headDoctor, description } = req.body;
  if (!name) return res.status(400).json({ message: "name is required" });
  const id = newId("DEPT");
  const hospitalId = req.user?.hospitalId || "HOSP-1";
  const inserted = await query("INSERT INTO departments (id, name, head_doctor, description, hospital_id) VALUES ($1,$2,$3,$4,$5) RETURNING *", [id, name, headDoctor ?? null, description ?? null, hospitalId]);
  logCRUD({ entity: "department", action: "CREATE", actor: req.user?.uid || "unknown", hospitalId, after: inserted.rows[0] });
  res.status(201).json(departmentToApi(inserted.rows[0]));
}

export async function updateDepartment(req, res) {
  const existing = await query("SELECT * FROM departments WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Department not found" });
  const current = existing.rows[0];
  if (req.user && current.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Department not found" });
  }
  const { name, headDoctor, description } = req.body;
  const updated = await query(
    "UPDATE departments SET name=$1, head_doctor=$2, description=$3, updated_at=now() WHERE id=$4 RETURNING *",
    [name ?? current.name, headDoctor ?? current.head_doctor, description ?? current.description, req.params.id]
  );
  logCRUD({ entity: "department", action: "UPDATE", actor: req.user?.uid || "unknown", before: current, after: updated.rows[0] });
  res.json(departmentToApi(updated.rows[0]));
}

export async function deleteDepartment(req, res) {
  const existing = await query("SELECT * FROM departments WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Department not found" });
  if (req.user && existing.rows[0].hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Department not found" });
  }
  await query("DELETE FROM departments WHERE id = $1", [req.params.id]);
  logCRUD({ entity: "department", action: "DELETE", actor: req.user?.uid || "unknown", before: existing.rows[0] });
  res.json({ success: true });
}

// ---- Service charges ----

function chargeToApi(row) {
  return { id: row.id, category: row.category, description: row.description, defaultRate: Number(row.default_rate), hospitalId: row.hospital_id };
}

export async function listServiceCharges(req, res) {
  if (!req.user) {
    const result = await query("SELECT * FROM service_charges ORDER BY category");
    return res.json(result.rows.map(chargeToApi));
  }
  const result = await query("SELECT * FROM service_charges WHERE hospital_id = $1 ORDER BY category", [req.user.hospitalId]);
  res.json(result.rows.map(chargeToApi));
}

export async function createServiceCharge(req, res) {
  const { category, description, defaultRate } = req.body;
  if (!category) return res.status(400).json({ message: "category is required" });
  const id = newId("SVC");
  const hospitalId = req.user?.hospitalId || "HOSP-1";
  const inserted = await query("INSERT INTO service_charges (id, category, description, default_rate, hospital_id) VALUES ($1,$2,$3,$4,$5) RETURNING *", [id, category, description ?? null, defaultRate ?? 0, hospitalId]);
  logCRUD({ entity: "service_charge", action: "CREATE", actor: req.user?.uid || "unknown", hospitalId, after: inserted.rows[0] });
  res.status(201).json(chargeToApi(inserted.rows[0]));
}

export async function updateServiceCharge(req, res) {
  const existing = await query("SELECT * FROM service_charges WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Service charge not found" });
  const current = existing.rows[0];
  if (req.user && current.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Service charge not found" });
  }
  const { category, description, defaultRate } = req.body;
  const updated = await query(
    "UPDATE service_charges SET category=$1, description=$2, default_rate=$3, updated_at=now() WHERE id=$4 RETURNING *",
    [category ?? current.category, description ?? current.description, defaultRate ?? current.default_rate, req.params.id]
  );
  logCRUD({ entity: "service_charge", action: "UPDATE", actor: req.user?.uid || "unknown", before: current, after: updated.rows[0] });
  res.json(chargeToApi(updated.rows[0]));
}

export async function deleteServiceCharge(req, res) {
  const existing = await query("SELECT * FROM service_charges WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Service charge not found" });
  if (req.user && existing.rows[0].hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Service charge not found" });
  }
  await query("DELETE FROM service_charges WHERE id = $1", [req.params.id]);
  logCRUD({ entity: "service_charge", action: "DELETE", actor: req.user?.uid || "unknown", before: existing.rows[0] });
  res.json({ success: true });
}

// ---- Staff ----
//
// Staff rows are what login role resolution matches against (see
// db/userResolution.js) — hospital_id here is what future logins for that
// email will resolve to, not just a filtering convenience.

function staffToApi(row) {
  return { id: row.id, name: row.name, role: row.role, department: row.department, email: row.email, status: row.status, hospitalId: row.hospital_id };
}

export async function listStaff(req, res) {
  if (!req.user) {
    const result = await query("SELECT * FROM staff ORDER BY name");
    return res.json(result.rows.map(staffToApi));
  }
  const result = await query("SELECT * FROM staff WHERE hospital_id = $1 ORDER BY name", [req.user.hospitalId]);
  res.json(result.rows.map(staffToApi));
}

export async function createStaff(req, res) {
  const { name, role, department, email, status } = req.body;
  if (!name || !role) return res.status(400).json({ message: "name and role are required" });
  const id = newId("STF");
  const hospitalId = req.user?.hospitalId || "HOSP-1";
  const inserted = await query("INSERT INTO staff (id, name, role, department, email, status, hospital_id) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *", [id, name, role, department ?? null, email ?? null, status ?? "Active", hospitalId]);
  logCRUD({ entity: "staff", action: "CREATE", actor: req.user?.uid || "unknown", hospitalId, after: inserted.rows[0] });
  res.status(201).json(staffToApi(inserted.rows[0]));
}

export async function updateStaff(req, res) {
  const existing = await query("SELECT * FROM staff WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Staff member not found" });
  const current = existing.rows[0];
  if (req.user && current.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Staff member not found" });
  }
  const { name, role, department, email, status } = req.body;
  const updated = await query(
    "UPDATE staff SET name=$1, role=$2, department=$3, email=$4, status=$5, updated_at=now() WHERE id=$6 RETURNING *",
    [name ?? current.name, role ?? current.role, department ?? current.department, email ?? current.email, status ?? current.status, req.params.id]
  );
  logCRUD({ entity: "staff", action: "UPDATE", actor: req.user?.uid || "unknown", before: current, after: updated.rows[0] });
  res.json(staffToApi(updated.rows[0]));
}

export async function deleteStaff(req, res) {
  const existing = await query("SELECT * FROM staff WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Staff member not found" });
  if (req.user && existing.rows[0].hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Staff member not found" });
  }
  await query("DELETE FROM staff WHERE id = $1", [req.params.id]);
  logCRUD({ entity: "staff", action: "DELETE", actor: req.user?.uid || "unknown", before: existing.rows[0] });
  res.json({ success: true });
}
