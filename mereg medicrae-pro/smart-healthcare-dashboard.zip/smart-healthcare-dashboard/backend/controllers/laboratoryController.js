import { query, newId } from "../db/query.js";
import { logCRUD } from "../utils/logger.js";
import { labTestOwnerScope } from "../db/scope.js";

function toApi(row) {
  return {
    id: row.id,
    patientId: row.patient_id,
    patientName: row.patient_name || null,
    doctorName: row.doctor_name,
    testName: row.test_name,
    category: row.category,
    orderDate: row.order_date,
    resultDate: row.result_date,
    status: row.status,
    result: row.result,
    referenceRange: row.reference_range,
    notes: row.notes,
    hospitalId: row.hospital_id,
  };
}

const SELECT_WITH_JOIN = `
  SELECT l.*, p.full_name AS patient_name
  FROM lab_tests l
  LEFT JOIN patients p ON p.id = l.patient_id
`;

// The frontend only sends a doctor NAME for lab orders (no doctor picker by
// ID) — doctor_email is resolved server-side by name lookup, best-effort.
// A name that doesn't match any doctors row leaves doctor_email NULL, which
// simply means that lab test won't grant care-team access via this route
// (fails closed, not open — see db/scope.js).
async function resolveDoctorEmailByName(name) {
  if (!name) return null;
  const result = await query("SELECT email FROM doctors WHERE name = $1 LIMIT 1", [name]);
  return result.rows[0]?.email ?? null;
}

/**
 * DOCTOR is row-level scoped to tests they ordered (labTestOwnerScope).
 * LAB_TECHNICIAN/NURSE/ADMIN are hospital-scoped only — see the comment on
 * labTestOwnerScope in db/scope.js for why LAB_TECHNICIAN isn't narrowed
 * (they process the whole queue, not one doctor's orders).
 */
export async function listTests(req, res) {
  if (!req.user) {
    const result = await query(`${SELECT_WITH_JOIN} ORDER BY l.created_at DESC`);
    return res.json(result.rows.map(toApi));
  }

  const params = [req.user.hospitalId];
  let sql = `${SELECT_WITH_JOIN} WHERE l.hospital_id = $1`;

  const ownerScope = labTestOwnerScope(req.user, params.length + 1);
  if (ownerScope) {
    sql += ` AND l.${ownerScope.clause}`;
    params.push(...ownerScope.params);
  }

  sql += " ORDER BY l.created_at DESC";
  const result = await query(sql, params);
  res.json(result.rows.map(toApi));
}

export async function getTestById(req, res) {
  const result = await query(`${SELECT_WITH_JOIN} WHERE l.id = $1`, [req.params.id]);
  if (result.rows.length === 0) return res.status(404).json({ message: "Lab test not found" });
  const test = result.rows[0];

  if (!req.user) return res.json(toApi(test));

  if (test.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Lab test not found" });
  }
  if (req.user.role === "DOCTOR" && test.doctor_email !== req.user.email) {
    return res.status(403).json({ message: "Forbidden: you didn't order this lab test." });
  }
  res.json(toApi(test));
}

export async function createTest(req, res) {
  const { patientId, doctorName, testName, category, orderDate, resultDate, status, result, referenceRange, notes } = req.body;
  if (!patientId || !testName) return res.status(400).json({ message: "patientId and testName are required" });

  const id = newId("LAB");
  const hospitalId = req.user?.hospitalId || "HOSP-1";
  const doctorEmail = await resolveDoctorEmailByName(doctorName);
  const inserted = await query(
    `INSERT INTO lab_tests (id, patient_id, doctor_name, doctor_email, test_name, category, order_date, result_date, status, result, reference_range, notes, hospital_id)
     VALUES ($1,$2,$3,$4,$5,$6,COALESCE($7, CURRENT_DATE),$8,$9,$10,$11,$12,$13) RETURNING *`,
    [id, patientId, doctorName ?? null, doctorEmail, testName, category ?? null, orderDate ?? null, resultDate ?? null, status ?? "Ordered", result ?? null, referenceRange ?? null, notes ?? null, hospitalId]
  );
  logCRUD({ entity: "lab_test", action: "CREATE", actor: req.user?.uid || "unknown", hospitalId, after: inserted.rows[0] });
  res.status(201).json(toApi(inserted.rows[0]));
}

async function loadAuthorizedTestForWrite(req, res) {
  const existing = await query("SELECT * FROM lab_tests WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) {
    res.status(404).json({ message: "Lab test not found" });
    return null;
  }
  const test = existing.rows[0];

  if (!req.user) return test;

  if (test.hospital_id !== req.user.hospitalId) {
    res.status(404).json({ message: "Lab test not found" });
    return null;
  }
  // LAB_TECHNICIAN/ADMIN keep full write access (processing results for the
  // whole queue is their job). DOCTOR may only modify tests they ordered.
  if (req.user.role === "DOCTOR" && test.doctor_email !== req.user.email) {
    res.status(403).json({ message: "Forbidden: you didn't order this lab test." });
    return null;
  }
  return test;
}

export async function updateTest(req, res) {
  const current = await loadAuthorizedTestForWrite(req, res);
  if (!current) return;

  const { doctorName, testName, category, orderDate, resultDate, status, result, referenceRange, notes } = req.body;
  const doctorEmail = doctorName && doctorName !== current.doctor_name ? await resolveDoctorEmailByName(doctorName) : current.doctor_email;
  const updated = await query(
    `UPDATE lab_tests SET doctor_name=$1, doctor_email=$2, test_name=$3, category=$4, order_date=$5, result_date=$6, status=$7, result=$8, reference_range=$9, notes=$10, updated_at=now()
     WHERE id=$11 RETURNING *`,
    [
      doctorName ?? current.doctor_name,
      doctorEmail,
      testName ?? current.test_name,
      category ?? current.category,
      orderDate ?? current.order_date,
      resultDate ?? current.result_date,
      status ?? current.status,
      result ?? current.result,
      referenceRange ?? current.reference_range,
      notes ?? current.notes,
      req.params.id,
    ]
  );
  logCRUD({ entity: "lab_test", action: "UPDATE", actor: req.user?.uid || "unknown", before: current, after: updated.rows[0] });
  res.json(toApi(updated.rows[0]));
}

export async function deleteTest(req, res) {
  const current = await loadAuthorizedTestForWrite(req, res);
  if (!current) return;

  await query("DELETE FROM lab_tests WHERE id = $1", [req.params.id]);
  logCRUD({ entity: "lab_test", action: "DELETE", actor: req.user?.uid || "unknown", before: current });
  res.json({ success: true });
}
