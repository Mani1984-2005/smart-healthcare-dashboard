import { query, newId } from "../db/query.js";
import { logCRUD } from "../utils/logger.js";
import { appointmentOwnerScope } from "../db/scope.js";

function toApi(row) {
  return {
    id: row.id,
    patientId: row.patient_id,
    patientName: row.patient_name || null,
    doctorId: row.doctor_id,
    doctorName: row.doctor_name || null,
    department: row.department,
    date: row.appointment_date,
    time: row.appointment_time,
    type: row.type,
    status: row.status,
    notes: row.notes,
    hospitalId: row.hospital_id,
  };
}

const SELECT_WITH_JOINS = `
  SELECT a.*, p.full_name AS patient_name, d.name AS doctor_name
  FROM appointments a
  LEFT JOIN patients p ON p.id = a.patient_id
  LEFT JOIN doctors d ON d.id = a.doctor_id
`;

/**
 * DOCTOR is row-level scoped to their own appointments (appointmentOwnerScope).
 * NURSE/ADMIN/RECEPTIONIST are hospital-scoped only — see the comment on
 * appointmentOwnerScope in db/scope.js for why NURSE isn't narrowed further.
 */
export async function listAppointments(req, res) {
  if (!req.user) {
    const result = await query(`${SELECT_WITH_JOINS} ORDER BY a.appointment_date DESC, a.appointment_time DESC`);
    return res.json(result.rows.map(toApi));
  }

  const params = [req.user.hospitalId];
  let sql = `${SELECT_WITH_JOINS} WHERE a.hospital_id = $1`;

  const ownerScope = appointmentOwnerScope(req.user, params.length + 1);
  if (ownerScope) {
    sql += ` AND a.${ownerScope.clause}`;
    params.push(...ownerScope.params);
  }

  sql += " ORDER BY a.appointment_date DESC, a.appointment_time DESC";
  const result = await query(sql, params);
  res.json(result.rows.map(toApi));
}

export async function getAppointmentById(req, res) {
  const result = await query(`${SELECT_WITH_JOINS} WHERE a.id = $1`, [req.params.id]);
  if (result.rows.length === 0) return res.status(404).json({ message: "Appointment not found" });
  const appointment = result.rows[0];

  if (!req.user) return res.json(toApi(appointment));

  if (appointment.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Appointment not found" });
  }
  if (req.user.role === "DOCTOR" && appointment.doctor_email !== req.user.email) {
    return res.status(403).json({ message: "Forbidden: this appointment isn't assigned to you." });
  }
  res.json(toApi(appointment));
}

export async function createAppointment(req, res) {
  const { patientId, doctorId, department, date, time, type, status, notes } = req.body;
  if (!patientId || !date || !time) return res.status(400).json({ message: "patientId, date, and time are required" });

  const id = newId("A");
  const hospitalId = req.user?.hospitalId || "HOSP-1";
  // doctor_email is resolved server-side from the doctors table (a real FK
  // lookup via doctorId), not trusted from the request body — it's the
  // authoritative link used for row-level care-team access checks.
  let doctorEmail = null;
  if (doctorId) {
    const doctorLookup = await query("SELECT email FROM doctors WHERE id = $1", [doctorId]);
    doctorEmail = doctorLookup.rows[0]?.email ?? null;
  }
  const result = await query(
    `INSERT INTO appointments (id, patient_id, doctor_id, doctor_email, department, appointment_date, appointment_time, type, status, notes, hospital_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [id, patientId, doctorId ?? null, doctorEmail, department ?? null, date, time, type ?? "Consultation", status ?? "Scheduled", notes ?? null, hospitalId]
  );
  logCRUD({ entity: "appointment", action: "CREATE", actor: req.user?.uid || "unknown", hospitalId, after: result.rows[0] });
  res.status(201).json(toApi(result.rows[0]));
}

async function loadAuthorizedAppointmentForWrite(req, res) {
  const existing = await query("SELECT * FROM appointments WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) {
    res.status(404).json({ message: "Appointment not found" });
    return null;
  }
  const appointment = existing.rows[0];

  if (!req.user) return appointment;

  if (appointment.hospital_id !== req.user.hospitalId) {
    res.status(404).json({ message: "Appointment not found" });
    return null;
  }
  // RECEPTIONIST/ADMIN keep full write access (scheduling is their job).
  // DOCTOR may only modify appointments assigned to them.
  if (req.user.role === "DOCTOR" && appointment.doctor_email !== req.user.email) {
    res.status(403).json({ message: "Forbidden: this appointment isn't assigned to you." });
    return null;
  }
  return appointment;
}

export async function updateAppointment(req, res) {
  const current = await loadAuthorizedAppointmentForWrite(req, res);
  if (!current) return;

  const { patientId, doctorId, department, date, time, type, status, notes } = req.body;
  let doctorEmail = current.doctor_email;
  if (doctorId && doctorId !== current.doctor_id) {
    const doctorLookup = await query("SELECT email FROM doctors WHERE id = $1", [doctorId]);
    doctorEmail = doctorLookup.rows[0]?.email ?? null;
  }
  const result = await query(
    `UPDATE appointments SET patient_id=$1, doctor_id=$2, doctor_email=$3, department=$4, appointment_date=$5, appointment_time=$6, type=$7, status=$8, notes=$9, updated_at=now()
     WHERE id=$10 RETURNING *`,
    [
      patientId ?? current.patient_id,
      doctorId ?? current.doctor_id,
      doctorEmail,
      department ?? current.department,
      date ?? current.appointment_date,
      time ?? current.appointment_time,
      type ?? current.type,
      status ?? current.status,
      notes ?? current.notes,
      req.params.id,
    ]
  );
  logCRUD({ entity: "appointment", action: "UPDATE", actor: req.user?.uid || "unknown", before: current, after: result.rows[0] });
  res.json(toApi(result.rows[0]));
}

export async function deleteAppointment(req, res) {
  const current = await loadAuthorizedAppointmentForWrite(req, res);
  if (!current) return;

  await query("DELETE FROM appointments WHERE id = $1", [req.params.id]);
  logCRUD({ entity: "appointment", action: "DELETE", actor: req.user?.uid || "unknown", before: current });
  res.json({ success: true });
}
