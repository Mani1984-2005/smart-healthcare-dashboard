import pool from "../config/db.js";
import { query, newId } from "../db/query.js";
import { logCRUD } from "../utils/logger.js";

function invoiceToApi(row, items) {
  return {
    id: row.id,
    invoiceNumber: row.invoice_number,
    patientId: row.patient_id,
    patientName: row.patient_name || null,
    phone: row.patient_phone || null,
    doctorName: row.doctor_name,
    department: row.department,
    items: items.map((item) => ({
      id: item.id,
      description: item.description,
      category: item.category,
      quantity: Number(item.quantity),
      unitPrice: Number(item.unit_price),
      amount: Number(item.amount),
    })),
    subtotal: Number(row.subtotal),
    discount: Number(row.discount),
    tax: Number(row.tax),
    insuranceCoverage: Number(row.insurance_coverage),
    insuranceProvider: row.insurance_provider,
    grandTotal: Number(row.grand_total),
    amountPaid: Number(row.amount_paid),
    balanceDue: Number(row.balance_due),
    paymentMethod: row.payment_method,
    status: row.status,
    billingDate: row.billing_date,
    dueDate: row.due_date,
    notes: row.notes,
    hospitalId: row.hospital_id,
  };
}

function computeTotals(items, discount, tax, insuranceCoverage, amountPaid) {
  const subtotal = items.reduce((sum, item) => sum + Number(item.quantity) * Number(item.unitPrice), 0);
  const taxable = Math.max(subtotal - discount, 0);
  const taxAmount = Math.round(taxable * (tax / 100));
  const grandTotal = Math.max(taxable + taxAmount - insuranceCoverage, 0);
  const balanceDue = Math.max(grandTotal - amountPaid, 0);
  return { subtotal, grandTotal, balanceDue };
}

const INVOICE_SELECT = `
  SELECT i.*, p.full_name AS patient_name, p.phone AS patient_phone
  FROM invoices i
  LEFT JOIN patients p ON p.id = i.patient_id
`;

// Billing summary and lists contain hospital-wide revenue figures — always
// hospital-scoped; there's no PATIENT-facing billing:read permission at
// all (see permissions.js), so no row-level (per-patient) scoping is
// needed here the way it is for patients/appointments.

export async function getSummary(req, res) {
  const hospitalScoped = Boolean(req.user);
  const result = await query(
    `SELECT
      COALESCE(SUM(amount_paid), 0) AS total_collected,
      COALESCE(SUM(balance_due), 0) AS total_outstanding,
      COUNT(*) FILTER (WHERE status = 'Overdue') AS overdue_count,
      COUNT(*) AS invoice_count
    FROM invoices
    ${hospitalScoped ? "WHERE hospital_id = $1" : ""}`,
    hospitalScoped ? [req.user.hospitalId] : []
  );
  const row = result.rows[0];
  res.json({
    totalCollected: Number(row.total_collected),
    totalOutstanding: Number(row.total_outstanding),
    overdueCount: Number(row.overdue_count),
    invoiceCount: Number(row.invoice_count),
  });
}

export async function getInvoices(req, res) {
  const hospitalScoped = Boolean(req.user);
  const invoicesResult = await query(
    `${INVOICE_SELECT} ${hospitalScoped ? "WHERE i.hospital_id = $1" : ""} ORDER BY i.created_at DESC`,
    hospitalScoped ? [req.user.hospitalId] : []
  );
  const itemsResult = await query("SELECT * FROM invoice_items ORDER BY id");
  const itemsByInvoice = new Map();
  for (const item of itemsResult.rows) {
    if (!itemsByInvoice.has(item.invoice_id)) itemsByInvoice.set(item.invoice_id, []);
    itemsByInvoice.get(item.invoice_id).push(item);
  }
  res.json(invoicesResult.rows.map((row) => invoiceToApi(row, itemsByInvoice.get(row.id) || [])));
}

export async function getInvoiceById(req, res) {
  const invoiceResult = await query(`${INVOICE_SELECT} WHERE i.id = $1`, [req.params.id]);
  if (invoiceResult.rows.length === 0) return res.status(404).json({ message: "Invoice not found" });
  const invoice = invoiceResult.rows[0];
  if (req.user && invoice.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Invoice not found" });
  }
  const itemsResult = await query("SELECT * FROM invoice_items WHERE invoice_id = $1 ORDER BY id", [req.params.id]);
  res.json(invoiceToApi(invoice, itemsResult.rows));
}

export async function createInvoice(req, res) {
  const { patientId, doctorName, department, items = [], discount = 0, tax = 0, insuranceCoverage = 0, insuranceProvider, amountPaid = 0, paymentMethod = "Pending", status = "Draft", dueDate, notes } = req.body;
  if (!patientId || items.length === 0) return res.status(400).json({ message: "patientId and at least one line item are required" });

  const { subtotal, grandTotal, balanceDue } = computeTotals(items, discount, tax, insuranceCoverage, amountPaid);
  const id = newId("INV");
  const invoiceNumber = `MCP-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 89999)}`;
  const hospitalId = req.user?.hospitalId || "HOSP-1";

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const invoiceResult = await client.query(
      `INSERT INTO invoices (id, invoice_number, patient_id, doctor_name, department, subtotal, discount, tax, insurance_coverage, insurance_provider, grand_total, amount_paid, balance_due, payment_method, status, due_date, notes, hospital_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18) RETURNING *`,
      [id, invoiceNumber, patientId, doctorName ?? null, department ?? null, subtotal, discount, tax, insuranceCoverage, insuranceProvider ?? null, grandTotal, amountPaid, balanceDue, paymentMethod, status, dueDate ?? null, notes ?? null, hospitalId]
    );
    for (const item of items) {
      await client.query(
        `INSERT INTO invoice_items (id, invoice_id, description, category, quantity, unit_price, amount) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [newId("LI"), id, item.description, item.category ?? "Other", item.quantity, item.unitPrice, Number(item.quantity) * Number(item.unitPrice)]
      );
    }
    await client.query("COMMIT");
    logCRUD({ entity: "invoice", action: "CREATE", actor: req.user?.uid || "unknown", hospitalId, after: invoiceResult.rows[0] });
    const itemsResult = await query("SELECT * FROM invoice_items WHERE invoice_id = $1 ORDER BY id", [id]);
    res.status(201).json(invoiceToApi(invoiceResult.rows[0], itemsResult.rows));
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function updateInvoice(req, res) {
  const existing = await query("SELECT * FROM invoices WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Invoice not found" });
  const current = existing.rows[0];
  if (req.user && current.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Invoice not found" });
  }

  const { doctorName, department, items, discount, tax, insuranceCoverage, insuranceProvider, amountPaid, paymentMethod, status, dueDate, notes } = req.body;
  const nextItems = items ?? (await query('SELECT description, category, quantity, unit_price AS "unitPrice" FROM invoice_items WHERE invoice_id = $1', [req.params.id])).rows;
  const { subtotal, grandTotal, balanceDue } = computeTotals(
    nextItems,
    discount ?? current.discount,
    tax ?? current.tax,
    insuranceCoverage ?? current.insurance_coverage,
    amountPaid ?? current.amount_paid
  );

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await client.query(
      `UPDATE invoices SET doctor_name=$1, department=$2, subtotal=$3, discount=$4, tax=$5, insurance_coverage=$6, insurance_provider=$7, grand_total=$8, amount_paid=$9, balance_due=$10, payment_method=$11, status=$12, due_date=$13, notes=$14, updated_at=now()
       WHERE id=$15 RETURNING *`,
      [
        doctorName ?? current.doctor_name,
        department ?? current.department,
        subtotal,
        discount ?? current.discount,
        tax ?? current.tax,
        insuranceCoverage ?? current.insurance_coverage,
        insuranceProvider ?? current.insurance_provider,
        grandTotal,
        amountPaid ?? current.amount_paid,
        balanceDue,
        paymentMethod ?? current.payment_method,
        status ?? current.status,
        dueDate ?? current.due_date,
        notes ?? current.notes,
        req.params.id,
      ]
    );
    if (items) {
      await client.query("DELETE FROM invoice_items WHERE invoice_id = $1", [req.params.id]);
      for (const item of items) {
        await client.query(
          `INSERT INTO invoice_items (id, invoice_id, description, category, quantity, unit_price, amount) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
          [newId("LI"), req.params.id, item.description, item.category ?? "Other", item.quantity, item.unitPrice, Number(item.quantity) * Number(item.unitPrice)]
        );
      }
    }
    await client.query("COMMIT");
    logCRUD({ entity: "invoice", action: "UPDATE", actor: req.user?.uid || "unknown", before: current, after: result.rows[0] });
    const itemsResult = await query("SELECT * FROM invoice_items WHERE invoice_id = $1 ORDER BY id", [req.params.id]);
    res.json(invoiceToApi(result.rows[0], itemsResult.rows));
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function deleteInvoice(req, res) {
  const existing = await query("SELECT * FROM invoices WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Invoice not found" });
  if (req.user && existing.rows[0].hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Invoice not found" });
  }
  await query("DELETE FROM invoices WHERE id = $1", [req.params.id]);
  logCRUD({ entity: "invoice", action: "DELETE", actor: req.user?.uid || "unknown", before: existing.rows[0] });
  res.json({ success: true });
}
