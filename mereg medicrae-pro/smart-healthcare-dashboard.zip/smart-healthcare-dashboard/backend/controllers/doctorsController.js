import { query, newId } from "../db/query.js";
import { logCRUD } from "../utils/logger.js";

function toApi(row) {
  return {
    id: row.id,
    name: row.name,
    specialty: row.specialty,
    department: row.department,
    phone: row.phone,
    email: row.email,
    qualifications: row.qualifications,
    experienceYears: row.experience_years,
    consultationFee: Number(row.consultation_fee),
    availability: row.availability,
    status: row.status,
    hospitalId: row.hospital_id,
  };
}

// Tenant isolation: every domain table has a hospital_id column (migration
// 002). In demo mode (no req.user — Firebase unconfigured) there's no
// authenticated hospital to scope by, so reads stay unscoped and writes
// fall back to the single seeded hospital, preserving prior open behavior.

export async function listDoctors(req, res) {
  if (!req.user) {
    const result = await query("SELECT * FROM doctors ORDER BY created_at DESC");
    return res.json(result.rows.map(toApi));
  }
  const result = await query("SELECT * FROM doctors WHERE hospital_id = $1 ORDER BY created_at DESC", [req.user.hospitalId]);
  res.json(result.rows.map(toApi));
}

export async function getDoctorById(req, res) {
  const result = await query("SELECT * FROM doctors WHERE id = $1", [req.params.id]);
  if (result.rows.length === 0) return res.status(404).json({ message: "Doctor not found" });
  const doctor = result.rows[0];
  if (req.user && doctor.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Doctor not found" });
  }
  res.json(toApi(doctor));
}

export async function createDoctor(req, res) {
  const { name, specialty, department, phone, email, qualifications, experienceYears, consultationFee, availability, status } = req.body;
  if (!name) return res.status(400).json({ message: "name is required" });

  const id = newId("D");
  const hospitalId = req.user?.hospitalId || "HOSP-1";
  const result = await query(
    `INSERT INTO doctors (id, name, specialty, department, phone, email, qualifications, experience_years, consultation_fee, availability, status, hospital_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
    [id, name, specialty ?? null, department ?? null, phone ?? null, email ?? null, qualifications ?? null, experienceYears ?? 0, consultationFee ?? 0, availability ?? null, status ?? "Available", hospitalId]
  );
  logCRUD({ entity: "doctor", action: "CREATE", actor: req.user?.uid || "unknown", hospitalId, after: result.rows[0] });
  res.status(201).json(toApi(result.rows[0]));
}

export async function updateDoctor(req, res) {
  const existing = await query("SELECT * FROM doctors WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Doctor not found" });
  const current = existing.rows[0];
  if (req.user && current.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Doctor not found" });
  }

  const { name, specialty, department, phone, email, qualifications, experienceYears, consultationFee, availability, status } = req.body;
  const result = await query(
    `UPDATE doctors SET name=$1, specialty=$2, department=$3, phone=$4, email=$5, qualifications=$6, experience_years=$7, consultation_fee=$8, availability=$9, status=$10, updated_at=now()
     WHERE id=$11 RETURNING *`,
    [
      name ?? current.name,
      specialty ?? current.specialty,
      department ?? current.department,
      phone ?? current.phone,
      email ?? current.email,
      qualifications ?? current.qualifications,
      experienceYears ?? current.experience_years,
      consultationFee ?? current.consultation_fee,
      availability ?? current.availability,
      status ?? current.status,
      req.params.id,
    ]
  );
  logCRUD({ entity: "doctor", action: "UPDATE", actor: req.user?.uid || "unknown", before: current, after: result.rows[0] });
  res.json(toApi(result.rows[0]));
}

export async function deleteDoctor(req, res) {
  const existing = await query("SELECT * FROM doctors WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Doctor not found" });
  if (req.user && existing.rows[0].hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Doctor not found" });
  }
  await query("DELETE FROM doctors WHERE id = $1", [req.params.id]);
  logCRUD({ entity: "doctor", action: "DELETE", actor: req.user?.uid || "unknown", before: existing.rows[0] });
  res.json({ success: true });
}
