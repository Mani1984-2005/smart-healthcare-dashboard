import { query, newId } from "../db/query.js";
import { logCRUD } from "../utils/logger.js";
import { prescriptionOwnerScope } from "../db/scope.js";

function medicineToApi(row) {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    form: row.form,
    strength: row.strength,
    manufacturer: row.manufacturer,
    stockQuantity: row.stock_quantity,
    reorderLevel: row.reorder_level,
    unitPrice: Number(row.unit_price),
    expiryDate: row.expiry_date,
    requiresPrescription: row.requires_prescription,
    hospitalId: row.hospital_id,
  };
}

function prescriptionToApi(row) {
  return {
    id: row.id,
    patientId: row.patient_id,
    patientName: row.patient_name || null,
    doctorName: row.doctor_name,
    medicineName: row.medicine_name,
    dosage: row.dosage,
    frequency: row.frequency,
    duration: row.duration,
    prescriptionDate: row.prescription_date,
    status: row.status,
    notes: row.notes,
    hospitalId: row.hospital_id,
  };
}

async function resolveDoctorEmailByName(name) {
  if (!name) return null;
  const result = await query("SELECT email FROM doctors WHERE name = $1 LIMIT 1", [name]);
  return result.rows[0]?.email ?? null;
}

// ---- Medicines ---- (hospital-scoped only — medicine inventory isn't
// patient data, no row-level ownership concept applies)

export async function listMedicines(req, res) {
  if (!req.user) {
    const result = await query("SELECT * FROM medicines ORDER BY name");
    return res.json(result.rows.map(medicineToApi));
  }
  const result = await query("SELECT * FROM medicines WHERE hospital_id = $1 ORDER BY name", [req.user.hospitalId]);
  res.json(result.rows.map(medicineToApi));
}

export async function getMedicine(req, res) {
  const result = await query("SELECT * FROM medicines WHERE id = $1", [req.params.id]);
  if (result.rows.length === 0) return res.status(404).json({ message: "Medicine not found" });
  const medicine = result.rows[0];
  if (req.user && medicine.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Medicine not found" });
  }
  res.json(medicineToApi(medicine));
}

export async function getLowStock(req, res) {
  if (!req.user) {
    const result = await query("SELECT * FROM medicines WHERE stock_quantity <= reorder_level ORDER BY name");
    return res.json(result.rows.map(medicineToApi));
  }
  const result = await query("SELECT * FROM medicines WHERE stock_quantity <= reorder_level AND hospital_id = $1 ORDER BY name", [req.user.hospitalId]);
  res.json(result.rows.map(medicineToApi));
}

export async function createMedicine(req, res) {
  const { name, category, form, strength, manufacturer, stockQuantity, reorderLevel, unitPrice, expiryDate, requiresPrescription } = req.body;
  if (!name) return res.status(400).json({ message: "name is required" });

  const id = newId("MED");
  const hospitalId = req.user?.hospitalId || "HOSP-1";
  const inserted = await query(
    `INSERT INTO medicines (id, name, category, form, strength, manufacturer, stock_quantity, reorder_level, unit_price, expiry_date, requires_prescription, hospital_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
    [id, name, category ?? null, form ?? null, strength ?? null, manufacturer ?? null, stockQuantity ?? 0, reorderLevel ?? 20, unitPrice ?? 0, expiryDate ?? null, requiresPrescription ?? true, hospitalId]
  );
  logCRUD({ entity: "medicine", action: "CREATE", actor: req.user?.uid || "unknown", hospitalId, after: inserted.rows[0] });
  res.status(201).json(medicineToApi(inserted.rows[0]));
}

export async function updateMedicine(req, res) {
  const existing = await query("SELECT * FROM medicines WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Medicine not found" });
  const current = existing.rows[0];
  if (req.user && current.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Medicine not found" });
  }

  const { name, category, form, strength, manufacturer, stockQuantity, reorderLevel, unitPrice, expiryDate, requiresPrescription } = req.body;
  const updated = await query(
    `UPDATE medicines SET name=$1, category=$2, form=$3, strength=$4, manufacturer=$5, stock_quantity=$6, reorder_level=$7, unit_price=$8, expiry_date=$9, requires_prescription=$10, updated_at=now()
     WHERE id=$11 RETURNING *`,
    [
      name ?? current.name,
      category ?? current.category,
      form ?? current.form,
      strength ?? current.strength,
      manufacturer ?? current.manufacturer,
      stockQuantity ?? current.stock_quantity,
      reorderLevel ?? current.reorder_level,
      unitPrice ?? current.unit_price,
      expiryDate ?? current.expiry_date,
      requiresPrescription ?? current.requires_prescription,
      req.params.id,
    ]
  );
  logCRUD({ entity: "medicine", action: "UPDATE", actor: req.user?.uid || "unknown", before: current, after: updated.rows[0] });
  res.json(medicineToApi(updated.rows[0]));
}

export async function deleteMedicine(req, res) {
  const existing = await query("SELECT * FROM medicines WHERE id = $1", [req.params.id]);
  if (existing.rows.length === 0) return res.status(404).json({ message: "Medicine not found" });
  if (req.user && existing.rows[0].hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Medicine not found" });
  }
  await query("DELETE FROM medicines WHERE id = $1", [req.params.id]);
  logCRUD({ entity: "medicine", action: "DELETE", actor: req.user?.uid || "unknown", before: existing.rows[0] });
  res.json({ success: true });
}

// ---- Prescriptions ---- (hospital-scoped; DOCTOR is additionally row-level
// scoped to prescriptions they personally wrote, via prescriptionOwnerScope
// — PHARMACIST/NURSE/ADMIN stay hospital-scoped only, since a pharmacist's
// real job is to fill any prescription in the hospital, not just one
// doctor's patients. See db/scope.js.)

const PRESCRIPTION_SELECT = `
  SELECT rx.*, p.full_name AS patient_name
  FROM prescriptions rx
  LEFT JOIN patients p ON p.id = rx.patient_id
`;

export async function listPrescriptions(req, res) {
  if (!req.user) {
    const result = await query(`${PRESCRIPTION_SELECT} ORDER BY rx.created_at DESC`);
    return res.json(result.rows.map(prescriptionToApi));
  }

  const params = [req.user.hospitalId];
  let sql = `${PRESCRIPTION_SELECT} WHERE rx.hospital_id = $1`;

  const ownerScope = prescriptionOwnerScope(req.user, params.length + 1);
  if (ownerScope) {
    sql += ` AND rx.${ownerScope.clause}`;
    params.push(...ownerScope.params);
  }

  sql += " ORDER BY rx.created_at DESC";
  const result = await query(sql, params);
  res.json(result.rows.map(prescriptionToApi));
}

export async function getByPatient(req, res) {
  if (!req.user) {
    const result = await query(`${PRESCRIPTION_SELECT} WHERE rx.patient_id = $1 ORDER BY rx.created_at DESC`, [req.params.patientId]);
    return res.json(result.rows.map(prescriptionToApi));
  }

  const params = [req.params.patientId, req.user.hospitalId];
  let sql = `${PRESCRIPTION_SELECT} WHERE rx.patient_id = $1 AND rx.hospital_id = $2`;

  const ownerScope = prescriptionOwnerScope(req.user, params.length + 1);
  if (ownerScope) {
    sql += ` AND rx.${ownerScope.clause}`;
    params.push(...ownerScope.params);
  }

  sql += " ORDER BY rx.created_at DESC";
  const result = await query(sql, params);
  res.json(result.rows.map(prescriptionToApi));
}

export async function getPrescriptionById(req, res) {
  const result = await query(`${PRESCRIPTION_SELECT} WHERE rx.id = $1`, [req.params.id]);
  if (result.rows.length === 0) return res.status(404).json({ message: "Prescription not found" });
  const prescription = result.rows[0];

  if (!req.user) return res.json(prescriptionToApi(prescription));

  if (prescription.hospital_id !== req.user.hospitalId) {
    return res.status(404).json({ message: "Prescription not found" });
  }
  if (req.user.role === "DOCTOR" && prescription.doctor_email !== req.user.email) {
    return res.status(403).json({ message: "Forbidden: you didn't write this prescription." });
  }
  res.json(prescriptionToApi(prescription));
}

export async function createPrescription(req, res) {
  const { patientId, doctorName, medicineName, dosage, frequency, duration, prescriptionDate, status, notes } = req.body;
  if (!patientId || !medicineName) return res.status(400).json({ message: "patientId and medicineName are required" });

  const id = newId("RX");
  const hospitalId = req.user?.hospitalId || "HOSP-1";
  const doctorEmail = await resolveDoctorEmailByName(doctorName);
  const inserted = await query(
    `INSERT INTO prescriptions (id, patient_id, doctor_name, doctor_email, medicine_name, dosage, frequency, duration, prescription_date, status, notes, hospital_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,COALESCE($9, CURRENT_DATE),$10,$11,$12) RETURNING *`,
    [id, patientId, doctorName ?? null, doctorEmail, medicineName, dosage ?? null, frequency ?? null, duration ?? null, prescriptionDate ?? null, status ?? "Active", notes ?? null, hospitalId]
  );
  logCRUD({ entity: "prescription", action: "CREATE", actor: req.user?.uid || "unknown", hospitalId, after: inserted.rows[0] });
  res.status(201).json(prescriptionToApi(inserted.rows[0]));
}

async function loadAuthorizedPrescriptionForWrite(req, res, idParam = "id") {
  const existing = await query("SELECT * FROM prescriptions WHERE id = $1", [req.params[idParam]]);
  if (existing.rows.length === 0) {
    res.status(404).json({ message: "Prescription not found" });
    return null;
  }
  const prescription = existing.rows[0];

  if (!req.user) return prescription;

  if (prescription.hospital_id !== req.user.hospitalId) {
    res.status(404).json({ message: "Prescription not found" });
    return null;
  }
  // PHARMACIST/ADMIN keep full write access (dispensing/status updates for
  // the whole queue is their job). DOCTOR may only modify prescriptions
  // they personally wrote.
  if (req.user.role === "DOCTOR" && prescription.doctor_email !== req.user.email) {
    res.status(403).json({ message: "Forbidden: you didn't write this prescription." });
    return null;
  }
  return prescription;
}

export async function updatePrescription(req, res) {
  const current = await loadAuthorizedPrescriptionForWrite(req, res);
  if (!current) return;

  const { doctorName, medicineName, dosage, frequency, duration, prescriptionDate, status, notes } = req.body;
  const doctorEmail = doctorName && doctorName !== current.doctor_name ? await resolveDoctorEmailByName(doctorName) : current.doctor_email;
  const updated = await query(
    `UPDATE prescriptions SET doctor_name=$1, doctor_email=$2, medicine_name=$3, dosage=$4, frequency=$5, duration=$6, prescription_date=$7, status=$8, notes=$9, updated_at=now()
     WHERE id=$10 RETURNING *`,
    [
      doctorName ?? current.doctor_name,
      doctorEmail,
      medicineName ?? current.medicine_name,
      dosage ?? current.dosage,
      frequency ?? current.frequency,
      duration ?? current.duration,
      prescriptionDate ?? current.prescription_date,
      status ?? current.status,
      notes ?? current.notes,
      req.params.id,
    ]
  );
  logCRUD({ entity: "prescription", action: "UPDATE", actor: req.user?.uid || "unknown", before: current, after: updated.rows[0] });
  res.json(prescriptionToApi(updated.rows[0]));
}

export async function updateStatus(req, res) {
  const current = await loadAuthorizedPrescriptionForWrite(req, res, "rxId");
  if (!current) return;

  const { status } = req.body;
  const result = await query("UPDATE prescriptions SET status = $1, updated_at = now() WHERE id = $2 RETURNING *", [status, req.params.rxId]);
  logCRUD({ entity: "prescription", action: "UPDATE", actor: req.user?.uid || "unknown", before: current, after: result.rows[0] });
  res.json(prescriptionToApi(result.rows[0]));
}

export async function deletePrescription(req, res) {
  const current = await loadAuthorizedPrescriptionForWrite(req, res);
  if (!current) return;

  await query("DELETE FROM prescriptions WHERE id = $1", [req.params.id]);
  logCRUD({ entity: "prescription", action: "DELETE", actor: req.user?.uid || "unknown", before: current });
  res.json({ success: true });
}
