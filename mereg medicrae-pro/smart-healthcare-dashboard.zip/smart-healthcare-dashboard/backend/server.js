import app from "./app.js";
import { firebaseConfigured } from "./config/firebaseAdmin.js";

// Fail safe, not silent: a "production" deployment must never accidentally
// run wide open just because nobody set the Firebase env vars. Demo/local
// dev is fine without them (see requireAuth.js / requirePermission.js —
// both no-op when Firebase isn't configured), but that no-op must not be
// reachable in production.
if (process.env.NODE_ENV === "production" && !firebaseConfigured) {
  console.error(
    "FATAL: NODE_ENV=production but Firebase Admin isn't configured (FIREBASE_PROJECT_ID / " +
      "FIREBASE_CLIENT_EMAIL / FIREBASE_PRIVATE_KEY). Refusing to start with authentication " +
      "and authorization disabled in production. Set those env vars, or unset NODE_ENV=production " +
      "for local/demo use."
  );
  process.exit(1);
}

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  if (!firebaseConfigured) {
    console.warn("Running in DEMO MODE — Firebase Admin isn't configured, so no route enforces authentication or authorization.");
  }
});
