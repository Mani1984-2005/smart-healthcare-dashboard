import express from "express";
const router = express.Router();
import * as billingController from "../controllers/billing.controller.js";
import requireAuth from "../middleware/requireAuth.js";
import requirePermission from "../middleware/requirePermission.js";

router.use(requireAuth);

router.get("/summary", requirePermission("billing:read"), billingController.getSummary);
router.get("/invoices", requirePermission("billing:read"), billingController.getInvoices);
router.get("/invoices/:id", requirePermission("billing:read"), billingController.getInvoiceById);
router.post("/invoices", requirePermission("billing:create"), billingController.createInvoice);
router.put("/invoices/:id", requirePermission("billing:update"), billingController.updateInvoice);
router.delete("/invoices/:id", requirePermission("billing:delete"), billingController.deleteInvoice);

export default router;
