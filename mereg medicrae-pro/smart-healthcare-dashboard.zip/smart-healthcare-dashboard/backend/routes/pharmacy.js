import express from "express";
import requireAuth from "../middleware/requireAuth.js";
import requirePermission from "../middleware/requirePermission.js";
import * as pharmacy from "../controllers/pharmacyController.js";

const router = express.Router();
router.use(requireAuth);

router.get("/medicines", requirePermission("pharmacy_medicines:read"), pharmacy.listMedicines);
router.get("/medicines/low-stock", requirePermission("pharmacy_medicines:read"), pharmacy.getLowStock);
router.get("/medicines/:id", requirePermission("pharmacy_medicines:read"), pharmacy.getMedicine);
router.post("/medicines", requirePermission("pharmacy_medicines:create"), pharmacy.createMedicine);
router.put("/medicines/:id", requirePermission("pharmacy_medicines:update"), pharmacy.updateMedicine);
router.delete("/medicines/:id", requirePermission("pharmacy_medicines:delete"), pharmacy.deleteMedicine);

router.get("/prescriptions", requirePermission("prescriptions:read"), pharmacy.listPrescriptions);
router.get("/prescriptions/patient/:patientId", requirePermission("prescriptions:read"), pharmacy.getByPatient);
router.get("/prescriptions/:id", requirePermission("prescriptions:read"), pharmacy.getPrescriptionById);
router.post("/prescriptions", requirePermission("prescriptions:create"), pharmacy.createPrescription);
router.put("/prescriptions/:id", requirePermission("prescriptions:update"), pharmacy.updatePrescription);
router.patch("/prescriptions/:rxId/status", requirePermission("prescriptions:update"), pharmacy.updateStatus);
router.delete("/prescriptions/:id", requirePermission("prescriptions:delete"), pharmacy.deletePrescription);

export default router;
