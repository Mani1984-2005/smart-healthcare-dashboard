import express from "express";
import authenticate from "../middleware/authMiddleware.js";
import * as authController from "../controllers/authController.js";

const router = express.Router();

// POST /api/auth/login — verifies a Firebase ID token from the request body
// and resolves it to a hospital role (staff or patient record by email).
router.post("/login", authController.login);

// GET /api/auth/me — same resolution, but reads the token from the
// Authorization header via the shared `authenticate` middleware.
router.get("/me", authenticate, authController.me);

export default router;
