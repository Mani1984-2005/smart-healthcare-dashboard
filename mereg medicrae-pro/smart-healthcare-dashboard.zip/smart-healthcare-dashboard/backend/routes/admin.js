import express from "express";
import requireAuth from "../middleware/requireAuth.js";
import requirePermission from "../middleware/requirePermission.js";
import * as admin from "../controllers/adminController.js";

const router = express.Router();
router.use(requireAuth);

router.get("/profile", requirePermission("admin:read"), admin.getProfile);
router.put("/profile", requirePermission("admin:update"), admin.updateProfile);

router.get("/departments", requirePermission("admin:read"), admin.listDepartments);
router.post("/departments", requirePermission("admin:create"), admin.createDepartment);
router.put("/departments/:id", requirePermission("admin:update"), admin.updateDepartment);
router.delete("/departments/:id", requirePermission("admin:delete"), admin.deleteDepartment);

router.get("/service-charges", requirePermission("admin:read"), admin.listServiceCharges);
router.post("/service-charges", requirePermission("admin:create"), admin.createServiceCharge);
router.put("/service-charges/:id", requirePermission("admin:update"), admin.updateServiceCharge);
router.delete("/service-charges/:id", requirePermission("admin:delete"), admin.deleteServiceCharge);

router.get("/staff", requirePermission("admin:read"), admin.listStaff);
router.post("/staff", requirePermission("admin:create"), admin.createStaff);
router.put("/staff/:id", requirePermission("admin:update"), admin.updateStaff);
router.delete("/staff/:id", requirePermission("admin:delete"), admin.deleteStaff);

export default router;
