import express from "express";
import requireAuth from "../middleware/requireAuth.js";
import requirePermission from "../middleware/requirePermission.js";
import * as doctors from "../controllers/doctorsController.js";

const router = express.Router();
router.use(requireAuth);

router.get("/", requirePermission("doctors:read"), doctors.listDoctors);
router.get("/:id", requirePermission("doctors:read"), doctors.getDoctorById);
router.post("/", requirePermission("doctors:create"), doctors.createDoctor);
router.put("/:id", requirePermission("doctors:update"), doctors.updateDoctor);
router.delete("/:id", requirePermission("doctors:delete"), doctors.deleteDoctor);

export default router;
