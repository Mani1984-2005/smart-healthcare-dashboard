import express from "express";
import requireAuth from "../middleware/requireAuth.js";
import requirePermission from "../middleware/requirePermission.js";
import * as patients from "../controllers/patientsController.js";

const router = express.Router();
router.use(requireAuth);

router.get("/", requirePermission("patients:read"), patients.listPatients);
// Not gated by requirePermission here — PATIENT has no general patients:read
// permission but does have the right to read their OWN record. The
// controller makes that row-level decision itself (isOwnPatientRecord),
// falling through to the normal permission+hospital+care-team check for
// every other role. See controllers/patientsController.js.
router.get("/:id", patients.getPatientById);
router.post("/", requirePermission("patients:create"), patients.createPatient);
router.put("/:id", requirePermission("patients:update"), patients.updatePatient);
router.delete("/:id", requirePermission("patients:delete"), patients.deletePatient);

export default router;
