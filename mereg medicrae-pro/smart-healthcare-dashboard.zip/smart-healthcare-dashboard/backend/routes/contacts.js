import express from "express";
import requireAuth from "../middleware/requireAuth.js";
import requirePermission from "../middleware/requirePermission.js";
import * as contacts from "../controllers/contactsController.js";

const router = express.Router();
router.use(requireAuth);

router.get("/", requirePermission("contacts:read"), contacts.listContacts);
router.get("/:id", requirePermission("contacts:read"), contacts.getContactById);
router.post("/", requirePermission("contacts:create"), contacts.createContact);
router.put("/:id", requirePermission("contacts:update"), contacts.updateContact);
router.patch("/:id/contacted", requirePermission("contacts:update"), contacts.markContacted);
router.delete("/:id", requirePermission("contacts:delete"), contacts.deleteContact);

export default router;
