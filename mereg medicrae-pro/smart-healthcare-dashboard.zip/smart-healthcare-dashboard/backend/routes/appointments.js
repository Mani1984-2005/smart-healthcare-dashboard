import express from "express";
import requireAuth from "../middleware/requireAuth.js";
import requirePermission from "../middleware/requirePermission.js";
import * as appointments from "../controllers/appointmentsController.js";

const router = express.Router();
router.use(requireAuth);

router.get("/", requirePermission("appointments:read"), appointments.listAppointments);
router.get("/:id", requirePermission("appointments:read"), appointments.getAppointmentById);
router.post("/", requirePermission("appointments:create"), appointments.createAppointment);
router.put("/:id", requirePermission("appointments:update"), appointments.updateAppointment);
router.delete("/:id", requirePermission("appointments:delete"), appointments.deleteAppointment);

export default router;
