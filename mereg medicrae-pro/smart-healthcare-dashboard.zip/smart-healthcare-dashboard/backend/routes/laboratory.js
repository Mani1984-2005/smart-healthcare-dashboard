import express from "express";
import requireAuth from "../middleware/requireAuth.js";
import requirePermission from "../middleware/requirePermission.js";
import * as lab from "../controllers/laboratoryController.js";

const router = express.Router();
router.use(requireAuth);

router.get("/tests", requirePermission("laboratory:read"), lab.listTests);
router.get("/tests/:id", requirePermission("laboratory:read"), lab.getTestById);
router.post("/tests", requirePermission("laboratory:create"), lab.createTest);
router.put("/tests/:id", requirePermission("laboratory:update"), lab.updateTest);
router.delete("/tests/:id", requirePermission("laboratory:delete"), lab.deleteTest);

export default router;
