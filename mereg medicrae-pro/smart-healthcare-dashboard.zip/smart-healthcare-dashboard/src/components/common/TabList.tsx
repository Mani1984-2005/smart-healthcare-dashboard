import { KeyboardEvent, useRef } from "react";

export type TabOption = { id: string; label: string };

type TabListProps = {
  label: string;
  options: TabOption[];
  activeId: string;
  onChange: (id: string) => void;
};

export default function TabList({ label, options, activeId, onChange }: TabListProps) {
  const buttonRefs = useRef<Record<string, HTMLButtonElement | null>>({});

  const focusAndSelect = (id: string) => {
    onChange(id);
    buttonRefs.current[id]?.focus();
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLButtonElement>, index: number) => {
    if (!["ArrowRight", "ArrowLeft", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    let nextIndex = index;
    if (event.key === "ArrowRight") nextIndex = (index + 1) % options.length;
    if (event.key === "ArrowLeft") nextIndex = (index - 1 + options.length) % options.length;
    if (event.key === "Home") nextIndex = 0;
    if (event.key === "End") nextIndex = options.length - 1;
    focusAndSelect(options[nextIndex].id);
  };

  return (
    <div className="flex flex-wrap gap-2" role="tablist" aria-label={label}>
      {options.map((option, index) => (
        <button
          key={option.id}
          ref={(el) => { buttonRefs.current[option.id] = el; }}
          type="button"
          role="tab"
          id={`tab-${option.id}`}
          aria-selected={activeId === option.id}
          aria-controls={`tabpanel-${option.id}`}
          tabIndex={activeId === option.id ? 0 : -1}
          onClick={() => onChange(option.id)}
          onKeyDown={(event) => handleKeyDown(event, index)}
          className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${
            activeId === option.id
              ? "bg-cyan-700 text-white"
              : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
          }`}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}
