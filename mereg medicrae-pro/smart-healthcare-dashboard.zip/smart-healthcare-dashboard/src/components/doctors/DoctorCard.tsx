import { Phone, Mail, Clock, Pencil, Trash2, IndianRupee } from "lucide-react";
import { DoctorRecord } from "../../stores/doctorsStore.ts";
import { Badge, Button } from "../ui";

type DoctorCardProps = {
  doctor: DoctorRecord;
  invoiceCount: number;
  revenue: number;
  onEdit: () => void;
  onDelete: () => void;
};

const statusVariant: Record<DoctorRecord["status"], "success" | "warning" | "neutral" | "danger"> = {
  Available: "success",
  "With Patient": "warning",
  "On Leave": "neutral",
  "Off Duty": "danger",
};

export default function DoctorCard({ doctor, invoiceCount, revenue, onEdit, onDelete }: DoctorCardProps) {
  return (
    <div className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 shadow-card dark:border-slate-800 dark:bg-slate-950">
      <div>
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">{doctor.name}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">{doctor.specialty}</p>
            <p className="mt-1 text-xs font-medium text-cyan-700 dark:text-cyan-300">{doctor.department}</p>
          </div>
          <Badge variant={statusVariant[doctor.status]}>{doctor.status}</Badge>
        </div>

        <div className="mt-4 space-y-2 text-sm text-slate-600 dark:text-slate-300">
          <p className="flex items-center gap-2"><Phone className="h-3.5 w-3.5 shrink-0 text-slate-400" /> {doctor.phone}</p>
          <p className="flex items-center gap-2 truncate"><Mail className="h-3.5 w-3.5 shrink-0 text-slate-400" /> {doctor.email}</p>
          <p className="flex items-center gap-2"><Clock className="h-3.5 w-3.5 shrink-0 text-slate-400" /> {doctor.availability}</p>
        </div>

        <div className="mt-3 rounded-lg bg-slate-50 p-2 text-xs text-slate-600 dark:bg-slate-900 dark:text-slate-400">
          {doctor.qualifications} · {doctor.experienceYears} yrs experience · ₹{doctor.consultationFee.toLocaleString("en-IN")} consultation
        </div>

        <div className="mt-3 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <IndianRupee className="h-3.5 w-3.5" />
          {invoiceCount > 0 ? `${invoiceCount} billed invoice${invoiceCount > 1 ? "s" : ""} · ₹${revenue.toLocaleString("en-IN")} generated` : "No billing history yet"}
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <Button variant="ghost" onClick={onEdit} className="gap-1"><Pencil className="h-3.5 w-3.5" /> Edit</Button>
        <Button variant="ghost" onClick={onDelete} className="gap-1"><Trash2 className="h-3.5 w-3.5 text-rose-600 dark:text-rose-300" /> Delete</Button>
      </div>
    </div>
  );
}
