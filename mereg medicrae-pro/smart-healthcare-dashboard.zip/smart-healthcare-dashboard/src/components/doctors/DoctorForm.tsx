import { FormEvent, useState } from "react";
import Input from "../common/Input.jsx";
import Select from "../common/Select.jsx";
import Button from "../common/Button.jsx";
import { DoctorRecord, DoctorStatus } from "../../stores/doctorsStore.ts";

export type DoctorFormData = Omit<DoctorRecord, "id">;

type DoctorFormProps = {
  initialValues?: DoctorFormData;
  onCancel: () => void;
  onSubmit: (data: DoctorFormData) => void;
  submitLabel: string;
};

const statuses: DoctorStatus[] = ["Available", "With Patient", "On Leave", "Off Duty"];

const defaultValues: DoctorFormData = {
  name: "",
  specialty: "",
  department: "",
  phone: "",
  email: "",
  qualifications: "",
  experienceYears: 0,
  consultationFee: 0,
  availability: "",
  status: "Available",
};

export default function DoctorForm({ initialValues, onCancel, onSubmit, submitLabel }: DoctorFormProps) {
  const [form, setForm] = useState<DoctorFormData>(initialValues || defaultValues);
  const [error, setError] = useState("");

  const handleChange = <K extends keyof DoctorFormData>(key: K, value: DoctorFormData[K]) => {
    setForm((current) => ({ ...current, [key]: value }));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (form.name.trim().length < 2 || form.department.trim().length < 2 || form.phone.trim().length < 3) {
      setError("Enter the doctor's name, department, and phone number.");
      return;
    }
    setError("");
    onSubmit(form);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {error && <div className="rounded-lg bg-rose-50 p-4 text-sm text-rose-700 dark:bg-rose-950/40 dark:text-rose-200">{error}</div>}

      <div className="grid gap-4 md:grid-cols-2">
        <Input label="Name" id="doctor-name" value={form.name} onChange={(event) => handleChange("name", event.target.value)} />
        <Input label="Department" id="doctor-department" value={form.department} onChange={(event) => handleChange("department", event.target.value)} />
        <Input label="Specialty" id="doctor-specialty" value={form.specialty} onChange={(event) => handleChange("specialty", event.target.value)} />
        <Select label="Status" id="doctor-status" value={form.status} onChange={(event) => handleChange("status", event.target.value as DoctorStatus)}>
          {statuses.map((status) => (
            <option key={status} value={status}>{status}</option>
          ))}
        </Select>
        <Input label="Phone" id="doctor-phone" value={form.phone} onChange={(event) => handleChange("phone", event.target.value)} />
        <Input label="Email" id="doctor-email" type="email" value={form.email} onChange={(event) => handleChange("email", event.target.value)} />
        <Input label="Qualifications" id="doctor-qualifications" value={form.qualifications} onChange={(event) => handleChange("qualifications", event.target.value)} />
        <Input label="Availability" id="doctor-availability" placeholder="e.g. Mon–Sat, 9 AM–5 PM" value={form.availability} onChange={(event) => handleChange("availability", event.target.value)} />
        <Input label="Experience (years)" id="doctor-experience" type="number" min={0} value={form.experienceYears} onChange={(event) => handleChange("experienceYears", Number(event.target.value))} />
        <Input label="Consultation fee (₹)" id="doctor-fee" type="number" min={0} value={form.consultationFee} onChange={(event) => handleChange("consultationFee", Number(event.target.value))} />
      </div>

      <div className="flex flex-wrap gap-3 pt-2">
        <Button type="submit">{submitLabel}</Button>
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
      </div>
    </form>
  );
}
