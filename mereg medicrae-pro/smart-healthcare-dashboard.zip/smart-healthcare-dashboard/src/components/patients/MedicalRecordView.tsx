import { PatientRecord } from "../../stores/patientStore.ts";
import { InvoiceRecord } from "../../stores/billingStore.ts";

type MedicalRecordViewProps = {
  patient: PatientRecord;
  invoices: InvoiceRecord[];
  referenceId: string;
  generatedAt: string;
};

const pendingSections: [string, string][] = [
  ["Appointments", "The Appointments module is not yet connected to per-patient records in this build — no appointment history is available."],
  ["Doctors / consultations", "Consultation notes, diagnoses, and treatment plans are not yet tracked per patient in this build."],
  ["Laboratory", "The Laboratory module is not yet connected to per-patient records in this build — no test results are available."],
  ["Prescriptions", "The Pharmacy/prescriptions module is not yet connected to per-patient records in this build — no prescription history is available."],
];

export default function MedicalRecordView({ patient, invoices, referenceId, generatedAt }: MedicalRecordViewProps) {
  const patientInvoices = invoices.filter((invoice) => invoice.patientId === patient.id);

  return (
    <div id="medical-record-print-area" className="space-y-6 text-sm text-slate-700 dark:text-slate-200">
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div>
          <p className="text-lg font-semibold text-slate-900 dark:text-slate-100">MediCare Pro Hospital</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">Registration No. MCP-HOSP-0042 · Emergency: +91 1800 200 1000</p>
        </div>
        <div className="text-right text-xs text-slate-500 dark:text-slate-400">
          <p>Reference: {referenceId}</p>
          <p>Generated {generatedAt}</p>
        </div>
      </div>

      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">Patient identity</p>
        <div className="mt-2 grid gap-x-6 gap-y-1 sm:grid-cols-2">
          <p><span className="font-medium text-slate-900 dark:text-slate-100">Patient ID:</span> {patient.id}</p>
          <p><span className="font-medium text-slate-900 dark:text-slate-100">Registered:</span> {patient.registrationDate}</p>
          <p><span className="font-medium text-slate-900 dark:text-slate-100">Full name:</span> {patient.fullName}</p>
          <p><span className="font-medium text-slate-900 dark:text-slate-100">Status:</span> {patient.status}</p>
          <p><span className="font-medium text-slate-900 dark:text-slate-100">Age / Gender:</span> {patient.age} / {patient.gender}</p>
          <p><span className="font-medium text-slate-900 dark:text-slate-100">Blood group:</span> {patient.bloodGroup || "Not on file"}</p>
          <p><span className="font-medium text-slate-900 dark:text-slate-100">Phone:</span> {patient.phone || "Not on file"}</p>
          <p><span className="font-medium text-slate-900 dark:text-slate-100">Email:</span> {patient.email || "Not on file"}</p>
          <p className="sm:col-span-2"><span className="font-medium text-slate-900 dark:text-slate-100">Address:</span> {patient.address || "Not on file"}</p>
        </div>
      </div>

      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">Medical history</p>
        <ul className="mt-2 space-y-1">
          {patient.medicalHistory.length > 0 ? (
            patient.medicalHistory.map((entry, index) => <li key={index} className="rounded bg-slate-50 px-2 py-1 dark:bg-slate-900">{entry}</li>)
          ) : (
            <li className="rounded bg-slate-50 px-2 py-1 dark:bg-slate-900">No medical history recorded.</li>
          )}
        </ul>
      </div>

      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">Billing</p>
        {patientInvoices.length > 0 ? (
          <div className="mt-2 overflow-hidden rounded-lg border border-slate-200 dark:border-slate-800">
            <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-800">
              <thead className="bg-slate-50 dark:bg-slate-900">
                <tr>
                  <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500 dark:text-slate-400">Invoice</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500 dark:text-slate-400">Date</th>
                  <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500 dark:text-slate-400">Status</th>
                  <th className="px-3 py-2 text-right text-xs font-semibold uppercase text-slate-500 dark:text-slate-400">Amount (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {patientInvoices.map((invoice) => (
                  <tr key={invoice.id}>
                    <td className="px-3 py-2">{invoice.invoiceNumber}</td>
                    <td className="px-3 py-2">{invoice.billingDate}</td>
                    <td className="px-3 py-2">{invoice.status}</td>
                    <td className="px-3 py-2 text-right">{invoice.grandTotal.toLocaleString("en-IN")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="mt-2 rounded bg-slate-50 px-2 py-1 dark:bg-slate-900">No billing records on file for this patient.</p>
        )}
      </div>

      {pendingSections.map(([title, note]) => (
        <div key={title}>
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">{title}</p>
          <p className="mt-2 rounded bg-amber-50 px-2 py-1 text-xs text-amber-900 dark:bg-amber-950/30 dark:text-amber-100">{note}</p>
        </div>
      ))}

      <p className="border-t border-slate-200 pt-3 text-center text-xs text-slate-400 dark:border-slate-800 dark:text-slate-500">
        Confidential patient medical record — for authorized use only.
      </p>
    </div>
  );
}
