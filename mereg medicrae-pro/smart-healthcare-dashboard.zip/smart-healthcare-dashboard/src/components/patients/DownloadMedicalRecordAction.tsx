import { useState } from "react";
import { FileDown, Eye, Printer, Loader2, CheckCircle2, AlertTriangle } from "lucide-react";
import { PatientRecord } from "../../stores/patientStore.ts";
import { InvoiceRecord } from "../../stores/billingStore.ts";
import { Button } from "../ui";
import Dialog from "../ui/Dialog.tsx";
import { generatePatientRecordPdf } from "../../lib/pdf/patientRecordPdf.ts";
import MedicalRecordView from "./MedicalRecordView.tsx";

type Status = "idle" | "generating" | "ready" | "error";

type DownloadMedicalRecordActionProps = {
  patient: PatientRecord;
  invoices: InvoiceRecord[];
  currentUserLabel: string;
};

export default function DownloadMedicalRecordAction({ patient, invoices, currentUserLabel }: DownloadMedicalRecordActionProps) {
  const [status, setStatus] = useState<Status>("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewMeta, setPreviewMeta] = useState<{ referenceId: string; generatedAt: string } | null>(null);

  const handleDownload = async () => {
    setStatus("generating");
    setErrorMessage("");
    try {
      const { doc, filename } = await generatePatientRecordPdf({ patient, invoices, generatedBy: currentUserLabel });
      doc.save(filename);
      setStatus("ready");
    } catch (error) {
      setStatus("error");
      setErrorMessage(
        error instanceof Error
          ? `${error.message} You can use "Print record" instead, which works offline via your browser's Save as PDF option.`
          : "Something went wrong generating the PDF."
      );
    }
  };

  const handlePreview = () => {
    setPreviewMeta({ referenceId: `REC-${patient.id}-PREVIEW`, generatedAt: new Date().toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) });
    setPreviewOpen(true);
  };

  const handlePrint = () => {
    setPreviewMeta({ referenceId: `REC-${patient.id}-PREVIEW`, generatedAt: new Date().toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) });
    setPreviewOpen(true);
    requestAnimationFrame(() => window.print());
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-card dark:border-slate-800 dark:bg-slate-950">
      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">Medical record</p>
      <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Includes patient identity, medical history, and linked billing records currently on file.</p>

      <div className="mt-4 flex flex-wrap gap-2">
        <Button onClick={handleDownload} disabled={status === "generating"} className="gap-2">
          {status === "generating" ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileDown className="h-4 w-4" />}
          {status === "generating" ? "Generating medical record..." : "Download medical record"}
        </Button>
        <Button variant="secondary" onClick={handlePreview} className="gap-2">
          <Eye className="h-4 w-4" /> View medical record
        </Button>
        <Button variant="ghost" onClick={handlePrint} className="gap-2">
          <Printer className="h-4 w-4" /> Print record
        </Button>
      </div>

      {status === "ready" && (
        <p className="mt-3 flex items-center gap-2 text-sm text-emerald-700 dark:text-emerald-300">
          <CheckCircle2 className="h-4 w-4" /> PDF ready — check your downloads folder.
        </p>
      )}
      {status === "error" && (
        <p className="mt-3 flex items-start gap-2 text-sm text-rose-700 dark:text-rose-300">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /> {errorMessage}
        </p>
      )}

      <Dialog open={previewOpen} onClose={() => setPreviewOpen(false)} title={`Medical record — ${patient.fullName}`}>
        {previewMeta && <MedicalRecordView patient={patient} invoices={invoices} referenceId={previewMeta.referenceId} generatedAt={previewMeta.generatedAt} />}
      </Dialog>
    </div>
  );
}
