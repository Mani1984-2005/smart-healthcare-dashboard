import { FormEvent, useState } from "react";
import Input from "../common/Input.jsx";
import Select from "../common/Select.jsx";
import Button from "../common/Button.jsx";
import { ContactCategory, ContactRecord, EmergencyPriority } from "../../stores/contactsStore.ts";

export type ContactFormData = Omit<ContactRecord, "id" | "lastContacted">;

type ContactFormProps = {
  initialValues?: ContactFormData;
  onCancel: () => void;
  onSubmit: (data: ContactFormData) => void;
  submitLabel: string;
};

const categories: ContactCategory[] = ["Emergency", "Hospital", "Patient"];
const priorities: EmergencyPriority[] = ["Critical", "High", "Normal"];
const subTypesByCategory: Record<ContactCategory, string[]> = {
  Emergency: ["Ambulance", "Blood Bank", "Police", "Fire Department", "Nearby Hospital"],
  Hospital: ["Doctor", "Nurse", "Department", "Administration"],
  Patient: ["Family Contact", "Insurance Contact"],
};

const defaultValues: ContactFormData = {
  name: "",
  category: "Hospital",
  subType: subTypesByCategory.Hospital[0],
  phone: "",
  email: "",
  address: "",
  department: "",
  availability: "",
  emergencyPriority: "Normal",
  location: "",
  notes: "",
};

export default function ContactForm({ initialValues, onCancel, onSubmit, submitLabel }: ContactFormProps) {
  const [form, setForm] = useState<ContactFormData>(initialValues || defaultValues);
  const [error, setError] = useState("");

  const handleChange = <K extends keyof ContactFormData>(key: K, value: ContactFormData[K]) => {
    setForm((current) => ({ ...current, [key]: value }));
  };

  const handleCategoryChange = (category: ContactCategory) => {
    setForm((current) => ({ ...current, category, subType: subTypesByCategory[category][0] }));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (form.name.trim().length < 2 || form.phone.trim().length < 3) {
      setError("Enter a contact name and a phone number.");
      return;
    }
    setError("");
    onSubmit(form);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {error && <div className="rounded-lg bg-rose-50 p-4 text-sm text-rose-700 dark:bg-rose-950/40 dark:text-rose-200">{error}</div>}

      <div className="grid gap-4 md:grid-cols-2">
        <Input label="Name" id="contact-name" value={form.name} onChange={(event) => handleChange("name", event.target.value)} />
        <Select label="Category" id="contact-category" value={form.category} onChange={(event) => handleCategoryChange(event.target.value as ContactCategory)}>
          {categories.map((category) => (
            <option key={category} value={category}>{category}</option>
          ))}
        </Select>
        <Select label="Type" id="contact-subtype" value={form.subType} onChange={(event) => handleChange("subType", event.target.value)}>
          {subTypesByCategory[form.category].map((subType) => (
            <option key={subType} value={subType}>{subType}</option>
          ))}
        </Select>
        <Select label="Emergency priority" id="contact-priority" value={form.emergencyPriority} onChange={(event) => handleChange("emergencyPriority", event.target.value as EmergencyPriority)}>
          {priorities.map((priority) => (
            <option key={priority} value={priority}>{priority}</option>
          ))}
        </Select>
        <Input label="Phone" id="contact-phone" value={form.phone} onChange={(event) => handleChange("phone", event.target.value)} />
        <Input label="Email" id="contact-email" type="email" value={form.email} onChange={(event) => handleChange("email", event.target.value)} />
        <Input label="Department" id="contact-department" value={form.department} onChange={(event) => handleChange("department", event.target.value)} />
        <Input label="Availability" id="contact-availability" placeholder="e.g. 24/7 or Mon–Fri, 9 AM–5 PM" value={form.availability} onChange={(event) => handleChange("availability", event.target.value)} />
        <Input label="Location" id="contact-location" value={form.location} onChange={(event) => handleChange("location", event.target.value)} />
        <Input label="Address" id="contact-address" value={form.address} onChange={(event) => handleChange("address", event.target.value)} />
      </div>

      <div>
        <label htmlFor="contact-notes" className="block text-sm font-medium text-slate-700 dark:text-slate-200">Notes</label>
        <textarea
          id="contact-notes"
          rows={3}
          value={form.notes}
          onChange={(event) => handleChange("notes", event.target.value)}
          className="mt-2 block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-cyan-600 focus:ring-2 focus:ring-cyan-200 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
        />
      </div>

      <div className="flex flex-wrap gap-3 pt-2">
        <Button type="submit">{submitLabel}</Button>
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
      </div>
    </form>
  );
}
