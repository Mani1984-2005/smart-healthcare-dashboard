import { Phone, Mail, MapPin, Clock, MessageSquareText, Pencil, Trash2 } from "lucide-react";
import { ContactRecord } from "../../stores/contactsStore.ts";
import { Badge, Button } from "../ui";

type ContactCardProps = {
  contact: ContactRecord;
  onEdit: () => void;
  onDelete: () => void;
  onMessage: () => void;
};

const priorityVariant: Record<ContactRecord["emergencyPriority"], "danger" | "warning" | "neutral"> = {
  Critical: "danger",
  High: "warning",
  Normal: "neutral",
};

export default function ContactCard({ contact, onEdit, onDelete, onMessage }: ContactCardProps) {
  return (
    <div className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 shadow-card dark:border-slate-800 dark:bg-slate-950">
      <div>
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">{contact.name}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">{contact.subType}{contact.department && ` · ${contact.department}`}</p>
          </div>
          <Badge variant={priorityVariant[contact.emergencyPriority]}>{contact.emergencyPriority}</Badge>
        </div>

        <div className="mt-4 space-y-2 text-sm text-slate-600 dark:text-slate-300">
          {contact.phone && (
            <p className="flex items-center gap-2"><Phone className="h-3.5 w-3.5 shrink-0 text-slate-400" /> {contact.phone}</p>
          )}
          {contact.email && (
            <p className="flex items-center gap-2 truncate"><Mail className="h-3.5 w-3.5 shrink-0 text-slate-400" /> {contact.email}</p>
          )}
          {(contact.location || contact.address) && (
            <p className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5 shrink-0 text-slate-400" /> {contact.location || contact.address}</p>
          )}
          {contact.availability && (
            <p className="flex items-center gap-2"><Clock className="h-3.5 w-3.5 shrink-0 text-slate-400" /> {contact.availability}</p>
          )}
        </div>

        {contact.notes && <p className="mt-3 rounded-lg bg-slate-50 p-2 text-xs text-slate-600 dark:bg-slate-900 dark:text-slate-400">{contact.notes}</p>}
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <Button variant="secondary" onClick={onMessage} className="gap-1"><MessageSquareText className="h-3.5 w-3.5" /> Message</Button>
        <Button variant="ghost" onClick={onEdit} className="gap-1"><Pencil className="h-3.5 w-3.5" /> Edit</Button>
        <Button variant="ghost" onClick={onDelete} className="gap-1"><Trash2 className="h-3.5 w-3.5 text-rose-600 dark:text-rose-300" /> Delete</Button>
      </div>
    </div>
  );
}
