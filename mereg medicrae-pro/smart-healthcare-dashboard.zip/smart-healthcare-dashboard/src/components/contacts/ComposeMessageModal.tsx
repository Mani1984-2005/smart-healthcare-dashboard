import { useState } from "react";
import { Info, MessageCircle, Smartphone, Mail, Bell } from "lucide-react";
import { ContactRecord } from "../../stores/contactsStore.ts";
import { Button } from "../ui";

type Channel = "SMS" | "Email" | "WhatsApp" | "Push";

type ComposeMessageModalProps = {
  contact: ContactRecord;
  onClose: () => void;
  onQueued: (channel: Channel) => void;
};

const channels: { id: Channel; label: string; icon: typeof Mail }[] = [
  { id: "SMS", label: "SMS", icon: Smartphone },
  { id: "Email", label: "Email", icon: Mail },
  { id: "WhatsApp", label: "WhatsApp", icon: MessageCircle },
  { id: "Push", label: "Push", icon: Bell },
];

export default function ComposeMessageModal({ contact, onClose, onQueued }: ComposeMessageModalProps) {
  const [channel, setChannel] = useState<Channel>("SMS");
  const [message, setMessage] = useState("");

  const handleQueue = () => {
    onQueued(channel);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-start gap-2 rounded-lg bg-amber-50 p-3 text-xs text-amber-900 dark:bg-amber-950/30 dark:text-amber-100">
        <Info className="mt-0.5 h-4 w-4 shrink-0" />
        This is the messaging UI only — no SMS, email, WhatsApp, or push provider is connected yet, so nothing is actually sent. Hook up a provider (e.g. Twilio, SES, WhatsApp Business API) in the backend to make this live.
      </div>

      <div>
        <p className="text-sm font-medium text-slate-700 dark:text-slate-200">To</p>
        <p className="mt-1 text-sm text-slate-900 dark:text-slate-100">{contact.name} {contact.phone && `· ${contact.phone}`} {contact.email && `· ${contact.email}`}</p>
      </div>

      <div>
        <p className="text-sm font-medium text-slate-700 dark:text-slate-200">Channel</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {channels.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setChannel(item.id)}
                className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm font-medium transition ${
                  channel === item.id
                    ? "border-cyan-600 bg-cyan-50 text-cyan-800 dark:border-cyan-500 dark:bg-cyan-950/40 dark:text-cyan-200"
                    : "border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-900"
                }`}
              >
                <Icon className="h-4 w-4" /> {item.label}
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <label htmlFor="compose-message" className="block text-sm font-medium text-slate-700 dark:text-slate-200">Message</label>
        <textarea
          id="compose-message"
          rows={4}
          value={message}
          onChange={(event) => setMessage(event.target.value)}
          placeholder="Type your message..."
          className="mt-2 block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-cyan-600 focus:ring-2 focus:ring-cyan-200 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
        />
      </div>

      <div className="flex flex-wrap gap-3 pt-2">
        <Button type="button" onClick={handleQueue} disabled={!message.trim()}>Mark as sent</Button>
        <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
      </div>
    </div>
  );
}
