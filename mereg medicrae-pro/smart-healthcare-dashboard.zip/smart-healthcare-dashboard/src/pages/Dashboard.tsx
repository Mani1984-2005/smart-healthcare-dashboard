import { useEffect, useMemo } from "react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Activity, AlertTriangle, ArrowUpRight, BedDouble, BrainCircuit, CalendarDays, Clock3, FileClock, FlaskConical, IndianRupee, Pill, Plus, Stethoscope, UserRoundCheck, UsersRound } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "../store/authStore.js";
import { Badge, Button, MetricCard, PageHeader, Section } from "../components/ui";
import { usePatientStore } from "../stores/patientStore.ts";
import { useDoctorsStore } from "../stores/doctorsStore.ts";
import { useAppointmentsStore } from "../stores/appointmentsStore.ts";
import { useBillingStore } from "../stores/billingStore.ts";
import { useLabStore } from "../stores/labStore.ts";
import { usePharmacyStore, generatePharmacyInsights } from "../stores/pharmacyStore.ts";
import { wardCapacity } from "../components/reports/reportData.ts";

function chartTooltip(value: unknown) {
  return typeof value === "number" ? value.toLocaleString("en-IN") : String(value);
}

function monthLabel(dateStr: string) {
  return new Date(dateStr).toLocaleDateString("en-IN", { month: "short" });
}

export default function Dashboard() {
  const { user } = useAuthStore();
  const navigate = useNavigate();

  const { patients, loadPatients } = usePatientStore();
  const { doctors } = useDoctorsStore();
  const { appointments } = useAppointmentsStore();
  const { invoices, loadInvoices } = useBillingStore();
  const { tests } = useLabStore();
  const { medicines } = usePharmacyStore();

  useEffect(() => {
    loadPatients();
    loadInvoices();
  }, [loadPatients, loadInvoices]);

  const dateContext = useMemo(() => new Intl.DateTimeFormat("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(new Date()), []);
  const greeting = user?.name ? `Good day, ${user.name}` : "Good day";
  const todayStr = new Date().toISOString().split("T")[0];

  const todaysAppointments = useMemo(() => appointments.filter((a) => a.date === todayStr), [appointments, todayStr]);
  const checkedInToday = todaysAppointments.filter((a) => a.status === "Checked In" || a.status === "Completed").length;
  const availableDoctors = doctors.filter((d) => d.status === "Available").length;
  const monthRevenue = useMemo(() => {
    const thisMonth = new Date().getMonth();
    return invoices.filter((inv) => new Date(inv.billingDate).getMonth() === thisMonth).reduce((sum, inv) => sum + inv.amountPaid, 0);
  }, [invoices]);
  const pendingLabTests = tests.filter((t) => t.status === "Ordered" || t.status === "Sample Collected" || t.status === "In Progress");

  const metrics = [
    { label: "Total patients", value: String(patients.length), description: "Registered patient base", trend: `${patients.filter((p) => p.status === "Active").length} active`, icon: <UsersRound className="h-5 w-5" aria-hidden="true" /> },
    { label: "Today's appointments", value: String(todaysAppointments.length), description: `${checkedInToday} checked in / completed`, trend: `${todaysAppointments.length - checkedInToday} remaining`, icon: <CalendarDays className="h-5 w-5" aria-hidden="true" /> },
    { label: "Active doctors", value: String(doctors.length), description: `Across ${new Set(doctors.map((d) => d.department)).size} departments`, trend: `${availableDoctors} currently available`, icon: <Stethoscope className="h-5 w-5" aria-hidden="true" /> },
    { label: "Revenue", value: `₹${monthRevenue.toLocaleString("en-IN")}`, description: "Month to date, collected", trend: `${invoices.filter((i) => i.status === "Overdue").length} overdue invoices`, icon: <IndianRupee className="h-5 w-5" aria-hidden="true" /> },
    { label: "Pending lab tests", value: String(pendingLabTests.length), description: "Ordered, collected, or in progress", trend: pendingLabTests.length > 0 ? "Needs review" : "All clear", icon: <FileClock className="h-5 w-5" aria-hidden="true" /> },
  ];

  const patientGrowth = useMemo(() => {
    const byMonth: Record<string, number> = {};
    patients.forEach((p) => { byMonth[monthLabel(p.registrationDate)] = (byMonth[monthLabel(p.registrationDate)] || 0) + 1; });
    return Object.entries(byMonth).map(([month, count]) => ({ month, patients: count }));
  }, [patients]);

  const appointmentTrends = useMemo(() => {
    const byDay: Record<string, { completed: number; scheduled: number }> = {};
    appointments.forEach((a) => {
      const day = new Date(a.date).toLocaleDateString("en-IN", { weekday: "short" });
      if (!byDay[day]) byDay[day] = { completed: 0, scheduled: 0 };
      if (a.status === "Completed") byDay[day].completed += 1;
      else if (a.status === "Scheduled" || a.status === "Checked In") byDay[day].scheduled += 1;
    });
    return Object.entries(byDay).map(([day, counts]) => ({ day, ...counts }));
  }, [appointments]);

  const revenueTrend = useMemo(() => {
    const byMonth: Record<string, number> = {};
    invoices.forEach((inv) => { byMonth[monthLabel(inv.billingDate)] = (byMonth[monthLabel(inv.billingDate)] || 0) + inv.grandTotal; });
    return Object.entries(byMonth).map(([month, revenue]) => ({ month, revenue: Math.round(revenue / 1000) / 100 }));
  }, [invoices]);

  const pharmacyInsights = useMemo(() => generatePharmacyInsights(medicines), [medicines]);
  const criticalPatients = patients.filter((p) => p.status === "Critical");
  const icuWard = wardCapacity.find((w) => w.ward === "ICU");

  return <div className="space-y-6">
    <PageHeader eyebrow={dateContext} title={greeting} description="Monitor care delivery, clinical capacity, and the priorities requiring action today." actions={<><Button variant="secondary" onClick={() => navigate("/appointments")}><CalendarDays className="h-4 w-4" aria-hidden="true" />View schedule</Button><Button onClick={() => navigate("/patients")}><Plus className="h-4 w-4" aria-hidden="true" />Add patient</Button></>} />

    <section aria-label="Healthcare key performance indicators" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
      {metrics.map((metric) => <MetricCard key={metric.label} {...metric} trend={<><ArrowUpRight className="mr-1 inline h-3.5 w-3.5" aria-hidden="true" />{metric.trend}</>} />)}
    </section>

    <section className="grid gap-6 xl:grid-cols-2">
      <Section title="Patient growth" description="Registered patients by month" action={<Badge variant="success">{patients.length} total</Badge>}>
        {patientGrowth.length > 0 ? (
          <div className="h-72" aria-label="Patient growth chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={patientGrowth} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}><defs><linearGradient id="patientGrowthGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#0b6e99" stopOpacity={0.25} /><stop offset="95%" stopColor="#0b6e99" stopOpacity={0} /></linearGradient></defs><CartesianGrid vertical={false} stroke="#e2e8f0" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "#64748b", fontSize: 12 }} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "#64748b", fontSize: 12 }} /><Tooltip formatter={chartTooltip} /><Area type="monotone" dataKey="patients" stroke="#0b6e99" strokeWidth={2.5} fill="url(#patientGrowthGradient)" /></AreaChart></ResponsiveContainer></div>
        ) : <p className="text-sm text-slate-500 dark:text-slate-400">No registered patients yet.</p>}
      </Section>
      <Section title="Appointment flow" description="Scheduled vs. completed, by day" action={<Badge variant="info">{appointments.length} total</Badge>}>
        {appointmentTrends.length > 0 ? (
          <div className="h-72" aria-label="Appointment trends chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={appointmentTrends} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}><CartesianGrid vertical={false} stroke="#e2e8f0" /><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#64748b", fontSize: 12 }} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "#64748b", fontSize: 12 }} /><Tooltip formatter={chartTooltip} /><Legend iconType="circle" iconSize={8} /><Bar dataKey="scheduled" name="Scheduled" fill="#93c5fd" radius={[4, 4, 0, 0]} /><Bar dataKey="completed" name="Completed" fill="#0b6e99" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div>
        ) : <p className="text-sm text-slate-500 dark:text-slate-400">No appointments booked yet.</p>}
      </Section>
    </section>

    <section className="grid gap-6 xl:grid-cols-[1.45fr_1fr]">
      <Section title="Revenue performance" description="Monthly collections (₹ lakhs)" action={<Badge variant="success">₹{monthRevenue.toLocaleString("en-IN")} MTD</Badge>}>
        {revenueTrend.length > 0 ? (
          <div className="h-64" aria-label="Revenue trend chart"><ResponsiveContainer width="100%" height="100%"><LineChart data={revenueTrend} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}><CartesianGrid vertical={false} stroke="#e2e8f0" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "#64748b", fontSize: 12 }} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "#64748b", fontSize: 12 }} /><Tooltip formatter={(value) => `₹${chartTooltip(value)}L`} /><Line type="monotone" dataKey="revenue" stroke="#16803c" strokeWidth={2.5} dot={{ r: 3 }} /></LineChart></ResponsiveContainer></div>
        ) : <p className="text-sm text-slate-500 dark:text-slate-400">No billing history yet.</p>}
      </Section>
      <Section title="MediCare AI Insights" description="Future-ready clinical operations intelligence.">
        <div className="flex h-64 flex-col justify-between rounded-lg bg-cyan-50 p-5 dark:bg-cyan-950/30"><div><div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white text-cyan-700 shadow-card dark:bg-slate-900"><BrainCircuit className="h-5 w-5" aria-hidden="true" /></div><p className="mt-4 text-sm font-semibold text-slate-900 dark:text-slate-100">Insight workspace ready</p><p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-400">Rule-based insights already run in Billing, Reports, Contacts, and Pharmacy. A model-backed insight layer for cross-module forecasting isn't connected yet.</p></div><Badge variant="neutral">See per-module insight panels</Badge></div>
      </Section>
    </section>

    <section className="grid gap-6 xl:grid-cols-[1.25fr_1fr]">
      <Section title="Today's schedule" description="Appointments booked for today" action={<Button variant="ghost" onClick={() => navigate("/appointments")}>Open appointments</Button>}>
        {todaysAppointments.length > 0 ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">{todaysAppointments.map((item) => <div key={item.id} className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center"><div className="flex w-16 items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100"><Clock3 className="h-4 w-4 text-cyan-700" aria-hidden="true" />{item.time}</div><div className="flex-1"><p className="text-sm font-semibold text-slate-900 dark:text-slate-100">{item.patientName}</p><p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{item.type} with {item.doctorName}</p></div><Badge variant={item.status === "Checked In" || item.status === "Completed" ? "success" : "neutral"}>{item.status}</Badge></div>)}</div>
        ) : <p className="text-sm text-slate-500 dark:text-slate-400">No appointments scheduled for today.</p>}
      </Section>
      <Section title="Doctor availability" description="Live care-team capacity" action={<Button variant="ghost" onClick={() => navigate("/doctors")}>View directory</Button>}>
        {doctors.length > 0 ? (
          <div className="space-y-4">{doctors.slice(0, 5).map((doctor) => <div key={doctor.id} className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-full bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300"><UserRoundCheck className="h-4 w-4" aria-hidden="true" /></div><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-slate-900 dark:text-slate-100">{doctor.name}</p><p className="text-xs text-slate-500 dark:text-slate-400">{doctor.specialty}</p></div><Badge variant={doctor.status === "Available" ? "success" : doctor.status === "With Patient" ? "warning" : "neutral"}>{doctor.status}</Badge></div>)}</div>
        ) : <p className="text-sm text-slate-500 dark:text-slate-400">No doctors in the directory yet.</p>}
      </Section>
    </section>

    <section className="grid gap-6 lg:grid-cols-3">
      <Section title="Laboratory queue" description="Tests awaiting review" action={<FlaskConical className="h-5 w-5 text-cyan-700" aria-hidden="true" />}>
        {pendingLabTests.length > 0 ? (
          <ul className="space-y-3">{pendingLabTests.map((test) => <li key={test.id} className="flex items-start gap-3 rounded-lg bg-slate-50 p-3 text-sm text-slate-700 dark:bg-slate-900 dark:text-slate-200"><Activity className="mt-0.5 h-4 w-4 shrink-0 text-cyan-700" aria-hidden="true" />{test.testName} — {test.patientName} ({test.status})</li>)}</ul>
        ) : <p className="text-sm text-slate-500 dark:text-slate-400">No pending lab tests.</p>}
      </Section>
      <Section title="Pharmacy alerts" description="Inventory conditions to monitor" action={<Pill className="h-5 w-5 text-amber-700" aria-hidden="true" />}>
        <ul className="space-y-3">{pharmacyInsights.map((insight) => <li key={insight.id} className="flex items-start gap-3 rounded-lg bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-950/30 dark:text-amber-100"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />{insight.message}</li>)}</ul>
      </Section>
      <Section title="Bed &amp; ICU availability" description="Ward occupancy" action={<BedDouble className="h-5 w-5 text-slate-500" aria-hidden="true" />}>
        <ul className="space-y-3">{wardCapacity.map((ward) => { const pct = Math.round((ward.occupied / ward.capacity) * 100); return <li key={ward.ward} className="rounded-lg bg-slate-50 p-3 text-sm dark:bg-slate-900"><div className="flex items-center justify-between"><span className="font-medium text-slate-900 dark:text-slate-100">{ward.ward}</span><span className="text-slate-500 dark:text-slate-400">{ward.occupied}/{ward.capacity}</span></div><div className="mt-2 h-1.5 rounded-full bg-slate-200 dark:bg-slate-800"><div className={`h-1.5 rounded-full ${pct >= 85 ? "bg-rose-600" : pct >= 70 ? "bg-amber-500" : "bg-emerald-600"}`} style={{ width: `${pct}%` }} /></div></li>; })}</ul>
      </Section>
    </section>

    <Section title="Critical attention" description="High-priority events that require an owner or immediate review." className="border-rose-200 dark:border-rose-900/60" action={<Badge variant="critical">{criticalPatients.length + (icuWard && Math.round((icuWard.occupied / icuWard.capacity) * 100) >= 75 ? 1 : 0)} active alerts</Badge>}>
      <div className="grid gap-4 md:grid-cols-2">
        {criticalPatients.length > 0 ? criticalPatients.slice(0, 1).map((patient) => (
          <div key={patient.id} className="rounded-lg border border-rose-200 bg-rose-50 p-4 dark:border-rose-900/50 dark:bg-rose-950/30"><div className="flex items-start justify-between gap-3"><div><p className="text-sm font-semibold text-rose-900 dark:text-rose-100">Critical patient observation</p><p className="mt-1 text-sm text-rose-800 dark:text-rose-200">{patient.fullName} ({patient.id}) is marked critical and needs a care-team review.</p></div><Badge variant="critical">Critical</Badge></div><Button variant="danger" className="mt-4" onClick={() => navigate(`/patients/${patient.id}`)}>Review patient</Button></div>
        )) : <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 text-sm text-slate-500 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">No patients currently marked critical.</div>}
        {pendingLabTests.length > 0 ? (
          <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 dark:border-amber-900/50 dark:bg-amber-950/30"><div className="flex items-start justify-between gap-3"><div><p className="text-sm font-semibold text-amber-900 dark:text-amber-100">Laboratory turnaround risk</p><p className="mt-1 text-sm text-amber-800 dark:text-amber-200">{pendingLabTests.length} report{pendingLabTests.length > 1 ? "s are" : " is"} still pending review.</p></div><Badge variant="warning">Priority</Badge></div><Button variant="secondary" className="mt-4" onClick={() => navigate("/laboratory")}>Open laboratory</Button></div>
        ) : <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 text-sm text-slate-500 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">No lab tests awaiting review.</div>}
      </div>
    </Section>
  </div>;
}
