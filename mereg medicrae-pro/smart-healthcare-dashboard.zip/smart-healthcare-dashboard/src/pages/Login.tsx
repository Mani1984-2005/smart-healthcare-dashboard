import { FormEvent, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuthStore } from "../store/authStore.js";
import { firebaseConfigured } from "../lib/firebase.js";
import { ROLES } from "../app/roles.js";

const defaultRoles = [
  ROLES.PATIENT,
  ROLES.DOCTOR,
  ROLES.NURSE,
  ROLES.RECEPTIONIST,
  ROLES.LAB_TECHNICIAN,
  ROLES.PHARMACIST,
  ROLES.ADMIN,
];

export default function LoginPage() {
  const [mode, setMode] = useState<"real" | "demo">(firebaseConfigured ? "real" : "demo");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [demoName, setDemoName] = useState("");
  const [demoEmail, setDemoEmail] = useState("");
  const [demoRole, setDemoRole] = useState(ROLES.PATIENT);
  const [formError, setFormError] = useState("");
  const navigate = useNavigate();
  const location = useLocation();
  const { loginWithFirebase, loginDemo, loading, error } = useAuthStore();

  const from = (location.state as { from?: { pathname?: string } } | null)?.from?.pathname || "/dashboard";

  const handleRealSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setFormError("");
    if (!email.trim() || !password) {
      setFormError("Email and password are required.");
      return;
    }
    const success = await loginWithFirebase(email.trim(), password);
    if (success) navigate(from, { replace: true });
  };

  const handleDemoSubmit = (event: FormEvent) => {
    event.preventDefault();
    setFormError("");
    if (!demoName.trim() || !demoEmail.trim()) {
      setFormError("Name and email are required.");
      return;
    }
    loginDemo({ id: crypto.randomUUID(), name: demoName.trim(), email: demoEmail.trim(), role: demoRole, hospitalId: "hospital-01" });
    navigate(from, { replace: true });
  };

  return (
    <div className="min-h-screen bg-slate-100 px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-md rounded-3xl bg-white p-8 shadow-xl ring-1 ring-slate-200">
        <h1 className="text-3xl font-semibold text-slate-900">Sign in to MediCare Pro</h1>
        <p className="mt-2 text-sm text-slate-600">Enterprise-ready healthcare access.</p>

        {firebaseConfigured && (
          <div className="mt-6 flex gap-2 rounded-full bg-slate-100 p-1 text-sm">
            <button type="button" onClick={() => setMode("real")} className={`flex-1 rounded-full px-3 py-1.5 font-medium transition ${mode === "real" ? "bg-white shadow-sm text-slate-900" : "text-slate-500"}`}>Sign in</button>
            <button type="button" onClick={() => setMode("demo")} className={`flex-1 rounded-full px-3 py-1.5 font-medium transition ${mode === "demo" ? "bg-white shadow-sm text-slate-900" : "text-slate-500"}`}>Demo mode</button>
          </div>
        )}

        {(formError || error) && <div className="mt-4 rounded-2xl bg-red-50 px-4 py-3 text-sm text-red-700">{formError || error}</div>}

        {mode === "real" ? (
          <form onSubmit={handleRealSubmit} className="mt-8 space-y-5">
            <p className="text-xs text-slate-500">
              Sign in with the email your hospital administrator registered for you (as staff or as a patient). Your role is assigned by the hospital, not chosen here.
            </p>
            <div>
              <label className="block text-sm font-medium text-slate-700">Email</label>
              <input
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700">Password</label>
              <input
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-cyan-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-cyan-700 disabled:opacity-50"
            >
              {loading ? "Signing in..." : "Sign in"}
            </button>
          </form>
        ) : (
          <form onSubmit={handleDemoSubmit} className="mt-8 space-y-5">
            <p className="text-xs text-amber-700 bg-amber-50 rounded-2xl px-3 py-2">
              Demo mode — no real authentication. You pick your own role, and the backend treats these requests as unauthenticated. Only use this for exploring the app.
            </p>
            <div>
              <label className="block text-sm font-medium text-slate-700">Name</label>
              <input
                type="text"
                value={demoName}
                onChange={(event) => setDemoName(event.target.value)}
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700">Email</label>
              <input
                type="email"
                value={demoEmail}
                onChange={(event) => setDemoEmail(event.target.value)}
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700">Role</label>
              <select
                value={demoRole}
                onChange={(event) => setDemoRole(event.target.value)}
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-200"
              >
                {defaultRoles.map((option) => (
                  <option key={option} value={option}>
                    {option.replace(/_/g, " ")}
                  </option>
                ))}
              </select>
            </div>
            <button type="submit" className="w-full rounded-2xl bg-slate-700 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-slate-800">
              Continue in demo mode
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
