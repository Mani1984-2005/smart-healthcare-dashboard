import { useEffect, useMemo, useState } from "react";
import { PageHeader, Button } from "../components/ui";
import Input from "../components/common/Input.jsx";
import Select from "../components/common/Select.jsx";
import Toast from "../components/common/Toast.jsx";
import Dialog from "../components/ui/Dialog.tsx";
import { useDoctorsStore, DoctorRecord } from "../stores/doctorsStore.ts";
import { useBillingStore } from "../stores/billingStore.ts";
import DoctorCard from "../components/doctors/DoctorCard.tsx";
import DoctorForm, { DoctorFormData } from "../components/doctors/DoctorForm.tsx";

const statusOptions = ["All", "Available", "With Patient", "On Leave", "Off Duty"];

export default function Doctors() {
  const { doctors, searchTerm, filters, loading, error, loadDoctors, addDoctor, updateDoctor, deleteDoctor, search, filter } = useDoctorsStore();
  const { invoices, loadInvoices } = useBillingStore();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState<DoctorRecord | null>(null);
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string; variant: "success" | "danger" | "info" } | null>(null);

  useEffect(() => {
    loadDoctors();
    loadInvoices();
  }, [loadDoctors, loadInvoices]);

  const departmentOptions = useMemo(() => ["All", ...Array.from(new Set(doctors.map((d) => d.department)))], [doctors]);

  const filteredDoctors = useMemo(() => {
    let list = doctors;
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      list = list.filter((d) => d.name.toLowerCase().includes(term) || d.specialty.toLowerCase().includes(term) || d.department.toLowerCase().includes(term));
    }
    if (filters.department !== "All") list = list.filter((d) => d.department === filters.department);
    if (filters.status !== "All") list = list.filter((d) => d.status === filters.status);
    return list;
  }, [doctors, searchTerm, filters]);

  const billingByDoctor = useMemo(() => {
    const map = new Map<string, { count: number; revenue: number }>();
    invoices.forEach((invoice) => {
      const key = invoice.doctorName;
      const current = map.get(key) || { count: 0, revenue: 0 };
      map.set(key, { count: current.count + 1, revenue: current.revenue + invoice.grandTotal });
    });
    return map;
  }, [invoices]);

  const handleAdd = () => {
    setEditingDoctor(null);
    setModalOpen(true);
  };

  const handleEdit = (doctor: DoctorRecord) => {
    setEditingDoctor(doctor);
    setModalOpen(true);
  };

  const handleSave = (data: DoctorFormData) => {
    if (editingDoctor) {
      updateDoctor(editingDoctor.id, data);
      setToast({ message: "Doctor profile updated.", variant: "success" });
    } else {
      addDoctor(data);
      setToast({ message: "Doctor added to directory.", variant: "success" });
    }
    setModalOpen(false);
    setEditingDoctor(null);
  };

  const handleDelete = () => {
    if (!deleteTargetId) return;
    deleteDoctor(deleteTargetId);
    setToast({ message: "Doctor removed.", variant: "success" });
    setDeleteTargetId(null);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Care team"
        title="Doctor directory"
        description="Specialties, availability, and consultation load across the hospital."
        actions={<Button onClick={handleAdd} disabled={loading}>Add doctor</Button>}
      />

      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-950 dark:text-rose-100">
          <p className="font-semibold">Sync issue</p>
          <p className="mt-1">{error}</p>
        </div>
      )}

      <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-card dark:border-slate-800 dark:bg-slate-950">
        <div className="grid gap-4 sm:grid-cols-3">
          <Input label="Search" id="doctor-search" placeholder="Name, specialty, department" value={searchTerm} onChange={(event) => search(event.target.value)} />
          <Select label="Department" id="doctor-department-filter" value={filters.department} onChange={(event) => filter({ department: event.target.value })}>
            {departmentOptions.map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </Select>
          <Select label="Status" id="doctor-status-filter" value={filters.status} onChange={(event) => filter({ status: event.target.value })}>
            {statusOptions.map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </Select>
        </div>
      </section>

      {filteredDoctors.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-card dark:border-slate-800 dark:bg-slate-950">
          <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">No doctors found.</p>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">Adjust the search or filters, or add a new doctor.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filteredDoctors.map((doctor) => {
            const billing = billingByDoctor.get(doctor.name) || { count: 0, revenue: 0 };
            return (
              <DoctorCard
                key={doctor.id}
                doctor={doctor}
                invoiceCount={billing.count}
                revenue={billing.revenue}
                onEdit={() => handleEdit(doctor)}
                onDelete={() => setDeleteTargetId(doctor.id)}
              />
            );
          })}
        </div>
      )}

      <Dialog open={modalOpen} onClose={() => { setModalOpen(false); setEditingDoctor(null); }} title={editingDoctor ? "Edit doctor" : "Add doctor"}>
        <DoctorForm
          initialValues={editingDoctor ? { ...editingDoctor } : undefined}
          onCancel={() => { setModalOpen(false); setEditingDoctor(null); }}
          onSubmit={handleSave}
          submitLabel={editingDoctor ? "Update doctor" : "Add doctor"}
        />
      </Dialog>

      <Dialog open={Boolean(deleteTargetId)} onClose={() => setDeleteTargetId(null)} title="Confirm deletion">
        <div className="space-y-6">
          <p>Are you sure you want to remove this doctor from the directory? This action cannot be undone.</p>
          <div className="flex flex-wrap justify-end gap-3">
            <Button variant="secondary" onClick={() => setDeleteTargetId(null)}>Cancel</Button>
            <Button variant="danger" onClick={handleDelete}>Delete</Button>
          </div>
        </div>
      </Dialog>

      {toast && <Toast message={toast.message} variant={toast.variant} onClose={() => setToast(null)} />}
    </div>
  );
}
