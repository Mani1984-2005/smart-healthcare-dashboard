import api from "./api.js";

/**
 * Exchanges a verified Firebase ID token for the app's resolved hospital
 * user record (role comes from matching the token's email against the
 * staff or patients table server-side — Firebase only knows identity, not
 * hospital role).
 */
export async function loginWithFirebaseToken(idToken) {
  return api.post("/auth/login", { idToken }).then((res) => res.data);
}

export async function fetchCurrentUser() {
  return api.get("/auth/me").then((res) => res.data);
}
