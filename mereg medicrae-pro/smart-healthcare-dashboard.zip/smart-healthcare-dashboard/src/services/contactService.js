import api from "./api.js";

export async function fetchContacts() {
  return api.get("/contacts").then((res) => res.data);
}

export async function fetchContactById(id) {
  return api.get(`/contacts/${id}`).then((res) => res.data);
}

export async function createContact(payload) {
  return api.post("/contacts", payload).then((res) => res.data);
}

export async function updateContact(id, payload) {
  return api.put(`/contacts/${id}`, payload).then((res) => res.data);
}

export async function markContactContacted(id) {
  return api.patch(`/contacts/${id}/contacted`).then((res) => res.data);
}

export async function deleteContact(id) {
  return api.delete(`/contacts/${id}`).then((res) => res.data);
}
