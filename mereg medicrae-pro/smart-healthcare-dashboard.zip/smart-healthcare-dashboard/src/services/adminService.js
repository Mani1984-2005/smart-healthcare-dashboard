import api from "./api.js";

export async function fetchHospitalProfile() {
  return api.get("/admin/profile").then((res) => res.data);
}

export async function updateHospitalProfile(payload) {
  return api.put("/admin/profile", payload).then((res) => res.data);
}

export async function fetchDepartments() {
  return api.get("/admin/departments").then((res) => res.data);
}

export async function createDepartment(payload) {
  return api.post("/admin/departments", payload).then((res) => res.data);
}

export async function updateDepartment(id, payload) {
  return api.put(`/admin/departments/${id}`, payload).then((res) => res.data);
}

export async function deleteDepartment(id) {
  return api.delete(`/admin/departments/${id}`).then((res) => res.data);
}

export async function fetchServiceCharges() {
  return api.get("/admin/service-charges").then((res) => res.data);
}

export async function createServiceCharge(payload) {
  return api.post("/admin/service-charges", payload).then((res) => res.data);
}

export async function updateServiceCharge(id, payload) {
  return api.put(`/admin/service-charges/${id}`, payload).then((res) => res.data);
}

export async function deleteServiceCharge(id) {
  return api.delete(`/admin/service-charges/${id}`).then((res) => res.data);
}

export async function fetchStaff() {
  return api.get("/admin/staff").then((res) => res.data);
}

export async function createStaff(payload) {
  return api.post("/admin/staff", payload).then((res) => res.data);
}

export async function updateStaff(id, payload) {
  return api.put(`/admin/staff/${id}`, payload).then((res) => res.data);
}

export async function deleteStaff(id) {
  return api.delete(`/admin/staff/${id}`).then((res) => res.data);
}
