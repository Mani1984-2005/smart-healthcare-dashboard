import { create } from "zustand";
import { signInWithEmailAndPassword, signOut } from "firebase/auth";
import { firebaseAuth, firebaseConfigured } from "../lib/firebase.js";
import { loginWithFirebaseToken } from "../services/authService.js";

const userStorageKey = "medicare_pro_user";
const tokenStorageKey = "medicare_auth_token";

function loadUser() {
  if (typeof window === "undefined") return null;
  try {
    return JSON.parse(window.localStorage.getItem(userStorageKey) || "null");
  } catch {
    return null;
  }
}

function persistUser(user) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(userStorageKey, JSON.stringify(user));
}

function persistToken(token) {
  if (typeof window === "undefined") return;
  if (token) window.localStorage.setItem(tokenStorageKey, token);
  else window.localStorage.removeItem(tokenStorageKey);
}

export const useAuthStore = create((set) => ({
  user: loadUser(),
  isAuthenticated: Boolean(loadUser()),
  authMode: firebaseConfigured ? "firebase" : "demo",
  loading: false,
  error: null,

  /**
   * Real sign-in: authenticates against Firebase, then asks the backend to
   * resolve a hospital role for that email (via the staff/patients tables).
   * Only available when VITE_FIREBASE_* env vars are set — see src/lib/firebase.js.
   */
  async loginWithFirebase(email, password) {
    if (!firebaseConfigured || !firebaseAuth) {
      set({ error: "Firebase isn't configured on this deployment — use demo sign-in instead." });
      return false;
    }
    set({ loading: true, error: null });
    try {
      const credential = await signInWithEmailAndPassword(firebaseAuth, email, password);
      const idToken = await credential.user.getIdToken();
      persistToken(idToken);
      const response = await loginWithFirebaseToken(idToken);
      const user = response.user;
      persistUser(user);
      set({ user, isAuthenticated: true, loading: false, error: null });
      return true;
    } catch (error) {
      persistToken(null);
      const message =
        error?.code === "auth/invalid-credential" || error?.code === "auth/wrong-password" || error?.code === "auth/user-not-found"
          ? "Incorrect email or password."
          : error?.message || "Sign-in failed.";
      set({ loading: false, error: message });
      return false;
    }
  },

  /**
   * Demo sign-in: no real authentication, self-selected role, works entirely
   * offline. Used when Firebase isn't configured, or explicitly chosen. The
   * backend treats these requests as unauthenticated (no Bearer token sent).
   */
  loginDemo(user) {
    persistToken(null);
    persistUser(user);
    set({ user, isAuthenticated: true, error: null });
  },

  async logout() {
    if (firebaseConfigured && firebaseAuth) {
      try {
        await signOut(firebaseAuth);
      } catch {
        // already signed out client-side is fine
      }
    }
    persistToken(null);
    if (typeof window !== "undefined") {
      window.localStorage.removeItem(userStorageKey);
    }
    set({ user: null, isAuthenticated: false, error: null });
  },

  clearError() {
    set({ error: null });
  },
}));
