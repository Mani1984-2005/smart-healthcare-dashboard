// backend/controllers/patientController.js
import QRCode from "qrcode";
import Patient from "../models/Patient.js";
import { getPatientTimeline } from "../services/patientTimelineService.js";
import { findPotentialDuplicates } from "../services/duplicatePatientService.js";
import { logCRUD, logAuditEvent } from "../utils/logger.js";
import { actorFromReq } from "../utils/actor.js";

export async function listPatients(req, res) {
  try {
    const { search = "", status = "", page = 1, limit = 20 } = req.query;
    const result = await Patient.findAll({ search, status, page: Number(page), limit: Number(limit) });
    res.json({ success: true, ...result });
  } catch (error) {
    console.error("listPatients failed:", error);
    res.status(500).json({ success: false, message: "Unable to load patients right now." });
  }
}

export async function getPatientById(req, res) {
  try {
    const patient = await Patient.findById(req.params.id);
    if (!patient) {
      return res.status(404).json({ success: false, message: "Patient not found." });
    }
    res.json({ success: true, patient });
  } catch (error) {
    console.error("getPatientById failed:", error);
    res.status(500).json({ success: false, message: "Unable to load this patient right now." });
  }
}

export async function getPatientTimelineHandler(req, res) {
  try {
    const { page = 1, limit = 25 } = req.query;
    const timeline = await getPatientTimeline(req.params.id, { page: Number(page), limit: Number(limit) });
    if (!timeline) {
      return res.status(404).json({ success: false, message: "Patient not found." });
    }
    res.json({ success: true, ...timeline });
  } catch (error) {
    console.error("getPatientTimeline failed:", error);
    res.status(500).json({ success: false, message: "Unable to load this patient's timeline right now." });
  }
}

export async function checkDuplicatePatients(req, res) {
  try {
    const { full_name = "", phone = "", email = "", date_of_birth = "" } = req.query;
    if (!full_name && !phone && !email) {
      return res.status(400).json({ success: false, message: "Provide at least one of full_name, phone, or email to check." });
    }
    const potentialDuplicates = await findPotentialDuplicates({ full_name, phone, email, date_of_birth });
    res.json({ success: true, potentialDuplicates });
  } catch (error) {
    console.error("checkDuplicatePatients failed:", error);
    res.status(500).json({ success: false, message: "Unable to check for duplicate patients right now." });
  }
}

export async function createPatient(req, res) {
  try {
    const { full_name, phone, confirmDespiteDuplicates } = req.body || {};
    if (!full_name || !phone) {
      return res.status(400).json({ success: false, message: "full_name and phone are required." });
    }

    if (!confirmDespiteDuplicates) {
      const potentialDuplicates = await findPotentialDuplicates(req.body);
      if (potentialDuplicates.length > 0) {
        // Per spec: never auto-merge or silently create over a likely
        // duplicate. Return 200 (this isn't an error — it's a decision
        // point) with enough detail for the UI to show "POSSIBLE EXISTING
        // PATIENT" and let a human choose, mirroring what a real receptionist
        // workflow needs: who matched, on what, how confidently.
        return res.json({ success: true, created: false, potentialDuplicates });
      }
    }

    const patient = await Patient.create(req.body);
    logCRUD({ entity: "patient", action: "CREATE", actor: actorFromReq(req), after: patient, requestId: req.headers["x-request-id"] || "" });

    if (confirmDespiteDuplicates) {
      // The override itself is a meaningful decision worth its own audit
      // trail entry, separate from the generic CREATE above — a reviewer
      // asking "why do we have two Jane Doe records" needs to find this.
      logAuditEvent({
        action: "CREATE_DESPITE_DUPLICATE_WARNING",
        actor: actorFromReq(req),
        resource: { type: "patient", id: patient.id },
        after: patient,
        outcome: "success",
        timestamp: new Date().toISOString(),
      });
    }

    res.status(201).json({ success: true, created: true, patient });
  } catch (error) {
    console.error("createPatient failed:", error);
    res.status(500).json({ success: false, message: "Unable to create patient right now." });
  }
}

export async function updatePatient(req, res) {
  try {
    const before = await Patient.findById(req.params.id);
    if (!before) {
      return res.status(404).json({ success: false, message: "Patient not found." });
    }
    const patient = await Patient.update(req.params.id, req.body || {});
    logCRUD({ entity: "patient", action: "UPDATE", actor: actorFromReq(req), before, after: patient, requestId: req.headers["x-request-id"] || "" });
    res.json({ success: true, patient });
  } catch (error) {
    console.error("updatePatient failed:", error);
    res.status(500).json({ success: false, message: "Unable to update patient right now." });
  }
}

// ─── QR identity (spec sections 13–14) ─────────────────────────────────────
// The QR payload is ONLY the opaque qr_token — no name, no UHID, no medical
// data. A scan doesn't grant access by itself: the scanning client still has
// to call GET /:id/qrcode/resolve/:token through the normal authenticated
// API, which goes through the same requirePermission("patients","read")
// gate as every other patient read. The prescription QR system in
// backend/models/Prescription.js used to embed patient_id and medicine
// names directly in the payload — the same anti-pattern this design always
// avoided — and has since been fixed to follow this same opaque-token
// pattern (see Prescription.js generateQrToken / pharmacyController.js
// resolvePrescriptionQrToken).

export async function getPatientQrCode(req, res) {
  try {
    let patient = await Patient.findById(req.params.id);
    if (!patient) {
      return res.status(404).json({ success: false, message: "Patient not found." });
    }
    // Backfill for patients created before qr_token existed, or before this
    // migration ran.
    if (!patient.qr_token) {
      patient = await Patient.regenerateQrToken(patient.id);
    }
    const qrDataUrl = await QRCode.toDataURL(patient.qr_token, { errorCorrectionLevel: "M", margin: 1 });
    res.json({ success: true, qrToken: patient.qr_token, qrCodeDataUrl: qrDataUrl });
  } catch (error) {
    console.error("getPatientQrCode failed:", error);
    res.status(500).json({ success: false, message: "Unable to generate this patient's QR code right now." });
  }
}

export async function regeneratePatientQrCode(req, res) {
  try {
    const before = await Patient.findById(req.params.id);
    if (!before) {
      return res.status(404).json({ success: false, message: "Patient not found." });
    }
    const patient = await Patient.regenerateQrToken(req.params.id);
    const qrDataUrl = await QRCode.toDataURL(patient.qr_token, { errorCorrectionLevel: "M", margin: 1 });

    // A regeneration silently revokes the old QR code (anyone with the old
    // printout/photo can no longer resolve it) — that's a meaningful
    // security action worth its own audit trail entry.
    logAuditEvent({
      action: "QR_TOKEN_REGENERATED",
      actor: actorFromReq(req),
      resource: { type: "patient", id: patient.id },
      outcome: "success",
      timestamp: new Date().toISOString(),
    });

    res.json({ success: true, qrToken: patient.qr_token, qrCodeDataUrl: qrDataUrl });
  } catch (error) {
    console.error("regeneratePatientQrCode failed:", error);
    res.status(500).json({ success: false, message: "Unable to regenerate this patient's QR code right now." });
  }
}

export async function resolveQrToken(req, res) {
  try {
    const patient = await Patient.findByQrToken(req.params.token);

    // Log every resolution attempt, success or failure — per spec section
    // 14 ("audit logging"), an invalid/expired-looking scan is itself
    // security-relevant (could be a stale printout, could be someone
    // probing).
    logAuditEvent({
      action: "QR_SCAN",
      actor: actorFromReq(req),
      resource: { type: "patient", id: patient?.id || null },
      outcome: patient ? "success" : "failure",
      timestamp: new Date().toISOString(),
    });

    if (!patient) {
      return res.status(404).json({ success: false, message: "This QR code isn't recognized. It may have been regenerated or revoked." });
    }
    res.json({ success: true, patient });
  } catch (error) {
    console.error("resolveQrToken failed:", error);
    res.status(500).json({ success: false, message: "Unable to resolve this QR code right now." });
  }
}
