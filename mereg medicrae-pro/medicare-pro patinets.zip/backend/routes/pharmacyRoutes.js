// backend/routes/pharmacyRoutes.js
// Connected during the production-audit remediation pass — was previously
// defined and never mounted in server.js, with zero auth/RBAC of any kind.
// The controller itself (pharmacyController.js) was NOT rewritten: it is
// real, working code against Medicine.js/Prescription.js (real Postgres
// models), and the audit's own instruction was to connect the existing
// implementation, not replace it.
import express from "express";
import * as pharmacy from "../controllers/pharmacyController.js";
import { attachUserIfPresent } from "../middleware/authMiddleware.js";
import { resolveRole, requirePermission } from "../middleware/rbacMiddleware.js";
import auditMiddleware from "../middleware/auditMiddleware.js";

const router = express.Router();

router.use(attachUserIfPresent);
router.use(resolveRole);
router.use(auditMiddleware);

const read = requirePermission("pharmacy", "read");
const write = requirePermission("pharmacy", "write");

router.get("/drug-list", read, pharmacy.getDrugList);
router.post("/check-interactions", read, pharmacy.checkInteractions);
router.get("/dosage-suggestion", read, pharmacy.getDosageSuggestion);
router.post("/prescriptions", write, pharmacy.createPrescription);
router.get("/prescriptions", read, pharmacy.getAllPrescriptions);
router.get("/prescriptions/patient/:patientId", read, pharmacy.getByPatient);
// resolve/:token must be registered before :rxId — same ordering rule used
// everywhere else in this codebase (Express matches route patterns in
// registration order, and :rxId would otherwise capture "resolve" as an id).
router.get("/prescriptions/resolve/:token", read, pharmacy.resolvePrescriptionQrToken);
router.get("/prescriptions/:rxId", read, pharmacy.getPrescriptionById);
router.get("/prescriptions/:rxId/qrcode", read, pharmacy.getPrescriptionQrCode);
router.post("/prescriptions/:rxId/qrcode/regenerate", write, pharmacy.regeneratePrescriptionQrCode);
router.patch("/prescriptions/:rxId/status", write, pharmacy.updateStatus);
router.delete("/prescriptions/:rxId", write, pharmacy.deletePrescription);
router.delete("/medicines/:medicineId", write, pharmacy.deletePrescriptionMedicine);
router.get("/medicines", read, pharmacy.listMedicines);
router.get("/medicines/low-stock", read, pharmacy.getLowStock);
router.get("/medicines/:id", read, pharmacy.getMedicine);
router.get("/categories", read, pharmacy.getCategories);
router.post("/medicines", write, pharmacy.createMedicine);
router.put("/medicines/:id", write, pharmacy.updateMedicine);
router.delete("/medicines/:id", write, pharmacy.deleteMedicine);

export default router;
