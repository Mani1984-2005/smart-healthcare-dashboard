// backend/models/Prescription.test.js
// Regression tests for two real bugs found while fixing the QR
// anti-pattern (see backend/models/Prescription.js's comment above
// generateQrToken, and backend/controllers/pharmacyController.js's comment
// above its Prescription import):
//
// 1. Prescription.js used to embed patient_id, doctor name, and every
//    medicine's name/dosage directly into a JSON QR payload
//    (buildPrescriptionQR, now removed) — the same anti-pattern the real
//    Patient QR system was built to avoid. Replaced with an opaque token.
//
// 2. pharmacyController.js imported this module as
//    `import * as Prescription from "..."`, which does NOT give direct
//    access to Prescription.create/.addMedicine/etc — those live one level
//    deeper, at Prescription.Prescription.create. Every call in that file
//    would have thrown "is not a function". This test asserts the shape a
//    correct `import { Prescription } from "..."` actually needs.
import test from "node:test";
import assert from "node:assert/strict";
import { Prescription, generateQrToken } from "./Prescription.js";

test("Prescription export shape supports the named import pharmacyController.js relies on", () => {
  // This is the exact regression test for bug #2 above: if this module's
  // export shape ever goes back to being wrapped (e.g. { Prescription: {...} }
  // instead of the model object's methods being directly on the named
  // export), this fails loudly here instead of every pharmacy prescription
  // endpoint silently throwing "is not a function" in production.
  assert.equal(typeof Prescription.create, "function");
  assert.equal(typeof Prescription.addMedicine, "function");
  assert.equal(typeof Prescription.findById, "function");
  assert.equal(typeof Prescription.findByPatient, "function");
  assert.equal(typeof Prescription.getAllPrescriptions, "function");
  assert.equal(typeof Prescription.updateStatus, "function");
  assert.equal(typeof Prescription.findByQrToken, "function");
  assert.equal(typeof Prescription.regenerateQrToken, "function");
});

test("generateQrToken produces an opaque token with no embedded PHI-shaped content", () => {
  const token = generateQrToken();
  // 24 random bytes as hex = 48 characters, pure hex — not JSON, not a
  // delimited/structured string a PHI field could hide inside.
  assert.equal(token.length, 48);
  assert.match(token, /^[0-9a-f]{48}$/);
  // The old buildPrescriptionQR (removed) produced JSON with these key
  // names — asserting none of that shape survived is a direct regression
  // check against the anti-pattern this fix removed.
  assert.doesNotMatch(token, /[{}":,]/);
});

test("generateQrToken produces a different token on every call (no reuse/caching)", () => {
  const a = generateQrToken();
  const b = generateQrToken();
  assert.notEqual(a, b);
});
