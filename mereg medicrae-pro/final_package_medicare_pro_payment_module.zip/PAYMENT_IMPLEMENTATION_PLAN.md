# MediCare Pro — Payment & Financial Transaction Module
## Implementation Plan

Status: DRAFT — based on repository forensics performed prior to any code changes.

---

## 1. Repository Forensics Summary

The backend (`backend/`) is an Express 5 app that is **substantially a scaffold**, not the
mature platform assumed by the original brief. Verified facts:

- `server.js` mounts only `patientRoutes.js` and `healthRoutes.js`. `routes/index.js`
  (which references `authRoutes`, `patientRoutes`, `pharmacyRoutes`) is never imported
  anywhere — dead code.
- `routes/billingRoutes.js` exists but is unmounted. Its controller
  (`controllers/billing.controller.js`) has 6 handlers that all just `res.json({ message: "..." })`
  — no persistence, no validation despite `validations/billing.validation.js` existing separately.
- Two conflicting database layers are configured simultaneously:
  - `config/db.js` — a `pg.Pool` (Postgres), unused by any model.
  - `models/Billing.js`, `Department.js`, `Medicine.js`, `Staff.js`, `Prescription.js` —
    Mongoose (MongoDB) schemas.
  - `models/Patient.js` is an **empty file** (0 bytes).
  - No Prisma anywhere. No `.env` file present. No migrations of any kind.
- `authMiddleware.js` verifies a Firebase ID token and attaches decoded claims to `req.user`.
  There is **no role or permission model** — no RBAC exists to reuse, contrary to the brief's
  assumption.
- No Redis/BullMQ/queue infrastructure exists anywhere in the repo.
- `auditMiddleware.js` is real and generic (logs actor/request/response/outcome on mutating
  HTTP verbs) — this is genuinely reusable as-is.
- Frontend (`src/`) is comparatively solid: a real design system (`design-system/colors.ts`,
  `typography.ts`, `spacing.ts`, `shadows.ts`), a shared axios client (`services/api.js`) with
  bearer-token injection, Zustand stores, and existing pages (`Billing.tsx`, `Patients.tsx`,
  etc.) that can be extended in the same visual language.

**Decision (confirmed with you):**
- Backend standardizes on **Prisma + PostgreSQL**, replacing the dual pg/Mongoose setup.
- Payment provider: **Razorpay**, integrated against its sandbox/test mode.
- Scope for this engagement: **fix the backend foundation first**, then build the Payment
  module on top of it. Frontend payment UI is deferred to a follow-up phase (flagged below).

---

## 2. Reuse Map

| Existing component | Payment module usage |
|---|---|
| `middleware/auditMiddleware.js` | Reused as-is for generic request auditing; payment-specific domain events get their own `PaymentAuditLog` table for financial-grade detail. |
| `middleware/authMiddleware.js` (Firebase token verification) | Reused for authentication; a new `rbac.js` middleware is added on top since none currently exists. |
| `src/design-system/*` | Reused for any future patient payment page (Phase 3, not built this session). |
| `src/services/api.js` axios client | Reused as the base for a future `paymentService.js` on the frontend. |
| `models/Billing.js` (Mongoose) | **Not reused as-is** — superseded by a Prisma `Invoice` model, since Mongoose and the new Prisma/Postgres layer cannot safely coexist for the same data. Field names are carried over 1:1 where sensible to minimize churn. |
| `config/db.js` (pg.Pool) | Removed. Replaced by Prisma's own connection handling (`DATABASE_URL`). |

---

## 3. Payment Domain Model (Prisma)

`Invoice → PaymentOrder → PaymentAttempt → Payment → Refund`, matching the lifecycle in the
brief, not conflating Invoice with Payment.

States implemented (subset of the brief's list, chosen for what a Razorpay-backed flow can
actually produce and verify):
`PaymentOrder`: CREATED, ATTEMPTED, PAID, EXPIRED, CANCELLED
`Payment`: PENDING, PROCESSING, SUCCESS, FAILED, REFUNDED, PARTIALLY_REFUNDED
`Refund`: PENDING, PROCESSED, FAILED

RECONCILIATION_PENDING / DISPUTED are documented but not implemented this session (would
require settlement-report ingestion, which needs live provider credentials — out of scope
until sandbox keys exist).

---

## 4. Files To Create

Backend foundation:
- `backend/prisma/schema.prisma`
- `backend/prisma/seed.js` (minimal RBAC roles + a demo staff user)
- `backend/src/lib/prisma.js` (singleton Prisma client)
- `backend/middleware/rbac.js`
- `backend/utils/errors.js` (typed AppError + centralized error handler)

Payment module:
- `backend/modules/payments/payment.constants.js` (states + transition table)
- `backend/modules/payments/payment.provider.js` (PaymentProvider interface / contract)
- `backend/modules/payments/providers/razorpay.provider.js`
- `backend/modules/payments/idempotency.js`
- `backend/modules/payments/payment.service.js`
- `backend/modules/payments/payment.controller.js`
- `backend/modules/payments/payment.routes.js`
- `backend/modules/payments/webhook.controller.js`
- `backend/modules/payments/webhook.routes.js`
- `backend/modules/payments/refund.service.js`
- `backend/modules/payments/__tests__/*.test.js` (Vitest)

Docs:
- `PAYMENT_IMPLEMENTATION_PLAN.md` (this file)
- `PAYMENT_IMPLEMENTATION_REPORT.md` (written after implementation, with honest status labels)

## 5. Files To Modify

- `backend/server.js` — wire `routes/index.js` properly, mount `payment.routes.js` and
  `webhook.routes.js`, add centralized error handler.
- `backend/routes/index.js` — mount payments.
- `backend/routes/billingRoutes.js` — rewritten against Prisma `Invoice` instead of the stub
  controller.
- `backend/controllers/billing.controller.js` — real Prisma-backed implementation.
- `backend/package.json` — add `prisma`, `@prisma/client`, `razorpay`, `vitest`, `zod`.

## 6. Files Left Untouched

- Everything under `src/` (frontend) this session — no frontend payment UI is built yet,
  so nothing there needs to change. `pharmacyController.js`, `hospitalController.js`, and
  their routes are untouched (out of scope for Payment).

## 7. Known Constraints / Risks Going In

- **No live Postgres instance is reachable from this sandbox**, and outbound network is
  restricted to package registries (npm/pip/etc.) — no arbitrary DB host. `prisma generate`
  can run (schema-only, no DB connection needed), but `prisma migrate dev` against a real
  database, and any actual `npm test` run that hits Postgres, **cannot be executed or
  verified from here**. This mirrors the Vikrant engagement's sandbox limitation and will be
  labeled `NOT VERIFIED` rather than claimed as passing.
- **No real Razorpay API keys exist.** The adapter will be built against Razorpay's documented
  sandbox/test-mode contract and clearly marked `CONFIGURATION REQUIRED`. Signature verification
  logic is real and testable with synthetic payloads; a live checkout round-trip is not.
- Given this, Vitest tests will cover: state machine transitions, idempotency key handling,
  webhook signature verification, and service-layer logic with a mocked Prisma client —
  not a live DB or live gateway.

---

Proceeding to implementation in this order: Prisma schema → RBAC → billing rebuild →
payment provider abstraction → payment service/state machine → webhook verification →
refunds → routes wiring → tests → `PAYMENT_IMPLEMENTATION_REPORT.md`.
