import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.tsx";
import ErrorBoundary from "./components/security/ErrorBoundary.tsx";
import { initAuthTokenRefresh } from "./store/authStore.js";
import "./index.css";

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Root element not found");

// No-ops entirely when Firebase isn't configured (see services/firebase.js).
// Keeps the bearer token api.js reads fresh across the session once it is.
initAuthTokenRefresh();

const root = createRoot(rootElement);
root.render(
  <React.StrictMode>
    <ErrorBoundary>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </ErrorBoundary>
  </React.StrictMode>
);
