import { defineConfig } from "vitest/config";

// Without this file, `vitest` walks up the directory tree and picks up the
// FRONTEND's /vite.config.js (this backend lives nested inside the frontend
// repo), which fails to load in this environment due to an unrelated
// rolldown native-binding issue in the frontend's own node_modules. This
// file scopes vitest to the backend only and avoids that entirely.
export default defineConfig({
  test: {
    root: import.meta.dirname,
    environment: "node",
    include: ["**/__tests__/**/*.test.js"],
  },
});
