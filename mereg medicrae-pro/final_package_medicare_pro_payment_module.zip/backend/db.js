import pg from "pg";
import dotenv from "dotenv";

dotenv.config();

const { Pool } = pg;

// ISOLATION FIX (see PAYMENT_FINAL_VERIFICATION_GATE.md §1 — Database Architecture):
// this legacy raw-SQL pool previously read the SAME process.env.DATABASE_URL that
// prisma/schema.prisma also reads. routes/patients.js (the only consumer of this
// file) is actively mounted in server.js at /patients — it is NOT dead code — so
// the moment a real DATABASE_URL was ever set for Prisma, this pool would silently
// start executing unmigrated raw SQL (`SELECT * FROM patients`) against the exact
// same physical database Prisma manages, with no schema coordination between them.
//
// Fixed by requiring a DISTINCT env var (LEGACY_PATIENTS_DATABASE_URL) so the two
// paths can never collide by accident. An operator who genuinely wants them to
// share a database must now do so explicitly, by setting both variables to the
// same value — a deliberate choice instead of an accidental default.
//
// This does NOT change routes/patients.js's behavior, schema, or SQL in any way —
// only which connection string this pool reads. See §1 of the verification gate
// for the full trace of why this was classified DANGEROUS rather than DEAD.
const connectionString = process.env.LEGACY_PATIENTS_DATABASE_URL;

if (!connectionString) {
  console.warn(
    "[legacy backend/db.js] LEGACY_PATIENTS_DATABASE_URL is not set. " +
      "routes/patients.js (mounted at /patients) will fail on first query rather " +
      "than silently reusing Prisma's DATABASE_URL. This is intentional isolation, " +
      "not a bug — see PAYMENT_FINAL_VERIFICATION_GATE.md §1."
  );
}

const pool = new Pool({
  connectionString,
});

export default pool;