// Demo seed data — enough to exercise RBAC and the payment flow once a real
// database exists. Uses upsert on firebaseUid/invoiceNumber so it's safe to
// re-run.
//
// STATUS: IMPLEMENTED, NOT VERIFIED — cannot run `prisma db seed` or `node
// prisma/seed.js` in this sandbox (no reachable Postgres, and `prisma
// generate` itself is blocked — see PAYMENT_IMPLEMENTATION_REPORT.md §6).
// Reviewed by hand against the schema; treat as unverified until run for
// real.
//
// IMPORTANT: firebaseUid values below are PLACEHOLDERS ("seed-admin-uid" etc.),
// not real Firebase UIDs. Real Firebase accounts must be created first (via
// backend/config/firebaseAdmin.js's project), and their actual UIDs substituted
// here, before authMiddleware.js can resolve a real login to these User rows.

import pkg from "@prisma/client";
const { PrismaClient } = pkg; // see src/lib/prisma.js for why this can't be a named import

const prisma = new PrismaClient();

const demoUsers = [
  { firebaseUid: "seed-admin-uid", email: "admin@medicarepro.demo", name: "Admin Demo", role: "ADMIN" },
  { firebaseUid: "seed-billing-uid", email: "billing@medicarepro.demo", name: "Billing Staff Demo", role: "BILLING" },
  { firebaseUid: "seed-doctor-uid", email: "doctor@medicarepro.demo", name: "Dr. Demo", role: "DOCTOR" },
  { firebaseUid: "seed-nurse-uid", email: "nurse@medicarepro.demo", name: "Nurse Demo", role: "NURSE" },
  { firebaseUid: "seed-reception-uid", email: "reception@medicarepro.demo", name: "Reception Demo", role: "RECEPTIONIST" },
  { firebaseUid: "seed-lab-uid", email: "lab@medicarepro.demo", name: "Lab Tech Demo", role: "LAB_TECHNICIAN" },
  { firebaseUid: "seed-pharmacist-uid", email: "pharmacist@medicarepro.demo", name: "Pharmacist Demo", role: "PHARMACIST" },
  { firebaseUid: "seed-patient-uid", email: "patient@medicarepro.demo", name: "Patient Demo", role: "PATIENT" },
];

async function main() {
  const createdUsers = {};
  for (const u of demoUsers) {
    createdUsers[u.role] = await prisma.user.upsert({
      where: { firebaseUid: u.firebaseUid },
      update: {},
      create: u,
    });
  }

  const patient = await prisma.patient.upsert({
    where: { userId: createdUsers.PATIENT.id },
    update: {},
    create: {
      userId: createdUsers.PATIENT.id,
      fullName: createdUsers.PATIENT.name,
      email: createdUsers.PATIENT.email,
      phone: "+91 90000 00000",
    },
  });

  const existingInvoice = await prisma.invoice.findUnique({ where: { invoiceNumber: "DEMO-INV-0001" } });
  if (!existingInvoice) {
    await prisma.invoice.create({
      data: {
        invoiceNumber: "DEMO-INV-0001",
        patientId: patient.id,
        subtotal: 1500,
        discount: 0,
        tax: 0,
        grandTotal: 1500,
        amountPaid: 0,
        balanceDue: 1500,
        status: "UNPAID",
        createdById: createdUsers.BILLING.id,
        items: {
          create: [
            { serviceName: "General Consultation", category: "CONSULTATION", quantity: 1, unitPrice: 800, amount: 800 },
            { serviceName: "Blood Panel", category: "LAB", quantity: 1, unitPrice: 700, amount: 700 },
          ],
        },
      },
    });
  }

  console.log("Seed complete:", {
    users: Object.keys(createdUsers).length,
    patient: patient.id,
    invoice: "DEMO-INV-0001",
  });
}

main()
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
