// Centralized error handling. The rest of the backend (billing/payments) throws
// AppError subclasses; server.js registers errorHandler as the final middleware.

export class AppError extends Error {
  constructor(message, statusCode = 500, code = "INTERNAL_ERROR", details = undefined) {
    super(message);
    this.name = this.constructor.name;
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.isOperational = true;
    Error.captureStackTrace?.(this, this.constructor);
  }
}

export class ValidationError extends AppError {
  constructor(message, details) {
    super(message, 400, "VALIDATION_ERROR", details);
  }
}

export class NotFoundError extends AppError {
  constructor(message = "Resource not found") {
    super(message, 404, "NOT_FOUND");
  }
}

export class ForbiddenError extends AppError {
  constructor(message = "You do not have permission to perform this action") {
    super(message, 403, "FORBIDDEN");
  }
}

export class UnauthorizedError extends AppError {
  constructor(message = "Authentication required") {
    super(message, 401, "UNAUTHORIZED");
  }
}

export class ConflictError extends AppError {
  constructor(message = "Request conflicts with current state", details) {
    super(message, 409, "CONFLICT", details);
  }
}

// Wrap async Express handlers so thrown/rejected errors reach errorHandler
// instead of crashing the process or hanging the request.
export function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

// Known, safe-to-expose Express/body-parser error shapes that are NOT
// AppError instances but ARE legitimate client errors (4xx), not unexpected
// server failures. Added while closing the oversized-payload gap flagged in
// PAYMENT_MODULE_HANDOFF.md: before this, a PayloadTooLargeError (413) or a
// malformed-JSON ParseError (400) from body-parser fell through to the
// generic 500 "unexpected error" branch below — semantically wrong (a
// too-large or malformed request is the client's mistake, not the server's)
// and it also meant every such request was logged as an "UNHANDLED ERROR"
// even though it's an entirely expected, well-understood input class.
function classifyKnownNonAppError(err) {
  if (err?.type === "entity.too.large" || err?.status === 413 || err?.statusCode === 413) {
    return { statusCode: 413, code: "PAYLOAD_TOO_LARGE", message: "Request payload is too large." };
  }
  if (err?.type === "entity.parse.failed" || (err instanceof SyntaxError && err?.status === 400)) {
    return { statusCode: 400, code: "MALFORMED_JSON", message: "Request body is not valid JSON." };
  }
  return null;
}

export function errorHandler(err, req, res, _next) {
  const isAppError = err instanceof AppError;
  const known = !isAppError ? classifyKnownNonAppError(err) : null;

  const statusCode = isAppError ? err.statusCode : known ? known.statusCode : 500;
  const code = isAppError ? err.code : known ? known.code : "INTERNAL_ERROR";
  const message = isAppError ? err.message : known ? known.message : "An unexpected error occurred.";

  if (!isAppError && !known) {
    // Genuinely unexpected — log full detail server-side, never leak internals to the client.
    console.error("[UNHANDLED ERROR]", err);
  }

  res.status(statusCode).json({
    success: false,
    error: {
      code,
      message,
      ...(isAppError && err.details ? { details: err.details } : {}),
    },
  });
}
