import express from "express";
const router = express.Router();
import * as billingController from "../controllers/billing.controller.js";
import authenticate from "../middleware/authMiddleware.js";
import { loadAppUser, requireRole, requireSelfOrStaff } from "../middleware/rbac.js";
import { prisma } from "../src/lib/prisma.js";
import { NotFoundError } from "../utils/errors.js";

// This file was previously unmounted entirely (see PAYMENT_IMPLEMENTATION_REPORT.md)
// and its controller was pure placeholders with no auth. Both are fixed here.
router.use(authenticate, loadAppUser);

// RECEPTIONIST added here (continuation of PAYMENT_IMPLEMENTATION_REPORT.md §8b's
// gap): front-desk staff need to see and create invoices at checkout. They are
// deliberately NOT granted /summary, refunds, or the payment dashboard — those
// stay BILLING/ADMIN-only, matching the brief's distinction between general
// "Staff: authorized operational actions" and "Billing Staff: financial operations".
router.get("/summary", requireRole("BILLING", "ADMIN"), billingController.getSummary);
router.get("/invoices", requireRole("BILLING", "ADMIN", "DOCTOR", "RECEPTIONIST"), billingController.getInvoices);

// Ownership check (closes the gap flagged in PAYMENT_IMPLEMENTATION_REPORT.md §8):
// a PATIENT may only fetch their own invoice; every staff role may fetch any
// invoice, matching how DOCTOR/NURSE/RECEPTIONIST/BILLING/ADMIN already need
// cross-patient visibility for care coordination and front-desk operations.
router.get(
  "/invoices/:id",
  requireSelfOrStaff(async (req) => {
    const invoice = await prisma.invoice.findUnique({ where: { id: req.params.id } });
    if (!invoice) throw new NotFoundError("Invoice not found");
    return invoice.patientId;
  }),
  billingController.getInvoiceById
);

router.post("/invoices", requireRole("BILLING", "ADMIN", "RECEPTIONIST"), billingController.createInvoice);
router.put("/invoices/:id", requireRole("BILLING", "ADMIN"), billingController.updateInvoice);
router.delete("/invoices/:id", requireRole("ADMIN"), billingController.deleteInvoice);

export default router;
