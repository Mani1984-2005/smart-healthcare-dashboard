import express from "express";
import authenticate from "../middleware/authMiddleware.js";
import { loadAppUser } from "../middleware/rbac.js";

const router = express.Router();

// GET /api/auth/me
// Protected — requires a valid Firebase ID token in Authorization header.
//
// FIX: previously returned only raw Firebase token claims (uid/email/name/
// picture) — it never resolved the caller's actual application role. That
// meant the frontend had no trustworthy way to learn a signed-in user's role
// except by trusting whatever the client-side login form happened to set
// locally (see src/store/authStore.js / src/pages/Login.tsx), which is not a
// real authorization signal — a client can claim to be anything. Every other
// Payment/Billing route already resolves the true role server-side via
// loadAppUser (Firebase uid -> Prisma User.role); this endpoint now does the
// same and is the one place the frontend should ever fetch role from.
router.get("/me", authenticate, loadAppUser, (req, res) => {
  const { id, firebaseUid, name, email, role, isActive } = req.appUser;

  res.status(200).json({
    success: true,
    data: { id, firebaseUid, name, email, role, isActive },
  });
});

export default router;