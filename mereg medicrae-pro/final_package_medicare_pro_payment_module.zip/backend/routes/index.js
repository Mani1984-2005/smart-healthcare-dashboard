import express from "express";
const router = express.Router();

// Import all route modules
import authRoutes from "./authRoutes.js";
import patientRoutes from "./patientRoutes.js";
import pharmacyRoutes from "./pharmacyRoutes.js";
import healthRoutes from "./healthRoutes.js";
import billingRoutes from "./billingRoutes.js";
import paymentRoutes from "../modules/payments/payment.routes.js";
// NOTE: webhook.routes.js is intentionally NOT mounted here — it needs
// express.raw() instead of express.json() for signature verification, so it
// is mounted directly in server.js before the global JSON body parser.
// This file (routes/index.js) was previously written but never imported by
// server.js at all — see PAYMENT_IMPLEMENTATION_REPORT.md.

// Mount routes
router.use("/auth", authRoutes);
router.use("/patients", patientRoutes);
router.use("/pharmacy", pharmacyRoutes);
router.use("/health", healthRoutes);
router.use("/billing", billingRoutes);
router.use("/payments", paymentRoutes);

// Default route (optional but useful)
router.get("/", (req, res) => {
  res.json({
    message: "MediCare Pro API Routes Working 🚀",
    availableRoutes: [
      "/auth",
      "/patients",
      "/pharmacy",
      "/health",
      "/billing",
      "/payments"
    ]
  });
});

export default router;