// Verifies the fix to routes/authRoutes.js: /auth/me must return the
// authoritative application role (from Prisma, via loadAppUser), not raw
// Firebase token claims — the frontend needs a trustworthy source for role,
// since a client-side login form's self-reported role is not a real
// authorization signal. Real HTTP round trip via supertest against a minimal
// app built from the actual route file, mocking only Firebase/Prisma (no
// live database/Firebase project reachable in this sandbox).

import { describe, it, expect, vi, beforeEach } from "vitest";
import express from "express";
import request from "supertest";
import { errorHandler } from "../../utils/errors.js";

const mockVerifyIdToken = vi.fn();
vi.mock("../../config/firebaseAdmin.js", () => ({
  default: { auth: () => ({ verifyIdToken: mockVerifyIdToken }) },
}));

const mockPrisma = { user: { findUnique: vi.fn() } };
vi.mock("../../src/lib/prisma.js", () => ({ prisma: mockPrisma }));

const { default: authRoutes } = await import("../authRoutes.js");

function buildTestApp() {
  const app = express();
  app.use(express.json());
  app.use("/auth", authRoutes);
  app.use(errorHandler);
  return app;
}

describe("GET /auth/me", () => {
  beforeEach(() => vi.clearAllMocks());

  it("returns 401 with no Authorization header", async () => {
    const app = buildTestApp();
    const res = await request(app).get("/auth/me");
    expect(res.status).toBe(401);
  });

  it("returns the authoritative Prisma role, not a client-suppliable value", async () => {
    mockVerifyIdToken.mockResolvedValueOnce({ uid: "firebase-uid-1", email: "patient@example.com" });
    mockPrisma.user.findUnique.mockResolvedValueOnce({
      id: "app-user-1",
      firebaseUid: "firebase-uid-1",
      name: "Jane Patient",
      email: "patient@example.com",
      role: "PATIENT",
      isActive: true,
    });

    const app = buildTestApp();
    const res = await request(app).get("/auth/me").set("Authorization", "Bearer valid.token");

    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({
      success: true,
      data: { id: "app-user-1", role: "PATIENT", name: "Jane Patient" },
    });
    // The response must never echo back raw Firebase claims as if they were
    // authorization-relevant — only the resolved Prisma User fields.
    expect(res.body.data).not.toHaveProperty("picture");
  });

  it("returns 403 when the Firebase-authenticated caller has no provisioned User row", async () => {
    mockVerifyIdToken.mockResolvedValueOnce({ uid: "unknown-firebase-uid" });
    mockPrisma.user.findUnique.mockResolvedValueOnce(null);

    const app = buildTestApp();
    const res = await request(app).get("/auth/me").set("Authorization", "Bearer valid.token");

    expect(res.status).toBe(403);
  });

  it("returns 403 for a deactivated user account", async () => {
    mockVerifyIdToken.mockResolvedValueOnce({ uid: "firebase-uid-2" });
    mockPrisma.user.findUnique.mockResolvedValueOnce({
      id: "app-user-2",
      firebaseUid: "firebase-uid-2",
      role: "PATIENT",
      isActive: false,
    });

    const app = buildTestApp();
    const res = await request(app).get("/auth/me").set("Authorization", "Bearer valid.token");

    expect(res.status).toBe(403);
  });
});
