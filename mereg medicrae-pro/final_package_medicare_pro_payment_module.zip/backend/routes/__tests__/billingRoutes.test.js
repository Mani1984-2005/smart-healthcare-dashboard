// billing.controller.js and billingRoutes.js had ZERO test coverage before
// this pass — not even at the mocked-unit level — despite Invoice being the
// entity every PaymentOrder is created against. This is a real HTTP round
// trip (via supertest) through the actual mounted router, mocking only
// Firebase/Prisma (no live database reachable in this sandbox). It closes
// two gaps at once: (1) billing.controller.js's own logic was never
// exercised at all, and (2) requireSelfOrStaff's generic behavior was
// unit-tested in rbac.test.js, but nothing had ever proven the real
// GET /billing/invoices/:id route wires its actual ownership callback
// (looking up Invoice.patientId) correctly — this is the closest thing to
// a genuine "cross-patient payment access" attack test achievable without a
// live database, since Invoice ownership is what PaymentOrder ownership is
// ultimately derived from (see modules/payments/payment.controller.js's
// resolvePatientContext).
//
// IMPORTANT TEST-HYGIENE NOTE (found while writing this file, real
// investigation, not assumed): a request may or may not reach every mocked
// function depending on WHERE in the middleware chain it gets rejected
// (e.g. requireSelfOrStaff throwing before the controller's own
// prisma.invoice.findUnique ever runs). Queuing more mockResolvedValueOnce()
// calls than a given test path actually consumes leaves a stale value in
// the queue, which then leaks into the NEXT test and silently changes its
// behavior — this genuinely happened while first writing this file (a "404"
// test spuriously got 403 because an earlier test's unconsumed queued value
// was consumed instead of this test's own). `vi.resetAllMocks()` (not
// `vi.clearAllMocks()`, which only clears call history, not queued
// once-implementations) in every `beforeEach` below is what prevents this.

import { describe, it, expect, vi, beforeEach } from "vitest";
import express from "express";
import request from "supertest";
import { errorHandler } from "../../utils/errors.js";

const mockVerifyIdToken = vi.fn();
vi.mock("../../config/firebaseAdmin.js", () => ({
  default: { auth: () => ({ verifyIdToken: mockVerifyIdToken }) },
}));

const mockPrisma = {
  user: { findUnique: vi.fn() },
  patient: { findUnique: vi.fn() },
  invoice: { findUnique: vi.fn(), findMany: vi.fn(), count: vi.fn(), create: vi.fn() },
};
vi.mock("../../src/lib/prisma.js", () => ({ prisma: mockPrisma }));

const { default: billingRoutes } = await import("../billingRoutes.js");

function buildTestApp() {
  const app = express();
  app.use(express.json());
  app.use("/billing", billingRoutes);
  app.use(errorHandler);
  return app;
}

function authAs(role, userId, firebaseUid = "fb-uid") {
  mockVerifyIdToken.mockResolvedValueOnce({ uid: firebaseUid });
  mockPrisma.user.findUnique.mockResolvedValueOnce({ id: userId, role, isActive: true });
}

const INVOICE_A = { id: "inv-A", patientId: "patient-A", invoiceNumber: "INV-A", items: [] };

describe("GET /billing/invoices/:id — real HTTP ownership enforcement", () => {
  beforeEach(() => vi.resetAllMocks()); // NOT clearAllMocks() — see file header for why: leftover queued mockResolvedValueOnce values from a short-circuited request (e.g. requireSelfOrStaff throwing before the controller's own fetch runs) must not leak into the next test

  it("rejects an unauthenticated request with 401", async () => {
    const app = buildTestApp();
    const res = await request(app).get("/billing/invoices/inv-A");
    expect(res.status).toBe(401);
  });

  it("Attack: Patient A cannot access Patient B's invoice by ID (cross-patient access)", async () => {
    authAs("PATIENT", "user-B");
    mockPrisma.invoice.findUnique
      .mockResolvedValueOnce(INVOICE_A) // requireSelfOrStaff's ownership lookup
      .mockResolvedValueOnce(INVOICE_A); // would be the controller's own fetch, never reached
    mockPrisma.patient.findUnique.mockResolvedValueOnce({ id: "patient-B", userId: "user-B" });

    const app = buildTestApp();
    const res = await request(app).get("/billing/invoices/inv-A").set("Authorization", "Bearer valid");

    expect(res.status).toBe(403);
  });

  it("allows a patient to access their own invoice", async () => {
    authAs("PATIENT", "user-A");
    mockPrisma.invoice.findUnique
      .mockResolvedValueOnce(INVOICE_A) // ownership lookup
      .mockResolvedValueOnce(INVOICE_A); // controller's fetch after passing the check
    mockPrisma.patient.findUnique.mockResolvedValueOnce({ id: "patient-A", userId: "user-A" });

    const app = buildTestApp();
    const res = await request(app).get("/billing/invoices/inv-A").set("Authorization", "Bearer valid");

    expect(res.status).toBe(200);
    expect(res.body.data.id).toBe("inv-A");
  });

  it("allows staff (e.g. DOCTOR) to access any patient's invoice", async () => {
    authAs("DOCTOR", "user-doc");
    mockPrisma.invoice.findUnique.mockResolvedValueOnce(INVOICE_A); // controller's fetch (ownership check bypassed for staff)

    const app = buildTestApp();
    const res = await request(app).get("/billing/invoices/inv-A").set("Authorization", "Bearer valid");

    expect(res.status).toBe(200);
  });

  it("returns 404 for a nonexistent invoice rather than leaking ownership info either way", async () => {
    authAs("PATIENT", "user-A");
    mockPrisma.invoice.findUnique.mockResolvedValueOnce(null); // ownership lookup finds nothing

    const app = buildTestApp();
    const res = await request(app).get("/billing/invoices/does-not-exist").set("Authorization", "Bearer valid");

    expect(res.status).toBe(404);
  });
});

describe("POST /billing/invoices — RBAC + validation, real HTTP", () => {
  beforeEach(() => vi.resetAllMocks());

  it("rejects a PATIENT attempting to create an invoice (mass-assignment/privilege check)", async () => {
    authAs("PATIENT", "user-A");
    const app = buildTestApp();
    const res = await request(app)
      .post("/billing/invoices")
      .set("Authorization", "Bearer valid")
      .send({ patientId: "patient-A", invoiceNumber: "X", items: [{ serviceName: "x", unitPrice: 10 }] });

    expect(res.status).toBe(403);
    expect(mockPrisma.invoice.create).not.toHaveBeenCalled();
  });

  it("rejects malformed invoice payloads with 400 (real zod validation, not just unit-tested in isolation)", async () => {
    authAs("BILLING", "user-billing");
    const app = buildTestApp();
    const res = await request(app)
      .post("/billing/invoices")
      .set("Authorization", "Bearer valid")
      .send({ patientId: "not-a-uuid", invoiceNumber: "", items: [] }); // empty items array is invalid too

    expect(res.status).toBe(400);
    expect(mockPrisma.invoice.create).not.toHaveBeenCalled();
  });
});
