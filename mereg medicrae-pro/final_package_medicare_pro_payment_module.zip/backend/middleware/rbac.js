// RBAC middleware.
//
// IMPORTANT: no role/permission system existed anywhere in the original repo —
// authMiddleware.js only verifies the Firebase token. This module builds the
// missing authorization layer on top of that, using the `User.role` column
// added in prisma/schema.prisma.
//
// Usage:
//   router.post("/invoices", authenticate, loadAppUser, requireRole("BILLING", "ADMIN"), handler)

import { prisma } from "../src/lib/prisma.js";
import { ForbiddenError, UnauthorizedError } from "../utils/errors.js";
import { asyncHandler } from "../utils/errors.js";

// Resolves the Firebase-authenticated req.user (decoded token claims) to our
// application User row, and attaches it as req.appUser. Must run after
// authMiddleware.js's `authenticate`.
export const loadAppUser = asyncHandler(async (req, res, next) => {
  if (!req.user?.uid) {
    throw new UnauthorizedError("No authenticated Firebase user on request");
  }

  const appUser = await prisma.user.findUnique({
    where: { firebaseUid: req.user.uid },
  });

  if (!appUser || !appUser.isActive) {
    throw new ForbiddenError("No active MediCare Pro account is linked to this login");
  }

  req.appUser = appUser;
  next();
});

// Restricts a route to one or more roles. Call loadAppUser earlier in the chain.
export function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.appUser) {
      return next(new UnauthorizedError("loadAppUser must run before requireRole"));
    }
    if (!allowedRoles.includes(req.appUser.role)) {
      return next(
        new ForbiddenError(
          `This action requires one of the following roles: ${allowedRoles.join(", ")}`
        )
      );
    }
    next();
  };
}

// Ownership check for patient-scoped resources: a PATIENT role may only act on
// their own invoices/payments; staff roles bypass this check.
export function requireSelfOrStaff(getPatientIdFromReq) {
  const staffRoles = ["DOCTOR", "NURSE", "RECEPTIONIST", "LAB_TECHNICIAN", "PHARMACIST", "BILLING", "ADMIN"];
  return asyncHandler(async (req, res, next) => {
    if (!req.appUser) throw new UnauthorizedError("loadAppUser must run before requireSelfOrStaff");
    if (staffRoles.includes(req.appUser.role)) return next();

    if (req.appUser.role !== "PATIENT") {
      throw new ForbiddenError("This action is restricted to patients or authorized staff");
    }

    const targetPatientId = await getPatientIdFromReq(req);
    const ownPatient = await prisma.patient.findUnique({ where: { userId: req.appUser.id } });

    if (!ownPatient || ownPatient.id !== targetPatientId) {
      throw new ForbiddenError("You may only access your own records");
    }
    next();
  });
}
