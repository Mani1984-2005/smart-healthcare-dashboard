import { describe, it, expect, vi, beforeEach } from "vitest";

const mockPrisma = {
  user: { findUnique: vi.fn() },
  patient: { findUnique: vi.fn() },
};

vi.mock("../../src/lib/prisma.js", () => ({ prisma: mockPrisma }));

const { requireRole, requireSelfOrStaff, loadAppUser } = await import("../rbac.js");

function mockReqRes(appUser) {
  const req = { appUser, params: {} };
  const res = {};
  let calledWith;
  const next = (err) => {
    calledWith = err;
  };
  return { req, res, next, getNextArg: () => calledWith };
}

describe("requireRole", () => {
  it("calls next() with no argument when the user has an allowed role", () => {
    const { req, res, next, getNextArg } = mockReqRes({ role: "ADMIN" });
    requireRole("ADMIN", "BILLING")(req, res, next);
    expect(getNextArg()).toBeUndefined();
  });

  it("calls next(err) with a FORBIDDEN error when the role is not allowed", () => {
    const { req, res, next, getNextArg } = mockReqRes({ role: "PATIENT" });
    requireRole("ADMIN", "BILLING")(req, res, next);
    expect(getNextArg()).toMatchObject({ code: "FORBIDDEN" });
  });

  it("calls next(err) with UNAUTHORIZED when loadAppUser hasn't run", () => {
    const { req, res, next, getNextArg } = mockReqRes(undefined);
    requireRole("ADMIN")(req, res, next);
    expect(getNextArg()).toMatchObject({ code: "UNAUTHORIZED" });
  });
});

describe("requireSelfOrStaff", () => {
  beforeEach(() => vi.clearAllMocks());

  it("lets any staff role through without checking ownership at all", async () => {
    const getPatientId = vi.fn();
    const { req, res, next, getNextArg } = mockReqRes({ role: "DOCTOR", id: "user-doc-1" });
    await requireSelfOrStaff(getPatientId)(req, res, next);
    expect(getNextArg()).toBeUndefined();
    expect(getPatientId).not.toHaveBeenCalled(); // staff bypass is unconditional, no ownership lookup needed
  });

  it("allows a PATIENT to access their own record", async () => {
    mockPrisma.patient.findUnique.mockResolvedValueOnce({ id: "patient-1", userId: "user-pat-1" });
    const { req, res, next, getNextArg } = mockReqRes({ role: "PATIENT", id: "user-pat-1" });
    await requireSelfOrStaff(async () => "patient-1")(req, res, next);
    expect(getNextArg()).toBeUndefined();
  });

  it("rejects a PATIENT accessing someone else's record", async () => {
    mockPrisma.patient.findUnique.mockResolvedValueOnce({ id: "patient-1", userId: "user-pat-1" });
    const { req, res, next, getNextArg } = mockReqRes({ role: "PATIENT", id: "user-pat-1" });
    await requireSelfOrStaff(async () => "someone-elses-patient-id")(req, res, next);
    expect(getNextArg()).toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects when the caller's role is neither staff nor PATIENT", async () => {
    const { req, res, next, getNextArg } = mockReqRes({ role: "SOME_UNKNOWN_ROLE" });
    await requireSelfOrStaff(async () => "patient-1")(req, res, next);
    expect(getNextArg()).toMatchObject({ code: "FORBIDDEN" });
  });
});

describe("loadAppUser", () => {
  beforeEach(() => vi.clearAllMocks());

  it("attaches an active user to req.appUser and calls next()", async () => {
    mockPrisma.user.findUnique.mockResolvedValueOnce({ id: "u1", isActive: true, role: "PATIENT" });
    const req = { user: { uid: "firebase-uid-1" } };
    const res = {};
    let nextArg;
    await loadAppUser(req, res, (err) => (nextArg = err));
    expect(nextArg).toBeUndefined();
    expect(req.appUser).toEqual({ id: "u1", isActive: true, role: "PATIENT" });
  });

  it("rejects an inactive account", async () => {
    mockPrisma.user.findUnique.mockResolvedValueOnce({ id: "u1", isActive: false, role: "PATIENT" });
    const req = { user: { uid: "firebase-uid-1" } };
    const res = {};
    let nextArg;
    await loadAppUser(req, res, (err) => (nextArg = err));
    expect(nextArg).toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects when there is no Firebase-authenticated user on the request at all", async () => {
    const req = {};
    const res = {};
    let nextArg;
    await loadAppUser(req, res, (err) => (nextArg = err));
    expect(nextArg).toMatchObject({ code: "UNAUTHORIZED" });
  });
});
