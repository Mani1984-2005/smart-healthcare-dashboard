// authMiddleware.js was never directly unit-tested before this pass (only its
// downstream consumers, loadAppUser/requireRole, were covered in
// middleware/__tests__/rbac.test.js). Added for PAYMENT_MODULE_CLOSURE_REPORT.md
// Attack B (unauthenticated request must be rejected) — config/firebaseAdmin.js
// is mocked here because it throws at import time without real env vars (by
// design, see PAYMENT_FINAL_VERIFICATION_GATE.md §3), which would otherwise
// make this file unimportable in a test context with no Firebase credentials.

import { describe, it, expect, vi, beforeEach } from "vitest";

const mockVerifyIdToken = vi.fn();

vi.mock("../../config/firebaseAdmin.js", () => ({
  default: { auth: () => ({ verifyIdToken: mockVerifyIdToken }) },
}));

const { default: authenticate } = await import("../authMiddleware.js");

function mockReqRes(headers) {
  const req = { headers };
  let statusCode;
  let jsonBody;
  const res = {
    status(code) {
      statusCode = code;
      return this;
    },
    json(body) {
      jsonBody = body;
      return this;
    },
  };
  const next = vi.fn();
  return { req, res, next, getStatus: () => statusCode, getJson: () => jsonBody };
}

describe("authMiddleware — Attack B: unauthenticated/malformed/invalid token rejection", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rejects a request with no Authorization header at all (401)", async () => {
    const { req, res, next, getStatus } = mockReqRes({});
    await authenticate(req, res, next);
    expect(getStatus()).toBe(401);
    expect(next).not.toHaveBeenCalled();
    expect(mockVerifyIdToken).not.toHaveBeenCalled(); // rejected before ever calling Firebase
  });

  it("rejects a malformed Authorization header (no 'Bearer ' prefix) (401)", async () => {
    const { req, res, next, getStatus } = mockReqRes({ authorization: "Basic sometoken" });
    await authenticate(req, res, next);
    expect(getStatus()).toBe(401);
    expect(next).not.toHaveBeenCalled();
  });

  it("rejects an invalid/expired token — Firebase verifyIdToken rejects (401)", async () => {
    mockVerifyIdToken.mockRejectedValueOnce(new Error("Firebase ID token has expired"));
    const { req, res, next, getStatus, getJson } = mockReqRes({ authorization: "Bearer expired.token.here" });
    await authenticate(req, res, next);
    expect(getStatus()).toBe(401);
    expect(getJson()).toMatchObject({ success: false });
    expect(next).not.toHaveBeenCalled();
  });

  it("does not leak the underlying Firebase error message to the client", async () => {
    mockVerifyIdToken.mockRejectedValueOnce(new Error("some internal Firebase SDK detail"));
    const { req, res, next, getJson } = mockReqRes({ authorization: "Bearer bad.token" });
    await authenticate(req, res, next);
    expect(JSON.stringify(getJson())).not.toContain("internal Firebase SDK detail");
  });

  it("accepts a valid token, attaches decoded claims to req.user, and calls next()", async () => {
    mockVerifyIdToken.mockResolvedValueOnce({ uid: "firebase-uid-123", email: "patient@example.com" });
    const { req, res, next } = mockReqRes({ authorization: "Bearer valid.token.here" });
    await authenticate(req, res, next);
    expect(next).toHaveBeenCalledOnce();
    expect(req.user).toEqual({ uid: "firebase-uid-123", email: "patient@example.com" });
  });
});
