// Rebuilt on Prisma. The original file's 6 handlers all returned
// `{ message: "... API" }` with no persistence — this replaces that with real
// CRUD against the Invoice/InvoiceItem models in prisma/schema.prisma.
// validations/billing.validation.js was an empty file; validation now lives
// here via zod, following the same pattern used in modules/payments.

import { z } from "zod";
import { prisma } from "../src/lib/prisma.js";
import { asyncHandler, NotFoundError, ValidationError } from "../utils/errors.js";

const invoiceItemSchema = z.object({
  serviceName: z.string().min(1),
  category: z
    .enum(["CONSULTATION", "LAB", "PROCEDURE", "MEDICINE", "ROOM", "TELEMEDICINE", "OTHER"])
    .default("OTHER"),
  quantity: z.number().int().positive().default(1),
  unitPrice: z.number().nonnegative(),
});

const createInvoiceSchema = z.object({
  patientId: z.string().uuid(),
  invoiceNumber: z.string().min(1),
  items: z.array(invoiceItemSchema).min(1),
  discount: z.number().nonnegative().default(0),
  tax: z.number().nonnegative().default(0),
  notes: z.string().max(2000).optional(),
  dueDate: z.string().datetime().optional(),
  appointmentRef: z.string().optional(),
  labOrderRef: z.string().optional(),
  pharmacyOrderRef: z.string().optional(),
});

const updateInvoiceSchema = createInvoiceSchema.partial().extend({
  status: z.enum(["DRAFT", "UNPAID", "PARTIALLY_PAID", "PAID", "CANCELLED"]).optional(),
});

function computeTotals(items, discount, tax) {
  const subtotal = items.reduce((sum, it) => sum + it.quantity * it.unitPrice, 0);
  const grandTotal = Math.max(subtotal - discount + tax, 0);
  return { subtotal, grandTotal };
}

export const getSummary = asyncHandler(async (req, res) => {
  const [unpaidAgg, paidAgg, draftCount] = await Promise.all([
    prisma.invoice.aggregate({
      _sum: { balanceDue: true },
      _count: true,
      where: { status: { in: ["UNPAID", "PARTIALLY_PAID"] } },
    }),
    prisma.invoice.aggregate({ _sum: { amountPaid: true }, where: { status: "PAID" } }),
    prisma.invoice.count({ where: { status: "DRAFT" } }),
  ]);

  res.json({
    success: true,
    data: {
      outstandingAmount: unpaidAgg._sum.balanceDue ?? 0,
      outstandingInvoices: unpaidAgg._count,
      totalCollected: paidAgg._sum.amountPaid ?? 0,
      draftInvoices: draftCount,
    },
  });
});

export const getInvoices = asyncHandler(async (req, res) => {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const pageSize = Math.min(Math.max(parseInt(req.query.pageSize, 10) || 20, 1), 100);
  const where = {};
  if (req.query.status) where.status = req.query.status;
  if (req.query.patientId) where.patientId = req.query.patientId;

  const [items, total] = await Promise.all([
    prisma.invoice.findMany({
      where,
      include: { items: true, patient: true },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.invoice.count({ where }),
  ]);

  res.json({ success: true, data: { items, total, page, pageSize } });
});

export const getInvoiceById = asyncHandler(async (req, res) => {
  const invoice = await prisma.invoice.findUnique({
    where: { id: req.params.id },
    include: { items: true, patient: true, paymentOrders: { include: { payments: true } } },
  });
  if (!invoice) throw new NotFoundError("Invoice not found");
  res.json({ success: true, data: invoice });
});

export const createInvoice = asyncHandler(async (req, res) => {
  const parsed = createInvoiceSchema.safeParse(req.body);
  if (!parsed.success) throw new ValidationError("Invalid invoice payload", parsed.error.flatten());
  const { patientId, invoiceNumber, items, discount, tax, notes, dueDate, appointmentRef, labOrderRef, pharmacyOrderRef } = parsed.data;

  const itemsWithAmount = items.map((it) => ({ ...it, amount: it.quantity * it.unitPrice }));
  const { subtotal, grandTotal } = computeTotals(itemsWithAmount, discount, tax);

  const invoice = await prisma.invoice.create({
    data: {
      invoiceNumber,
      patientId,
      appointmentRef,
      labOrderRef,
      pharmacyOrderRef,
      subtotal,
      discount,
      tax,
      grandTotal,
      amountPaid: 0,
      balanceDue: grandTotal,
      status: "UNPAID",
      notes,
      dueDate: dueDate ? new Date(dueDate) : undefined,
      createdById: req.appUser?.id,
      items: { create: itemsWithAmount },
    },
    include: { items: true },
  });

  res.status(201).json({ success: true, data: invoice });
});

export const updateInvoice = asyncHandler(async (req, res) => {
  const parsed = updateInvoiceSchema.safeParse(req.body);
  if (!parsed.success) throw new ValidationError("Invalid invoice payload", parsed.error.flatten());

  const existing = await prisma.invoice.findUnique({ where: { id: req.params.id } });
  if (!existing) throw new NotFoundError("Invoice not found");
  if (existing.status === "PAID") {
    throw new ValidationError("Paid invoices cannot be edited — issue a refund or credit note instead");
  }

  const data = { ...parsed.data };
  delete data.items;

  if (parsed.data.items) {
    const itemsWithAmount = parsed.data.items.map((it) => ({ ...it, amount: it.quantity * it.unitPrice }));
    const { subtotal, grandTotal } = computeTotals(
      itemsWithAmount,
      parsed.data.discount ?? existing.discount,
      parsed.data.tax ?? existing.tax
    );
    data.subtotal = subtotal;
    data.grandTotal = grandTotal;
    data.balanceDue = Math.max(grandTotal - Number(existing.amountPaid), 0);

    await prisma.invoiceItem.deleteMany({ where: { invoiceId: existing.id } });
    await prisma.invoiceItem.createMany({
      data: itemsWithAmount.map((it) => ({ ...it, invoiceId: existing.id })),
    });
  }
  if (data.dueDate) data.dueDate = new Date(data.dueDate);

  const invoice = await prisma.invoice.update({
    where: { id: existing.id },
    data,
    include: { items: true },
  });

  res.json({ success: true, data: invoice });
});

export const deleteInvoice = asyncHandler(async (req, res) => {
  const existing = await prisma.invoice.findUnique({ where: { id: req.params.id } });
  if (!existing) throw new NotFoundError("Invoice not found");
  if (existing.status === "PAID" || Number(existing.amountPaid) > 0) {
    throw new ValidationError("Invoices with recorded payments cannot be deleted — cancel them instead");
  }

  await prisma.invoice.update({ where: { id: existing.id }, data: { status: "CANCELLED" } });
  res.json({ success: true, message: "Invoice cancelled" });
});
