import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import patientRoutes from "./routes/patients.js"; // legacy raw pg.Pool route, left untouched — see PAYMENT_IMPLEMENTATION_REPORT.md
import healthRoutes from "./routes/healthRoutes.js";
import apiRoutes from "./routes/index.js"; // previously written but never imported anywhere — now actually wired in
import webhookRoutes from "./modules/payments/webhook.routes.js";
import { errorHandler } from "./utils/errors.js";
import { JSON_BODY_LIMIT } from "./config/bodyLimit.js";

dotenv.config();

const app = express();

app.use(cors());

// Webhook routes MUST be mounted before express.json(), using their own
// express.raw() body parser (declared inside webhook.routes.js) — Razorpay's
// HMAC signature is computed over the exact raw request bytes, and a
// parse-then-reserialize round trip through express.json() would break
// verification. See modules/payments/webhook.controller.js.
app.use("/api/webhooks", webhookRoutes);

// Explicit limit (previously relied on Express's undocumented 100kb default)
// — see config/bodyLimit.js for why this value was chosen. Applies to every
// router mounted below, including Payment/Billing.
app.use(express.json({ limit: JSON_BODY_LIMIT }));

app.get("/", (req, res) => {
  res.send("MediCare Pro Backend Running 🚀");
});

app.use("/health", healthRoutes);
app.use("/api/health", healthRoutes);
app.use("/patients", patientRoutes); // legacy — untouched
app.use("/api", apiRoutes); // auth, patients, pharmacy, health, billing, payments

// Centralized error handler — must be the last app.use(). Any asyncHandler-
// wrapped controller that throws (or an AppError subclass) lands here instead
// of crashing the process or leaking a raw stack trace to the client.
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
