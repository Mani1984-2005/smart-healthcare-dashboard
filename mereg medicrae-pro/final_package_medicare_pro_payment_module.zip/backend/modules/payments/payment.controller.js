import { z } from "zod";
import { asyncHandler, ValidationError, ForbiddenError, NotFoundError } from "../../utils/errors.js";
import { prisma } from "../../src/lib/prisma.js";
import * as paymentService from "./payment.service.js";
import * as refundService from "./refund.service.js";
import { resolveIdempotencyKey } from "./idempotency.js";

const createOrderSchema = z.object({
  invoiceId: z.string().uuid(),
});

const recordAttemptSchema = z.object({
  paymentOrderId: z.string().uuid(),
  method: z.enum(["UPI", "CARD", "NETBANKING", "WALLET", "CASH", "BANK_TRANSFER", "OTHER"]),
});

const confirmSchema = z.object({
  paymentOrderId: z.string().uuid(),
  paymentAttemptId: z.string().uuid(),
  providerOrderId: z.string().min(1),
  providerPaymentId: z.string().min(1),
  providerSignature: z.string().min(1),
});

const refundSchema = z.object({
  paymentId: z.string().uuid(),
  amount: z.number().positive().optional(), // omit for full refund
  reason: z.string().max(500).optional(),
});

function parseOrThrow(schema, body) {
  const result = schema.safeParse(body);
  if (!result.success) {
    throw new ValidationError("Invalid request body", result.error.flatten());
  }
  return result.data;
}

// POST /api/payments/orders
// Patient (or staff on a patient's behalf) creates a payment order for an
// invoice's outstanding balance. requireSelfOrStaff on the route enforces
// that a PATIENT caller can only do this for their own invoice's patientId.
export const createOrder = asyncHandler(async (req, res) => {
  const { invoiceId } = parseOrThrow(createOrderSchema, req.body);
  const idempotencyKey = resolveIdempotencyKey(req);

  const patient = await resolvePatientContext(req);
  const order = await paymentService.createPaymentOrder({
    invoiceId,
    patientId: patient.id,
    idempotencyKey,
  });

  res.status(201).json({ success: true, data: order });
});

// POST /api/payments/attempts
// P0 FIX (PAYMENT_FINAL_VERIFICATION_GATE.md §4): this endpoint previously
// accepted paymentOrderId from the client body and passed it straight to
// paymentService with no ownership check at all — any authenticated PATIENT
// could supply another patient's paymentOrderId and mutate that order's
// state (CREATED -> ATTEMPTED) or spam PaymentAttempt rows against it. Now
// enforced via assertOwnsPaymentOrder before any state change happens.
export const recordAttempt = asyncHandler(async (req, res) => {
  const body = parseOrThrow(recordAttemptSchema, req.body);
  await assertOwnsPaymentOrder(req, body.paymentOrderId);
  const attempt = await paymentService.recordPaymentAttempt(body);
  res.status(201).json({ success: true, data: attempt });
});

// POST /api/payments/confirm
// Frontend calls this immediately after the Razorpay checkout callback fires
// — but per brief section 12, this endpoint independently re-verifies the
// signature server-side rather than trusting the frontend's "success" claim.
// P0 FIX (same as recordAttempt above): ownership is now checked before
// confirmation proceeds, even though forging a valid provider signature for
// someone else's order/payment id pair would independently require the
// Razorpay API secret — ownership enforcement is defense-in-depth, not the
// only protection, and IDOR must be blocked regardless of whether the
// crypto happens to also block the worst-case outcome.
export const confirmPayment = asyncHandler(async (req, res) => {
  const body = parseOrThrow(confirmSchema, req.body);
  await assertOwnsPaymentOrder(req, body.paymentOrderId);
  const payment = await paymentService.confirmPayment(body);
  res.status(200).json({ success: true, data: payment });
});

// GET /api/payments/history
export const getHistory = asyncHandler(async (req, res) => {
  const patient = await resolvePatientContext(req);
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const pageSize = Math.min(Math.max(parseInt(req.query.pageSize, 10) || 20, 1), 100);
  const history = await paymentService.getPaymentHistoryForPatient(patient.id, { page, pageSize });
  res.status(200).json({ success: true, data: history });
});

// POST /api/payments/refunds — BILLING/ADMIN only (enforced via requireRole on the route)
export const createRefund = asyncHandler(async (req, res) => {
  const body = parseOrThrow(refundSchema, req.body);
  const refund = await refundService.initiateRefund({ ...body, initiatedById: req.appUser.id });
  res.status(201).json({ success: true, data: refund });
});

// GET /api/payments/dashboard/summary — staff KPI cards (brief section 24)
export const getDashboardSummary = asyncHandler(async (req, res) => {
  const [todayRevenueAgg, successCount, pendingCount, failedCount, refundAgg, outstandingAgg] = await Promise.all([
    prisma.payment.aggregate({
      _sum: { amount: true },
      where: { status: "SUCCESS", createdAt: { gte: startOfToday() } },
    }),
    prisma.payment.count({ where: { status: "SUCCESS" } }),
    prisma.paymentAttempt.count({ where: { status: { in: ["INITIATED", "PENDING"] } } }),
    prisma.payment.count({ where: { status: "FAILED" } }),
    prisma.refund.aggregate({ _sum: { amount: true }, where: { status: "PROCESSED" } }),
    prisma.invoice.aggregate({ _sum: { balanceDue: true }, where: { status: { in: ["UNPAID", "PARTIALLY_PAID"] } } }),
  ]);

  res.status(200).json({
    success: true,
    data: {
      todaysRevenue: todayRevenueAgg._sum.amount ?? 0,
      successfulPayments: successCount,
      pendingPayments: pendingCount,
      failedPayments: failedCount,
      totalRefunded: refundAgg._sum.amount ?? 0,
      outstandingAmount: outstandingAgg._sum.balanceDue ?? 0,
    },
  });
});

// GET /api/payments/dashboard/transactions — paginated staff transaction table
export const listTransactions = asyncHandler(async (req, res) => {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const pageSize = Math.min(Math.max(parseInt(req.query.pageSize, 10) || 20, 1), 100);
  const where = {};
  if (req.query.status) where.status = req.query.status;
  if (req.query.method) where.method = req.query.method;

  const [items, total] = await Promise.all([
    prisma.payment.findMany({
      where,
      include: { paymentOrder: { include: { invoice: true, patient: true } } },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.payment.count({ where }),
  ]);

  res.status(200).json({ success: true, data: { items, total, page, pageSize } });
});

async function resolvePatientContext(req) {
  if (req.appUser.role === "PATIENT") {
    const patient = await prisma.patient.findUnique({ where: { userId: req.appUser.id } });
    if (!patient) throw new ForbiddenError("No patient record is linked to this account");
    return patient;
  }
  // Staff acting on behalf of a patient must supply patientId explicitly.
  const patientId = req.body.patientId || req.query.patientId;
  if (!patientId) throw new ValidationError("patientId is required for staff-initiated requests");
  const patient = await prisma.patient.findUnique({ where: { id: patientId } });
  if (!patient) throw new ValidationError("Unknown patientId");
  return patient;
}

// Added for the P0 IDOR fix on /attempts and /confirm (see above). Staff
// roles bypass — consistent with resolvePatientContext's existing trust
// model for staff-initiated actions — but a PATIENT caller must own the
// PaymentOrder they're referencing, verified server-side against their own
// Firebase-derived User -> Patient link, never against anything the client
// merely claims.
const STAFF_ROLES = ["DOCTOR", "NURSE", "RECEPTIONIST", "LAB_TECHNICIAN", "PHARMACIST", "BILLING", "ADMIN"];

async function assertOwnsPaymentOrder(req, paymentOrderId) {
  if (STAFF_ROLES.includes(req.appUser.role)) return;

  if (req.appUser.role !== "PATIENT") {
    throw new ForbiddenError("This action is restricted to patients or authorized staff");
  }

  const order = await prisma.paymentOrder.findUnique({ where: { id: paymentOrderId } });
  if (!order) throw new NotFoundError("Payment order not found");

  const ownPatient = await prisma.patient.findUnique({ where: { userId: req.appUser.id } });
  if (!ownPatient || ownPatient.id !== order.patientId) {
    throw new ForbiddenError("You may only act on your own payment orders");
  }
}

function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}
