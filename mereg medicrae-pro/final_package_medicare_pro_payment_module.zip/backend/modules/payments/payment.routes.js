import express from "express";
import authenticate from "../../middleware/authMiddleware.js";
import { loadAppUser, requireRole } from "../../middleware/rbac.js";
import * as paymentController from "./payment.controller.js";

const router = express.Router();

// Every payment route requires a verified Firebase session resolved to an
// active MediCare Pro User row.
router.use(authenticate, loadAppUser);

// Patient-facing (and staff-on-behalf-of-patient) flow
router.post("/orders", paymentController.createOrder);
router.post("/attempts", paymentController.recordAttempt);
router.post("/confirm", paymentController.confirmPayment);
router.get("/history", paymentController.getHistory);

// Billing-staff / admin operations
router.post(
  "/refunds",
  requireRole("BILLING", "ADMIN"),
  paymentController.createRefund
);

// Staff dashboard (brief section 24) — broader staff visibility, no financial mutation
router.get(
  "/dashboard/summary",
  requireRole("BILLING", "ADMIN"),
  paymentController.getDashboardSummary
);
router.get(
  "/dashboard/transactions",
  requireRole("BILLING", "ADMIN"),
  paymentController.listTransactions
);

export default router;
