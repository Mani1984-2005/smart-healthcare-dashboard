// Razorpay webhook handler.
//
// Every delivery is persisted to WebhookEvent BEFORE any business logic runs,
// with providerEventId UNIQUE — this is what makes duplicate/out-of-order
// delivery safe (brief sections 13-14): a re-delivered event hits the unique
// constraint and is acknowledged as already-processed instead of re-applying
// side effects.
//
// Razorpay's webhook payloads don't always include a single stable top-level
// event id the way Stripe's `evt_...` does, so this handler derives one from
// (event type + the relevant entity id + created_at) when the payload itself
// doesn't supply one — documented as a NOT VERIFIED assumption below, since it
// can't be checked against real Razorpay traffic from this sandbox.

import crypto from "node:crypto";
import { prisma } from "../../src/lib/prisma.js";
import { razorpayProvider } from "./providers/razorpay.provider.js";
import * as paymentService from "./payment.service.js";
import * as refundService from "./refund.service.js";
import { asyncHandler } from "../../utils/errors.js";

const provider = razorpayProvider;

function deriveEventId(payload) {
  if (payload?.id) return String(payload.id);
  // Fallback: hash the entity payload + event type + created_at so identical
  // re-deliveries collapse to the same id. NOT VERIFIED against real Razorpay
  // payload shapes — adjust once live webhook samples are available.
  const basis = JSON.stringify({
    event: payload?.event,
    createdAt: payload?.created_at,
    entity: payload?.payload,
  });
  return crypto.createHash("sha256").update(basis).digest("hex");
}

export const handleRazorpayWebhook = asyncHandler(async (req, res) => {
  // req.body must be the raw Buffer here — see webhook.routes.js, which uses
  // express.raw() instead of express.json() for this route specifically.
  const rawBody = req.body;
  const signatureHeader = req.headers["x-razorpay-signature"];

  const verification = provider.verifyWebhookSignature(rawBody, signatureHeader);

  if (!verification.valid) {
    // Do not leak *why* verification failed to the caller — just reject.
    // Still record the attempt for observability, without a providerEventId
    // conflict risk (invalid deliveries aren't required to be idempotent).
    console.warn("[webhook] signature verification failed");
    return res.status(401).json({ success: false, error: { code: "INVALID_SIGNATURE" } });
  }

  const eventId = deriveEventId(verification.payload);

  let event;
  try {
    event = await prisma.webhookEvent.create({
      data: {
        provider: "razorpay",
        providerEventId: eventId,
        eventType: verification.eventType ?? "unknown",
        payload: verification.payload,
        signatureValid: true,
      },
    });
  } catch (err) {
    if (err?.code === "P2002") {
      // Already processed (or in flight) — acknowledge success so the
      // provider stops retrying, without re-running side effects.
      return res.status(200).json({ success: true, deduped: true });
    }
    throw err;
  }

  try {
    await dispatchEvent(verification.eventType, verification.payload);
    await prisma.webhookEvent.update({
      where: { id: event.id },
      data: { processedAt: new Date() },
    });
    res.status(200).json({ success: true });
  } catch (err) {
    await prisma.webhookEvent.update({
      where: { id: event.id },
      data: { processingError: err.message },
    });
    // Surface a 500 so the provider retries — the unique providerEventId
    // constraint already makes retried processing safe.
    throw err;
  }
});

async function dispatchEvent(eventType, payload) {
  // NOT VERIFIED: exact payload shape assumed from Razorpay's documented
  // webhook contract, not confirmed against live traffic.
  switch (eventType) {
    case "payment.captured": {
      const entity = payload?.payload?.payment?.entity;
      if (!entity) {
        console.warn("[webhook] payment.captured event missing expected entity payload");
        return;
      }
      // Look up the attempt this payment corresponds to via our own
      // providerOrderId, then run it through the SAME confirmPayment() path
      // the frontend confirm endpoint uses, so both channels are equally
      // authoritative and equally idempotent.
      const order = await prisma.paymentOrder.findUnique({
        where: { providerOrderId: entity.order_id },
        include: { attempts: { orderBy: { createdAt: "desc" }, take: 1 } },
      });
      if (!order || order.attempts.length === 0) {
        // Observability fix (PAYMENT_MODULE_HANDOFF.md follow-up): this used
        // to be a silent `return` — an unmatched webhook (e.g. arriving
        // before our own order-creation write lands, or referencing an order
        // we genuinely have no record of) vanished with zero trace. Now
        // logged so it's investigable instead of invisible. Still correctly
        // returns without acting — we only warn, we never guess at ownership.
        console.warn("[webhook] payment.captured for unknown/attempt-less providerOrderId:", entity.order_id);
        return;
      }

      await paymentService.confirmPayment({
        paymentOrderId: order.id,
        paymentAttemptId: order.attempts[0].id,
        providerOrderId: entity.order_id,
        providerPaymentId: entity.id,
        // Authenticity for this call path comes from the webhook payload's
        // own HMAC (verified above via verifyWebhookSignature), not the
        // checkout-flow order|payment signature — see payment.service.js.
        trustedByWebhook: true,
      });
      break;
    }
    case "payment.failed": {
      const entity = payload?.payload?.payment?.entity;
      if (!entity) {
        console.warn("[webhook] payment.failed event missing expected entity payload");
        return;
      }
      const order = await prisma.paymentOrder.findUnique({
        where: { providerOrderId: entity.order_id },
        include: { attempts: { orderBy: { createdAt: "desc" }, take: 1 } },
      });
      if (!order || order.attempts.length === 0) {
        console.warn("[webhook] payment.failed for unknown/attempt-less providerOrderId:", entity.order_id);
        return;
      }
      await paymentService.markAttemptFailed({
        paymentAttemptId: order.attempts[0].id,
        reason: entity.error_description || "Payment failed",
      });
      break;
    }
    case "refund.processed": {
      const entity = payload?.payload?.refund?.entity;
      if (!entity) {
        console.warn("[webhook] refund.processed event missing expected entity payload");
        return;
      }
      const refund = await prisma.refund.findUnique({ where: { providerRefundId: entity.id } });
      if (!refund) {
        console.warn("[webhook] refund.processed for unknown providerRefundId:", entity.id);
        return;
      }
      await refundService.markRefundProcessed({ refundId: refund.id, providerRefundId: entity.id });
      break;
    }
    case "refund.failed": {
      const entity = payload?.payload?.refund?.entity;
      if (!entity) {
        console.warn("[webhook] refund.failed event missing expected entity payload");
        return;
      }
      const refund = await prisma.refund.findUnique({ where: { providerRefundId: entity.id } });
      if (!refund) {
        console.warn("[webhook] refund.failed for unknown providerRefundId:", entity.id);
        return;
      }
      await refundService.markRefundFailed({ refundId: refund.id, reason: "Refund failed at provider" });
      break;
    }
    default:
      // Unhandled event types are stored (for audit/reconciliation) but not
      // acted on — explicitly not a failure.
      return;
  }
}
