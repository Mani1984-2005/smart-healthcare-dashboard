// Core orchestration for the payment lifecycle:
//   Invoice -> PaymentOrder -> PaymentAttempt -> Payment -> (Invoice sync)
//
// The one rule this file exists to enforce (brief section 12): the frontend
// reporting "success" NEVER writes PAID to the database by itself. Only
// confirmPayment() — which independently verifies the provider signature —
// is allowed to transition a Payment to SUCCESS and cascade that into the
// Invoice. The webhook path (webhook.controller.js) calls the same function,
// so a confirmed payment is idempotent regardless of which channel reports it
// first.

import { prisma } from "../../src/lib/prisma.js";
import { razorpayProvider } from "./providers/razorpay.provider.js";
import { NotFoundError, ConflictError, ValidationError } from "../../utils/errors.js";
import { assertValidTransition, PAYMENT_ORDER_TRANSITIONS, PAYMENT_ATTEMPT_TRANSITIONS } from "./payment.constants.js";
import { runIdempotently } from "./idempotency.js";

const provider = razorpayProvider;

function toDecimalNumber(d) {
  return typeof d === "object" && d !== null && "toNumber" in d ? d.toNumber() : Number(d);
}

/**
 * Creates a PaymentOrder for an Invoice's outstanding balance, and a matching
 * provider-side order. Idempotent on idempotencyKey: a retried "Pay Now" click
 * with the same key returns the existing order instead of creating a duplicate.
 */
export async function createPaymentOrder({ invoiceId, patientId, idempotencyKey }) {
  return runIdempotently(async () => {
    const existing = await prisma.paymentOrder.findUnique({ where: { idempotencyKey } });
    if (existing) return existing;

    const invoice = await prisma.invoice.findUnique({ where: { id: invoiceId } });
    if (!invoice) throw new NotFoundError("Invoice not found");
    if (invoice.patientId !== patientId) {
      throw new ValidationError("Invoice does not belong to this patient");
    }
    if (invoice.status === "PAID" || invoice.status === "CANCELLED") {
      throw new ConflictError(`Invoice is already ${invoice.status.toLowerCase()}; no payment order can be created.`);
    }

    const balanceDue = toDecimalNumber(invoice.balanceDue);
    if (balanceDue <= 0) {
      throw new ConflictError("Invoice has no outstanding balance");
    }

    const providerOrder = await provider.createOrder({
      amount: balanceDue,
      currency: "INR",
      receipt: invoice.invoiceNumber,
      notes: { invoiceId: invoice.id, patientId },
    });

    return prisma.paymentOrder.create({
      data: {
        invoiceId,
        patientId,
        amount: balanceDue,
        currency: "INR",
        status: "CREATED",
        provider: "razorpay",
        providerOrderId: providerOrder.providerOrderId,
        idempotencyKey,
        // Razorpay orders are valid for a limited window; align our record with that.
        expiresAt: new Date(Date.now() + 15 * 60 * 1000),
      },
    });
  });
}

/**
 * Records a new attempt against a PaymentOrder (e.g. patient selected UPI and
 * launched the app). This does NOT mark anything as paid — it only tracks
 * that an attempt is in flight, so retried/duplicate attempts are visible and
 * a stuck PENDING attempt can be distinguished from a fresh one.
 */
export async function recordPaymentAttempt({ paymentOrderId, method }) {
  const order = await prisma.paymentOrder.findUnique({ where: { id: paymentOrderId } });
  if (!order) throw new NotFoundError("Payment order not found");
  if (order.status === "PAID") {
    throw new ConflictError("This invoice has already been paid.");
  }
  if (order.status === "EXPIRED" || order.status === "CANCELLED") {
    throw new ConflictError(`Payment order is ${order.status.toLowerCase()} and cannot accept new attempts.`);
  }

  const attempt = await prisma.paymentAttempt.create({
    data: { paymentOrderId, method, status: "INITIATED" },
  });

  if (order.status === "CREATED") {
    assertValidTransition("PaymentOrder", PAYMENT_ORDER_TRANSITIONS, order.status, "ATTEMPTED");
    await prisma.paymentOrder.update({ where: { id: order.id }, data: { status: "ATTEMPTED" } });
  }

  return attempt;
}

/**
 * THE ONLY function allowed to mark a Payment SUCCESS and cascade to Invoice.
 * Independently re-verifies the provider signature — it does not trust the
 * caller's claim that payment succeeded, whether the caller is the frontend
 * confirm endpoint or the webhook handler.
 *
 * Wrapped in a single DB transaction so a partial write (Payment updated but
 * Invoice not) can never happen — brief section 39.
 */
export async function confirmPayment({
  paymentOrderId,
  paymentAttemptId,
  providerOrderId,
  providerPaymentId,
  providerSignature,
  // Only ever true when called from webhook.controller.js. Razorpay's
  // checkout-flow HMAC (order_id|payment_id, signed with the API secret) is
  // returned to the frontend at checkout time and is NOT present in webhook
  // payloads — webhook authenticity is instead established separately via
  // provider.verifyWebhookSignature() over the whole payload before this
  // function is ever called. This flag makes that trust boundary explicit
  // instead of faking a signature value to pass through the normal check.
  trustedByWebhook = false,
}) {
  const verification = trustedByWebhook
    ? { valid: true, providerPaymentId }
    : await provider.verifyPaymentSignature({
        orderId: providerOrderId,
        paymentId: providerPaymentId,
        signature: providerSignature,
      });

  try {
    return await prisma.$transaction(async (tx) => {
      const attempt = await tx.paymentAttempt.findUnique({
        where: { id: paymentAttemptId },
        include: { payment: true },
      });
      if (!attempt || attempt.paymentOrderId !== paymentOrderId) {
        throw new NotFoundError("Payment attempt not found for this order");
      }

      // Idempotent re-delivery: this attempt was already resolved to SUCCESS
      // (e.g. webhook arrives after the frontend confirm call already landed).
      if (attempt.status === "SUCCESS" && attempt.payment) {
        return attempt.payment;
      }

      if (!verification.valid) {
        assertValidTransition("PaymentAttempt", PAYMENT_ATTEMPT_TRANSITIONS, attempt.status, "FAILED");
        await tx.paymentAttempt.update({
          where: { id: attempt.id },
          data: { status: "FAILED", failureReason: verification.failureReason ?? "Signature verification failed" },
        });
        throw new ValidationError("Payment could not be verified", { reason: verification.failureReason });
      }

      assertValidTransition("PaymentAttempt", PAYMENT_ATTEMPT_TRANSITIONS, attempt.status, "SUCCESS");
      await tx.paymentAttempt.update({
        where: { id: attempt.id },
        data: { status: "SUCCESS", providerPaymentId },
      });

      const order = await tx.paymentOrder.findUnique({ where: { id: paymentOrderId } });
      if (!order) throw new NotFoundError("Payment order not found");

      const payment = await tx.payment.create({
        data: {
          paymentOrderId: order.id,
          paymentAttemptId: attempt.id,
          amount: order.amount,
          currency: order.currency,
          method: attempt.method,
          status: "SUCCESS",
          provider: "razorpay",
          providerPaymentId,
          providerSignature,
          verifiedAt: new Date(),
        },
      });

      assertValidTransition("PaymentOrder", PAYMENT_ORDER_TRANSITIONS, order.status, "PAID");
      await tx.paymentOrder.update({ where: { id: order.id }, data: { status: "PAID" } });

      const invoice = await tx.invoice.findUnique({ where: { id: order.invoiceId } });
      const newAmountPaid = toDecimalNumber(invoice.amountPaid) + toDecimalNumber(order.amount);
      const grandTotal = toDecimalNumber(invoice.grandTotal);
      const newBalance = Math.max(grandTotal - newAmountPaid, 0);

      await tx.invoice.update({
        where: { id: invoice.id },
        data: {
          amountPaid: newAmountPaid,
          balanceDue: newBalance,
          status: newBalance <= 0 ? "PAID" : "PARTIALLY_PAID",
          paidAt: newBalance <= 0 ? new Date() : invoice.paidAt,
        },
      });

      await tx.paymentAuditLog.create({
        data: {
          action: "PAYMENT_VERIFIED",
          entityType: "Payment",
          entityId: payment.id,
          correlationId: providerPaymentId,
          metadata: { invoiceId: invoice.id, amount: order.amount.toString() },
        },
      });

      return payment;
    });
  } catch (err) {
    // P1 CONCURRENCY FIX (PAYMENT_FINAL_VERIFICATION_GATE.md §14): two
    // concurrent confirmations of the SAME attempt (e.g. the frontend confirm
    // call and a webhook delivery racing each other) can both pass the
    // in-transaction "already SUCCESS" check before either commits, under
    // Postgres's default READ COMMITTED isolation. The `Payment.paymentAttemptId`
    // UNIQUE constraint is what actually prevents a duplicate Payment row from
    // being created — but without this catch, the losing transaction would
    // surface as a raw, unhandled Prisma P2002 error instead of the idempotent
    // "already processed" result callers expect. This does not weaken any
    // check above; it only changes what happens after the database has
    // already correctly rejected a duplicate write.
    if (err?.code === "P2002" && err?.meta?.target?.includes?.("paymentAttemptId")) {
      const existing = await prisma.payment.findUnique({ where: { paymentAttemptId } });
      if (existing) return existing;
    }
    throw err;
  }
}

export async function markAttemptFailed({ paymentAttemptId, reason }) {
  const attempt = await prisma.paymentAttempt.findUnique({ where: { id: paymentAttemptId } });
  if (!attempt) throw new NotFoundError("Payment attempt not found");

  assertValidTransition("PaymentAttempt", PAYMENT_ATTEMPT_TRANSITIONS, attempt.status, "FAILED");
  return prisma.paymentAttempt.update({
    where: { id: attempt.id },
    data: { status: "FAILED", failureReason: reason },
  });
}

export async function getPaymentHistoryForPatient(patientId, { page = 1, pageSize = 20 } = {}) {
  const skip = (page - 1) * pageSize;
  const [items, total] = await Promise.all([
    prisma.payment.findMany({
      where: { paymentOrder: { patientId } },
      include: { paymentOrder: { include: { invoice: true } }, refunds: true },
      orderBy: { createdAt: "desc" },
      skip,
      take: pageSize,
    }),
    prisma.payment.count({ where: { paymentOrder: { patientId } } }),
  ]);
  return { items, total, page, pageSize };
}
