// Razorpay adapter — implements PaymentProvider against Razorpay's documented
// Orders / Payments / Refunds / Webhooks API.
//
// STATUS: IMPLEMENTED against Razorpay's documented contract, CONFIGURATION REQUIRED
// (no RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET / RAZORPAY_WEBHOOK_SECRET exist in this
// environment), NOT VERIFIED against a live sandbox account — this sandbox has no
// outbound network access to api.razorpay.com (egress is restricted to package
// registries only). Order-creation and refund calls are real SDK calls that will
// work once real sandbox keys are supplied and the deploy environment can reach
// Razorpay's API; the signature-verification logic (createOrder response handling
// and both HMAC checks) is pure crypto with no network dependency and IS unit-tested
// in __tests__/razorpay.provider.test.js against synthetic payloads.

import Razorpay from "razorpay";
import crypto from "node:crypto";
import { PaymentProvider } from "../payment.provider.js";

export class RazorpayProvider extends PaymentProvider {
  constructor({ keyId, keySecret, webhookSecret } = {}) {
    super();
    this.keyId = keyId ?? process.env.RAZORPAY_KEY_ID;
    this.keySecret = keySecret ?? process.env.RAZORPAY_KEY_SECRET;
    this.webhookSecret = webhookSecret ?? process.env.RAZORPAY_WEBHOOK_SECRET;

    // Fail loudly at construction time rather than silently no-op-ing — per the
    // project's standing rule against fake/placeholder behavior.
    if (!this.keyId || !this.keySecret) {
      this._configured = false;
    } else {
      this._configured = true;
      this.client = new Razorpay({ key_id: this.keyId, key_secret: this.keySecret });
    }
  }

  _assertConfigured() {
    if (!this._configured) {
      const err = new Error(
        "Razorpay is not configured: set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET. " +
          "This is a CONFIGURATION REQUIRED gap, not a bug — see razorpay.provider.js header."
      );
      err.statusCode = 503;
      err.code = "PAYMENT_PROVIDER_NOT_CONFIGURED";
      throw err;
    }
  }

  async createOrder({ amount, currency = "INR", receipt, notes = {} }) {
    this._assertConfigured();

    // Razorpay expects amount in the smallest currency unit (paise for INR).
    const amountInSubunits = Math.round(Number(amount) * 100);

    const order = await this.client.orders.create({
      amount: amountInSubunits,
      currency,
      receipt,
      notes,
      payment_capture: 1, // auto-capture on successful authorization
    });

    return {
      providerOrderId: order.id,
      status: order.status,
      raw: order,
    };
  }

  async verifyPaymentSignature({ orderId, paymentId, signature }) {
    this._assertConfigured();

    if (!orderId || !paymentId || !signature) {
      return { valid: false, failureReason: "Missing orderId/paymentId/signature" };
    }

    const expected = crypto
      .createHmac("sha256", this.keySecret)
      .update(`${orderId}|${paymentId}`)
      .digest("hex");

    const valid = timingSafeEqualHex(expected, signature);

    return valid
      ? { valid: true, providerPaymentId: paymentId }
      : { valid: false, failureReason: "Signature mismatch" };
  }

  async createRefund({ providerPaymentId, amount, reason }) {
    this._assertConfigured();

    const payload = {};
    if (amount != null) payload.amount = Math.round(Number(amount) * 100);
    if (reason) payload.notes = { reason };

    const refund = await this.client.payments.refund(providerPaymentId, payload);

    return {
      providerRefundId: refund.id,
      status: refund.status,
      raw: refund,
    };
  }

  verifyWebhookSignature(rawBody, signatureHeader) {
    if (!this.webhookSecret) {
      return { valid: false };
    }
    if (!signatureHeader || !rawBody) {
      return { valid: false };
    }

    const expected = crypto.createHmac("sha256", this.webhookSecret).update(rawBody).digest("hex");
    const valid = timingSafeEqualHex(expected, signatureHeader);
    if (!valid) return { valid: false };

    let payload;
    try {
      payload = JSON.parse(rawBody.toString("utf8"));
    } catch {
      return { valid: false };
    }

    return {
      valid: true,
      eventId: payload?.id || payload?.event_id, // Razorpay webhook payloads don't always carry a stable top-level id; see webhook.controller.js for the fallback used to build one
      eventType: payload?.event,
      payload,
    };
  }
}

function timingSafeEqualHex(a, b) {
  const bufA = Buffer.from(String(a), "utf8");
  const bufB = Buffer.from(String(b), "utf8");
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

// Singleton used by the rest of the payments module. Constructed lazily so
// importing this file never throws even when unconfigured — only calling an
// actual method does.
export const razorpayProvider = new RazorpayProvider();
