// Closes the gap flagged in PAYMENT_MODULE_CLOSURE_REPORT.md §5 (Attack F):
// webhook replay/idempotency had code-level reasoning but no dedicated test
// exercising the actual P2002-catch branch of webhook.controller.js, unlike
// its sibling race condition in payment.service.js which was tested directly.
// Mocked Prisma/provider/services — no live database or Razorpay account
// (none reachable from this sandbox, see PAYMENT_FINAL_VERIFICATION_GATE.md §16).

import { describe, it, expect, vi, beforeEach } from "vitest";

const mockPrisma = {
  webhookEvent: { create: vi.fn(), update: vi.fn() },
  paymentOrder: { findUnique: vi.fn() },
  refund: { findUnique: vi.fn() },
};

vi.mock("../../../src/lib/prisma.js", () => ({ prisma: mockPrisma }));

const mockVerifyWebhookSignature = vi.fn();
vi.mock("../providers/razorpay.provider.js", () => ({
  razorpayProvider: { verifyWebhookSignature: (...args) => mockVerifyWebhookSignature(...args) },
}));

vi.mock("../payment.service.js", () => ({
  confirmPayment: vi.fn(async () => ({ id: "payment-1", status: "SUCCESS" })),
  markAttemptFailed: vi.fn(),
}));
vi.mock("../refund.service.js", () => ({
  markRefundProcessed: vi.fn(),
  markRefundFailed: vi.fn(),
}));

const paymentService = await import("../payment.service.js");
const { handleRazorpayWebhook } = await import("../webhook.controller.js");

function mockReqRes({ rawBody, signature }) {
  const req = { body: rawBody, headers: { "x-razorpay-signature": signature } };
  let statusCode;
  let jsonBody;
  const res = {
    status(code) {
      statusCode = code;
      return this;
    },
    json(body) {
      jsonBody = body;
      return this;
    },
  };
  let nextErr;
  const next = (err) => {
    nextErr = err;
  };
  return { req, res, next, getStatus: () => statusCode, getJson: () => jsonBody, getNextErr: () => nextErr };
}

const CAPTURED_PAYLOAD = {
  event: "payment.captured",
  payload: { payment: { entity: { id: "pay_live_1", order_id: "order_live_1" } } },
};
const rawBody = Buffer.from(JSON.stringify(CAPTURED_PAYLOAD));

describe("webhook — Attack E: invalid signature rejection", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rejects an invalid signature with 401 and never persists a WebhookEvent", async () => {
    mockVerifyWebhookSignature.mockReturnValueOnce({ valid: false });

    const { req, res, next, getStatus } = mockReqRes({ rawBody, signature: "forged-signature" });
    await handleRazorpayWebhook(req, res, next);

    expect(getStatus()).toBe(401);
    expect(mockPrisma.webhookEvent.create).not.toHaveBeenCalled();
    expect(paymentService.confirmPayment).not.toHaveBeenCalled();
  });
});

describe("webhook — Attack F: replay / idempotency", () => {
  beforeEach(() => vi.clearAllMocks());

  it("processes a genuinely new, validly-signed event exactly once", async () => {
    mockVerifyWebhookSignature.mockReturnValueOnce({ valid: true, eventType: "payment.captured", payload: CAPTURED_PAYLOAD });
    mockPrisma.webhookEvent.create.mockResolvedValueOnce({ id: "event-1" });
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce({
      id: "order-1",
      attempts: [{ id: "attempt-1" }],
    });

    const { req, res, next, getStatus, getNextErr } = mockReqRes({ rawBody, signature: "valid-sig" });
    await handleRazorpayWebhook(req, res, next);

    expect(getNextErr()).toBeUndefined();
    expect(getStatus()).toBe(200);
    expect(paymentService.confirmPayment).toHaveBeenCalledOnce();
    expect(paymentService.confirmPayment).toHaveBeenCalledWith(
      expect.objectContaining({ trustedByWebhook: true, paymentOrderId: "order-1", paymentAttemptId: "attempt-1" })
    );
    expect(mockPrisma.webhookEvent.update).toHaveBeenCalledWith(
      expect.objectContaining({ where: { id: "event-1" }, data: expect.objectContaining({ processedAt: expect.any(Date) }) })
    );
  });

  it("THE ATTACK: replaying the identical webhook is deduped and does NOT re-run confirmPayment a second time", async () => {
    // Same signature-verified payload arrives twice, e.g. Razorpay's own retry
    // behavior or a malicious replay. The second delivery must hit the
    // providerEventId UNIQUE constraint (simulated here as a P2002 from
    // Prisma) and be acknowledged WITHOUT any financial side effect running
    // again — this is the exact mechanism, exercised directly, not just
    // reasoned about.
    mockVerifyWebhookSignature.mockReturnValue({ valid: true, eventType: "payment.captured", payload: CAPTURED_PAYLOAD });

    const p2002 = Object.assign(new Error("Unique constraint failed"), {
      code: "P2002",
      meta: { target: ["providerEventId"] },
    });
    mockPrisma.webhookEvent.create.mockRejectedValueOnce(p2002); // the replay's create() collides

    const { req, res, next, getStatus, getJson, getNextErr } = mockReqRes({ rawBody, signature: "valid-sig" });
    await handleRazorpayWebhook(req, res, next);

    expect(getNextErr()).toBeUndefined();
    expect(getStatus()).toBe(200);
    expect(getJson()).toMatchObject({ success: true, deduped: true });

    // The critical assertion: no financial mutation ran for the replay.
    expect(paymentService.confirmPayment).not.toHaveBeenCalled();
  });

  it("re-throws a non-P2002 database error rather than silently treating it as a dedupe", async () => {
    mockVerifyWebhookSignature.mockReturnValueOnce({ valid: true, eventType: "payment.captured", payload: CAPTURED_PAYLOAD });
    const dbError = new Error("connection lost");
    mockPrisma.webhookEvent.create.mockRejectedValueOnce(dbError);

    const { req, res, next, getNextErr } = mockReqRes({ rawBody, signature: "valid-sig" });
    await handleRazorpayWebhook(req, res, next);

    expect(getNextErr()).toBe(dbError);
    expect(paymentService.confirmPayment).not.toHaveBeenCalled();
  });

  it("records a processing failure and re-throws (for provider retry) if dispatchEvent itself fails, without masking the P2002 dedupe path", async () => {
    mockVerifyWebhookSignature.mockReturnValueOnce({ valid: true, eventType: "payment.captured", payload: CAPTURED_PAYLOAD });
    mockPrisma.webhookEvent.create.mockResolvedValueOnce({ id: "event-2" });
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce({ id: "order-1", attempts: [{ id: "attempt-1" }] });
    const dispatchError = new Error("confirmPayment blew up");
    paymentService.confirmPayment.mockRejectedValueOnce(dispatchError);

    const { req, res, next, getNextErr } = mockReqRes({ rawBody, signature: "valid-sig" });
    await handleRazorpayWebhook(req, res, next);

    expect(getNextErr()).toBe(dispatchError);
    expect(mockPrisma.webhookEvent.update).toHaveBeenCalledWith(
      expect.objectContaining({ where: { id: "event-2" }, data: { processingError: dispatchError.message } })
    );
  });
});
