// Closes a real gap found during the final completion audit: every prior
// webhook test called handleRazorpayWebhook directly with a hand-built
// req.body (a Buffer), never through the actual Express router
// (webhook.routes.js) that applies express.raw({type:"application/json"}).
// That specific wiring — using raw() instead of json() specifically so the
// exact signed bytes survive to signature verification — had never been
// proven through a real HTTP request. This test sends a genuine HTTP POST
// with a real Content-Type header through the real router and confirms the
// signature computed over the real raw body verifies correctly.
//
// Mocks only Prisma and the Razorpay provider's *business logic* — the
// crypto/body-parsing path under test here is 100% real, unmodified
// production code (webhook.routes.js's actual express.raw() call).

import { describe, it, expect, vi, beforeEach } from "vitest";
import express from "express";
import request from "supertest";
import crypto from "node:crypto";
import { errorHandler } from "../../../utils/errors.js";

const mockPrisma = {
  webhookEvent: { create: vi.fn(), update: vi.fn() },
  paymentOrder: { findUnique: vi.fn() },
};
vi.mock("../../../src/lib/prisma.js", () => ({ prisma: mockPrisma }));

vi.mock("../payment.service.js", () => ({
  confirmPayment: vi.fn(async () => ({ id: "payment-1", status: "SUCCESS" })),
  markAttemptFailed: vi.fn(),
}));
vi.mock("../refund.service.js", () => ({ markRefundProcessed: vi.fn(), markRefundFailed: vi.fn() }));

const WEBHOOK_SECRET = "test_webhook_secret_for_http_test_only";
process.env.RAZORPAY_WEBHOOK_SECRET = WEBHOOK_SECRET;
process.env.RAZORPAY_KEY_ID = "rzp_test_fake";
process.env.RAZORPAY_KEY_SECRET = "fake_secret";

const { default: webhookRoutes } = await import("../webhook.routes.js");

function buildTestApp() {
  const app = express();
  app.use("/webhooks", webhookRoutes);
  app.use(errorHandler);
  return app;
}

const payload = {
  event: "payment.captured",
  payload: { payment: { entity: { id: "pay_http_1", order_id: "order_http_1" } } },
};

describe("webhook.routes.js — real HTTP wiring (express.raw)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("accepts a genuinely HTTP-delivered, correctly-signed webhook and processes it", async () => {
    const rawBody = JSON.stringify(payload);
    const signature = crypto.createHmac("sha256", WEBHOOK_SECRET).update(rawBody).digest("hex");

    mockPrisma.webhookEvent.create.mockResolvedValueOnce({ id: "event-http-1" });
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce({ id: "order-1", attempts: [{ id: "attempt-1" }] });

    const res = await request(buildTestApp())
      .post("/webhooks/razorpay")
      .set("Content-Type", "application/json")
      .set("X-Razorpay-Signature", signature)
      .send(rawBody);

    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ success: true });
  });

  it("rejects a genuinely HTTP-delivered webhook with a forged signature — the real attack scenario", async () => {
    const rawBody = JSON.stringify(payload);
    const forgedSignature = crypto.createHmac("sha256", "wrong-secret").update(rawBody).digest("hex");

    const res = await request(buildTestApp())
      .post("/webhooks/razorpay")
      .set("Content-Type", "application/json")
      .set("X-Razorpay-Signature", forgedSignature)
      .send(rawBody);

    expect(res.status).toBe(401);
    expect(mockPrisma.webhookEvent.create).not.toHaveBeenCalled();
  });

  it("proves the raw-body requirement actually matters: a byte-reordered-but-logically-identical body fails verification over real HTTP", async () => {
    // Same signature computed over the ORIGINAL key order...
    const originalBody = JSON.stringify({ b: 2, a: 1, event: "payment.captured" });
    const signature = crypto.createHmac("sha256", WEBHOOK_SECRET).update(originalBody).digest("hex");

    // ...but a different, logically-equivalent body is actually sent over HTTP.
    const reorderedBody = JSON.stringify({ a: 1, b: 2, event: "payment.captured" });

    const res = await request(buildTestApp())
      .post("/webhooks/razorpay")
      .set("Content-Type", "application/json")
      .set("X-Razorpay-Signature", signature)
      .send(reorderedBody);

    expect(res.status).toBe(401);
  });

  it("rejects a request with no signature header at all", async () => {
    const res = await request(buildTestApp())
      .post("/webhooks/razorpay")
      .set("Content-Type", "application/json")
      .send(JSON.stringify(payload));

    expect(res.status).toBe(401);
  });
});
