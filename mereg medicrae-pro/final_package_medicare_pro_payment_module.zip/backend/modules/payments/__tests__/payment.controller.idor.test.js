// Regression tests for the P0 IDOR fix documented in
// PAYMENT_FINAL_VERIFICATION_GATE.md §4: recordAttempt and confirmPayment
// previously trusted a client-supplied paymentOrderId with no check that the
// calling PATIENT actually owned that order. These tests exercise the
// extracted assertOwnsPaymentOrder logic against a mocked Prisma client —
// they do not hit a live database (none is reachable in this sandbox).

import { describe, it, expect, vi, beforeEach } from "vitest";

const mockPrisma = {
  paymentOrder: { findUnique: vi.fn() },
  patient: { findUnique: vi.fn() },
};

vi.mock("../../../src/lib/prisma.js", () => ({ prisma: mockPrisma }));

// payment.controller.js also imports payment.service.js / refund.service.js /
// idempotency.js at module load time — mock them minimally so importing the
// controller doesn't pull in the full service graph (already covered by
// payment.service.test.js).
vi.mock("../payment.service.js", () => ({
  createPaymentOrder: vi.fn(),
  recordPaymentAttempt: vi.fn(async () => ({ id: "attempt-created" })),
  confirmPayment: vi.fn(async () => ({ id: "payment-confirmed" })),
  getPaymentHistoryForPatient: vi.fn(),
}));
vi.mock("../refund.service.js", () => ({ initiateRefund: vi.fn() }));

const paymentService = await import("../payment.service.js");
const { recordAttempt, confirmPayment } = await import("../payment.controller.js");

function mockReqRes(appUser, body) {
  const req = { appUser, body, query: {} };
  let statusCode;
  let jsonBody;
  const res = {
    status(code) {
      statusCode = code;
      return this;
    },
    json(body) {
      jsonBody = body;
      return this;
    },
  };
  let nextErr;
  const next = (err) => {
    nextErr = err;
  };
  return { req, res, next, getStatus: () => statusCode, getJson: () => jsonBody, getNextErr: () => nextErr };
}

const VALID_UUID_ORDER = "11111111-1111-4111-8111-111111111111";
const VALID_UUID_ATTEMPT = "22222222-2222-4222-8222-222222222222";

describe("recordAttempt — IDOR protection", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rejects a PATIENT supplying another patient's paymentOrderId", async () => {
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce({ id: VALID_UUID_ORDER, patientId: "patient-B" });
    mockPrisma.patient.findUnique.mockResolvedValueOnce({ id: "patient-A", userId: "user-A" });

    const { req, res, next, getNextErr } = mockReqRes(
      { role: "PATIENT", id: "user-A" },
      { paymentOrderId: VALID_UUID_ORDER, method: "UPI" }
    );

    await recordAttempt(req, res, next);

    expect(getNextErr()).toMatchObject({ code: "FORBIDDEN" });
    expect(paymentService.recordPaymentAttempt).not.toHaveBeenCalled(); // never reaches the service layer
  });

  it("allows a PATIENT to record an attempt against their own paymentOrderId", async () => {
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce({ id: VALID_UUID_ORDER, patientId: "patient-A" });
    mockPrisma.patient.findUnique.mockResolvedValueOnce({ id: "patient-A", userId: "user-A" });

    const { req, res, next, getNextErr } = mockReqRes(
      { role: "PATIENT", id: "user-A" },
      { paymentOrderId: VALID_UUID_ORDER, method: "UPI" }
    );

    await recordAttempt(req, res, next);

    expect(getNextErr()).toBeUndefined();
    expect(paymentService.recordPaymentAttempt).toHaveBeenCalledOnce();
  });

  it("allows staff roles through without an ownership lookup at all", async () => {
    const { req, res, next, getNextErr } = mockReqRes(
      { role: "BILLING", id: "user-staff" },
      { paymentOrderId: VALID_UUID_ORDER, method: "UPI" }
    );

    await recordAttempt(req, res, next);

    expect(getNextErr()).toBeUndefined();
    expect(mockPrisma.paymentOrder.findUnique).not.toHaveBeenCalled();
    expect(paymentService.recordPaymentAttempt).toHaveBeenCalledOnce();
  });

  it("returns NOT_FOUND rather than leaking existence info in a confusing way when the order doesn't exist", async () => {
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce(null);

    const { req, res, next, getNextErr } = mockReqRes(
      { role: "PATIENT", id: "user-A" },
      { paymentOrderId: VALID_UUID_ORDER, method: "UPI" }
    );

    await recordAttempt(req, res, next);

    expect(getNextErr()).toMatchObject({ code: "NOT_FOUND" });
  });
});

describe("confirmPayment — IDOR protection", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rejects a PATIENT confirming a payment order that isn't theirs", async () => {
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce({ id: VALID_UUID_ORDER, patientId: "patient-B" });
    mockPrisma.patient.findUnique.mockResolvedValueOnce({ id: "patient-A", userId: "user-A" });

    const { req, res, next, getNextErr } = mockReqRes(
      { role: "PATIENT", id: "user-A" },
      {
        paymentOrderId: VALID_UUID_ORDER,
        paymentAttemptId: VALID_UUID_ATTEMPT,
        providerOrderId: "order_x",
        providerPaymentId: "pay_x",
        providerSignature: "sig_x",
      }
    );

    await confirmPayment(req, res, next);

    expect(getNextErr()).toMatchObject({ code: "FORBIDDEN" });
    expect(paymentService.confirmPayment).not.toHaveBeenCalled();
  });

  it("allows confirmation to proceed once ownership is verified", async () => {
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce({ id: VALID_UUID_ORDER, patientId: "patient-A" });
    mockPrisma.patient.findUnique.mockResolvedValueOnce({ id: "patient-A", userId: "user-A" });

    const { req, res, next, getNextErr } = mockReqRes(
      { role: "PATIENT", id: "user-A" },
      {
        paymentOrderId: VALID_UUID_ORDER,
        paymentAttemptId: VALID_UUID_ATTEMPT,
        providerOrderId: "order_x",
        providerPaymentId: "pay_x",
        providerSignature: "sig_x",
      }
    );

    await confirmPayment(req, res, next);

    expect(getNextErr()).toBeUndefined();
    expect(paymentService.confirmPayment).toHaveBeenCalledOnce();
  });
});
