// These tests mock @prisma/client entirely (no live database — see
// PAYMENT_IMPLEMENTATION_REPORT.md for why one isn't reachable from this
// sandbox) to verify the SERVICE-LAYER LOGIC: idempotent order creation,
// never-trust-frontend confirmation, and the invoice-sync arithmetic. They do
// not, and cannot, verify actual Postgres constraint enforcement (e.g. the
// UNIQUE index on idempotencyKey) — that requires `prisma migrate dev`
// against a real database and is explicitly out of scope for this test file.

import { describe, it, expect, vi, beforeEach } from "vitest";

const mockPrisma = {
  paymentOrder: { findUnique: vi.fn(), create: vi.fn(), update: vi.fn() },
  paymentAttempt: { findUnique: vi.fn(), create: vi.fn(), update: vi.fn() },
  payment: { create: vi.fn() },
  invoice: { findUnique: vi.fn(), update: vi.fn() },
  paymentAuditLog: { create: vi.fn() },
  $transaction: vi.fn(async (fn) => fn(mockPrisma)),
};

vi.mock("../../../src/lib/prisma.js", () => ({ prisma: mockPrisma }));

vi.mock("../providers/razorpay.provider.js", () => ({
  razorpayProvider: {
    createOrder: vi.fn(async () => ({ providerOrderId: "order_mock_1", status: "created", raw: {} })),
    verifyPaymentSignature: vi.fn(async ({ signature }) => {
      return signature === "VALID_SIGNATURE"
        ? { valid: true, providerPaymentId: "pay_mock_1" }
        : { valid: false, failureReason: "Signature mismatch" };
    }),
  },
}));

const { createPaymentOrder, confirmPayment } = await import("../payment.service.js");

describe("createPaymentOrder", () => {
  beforeEach(() => vi.clearAllMocks());

  it("returns the existing order instead of creating a duplicate for a repeated idempotency key", async () => {
    const existingOrder = { id: "order-1", idempotencyKey: "key-abc" };
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce(existingOrder);

    const result = await createPaymentOrder({ invoiceId: "inv-1", patientId: "pat-1", idempotencyKey: "key-abc" });

    expect(result).toBe(existingOrder);
    expect(mockPrisma.invoice.findUnique).not.toHaveBeenCalled(); // short-circuited before touching the invoice
    expect(mockPrisma.paymentOrder.create).not.toHaveBeenCalled();
  });

  it("refuses to create an order for an already-PAID invoice", async () => {
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce(null);
    mockPrisma.invoice.findUnique.mockResolvedValueOnce({
      id: "inv-1",
      patientId: "pat-1",
      status: "PAID",
      balanceDue: 0,
    });

    await expect(
      createPaymentOrder({ invoiceId: "inv-1", patientId: "pat-1", idempotencyKey: "key-xyz" })
    ).rejects.toMatchObject({ code: "CONFLICT" });
  });
});

describe("confirmPayment", () => {
  beforeEach(() => vi.clearAllMocks());

  it("never marks a payment SUCCESS when the provider signature is invalid", async () => {
    mockPrisma.paymentAttempt.findUnique.mockResolvedValueOnce({
      id: "attempt-1",
      paymentOrderId: "order-1",
      status: "INITIATED",
      method: "UPI",
      payment: null,
    });

    await expect(
      confirmPayment({
        paymentOrderId: "order-1",
        paymentAttemptId: "attempt-1",
        providerOrderId: "order_mock_1",
        providerPaymentId: "pay_mock_1",
        providerSignature: "FORGED_SIGNATURE",
      })
    ).rejects.toMatchObject({ code: "VALIDATION_ERROR" });

    expect(mockPrisma.payment.create).not.toHaveBeenCalled();
    expect(mockPrisma.paymentOrder.update).not.toHaveBeenCalled();
    expect(mockPrisma.invoice.update).not.toHaveBeenCalled();
  });

  it("is idempotent: re-confirming an already-SUCCESS attempt returns the existing payment without re-writing state", async () => {
    const existingPayment = { id: "payment-1", status: "SUCCESS" };
    mockPrisma.paymentAttempt.findUnique.mockResolvedValueOnce({
      id: "attempt-1",
      paymentOrderId: "order-1",
      status: "SUCCESS",
      method: "UPI",
      payment: existingPayment,
    });

    const result = await confirmPayment({
      paymentOrderId: "order-1",
      paymentAttemptId: "attempt-1",
      providerOrderId: "order_mock_1",
      providerPaymentId: "pay_mock_1",
      providerSignature: "VALID_SIGNATURE",
    });

    expect(result).toBe(existingPayment);
    expect(mockPrisma.payment.create).not.toHaveBeenCalled(); // no duplicate Payment row created
  });

  it("marks the invoice PAID and zeroes balanceDue when the verified amount covers it in full", async () => {
    mockPrisma.paymentAttempt.findUnique.mockResolvedValueOnce({
      id: "attempt-1",
      paymentOrderId: "order-1",
      status: "INITIATED",
      method: "UPI",
      payment: null,
    });
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce({
      id: "order-1",
      invoiceId: "inv-1",
      status: "ATTEMPTED",
      amount: 500,
      currency: "INR",
    });
    mockPrisma.payment.create.mockResolvedValueOnce({ id: "payment-1", status: "SUCCESS" });
    mockPrisma.invoice.findUnique.mockResolvedValueOnce({
      id: "inv-1",
      amountPaid: 0,
      grandTotal: 500,
      paidAt: null,
    });

    await confirmPayment({
      paymentOrderId: "order-1",
      paymentAttemptId: "attempt-1",
      providerOrderId: "order_mock_1",
      providerPaymentId: "pay_mock_1",
      providerSignature: "VALID_SIGNATURE",
    });

    expect(mockPrisma.invoice.update).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { id: "inv-1" },
        data: expect.objectContaining({ status: "PAID", balanceDue: 0 }),
      })
    );
  });

  it("gracefully returns the already-created payment when a concurrent confirmation races and loses the DB unique-constraint check", async () => {
    // Simulates two concurrent confirmPayment calls for the same attempt
    // (e.g. frontend confirm + webhook racing). The DB's UNIQUE constraint on
    // Payment.paymentAttemptId is what actually stops a duplicate row; this
    // test verifies the losing call surfaces the winner's payment instead of
    // an unhandled Prisma P2002 error — see PAYMENT_FINAL_VERIFICATION_GATE.md §14.
    mockPrisma.paymentAttempt.findUnique.mockResolvedValueOnce({
      id: "attempt-1",
      paymentOrderId: "order-1",
      status: "INITIATED", // both racing transactions observe this before either commits
      method: "UPI",
      payment: null,
    });
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce({
      id: "order-1",
      invoiceId: "inv-1",
      status: "ATTEMPTED",
      amount: 500,
      currency: "INR",
    });

    const uniqueConstraintError = Object.assign(new Error("Unique constraint failed"), {
      code: "P2002",
      meta: { target: ["paymentAttemptId"] },
    });
    mockPrisma.payment.create.mockRejectedValueOnce(uniqueConstraintError);

    const winnerPayment = { id: "payment-from-winning-transaction", status: "SUCCESS" };
    // The regression fix re-fetches by paymentAttemptId outside the failed transaction.
    mockPrisma.payment.findUnique = vi.fn().mockResolvedValueOnce(winnerPayment);

    const result = await confirmPayment({
      paymentOrderId: "order-1",
      paymentAttemptId: "attempt-1",
      providerOrderId: "order_mock_1",
      providerPaymentId: "pay_mock_1",
      providerSignature: "VALID_SIGNATURE",
    });

    expect(result).toBe(winnerPayment);
    expect(mockPrisma.payment.findUnique).toHaveBeenCalledWith({ where: { paymentAttemptId: "attempt-1" } });
  });

  it("re-throws a P2002 on a different constraint without swallowing it (only paymentAttemptId races are treated as idempotent)", async () => {
    mockPrisma.paymentAttempt.findUnique.mockResolvedValueOnce({
      id: "attempt-1",
      paymentOrderId: "order-1",
      status: "INITIATED",
      method: "UPI",
      payment: null,
    });
    mockPrisma.paymentOrder.findUnique.mockResolvedValueOnce({
      id: "order-1",
      invoiceId: "inv-1",
      status: "ATTEMPTED",
      amount: 500,
      currency: "INR",
    });

    const unrelatedConstraintError = Object.assign(new Error("Unique constraint failed"), {
      code: "P2002",
      meta: { target: ["providerPaymentId"] },
    });
    mockPrisma.payment.create.mockRejectedValueOnce(unrelatedConstraintError);

    await expect(
      confirmPayment({
        paymentOrderId: "order-1",
        paymentAttemptId: "attempt-1",
        providerOrderId: "order_mock_1",
        providerPaymentId: "pay_mock_1",
        providerSignature: "VALID_SIGNATURE",
      })
    ).rejects.toBe(unrelatedConstraintError);
  });
});
