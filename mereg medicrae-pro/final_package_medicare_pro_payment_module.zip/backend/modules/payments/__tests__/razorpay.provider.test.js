import { describe, it, expect, beforeEach } from "vitest";
import crypto from "node:crypto";
import { RazorpayProvider } from "../providers/razorpay.provider.js";

const KEY_SECRET = "test_key_secret_for_unit_tests_only";
const WEBHOOK_SECRET = "test_webhook_secret_for_unit_tests_only";

describe("RazorpayProvider.verifyPaymentSignature", () => {
  let provider;
  beforeEach(() => {
    provider = new RazorpayProvider({ keyId: "rzp_test_fake", keySecret: KEY_SECRET });
  });

  it("accepts a correctly computed order_id|payment_id HMAC", async () => {
    const orderId = "order_ABC123";
    const paymentId = "pay_XYZ789";
    const signature = crypto.createHmac("sha256", KEY_SECRET).update(`${orderId}|${paymentId}`).digest("hex");

    const result = await provider.verifyPaymentSignature({ orderId, paymentId, signature });
    expect(result.valid).toBe(true);
    expect(result.providerPaymentId).toBe(paymentId);
  });

  it("rejects a tampered signature", async () => {
    const orderId = "order_ABC123";
    const paymentId = "pay_XYZ789";
    const wrongSignature = crypto.createHmac("sha256", "wrong_secret").update(`${orderId}|${paymentId}`).digest("hex");

    const result = await provider.verifyPaymentSignature({ orderId, paymentId, signature: wrongSignature });
    expect(result.valid).toBe(false);
  });

  it("rejects when the signature was computed for a different payment_id (replay across payments)", async () => {
    const orderId = "order_ABC123";
    const signatureForOtherPayment = crypto
      .createHmac("sha256", KEY_SECRET)
      .update(`${orderId}|pay_DIFFERENT`)
      .digest("hex");

    const result = await provider.verifyPaymentSignature({
      orderId,
      paymentId: "pay_XYZ789",
      signature: signatureForOtherPayment,
    });
    expect(result.valid).toBe(false);
  });

  it("rejects when required fields are missing", async () => {
    const result = await provider.verifyPaymentSignature({ orderId: "order_ABC123" });
    expect(result.valid).toBe(false);
  });

  it("throws PAYMENT_PROVIDER_NOT_CONFIGURED when keys are absent", async () => {
    const unconfigured = new RazorpayProvider({ keyId: undefined, keySecret: undefined });
    await expect(
      unconfigured.verifyPaymentSignature({ orderId: "o", paymentId: "p", signature: "s" })
    ).rejects.toMatchObject({ code: "PAYMENT_PROVIDER_NOT_CONFIGURED" });
  });
});

describe("RazorpayProvider.verifyWebhookSignature", () => {
  let provider;
  beforeEach(() => {
    provider = new RazorpayProvider({
      keyId: "rzp_test_fake",
      keySecret: KEY_SECRET,
      webhookSecret: WEBHOOK_SECRET,
    });
  });

  it("accepts a correctly signed raw body and parses the payload", () => {
    const payload = { event: "payment.captured", payload: { payment: { entity: { id: "pay_1" } } } };
    const rawBody = Buffer.from(JSON.stringify(payload));
    const signature = crypto.createHmac("sha256", WEBHOOK_SECRET).update(rawBody).digest("hex");

    const result = provider.verifyWebhookSignature(rawBody, signature);
    expect(result.valid).toBe(true);
    expect(result.eventType).toBe("payment.captured");
  });

  it("rejects a re-serialized body even with the same logical content (raw-bytes requirement)", () => {
    const original = { b: 2, a: 1 };
    const rawBody = Buffer.from(JSON.stringify(original));
    const signature = crypto.createHmac("sha256", WEBHOOK_SECRET).update(rawBody).digest("hex");

    // Same object, different key order -> different byte sequence -> different HMAC.
    const reserialized = Buffer.from(JSON.stringify({ a: 1, b: 2 }));
    const result = provider.verifyWebhookSignature(reserialized, signature);
    expect(result.valid).toBe(false);
  });

  it("rejects when the webhook secret is not configured", () => {
    const noSecret = new RazorpayProvider({ keyId: "x", keySecret: KEY_SECRET, webhookSecret: undefined });
    const rawBody = Buffer.from(JSON.stringify({ event: "payment.captured" }));
    const result = noSecret.verifyWebhookSignature(rawBody, "any-signature");
    expect(result.valid).toBe(false);
  });

  it("rejects a missing signature header", () => {
    const rawBody = Buffer.from(JSON.stringify({ event: "payment.captured" }));
    const result = provider.verifyWebhookSignature(rawBody, undefined);
    expect(result.valid).toBe(false);
  });
});
