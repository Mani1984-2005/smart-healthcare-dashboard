// Closes the gap flagged consistently since PAYMENT_FINAL_VERIFICATION_GATE.md:
// "refund.service.js itself has no dedicated unit test file." Mocked Prisma/
// provider — no live database (none reachable, see PAYMENT_MODULE_HANDOFF.md).

import { describe, it, expect, vi, beforeEach } from "vitest";

const mockPrisma = {
  payment: { findUnique: vi.fn(), update: vi.fn() },
  refund: { findUnique: vi.fn(), findMany: vi.fn(), create: vi.fn(), update: vi.fn() },
  paymentAuditLog: { create: vi.fn() },
  $transaction: vi.fn(async (fn) => fn(mockPrisma)),
};

vi.mock("../../../src/lib/prisma.js", () => ({ prisma: mockPrisma }));

vi.mock("../providers/razorpay.provider.js", () => ({
  razorpayProvider: {
    createRefund: vi.fn(async ({ amount }) => ({
      providerRefundId: "rfnd_mock_1",
      status: "processed",
      raw: { amount },
    })),
  },
}));

const { razorpayProvider } = await import("../providers/razorpay.provider.js");
const { initiateRefund, markRefundProcessed, markRefundFailed } = await import("../refund.service.js");

describe("initiateRefund", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rejects refunding a nonexistent payment", async () => {
    mockPrisma.payment.findUnique.mockResolvedValueOnce(null);
    await expect(initiateRefund({ paymentId: "missing", initiatedById: "staff-1" })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });

  it("rejects refunding a payment that isn't SUCCESS or PARTIALLY_REFUNDED", async () => {
    mockPrisma.payment.findUnique.mockResolvedValueOnce({ id: "p1", status: "FAILED", amount: 500, refunds: [] });
    await expect(initiateRefund({ paymentId: "p1", initiatedById: "staff-1" })).rejects.toMatchObject({
      code: "CONFLICT",
    });
    expect(razorpayProvider.createRefund).not.toHaveBeenCalled(); // never reaches the provider for an invalid payment
  });

  it("defaults to a full refund of the remaining balance when no amount is supplied", async () => {
    mockPrisma.payment.findUnique.mockResolvedValueOnce({
      id: "p1",
      status: "SUCCESS",
      amount: 500,
      providerPaymentId: "pay_1",
      refunds: [],
    });
    mockPrisma.refund.create.mockResolvedValueOnce({ id: "refund-1", amount: 500, status: "PENDING" });

    await initiateRefund({ paymentId: "p1", initiatedById: "staff-1" });

    expect(razorpayProvider.createRefund).toHaveBeenCalledWith(
      expect.objectContaining({ providerPaymentId: "pay_1", amount: 500 })
    );
  });

  it("computes the correct remaining balance for a partial refund on top of an already-partially-refunded payment", async () => {
    mockPrisma.payment.findUnique.mockResolvedValueOnce({
      id: "p1",
      status: "PARTIALLY_REFUNDED",
      amount: 500,
      providerPaymentId: "pay_1",
      refunds: [{ status: "PROCESSED", amount: 200 }],
    });
    mockPrisma.refund.create.mockResolvedValueOnce({ id: "refund-2", amount: 100, status: "PENDING" });

    await initiateRefund({ paymentId: "p1", amount: 100, initiatedById: "staff-1" });

    expect(razorpayProvider.createRefund).toHaveBeenCalledWith(expect.objectContaining({ amount: 100 }));
  });

  it("rejects a refund amount of zero or negative", async () => {
    mockPrisma.payment.findUnique.mockResolvedValueOnce({
      id: "p1",
      status: "SUCCESS",
      amount: 500,
      providerPaymentId: "pay_1",
      refunds: [],
    });
    await expect(
      initiateRefund({ paymentId: "p1", amount: 0, initiatedById: "staff-1" })
    ).rejects.toMatchObject({ code: "VALIDATION_ERROR" });
    expect(razorpayProvider.createRefund).not.toHaveBeenCalled();
  });

  it("rejects a refund amount exceeding the remaining refundable balance — cannot over-refund", async () => {
    mockPrisma.payment.findUnique.mockResolvedValueOnce({
      id: "p1",
      status: "SUCCESS",
      amount: 500,
      providerPaymentId: "pay_1",
      refunds: [{ status: "PROCESSED", amount: 400 }],
    });
    await expect(
      initiateRefund({ paymentId: "p1", amount: 200, initiatedById: "staff-1" }) // 400 + 200 > 500
    ).rejects.toMatchObject({ code: "VALIDATION_ERROR" });
    expect(razorpayProvider.createRefund).not.toHaveBeenCalled(); // validated before ever calling the provider
  });

  it("ignores non-PROCESSED refunds when computing the already-refunded total", async () => {
    mockPrisma.payment.findUnique.mockResolvedValueOnce({
      id: "p1",
      status: "SUCCESS",
      amount: 500,
      providerPaymentId: "pay_1",
      // A FAILED refund attempt for 400 must not count against the refundable balance.
      refunds: [{ status: "FAILED", amount: 400 }],
    });
    mockPrisma.refund.create.mockResolvedValueOnce({ id: "refund-1", amount: 500, status: "PENDING" });

    await initiateRefund({ paymentId: "p1", initiatedById: "staff-1" }); // should succeed, full 500 still available

    expect(razorpayProvider.createRefund).toHaveBeenCalledWith(expect.objectContaining({ amount: 500 }));
  });

  it("writes a REFUND_INITIATED audit log entry", async () => {
    mockPrisma.payment.findUnique.mockResolvedValueOnce({
      id: "p1",
      status: "SUCCESS",
      amount: 500,
      providerPaymentId: "pay_1",
      refunds: [],
    });
    mockPrisma.refund.create.mockResolvedValueOnce({ id: "refund-1", amount: 500, status: "PENDING" });

    await initiateRefund({ paymentId: "p1", initiatedById: "staff-1", reason: "patient requested" });

    expect(mockPrisma.paymentAuditLog.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ action: "REFUND_INITIATED", actorId: "staff-1" }),
      })
    );
  });
});

describe("markRefundProcessed", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rejects a nonexistent refund", async () => {
    mockPrisma.refund.findUnique.mockResolvedValueOnce(null);
    await expect(markRefundProcessed({ refundId: "missing" })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("is idempotent: re-processing an already-PROCESSED refund returns it unchanged without re-updating Payment", async () => {
    const alreadyProcessed = { id: "refund-1", status: "PROCESSED", payment: { id: "p1" } };
    mockPrisma.refund.findUnique.mockResolvedValueOnce(alreadyProcessed);

    const result = await markRefundProcessed({ refundId: "refund-1" });

    expect(result).toBe(alreadyProcessed);
    expect(mockPrisma.payment.update).not.toHaveBeenCalled();
  });

  it("marks the Payment REFUNDED (not PARTIALLY_REFUNDED) when the total processed refunds cover the full amount", async () => {
    mockPrisma.refund.findUnique.mockResolvedValueOnce({
      id: "refund-1",
      status: "PENDING",
      amount: 500,
      payment: { id: "p1", status: "SUCCESS", amount: 500 },
    });
    mockPrisma.refund.update.mockResolvedValueOnce({ id: "refund-1", status: "PROCESSED" });
    mockPrisma.refund.findMany.mockResolvedValueOnce([]); // no other already-processed refunds

    await markRefundProcessed({ refundId: "refund-1", providerRefundId: "rfnd_1" });

    expect(mockPrisma.payment.update).toHaveBeenCalledWith(
      expect.objectContaining({ where: { id: "p1" }, data: { status: "REFUNDED" } })
    );
  });

  it("marks the Payment PARTIALLY_REFUNDED when processed refunds don't yet cover the full amount", async () => {
    mockPrisma.refund.findUnique.mockResolvedValueOnce({
      id: "refund-2",
      status: "PENDING",
      amount: 100,
      payment: { id: "p1", status: "SUCCESS", amount: 500 },
    });
    mockPrisma.refund.update.mockResolvedValueOnce({ id: "refund-2", status: "PROCESSED" });
    mockPrisma.refund.findMany.mockResolvedValueOnce([]); // this is the only processed refund so far

    await markRefundProcessed({ refundId: "refund-2" });

    expect(mockPrisma.payment.update).toHaveBeenCalledWith(
      expect.objectContaining({ where: { id: "p1" }, data: { status: "PARTIALLY_REFUNDED" } })
    );
  });

  it("rejects an invalid refund status transition (e.g. an already-FAILED refund cannot become PROCESSED)", async () => {
    mockPrisma.refund.findUnique.mockResolvedValueOnce({
      id: "refund-1",
      status: "FAILED",
      payment: { id: "p1", status: "SUCCESS", amount: 500 },
    });
    await expect(markRefundProcessed({ refundId: "refund-1" })).rejects.toMatchObject({
      code: "INVALID_STATE_TRANSITION",
    });
  });
});

describe("markRefundFailed", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rejects a nonexistent refund", async () => {
    mockPrisma.refund.findUnique.mockResolvedValueOnce(null);
    await expect(markRefundFailed({ refundId: "missing", reason: "x" })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });

  it("marks a PENDING refund FAILED and persists the reason to the audit trail", async () => {
    mockPrisma.refund.findUnique.mockResolvedValueOnce({ id: "refund-1", status: "PENDING" });
    mockPrisma.refund.update.mockResolvedValueOnce({ id: "refund-1", status: "FAILED" });

    await markRefundFailed({ refundId: "refund-1", reason: "provider declined" });

    expect(mockPrisma.refund.update).toHaveBeenCalledWith(
      expect.objectContaining({ where: { id: "refund-1" }, data: { status: "FAILED" } })
    );
    // Regression check for the lint fix in PAYMENT_MODULE_CLOSURE_REPORT.md §6:
    // `reason` must actually be used, not silently discarded.
    expect(mockPrisma.paymentAuditLog.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ action: "REFUND_FAILED", metadata: { reason: "provider declined" } }),
      })
    );
  });

  it("rejects marking an already-PROCESSED refund as FAILED (terminal state)", async () => {
    mockPrisma.refund.findUnique.mockResolvedValueOnce({ id: "refund-1", status: "PROCESSED" });
    await expect(markRefundFailed({ refundId: "refund-1", reason: "x" })).rejects.toMatchObject({
      code: "INVALID_STATE_TRANSITION",
    });
  });
});
