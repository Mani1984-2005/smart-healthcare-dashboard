import { describe, it, expect } from "vitest";
import {
  assertValidTransition,
  InvalidTransitionError,
  PAYMENT_ORDER_TRANSITIONS,
  PAYMENT_ATTEMPT_TRANSITIONS,
  PAYMENT_TRANSITIONS,
  REFUND_TRANSITIONS,
} from "../payment.constants.js";

describe("payment state machine", () => {
  it("allows CREATED -> ATTEMPTED -> PAID for a PaymentOrder", () => {
    expect(() => assertValidTransition("PaymentOrder", PAYMENT_ORDER_TRANSITIONS, "CREATED", "ATTEMPTED")).not.toThrow();
    expect(() => assertValidTransition("PaymentOrder", PAYMENT_ORDER_TRANSITIONS, "ATTEMPTED", "PAID")).not.toThrow();
  });

  it("rejects PAID -> ATTEMPTED (a paid order can never be reopened)", () => {
    expect(() => assertValidTransition("PaymentOrder", PAYMENT_ORDER_TRANSITIONS, "PAID", "ATTEMPTED")).toThrow(
      InvalidTransitionError
    );
  });

  it("allows multiple failed attempts before one succeeds (brief section 11)", () => {
    // Attempt 1: INITIATED -> FAILED
    expect(() => assertValidTransition("PaymentAttempt", PAYMENT_ATTEMPT_TRANSITIONS, "INITIATED", "FAILED")).not.toThrow();
    // Order stays ATTEMPTED and accepts a new attempt (order-level transition ATTEMPTED -> ATTEMPTED is a no-op)
    expect(() => assertValidTransition("PaymentOrder", PAYMENT_ORDER_TRANSITIONS, "ATTEMPTED", "ATTEMPTED")).not.toThrow();
    // Attempt 3: INITIATED -> SUCCESS
    expect(() => assertValidTransition("PaymentAttempt", PAYMENT_ATTEMPT_TRANSITIONS, "INITIATED", "SUCCESS")).not.toThrow();
  });

  it("rejects a FAILED attempt from being resurrected to SUCCESS", () => {
    expect(() => assertValidTransition("PaymentAttempt", PAYMENT_ATTEMPT_TRANSITIONS, "FAILED", "SUCCESS")).toThrow(
      InvalidTransitionError
    );
  });

  it("treats a same-state transition as an idempotent no-op (duplicate webhook redelivery)", () => {
    expect(() => assertValidTransition("Payment", PAYMENT_TRANSITIONS, "SUCCESS", "SUCCESS")).not.toThrow();
  });

  it("allows SUCCESS -> PARTIALLY_REFUNDED -> REFUNDED for a Payment", () => {
    expect(() => assertValidTransition("Payment", PAYMENT_TRANSITIONS, "SUCCESS", "PARTIALLY_REFUNDED")).not.toThrow();
    expect(() => assertValidTransition("Payment", PAYMENT_TRANSITIONS, "PARTIALLY_REFUNDED", "REFUNDED")).not.toThrow();
  });

  it("rejects refunding a FAILED payment", () => {
    expect(() => assertValidTransition("Payment", PAYMENT_TRANSITIONS, "FAILED", "REFUNDED")).toThrow(InvalidTransitionError);
  });

  it("rejects re-processing an already-PROCESSED refund into FAILED", () => {
    expect(() => assertValidTransition("Refund", REFUND_TRANSITIONS, "PROCESSED", "FAILED")).toThrow(InvalidTransitionError);
  });

  it("throws for an unknown 'from' state rather than silently allowing it", () => {
    expect(() => assertValidTransition("PaymentOrder", PAYMENT_ORDER_TRANSITIONS, "NOT_A_REAL_STATE", "PAID")).toThrow(
      InvalidTransitionError
    );
  });
});
