// State machines for the payment domain. Every status transition in
// payment.service.js / refund.service.js must go through assertValidTransition()
// below rather than writing a new status directly — this is what "prevent
// invalid transitions" (brief section 10) actually means in code.

export const PAYMENT_ORDER_TRANSITIONS = {
  CREATED: ["ATTEMPTED", "EXPIRED", "CANCELLED"],
  ATTEMPTED: ["PAID", "ATTEMPTED", "EXPIRED", "CANCELLED"], // multiple attempts allowed while unpaid
  PAID: [], // terminal — an Invoice/PaymentOrder is never reopened for payment
  EXPIRED: [],
  CANCELLED: [],
};

export const PAYMENT_ATTEMPT_TRANSITIONS = {
  INITIATED: ["PENDING", "SUCCESS", "FAILED", "CANCELLED"],
  PENDING: ["SUCCESS", "FAILED", "CANCELLED"],
  SUCCESS: [], // terminal
  FAILED: [],
  CANCELLED: [],
};

export const PAYMENT_TRANSITIONS = {
  PENDING: ["PROCESSING", "SUCCESS", "FAILED"],
  PROCESSING: ["SUCCESS", "FAILED"],
  SUCCESS: ["REFUNDED", "PARTIALLY_REFUNDED"],
  FAILED: [], // terminal — a fresh attempt creates a new Payment, this one is never resurrected
  REFUNDED: [],
  PARTIALLY_REFUNDED: ["REFUNDED"], // a second partial/full refund can close it out
};

export const REFUND_TRANSITIONS = {
  PENDING: ["PROCESSED", "FAILED"],
  PROCESSED: [],
  FAILED: [],
};

export class InvalidTransitionError extends Error {
  constructor(entity, from, to) {
    super(`Invalid ${entity} transition: ${from} -> ${to}`);
    this.name = "InvalidTransitionError";
    this.statusCode = 409;
    this.code = "INVALID_STATE_TRANSITION";
  }
}

export function assertValidTransition(entity, table, from, to) {
  const allowed = table[from];
  if (!allowed) throw new InvalidTransitionError(entity, from, to);
  if (from === to) return; // idempotent no-op, e.g. duplicate webhook re-delivering SUCCESS
  if (!allowed.includes(to)) {
    throw new InvalidTransitionError(entity, from, to);
  }
}
