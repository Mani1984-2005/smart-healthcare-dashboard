import { prisma } from "../../src/lib/prisma.js";
import { razorpayProvider } from "./providers/razorpay.provider.js";
import { NotFoundError, ConflictError, ValidationError } from "../../utils/errors.js";
import { assertValidTransition, PAYMENT_TRANSITIONS, REFUND_TRANSITIONS } from "./payment.constants.js";

const provider = razorpayProvider;

function toDecimalNumber(d) {
  return typeof d === "object" && d !== null && "toNumber" in d ? d.toNumber() : Number(d);
}

/**
 * Initiates a refund (full or partial). Requires BILLING/ADMIN role,
 * enforced at the route layer via requireRole — this function assumes the
 * caller has already been authorized and just records who did it.
 */
export async function initiateRefund({ paymentId, amount, reason, initiatedById }) {
  const payment = await prisma.payment.findUnique({
    where: { id: paymentId },
    include: { refunds: true },
  });
  if (!payment) throw new NotFoundError("Payment not found");
  if (payment.status !== "SUCCESS" && payment.status !== "PARTIALLY_REFUNDED") {
    throw new ConflictError(`Cannot refund a payment in status ${payment.status}`);
  }

  const paymentAmount = toDecimalNumber(payment.amount);
  const alreadyRefunded = payment.refunds
    .filter((r) => r.status === "PROCESSED")
    .reduce((sum, r) => sum + toDecimalNumber(r.amount), 0);

  const refundAmount = amount != null ? Number(amount) : paymentAmount - alreadyRefunded;

  if (refundAmount <= 0) {
    throw new ValidationError("Refund amount must be greater than zero");
  }
  if (alreadyRefunded + refundAmount > paymentAmount) {
    throw new ValidationError("Refund amount exceeds remaining refundable balance", {
      paymentAmount,
      alreadyRefunded,
      requested: refundAmount,
    });
  }

  const providerRefund = await provider.createRefund({
    providerPaymentId: payment.providerPaymentId,
    amount: refundAmount,
    reason,
  });

  const refund = await prisma.$transaction(async (tx) => {
    const created = await tx.refund.create({
      data: {
        paymentId: payment.id,
        amount: refundAmount,
        reason,
        status: "PENDING",
        provider: "razorpay",
        providerRefundId: providerRefund.providerRefundId,
        initiatedById,
      },
    });

    await tx.paymentAuditLog.create({
      data: {
        action: "REFUND_INITIATED",
        entityType: "Refund",
        entityId: created.id,
        actorId: initiatedById,
        correlationId: providerRefund.providerRefundId,
        metadata: { paymentId: payment.id, amount: String(refundAmount) },
      },
    });

    return created;
  });

  return refund;
}

/**
 * Called once the provider confirms the refund actually processed (webhook
 * or a status-check call) — mirrors confirmPayment()'s "never trust the
 * initiating call alone" principle.
 */
export async function markRefundProcessed({ refundId, providerRefundId }) {
  return prisma.$transaction(async (tx) => {
    const refund = await tx.refund.findUnique({ where: { id: refundId }, include: { payment: true } });
    if (!refund) throw new NotFoundError("Refund not found");

    if (refund.status === "PROCESSED") return refund; // idempotent re-delivery

    assertValidTransition("Refund", REFUND_TRANSITIONS, refund.status, "PROCESSED");
    const updatedRefund = await tx.refund.update({
      where: { id: refund.id },
      data: { status: "PROCESSED", providerRefundId: providerRefundId ?? refund.providerRefundId },
    });

    const payment = refund.payment;
    const paymentAmount = toDecimalNumber(payment.amount);
    const allRefunds = await tx.refund.findMany({ where: { paymentId: payment.id, status: "PROCESSED" } });
    const totalRefunded = allRefunds.reduce((sum, r) => sum + toDecimalNumber(r.amount), 0) + toDecimalNumber(refund.amount);

    const newPaymentStatus = totalRefunded >= paymentAmount ? "REFUNDED" : "PARTIALLY_REFUNDED";
    assertValidTransition("Payment", PAYMENT_TRANSITIONS, payment.status, newPaymentStatus);
    await tx.payment.update({ where: { id: payment.id }, data: { status: newPaymentStatus } });

    await tx.paymentAuditLog.create({
      data: {
        action: "REFUND_PROCESSED",
        entityType: "Refund",
        entityId: refund.id,
        metadata: { paymentId: payment.id, totalRefunded: String(totalRefunded) },
      },
    });

    return updatedRefund;
  });
}

export async function markRefundFailed({ refundId, reason }) {
  const refund = await prisma.refund.findUnique({ where: { id: refundId } });
  if (!refund) throw new NotFoundError("Refund not found");
  assertValidTransition("Refund", REFUND_TRANSITIONS, refund.status, "FAILED");

  const updated = await prisma.refund.update({ where: { id: refund.id }, data: { status: "FAILED" } });

  // Lint fix (PAYMENT_MODULE_CLOSURE_REPORT.md §6): `reason` was accepted as a
  // parameter but silently discarded — the webhook path passes a real failure
  // reason here and it was being lost. Persisted to the audit trail (not the
  // Refund.reason column, which already holds the original refund-initiation
  // reason and would be overwritten/ambiguous if reused for this) — matching
  // the audit-logging pattern already used by every other transition in this
  // file and in payment.service.js.
  await prisma.paymentAuditLog.create({
    data: {
      action: "REFUND_FAILED",
      entityType: "Refund",
      entityId: refund.id,
      metadata: { reason: reason ?? "Refund failed at provider" },
    },
  });

  return updated;
}
