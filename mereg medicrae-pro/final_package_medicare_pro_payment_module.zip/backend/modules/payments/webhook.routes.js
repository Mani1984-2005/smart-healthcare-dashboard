import express from "express";
import { handleRazorpayWebhook } from "./webhook.controller.js";

const router = express.Router();

// IMPORTANT: this route must be mounted in server.js BEFORE the global
// express.json() body parser reaches it, using express.raw() here so
// req.body is the exact byte sequence Razorpay signed — HMAC verification
// over a re-serialized JSON object would not match.
router.post("/razorpay", express.raw({ type: "application/json" }), handleRazorpayWebhook);

export default router;
