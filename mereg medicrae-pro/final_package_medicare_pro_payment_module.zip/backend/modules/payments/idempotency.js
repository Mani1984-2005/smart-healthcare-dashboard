// Idempotency helpers.
//
// The actual enforcement lives in the DB: PaymentOrder.idempotencyKey is a
// UNIQUE column, and WebhookEvent.providerEventId is a UNIQUE column. This
// file just standardizes how keys are derived and how "already exists" DB
// errors are turned into a clean re-fetch instead of a 500.

import crypto from "node:crypto";
import { ConflictError } from "../../utils/errors.js";

// Client-supplied idempotency key (from the "Pay Now" button / Idempotency-Key
// header) if present, else a deterministic fallback derived from
// invoice + patient + a per-request nonce the caller must still vary on retry.
// We deliberately do NOT derive a key purely from invoiceId, because a patient
// legitimately re-paying after a prior order EXPIRED must be able to create a
// new order for the same invoice.
export function resolveIdempotencyKey(req) {
  const headerKey = req.headers["idempotency-key"];
  if (headerKey && typeof headerKey === "string" && headerKey.trim().length > 0) {
    return headerKey.trim();
  }
  // No client-supplied key: safe default is a fresh key per request, i.e. no
  // dedup guarantee for that specific call. Callers that care about
  // double-click protection (the patient-facing "Pay Now" flow) must send the
  // header; this fallback only prevents the endpoint from crashing.
  return crypto.randomUUID();
}

// Prisma throws P2002 (unique constraint violation) on a duplicate
// idempotency key or duplicate webhook event id. This turns that into a
// well-typed, callable-friendly error/result instead of a generic 500.
export async function runIdempotently(fn) {
  try {
    return await fn();
  } catch (err) {
    if (err?.code === "P2002") {
      throw new ConflictError(
        "A request with this idempotency key has already been processed.",
        { prismaTarget: err.meta?.target }
      );
    }
    throw err;
  }
}
