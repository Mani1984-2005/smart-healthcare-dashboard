// PaymentProvider contract. Any gateway adapter (Razorpay today, Stripe or
// others in future) must implement this shape so payment.service.js never
// depends on a specific provider's SDK directly.
//
//   PaymentService -> PaymentProvider (this contract) -> ProviderAdapter -> Gateway
//
// This is intentionally minimal: only what the current flows in this module
// actually call. Extend it deliberately, not speculatively.

/**
 * @typedef {Object} CreateOrderResult
 * @property {string} providerOrderId
 * @property {string} status
 * @property {Record<string, any>} raw - full provider response, for audit only
 */

/**
 * @typedef {Object} VerifyPaymentResult
 * @property {boolean} valid
 * @property {string} [providerPaymentId]
 * @property {string} [failureReason]
 */

/**
 * @typedef {Object} RefundResult
 * @property {string} providerRefundId
 * @property {string} status
 * @property {Record<string, any>} raw
 */

/**
 * @typedef {Object} WebhookVerificationResult
 * @property {boolean} valid
 * @property {string} [eventId]
 * @property {string} [eventType]
 * @property {Record<string, any>} [payload]
 */

export class PaymentProvider {
  /** @returns {Promise<CreateOrderResult>} */
  async createOrder(/* { amount, currency, receipt, notes } */) {
    throw new Error("createOrder() not implemented");
  }

  /** @returns {Promise<VerifyPaymentResult>} */
  async verifyPaymentSignature(/* { orderId, paymentId, signature } */) {
    throw new Error("verifyPaymentSignature() not implemented");
  }

  /** @returns {Promise<RefundResult>} */
  async createRefund(/* { providerPaymentId, amount, reason } */) {
    throw new Error("createRefund() not implemented");
  }

  /** @returns {WebhookVerificationResult} */
  verifyWebhookSignature(/* rawBody, signatureHeader */) {
    throw new Error("verifyWebhookSignature() not implemented");
  }
}
