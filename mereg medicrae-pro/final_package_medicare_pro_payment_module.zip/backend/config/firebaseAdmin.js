// P0 FIX (PAYMENT_FINAL_VERIFICATION_GATE.md §3 / §16): the installed
// firebase-admin version (14.1.0) does not expose the old namespaced API this
// file was originally written against (`admin.credential.cert`, `admin.apps`,
// `admin.initializeApp` as properties of a default-exported `admin` object —
// that shape belongs to firebase-admin v8 and earlier). Confirmed by actually
// importing the installed package: `admin.credential`, `admin.auth`, and
// `admin.apps` are all `undefined` on firebase-admin@14.1.0's default export;
// it only exposes the flat modular API. This means authentication could NEVER
// have worked in this repository — with or without real credentials, before
// or after any Payment-module change — until this was fixed. Found by
// actually running `node server.js` with placeholder env vars, not assumed.
import { initializeApp, cert, getApps } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";

const {
  FIREBASE_PROJECT_ID,
  FIREBASE_CLIENT_EMAIL,
  FIREBASE_PRIVATE_KEY,
} = process.env;

if (!FIREBASE_PROJECT_ID || !FIREBASE_CLIENT_EMAIL || !FIREBASE_PRIVATE_KEY) {
  console.error(
    "Firebase Admin: Missing required environment variables. " +
      "Ensure FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, and FIREBASE_PRIVATE_KEY are set."
  );

  throw new Error("Missing Firebase Admin environment variables");
}

// Initialise only once
let app;
if (!getApps().length) {
  app = initializeApp({
    credential: cert({
      projectId: FIREBASE_PROJECT_ID,
      clientEmail: FIREBASE_CLIENT_EMAIL,
      privateKey: FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n"),
    }),
  });

  console.log("Firebase Admin SDK initialised");
} else {
  app = getApps()[0];
}

// authMiddleware.js imports this default export and calls `.auth()` on it —
// kept as a thin shim around the modular getAuth() so that call site didn't
// need a second, separate fix (its usage pattern, `admin.auth().verifyIdToken`,
// is otherwise correct and unrelated to this bug).
const admin = { auth: () => getAuth(app) };

export default admin;