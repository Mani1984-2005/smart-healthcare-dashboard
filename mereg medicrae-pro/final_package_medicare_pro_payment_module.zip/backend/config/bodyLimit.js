// Single source of truth for the JSON body-size limit, applied globally in
// server.js. Extracted to its own module (rather than an inline string
// literal in server.js) so tests can exercise the exact same value instead
// of duplicating/guessing it — see routes/__tests__/bodyLimit.test.js.
//
// Chosen deliberately rather than relying on Express's undocumented-in-our-
// code default (100kb): every payload this API actually accepts is small —
// Payment/Billing request bodies are IDs, amounts, and short strings (at
// most a few KB even for an invoice with many line items); the largest
// legitimate body in the repo is a Razorpay webhook payload, which is also
// well under this limit. 256kb leaves generous headroom for legitimate use
// while still bounding request size against oversized-payload abuse.
export const JSON_BODY_LIMIT = "256kb";
