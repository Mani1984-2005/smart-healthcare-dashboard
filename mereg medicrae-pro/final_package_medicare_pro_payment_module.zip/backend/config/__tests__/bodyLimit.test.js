// Closes the "oversized-payload verification: NOT EXECUTED" gap flagged in
// PAYMENT_MODULE_HANDOFF.md and every prior closure report. This is a real
// HTTP-level test (via supertest, an actual request/response round trip
// through Express's body-parser and the real errorHandler) — not mocked —
// exercising the EXACT middleware configuration server.js uses
// (express.json({ limit: JSON_BODY_LIMIT }) followed by errorHandler),
// built as a minimal standalone app so it doesn't require the full
// server.js import graph (which cannot load without a generated Prisma
// client — see PAYMENT_FINAL_VERIFICATION_GATE.md §16). The body-parser and
// error-handling code under test here is the real, unmodified production
// code from config/bodyLimit.js and utils/errors.js, not a re-implementation.

import { describe, it, expect } from "vitest";
import express from "express";
import request from "supertest";
import { JSON_BODY_LIMIT } from "../bodyLimit.js";
import { errorHandler, asyncHandler } from "../../utils/errors.js";

function buildTestApp() {
  const app = express();
  app.use(express.json({ limit: JSON_BODY_LIMIT }));
  app.post(
    "/echo",
    asyncHandler(async (req, res) => {
      res.status(200).json({ success: true, data: req.body });
    })
  );
  app.use(errorHandler);
  return app;
}

describe("JSON body-size limit — real HTTP round trip", () => {
  it("accepts a normal-sized payment-confirmation-shaped payload", async () => {
    const app = buildTestApp();
    const normalPayload = {
      paymentOrderId: "11111111-1111-4111-8111-111111111111",
      paymentAttemptId: "22222222-2222-4222-8222-222222222222",
      providerOrderId: "order_abc123",
      providerPaymentId: "pay_abc123",
      providerSignature: "a".repeat(64), // realistic HMAC-hex length
    };

    const res = await request(app).post("/echo").send(normalPayload);

    expect(res.status).toBe(200);
    expect(res.body.data).toEqual(normalPayload);
  });

  it("rejects a payload larger than the configured limit with 413, not a crash or a generic 500", async () => {
    const app = buildTestApp();
    // JSON_BODY_LIMIT is "256kb" — send meaningfully more than that.
    const oversizedPayload = { junk: "x".repeat(400 * 1024) };

    const res = await request(app).post("/echo").send(oversizedPayload);

    expect(res.status).toBe(413);
    expect(res.body).toMatchObject({ success: false, error: { code: "PAYLOAD_TOO_LARGE" } });
    // Must not leak body-parser's internal error message/stack.
    expect(JSON.stringify(res.body)).not.toMatch(/request entity too large/i);
    expect(JSON.stringify(res.body)).not.toContain("at ");
  });

  it("accepts a payload right at the boundary and rejects one just over it", async () => {
    const app = buildTestApp();

    // ~250kb of actual content, comfortably under the 256kb limit once JSON
    // framing overhead is added.
    const underLimit = { data: "y".repeat(250 * 1024) };
    const resUnder = await request(app).post("/echo").send(underLimit);
    expect(resUnder.status).toBe(200);

    // Comfortably over.
    const overLimit = { data: "y".repeat(300 * 1024) };
    const resOver = await request(app).post("/echo").send(overLimit);
    expect(resOver.status).toBe(413);
  });

  it("rejects malformed JSON with 400, not a crash or a generic 500", async () => {
    const app = buildTestApp();

    const res = await request(app)
      .post("/echo")
      .set("Content-Type", "application/json")
      .send('{"paymentOrderId": "unterminated string, missing brace');

    expect(res.status).toBe(400);
    expect(res.body).toMatchObject({ success: false, error: { code: "MALFORMED_JSON" } });
    expect(JSON.stringify(res.body)).not.toContain("at "); // no stack trace leak
  });

  it("does not log a real unhandled-error entry for these expected client-error cases", async () => {
    // Regression guard for the errorHandler fix: PayloadTooLargeError and the
    // JSON parse SyntaxError must be classified as KNOWN errors, not fall
    // through to the "[UNHANDLED ERROR]" console.error branch reserved for
    // genuinely unexpected failures.
    const app = buildTestApp();
    const consoleSpy = { called: false };
    const originalError = console.error;
    console.error = (...args) => {
      if (String(args[0]).includes("[UNHANDLED ERROR]")) consoleSpy.called = true;
    };

    try {
      await request(app).post("/echo").send({ junk: "x".repeat(400 * 1024) });
      await request(app).post("/echo").set("Content-Type", "application/json").send("{not valid json");
    } finally {
      console.error = originalError;
    }

    expect(consoleSpy.called).toBe(false);
  });
});
