# Payment Module — Integration Compatibility Audit

**Type:** Read-only audit. No production code was modified to produce this report.
**Scope:** Comparison of the Payment module (backend/modules/payments, rebuilt
backend/controllers/billing.controller.js + billing routes, and the new frontend payment
UI/stores/services) against the rest of the actual MediCare Pro repository as it exists on disk.

Classification key used throughout: **SAFE** / **COMPATIBLE** (integration required later) /
**DUPLICATE** (existing implementation overlaps) / **CONFLICT** (implementations disagree) /
**BLOCKED** (infrastructure prevents verification) / **UNKNOWN** (insufficient evidence).

---

## 1. Billing Duplication

| Item | Finding | Classification |
|---|---|---|
| Invoice/Billing model | `backend/models/Billing.js` is a **Mongoose** schema with a field set that closely mirrors the new Prisma `Invoice` model (`invoiceNumber`, `patientId`, `items[]`, `subtotal`, `discount`, `tax`, `grandTotal`, `amountPaid`, `balanceDue`, `status`, `billingDate`, `paidAt`). It is never wired to a live database — a repo-wide search finds no `mongoose.connect(...)` call anywhere — so it is inert at runtime, but it is source-level duplication of the same concept. | **DUPLICATE** (dormant) |
| Payment/transaction model | No pre-existing Payment or Transaction model of any kind was found anywhere in the repo (Mongoose, raw SQL, or otherwise) prior to this module. | **SAFE** |
| Billing controller | `backend/controllers/billing.controller.js` was fully replaced (not duplicated) in an earlier session — the original 6 handlers were stub placeholders (`res.json({ message: "..." })`) with no persistence. One live implementation exists now. | **SAFE** |
| Billing routes | `backend/routes/billingRoutes.js` — same story, one live implementation, no duplicate route table. | **SAFE** |
| Payment routes/services | No pre-existing equivalent existed anywhere. | **SAFE** |
| Receipt generation | **Not found anywhere in the repository** — no code, no library, no route. | **SAFE**, but see §7 — the audit brief's premise that this already exists does not match the repo. |
| PDF invoice generation | **Not found anywhere.** Neither `package.json` (root or `backend/`) lists any PDF library (`jspdf`, `pdfkit`, `puppeteer`, `pdfmake`, `react-pdf` — all absent). | **SAFE**, same caveat as above. |
| Outstanding-balance logic | The old stub controller had none. The rebuilt `billing.controller.js` and `payment.service.js` are the only place this is computed. | **SAFE** |
| **Frontend service duplication** | `src/services/billingService.js` (pre-existing, predates this engagement) defines `fetchInvoices`, `fetchInvoiceById`, `createInvoice`, `updateInvoice` against the **exact same** `/billing/invoices*` endpoints that the new `src/services/paymentService.js` also calls. `Billing.tsx` and `paymentStore.ts` were wired to `paymentService.js` only — `billingService.js` is now orphaned, unused, dead code, not a live conflict, but a real duplicate left in the tree. | **DUPLICATE** |
| **Frontend type duplication** | `src/types/billing.js` exports a plain-object `BillingRecord` shape (`patientName` flat field, `amount`, `lineItems`) that overlaps in purpose but **disagrees in shape** with the new `src/types/payment.ts` `Invoice` interface (`patient` nested object, `grandTotal`/`balanceDue`, `items`). Nothing currently imports `billing.js`, so there's no live type conflict, but it's a second, incompatible definition of the same concept sitting in the repo. | **DUPLICATE** |

## 2. Database Compatibility

The repository has **four independent persistence mechanisms**, not two:

1. **Mongoose** (`models/Billing.js`, `Department.js`, `Staff.js`) — never connected (no `mongoose.connect` call exists anywhere). Dead code.
2. **Raw `pg.Pool` via `config/db.js`** (`getPool()`, reads `PG_HOST`/`PG_PORT`/`PG_DATABASE`/`PG_USER`/`PG_PASSWORD`) — used by `models/Medicine.js` and `models/Prescription.js`.
3. **Raw `pg.Pool` via root `backend/db.js`** (reads `process.env.DATABASE_URL`) — used only by `routes/patients.js`, assumes a lowercase `patients` table with columns `(name, age, gender, phone)` that is never defined by any migration in this repo.
4. **Prisma** (`prisma/schema.prisma`, reads `process.env.DATABASE_URL`) — the new Payment/Invoice/User/Patient models.

**CONFLICT — environment variable collision:** mechanisms (3) and (4) both read `DATABASE_URL`.
If a real connection string is ever set for Prisma, `routes/patients.js` will **also** connect to
that same database via raw SQL and expect a `patients` table with a schema Prisma knows nothing
about (Prisma's own `Patient` model maps to a `Patient`-named table by default — different
casing, different columns, no relationship). Nothing currently breaks only because no
`DATABASE_URL` is set at all in this sandbox; the moment one is, these two mechanisms start
talking to the same database with zero coordination.

**Patient identity — three incompatible representations found:**

| Source | ID format | Fields | Backing store |
|---|---|---|---|
| Frontend `PatientRecord` type (`src/stores/patientStore.ts`) | arbitrary string, e.g. `"P-1001"` | age, gender, bloodGroup, address, medicalHistory, status | Defaults to hardcoded `mockPatients[]`; `loadPatients()` can overwrite with an API call to `/patients` |
| `routes/patients.js` raw SQL `patients` table | presumably SERIAL integer (not shown, no migration exists) | name, age, gender, phone | mechanism (3) above |
| Prisma `Patient` model (new) | UUID | fullName, phone, email, linked `User` | mechanism (4) above, used exclusively by Invoice/PaymentOrder |

None of these three populate or reference each other. A patient who exists in the frontend mock
list, or in the legacy `patients` SQL table, has no corresponding Prisma `Patient`/`User` row,
and vice versa. **Classification: CONFLICT** — pre-existing and not caused by Payment, but Payment
adds itself as a third-ish party against an already-unreconciled identity model, and every
Invoice/PaymentOrder in the new schema is only ever linked to the Prisma-side `Patient.id`.

**Doctor identity / Appointment identity:** no backend model of any kind exists for either
(both are frontend-only mock pages, `Doctors.tsx`/`Appointments.tsx`, calling no real API).
`Invoice.appointmentRef` is deliberately an opaque string, not a foreign key, for exactly this
reason. **Classification: COMPATIBLE** (correctly deferred — nothing to conflict with yet).

**Prescription identity:** `Prescription.js` (mechanism 2, SERIAL integer `prescriptions.id`) has
no relationship to `Invoice.pharmacyOrderRef` (opaque string). No active conflict, no active
integration either. **Classification: COMPATIBLE.**

**ID format inconsistency, repo-wide:** Prisma uses UUID strings throughout; `Medicine`/
`Prescription` use SERIAL integers; the legacy `patients` table likely does too; the frontend
mock `PatientRecord` uses ad hoc strings like `"P-1001"`. Any future cross-referencing between
these will require an explicit mapping/migration step, not a trivial FK. **Classification:
CONFLICT-adjacent / future integration cost.**

## 3. Authentication Compatibility

**Backend — single real mechanism, correctly reused, but with a serious startup hazard:**
`middleware/authMiddleware.js` verifies a Firebase ID token via `config/firebaseAdmin.js`. The
Payment/Billing routes correctly reuse this (`authenticate` → `loadAppUser` chain) rather than
inventing a second auth system. **That part is SAFE.**

**BLOCKED / CONFLICT — `firebaseAdmin.js` throws at import time, not request time:**

```js
if (!FIREBASE_PROJECT_ID || !FIREBASE_CLIENT_EMAIL || !FIREBASE_PRIVATE_KEY) {
  ...
  throw new Error("Missing Firebase Admin environment variables");
}
```

Before this engagement, `routes/index.js` — and therefore `authRoutes.js` →
`authMiddleware.js` → `firebaseAdmin.js` — was **never imported by `server.js`**, so this throw
was unreachable dead code. Wiring `routes/index.js` into `server.js` (necessary to mount the
Payment and rebuilt Billing routes at all) means **this throw is now reachable at process
startup**. With no `.env` present in this repository, `node server.js` / `npm start` will now
crash immediately on boot, before accepting any request at all — not a graceful 401, a hard
process exit. This is a genuine, previously-latent issue that connecting the dead code surfaces.
It was not visible in earlier forensics because the code path was unreachable.

**CONFLICT — frontend sends no real Firebase token to anything, ever:** `src/pages/Login.tsx`
is a fully client-side mock — it stores `{id, name, email, role, hospitalId}` in
`localStorage` under the key `medicare_pro_user`. No Firebase SDK is initialized anywhere in
`src/` (`find src -iname "*firebase*"` returns nothing), despite `firebase` being listed as a
frontend dependency in `package.json` — it is installed but unused. Separately,
`src/services/api.js` reads its bearer token from a **different** localStorage key,
`medicare_auth_token`, which is **never written by anything** in the current codebase, before
or after this engagement. Net effect: **no request from this frontend has ever sent a real
bearer token**, for any route. This predates Payment. But `pharmacyRoutes.js` and
`hospitalRoutes.js` apply no `authenticate` middleware at all, so this gap was invisible before —
Payment/Billing are the first routes in the whole repo that actually enforce authentication, which
makes this pre-existing gap the first thing that will visibly break (every payment/billing call
from the current UI will 401).

**Role extraction mismatch:** the backend resolves role via a Prisma `User` row looked up by
Firebase UID (`loadAppUser`), never from Firebase token claims directly. The frontend mock sets
role directly on the fake login object with no token involved at all. Even with real Firebase
auth wired up, `loadAppUser` requires a matching `User` row to already exist — there is no
registration/account-provisioning flow anywhere in the repo, and `prisma/seed.js`'s
`firebaseUid` values are placeholders that won't match any real UID. **Classification: BLOCKED**
for genuine end-to-end auth until (a) real Firebase env vars exist, (b) the frontend performs a
real Firebase sign-in and stores the token under the key `api.js` actually reads, and (c) a
provisioning step creates matching `User` rows.

## 4. RBAC Compatibility

- Frontend role source of truth: `src/app/roles.js` → `ADMIN, DOCTOR, NURSE, RECEPTIONIST,
  LAB_TECHNICIAN, PHARMACIST, BILLING, PATIENT`. Consumed by `PermissionGuard`, `Sidebar`,
  `Login.tsx`, `routes.tsx`.
- Backend `Role` enum in `prisma/schema.prisma` was reconciled in an earlier session to match
  this list exactly (it originally used invented names — `BILLING_STAFF`, `LAB_STAFF`,
  `PHARMACY_STAFF`, `MANAGEMENT` — that did not exist on the frontend at all).
  **Current state: SAFE**, the two lists agree.
- No `MANAGEMENT` role exists anywhere in the frontend; confirmed absent from the backend now
  too. **SAFE.**
- **DUPLICATE definition, not a conflict today:** the frontend's `roles: [...]` array on the
  `/billing` route in `routes.tsx` and the backend's `requireRole(...)` calls in
  `billingRoutes.js`/`payment.routes.js` are two independently hand-maintained lists with no
  shared source of truth. They currently agree because both were edited by hand to match, but
  there's nothing structural preventing future drift.
- **Coverage inconsistency (not a Payment conflict, but adjacent):** `pharmacyRoutes.js` and
  `hospitalRoutes.js` apply **no** `authenticate` or `requireRole` middleware at all — zero
  access control on those routers. Payment/Billing are the only parts of the API with any RBAC
  enforcement. This is a pre-existing gap in the rest of the app, not something Payment
  introduced or is responsible for fixing, but it means Payment's security posture is not yet
  representative of the app as a whole.

## 5. Frontend Compatibility

- `Billing.tsx`: the old placeholder (`EmptyState` only, "coming soon") was replaced, not kept
  alongside a new page — no duplicate *page*. **SAFE.**
- `routes.tsx`: single `/billing` entry; the only change was adding `PATIENT` to its `roles`
  array (see prior session's report) — no new duplicate route paths. **SAFE.**
- Shared components: the Payment module consumes only existing `src/components/ui/*` primitives
  (`Card`, `Button`, `Badge`, `Dialog`, `MetricCard`, `PageHeader`, `EmptyState`,
  `LoadingState`) — zero new component primitives, zero forked design system. **SAFE.**
- Stores: `src/stores/paymentStore.ts` is new and additive, reads from `useAuthStore` for patient
  identity (name/email) the same way other pages do — no overlap with `patientStore.ts`'s
  responsibility. **SAFE**, inheriting the mock-auth caveat from §3.
- API services: **DUPLICATE + CONFLICT**, see §1 — `billingService.js` (orphaned) and
  `paymentService.js` (live) both call `/billing/invoices*`. Worth noting precisely: the two are
  not just duplicated but **incompatible in response-unwrapping** — `billingService.js` does
  `.then((res) => res.data)`, which under the now-live backend returns the whole
  `{ success, data }` envelope rather than the invoice payload itself. If anything were ever
  reconnected to `billingService.js` as written, it would silently receive the wrong shape.
- Axios configuration: single `api.js` instance, reused correctly. **SAFE.**
- Navigation: `Sidebar` auto-derives entries from `routes.tsx`/`roles.js`; no separate nav list
  was added for Payment. **SAFE.**
- Lazy routes: `/billing` uses the same `lazy(() => import(...))` pattern as every other route.
  **SAFE.**

## 6. API Compatibility

- No duplicate route *definitions* exist — the old stub billing routes were replaced, not
  duplicated, at the Express router level. **SAFE** at that layer (see §1/§5 for the
  frontend-side service duplication, which is a different layer).
- **CONFLICT — inconsistent response envelopes across the API surface:** the new/rebuilt
  Billing and Payment endpoints consistently return `{ success: true, data: ... }` or
  `{ success: false, error: { code, message } }` via the new centralized `errorHandler`. Routes
  untouched by this engagement do not follow this shape at all: `routes/patients.js` returns
  raw arrays/rows directly (`result.rows`) with no envelope and no error handling (an unhandled
  DB rejection there would produce Express's default error page, not JSON). This inconsistency
  predates Payment and Payment does not fix it (correctly out of scope), but it means two
  incompatible conventions now coexist in the same API.
- Base URLs: single `api.js` baseURL, no divergence. **SAFE.**
- Auth headers: Payment/Billing require `Authorization: Bearer <token>`; `/patients`,
  `/pharmacy/*`, `/hospital/*` require none at all. Not a conflict in the sense of disagreement,
  but a real inconsistency in what's protected. **COMPATIBLE** (harmonizing this is future work,
  not something to silently change here).
- ID formats: UUID (Payment/Billing/Prisma) vs SERIAL integers (`Medicine`, `Prescription`,
  presumably legacy `patients`) vs ad hoc strings (frontend mock `PatientRecord`). Genuine
  future integration cost wherever these need to cross-reference. **CONFLICT-adjacent.**

## 7. Existing PDF Invoice/Billing Functionality

**Result: no such functionality exists anywhere in this repository.** Confirmed by a full-repo
grep for `pdf`/`receipt` (only matches were the word "receipt" used conversationally inside the
new Payment UI copy and Razorpay's own API field names, plus a pre-existing `ReceiptText` lucide
icon import in `Sidebar.tsx` used purely as a nav icon) and by checking both `package.json` files
for any PDF-capable library — none are installed. The audit brief's premise that "MediCare Pro
already has invoice/PDF-related functionality" **does not match the actual repository state**,
consistent with the original engagement's forensics finding that the pre-existing Billing/RBAC
were likewise assumed-but-absent. **Classification: UNKNOWN/SAFE** — there is nothing to
duplicate, conflict with, or connect to; if PDF/receipt generation is wanted, it is net-new work,
not an integration.

## 8. Pharmacy Compatibility

- `Medicine.unit_price` (raw pg, `config/db.js`) has zero connection to `InvoiceItem.unitPrice`
  — two separate prices for the same concept could exist with no reconciliation, but nothing
  currently enforces or even reads both, so there's no live conflict, just an unbuilt
  integration. `Invoice.pharmacyOrderRef` is an opaque string, not a real FK to any pharmacy
  table, deliberately. **Classification: COMPATIBLE** (integration required later, correctly
  deferred).
- Prescription creation (`pharmacyController.js` / `Prescription.js`) has no billing/payment hook
  in either the old or new code — creating a prescription does not touch `Invoice` in any way.
  **SAFE** (no conflict), **COMPATIBLE** (future work if pharmacy fulfillment should require
  payment first, per the original brief's aspiration).

## 9. Patient Identity Compatibility

Covered in full in §2. Restated: **three non-integrated Patient representations exist**
(frontend mock, legacy raw-SQL `patients` table, new Prisma `Patient`), and Payment's entire
domain (`PaymentOrder`, `Payment`, `Refund`, `Invoice`) is built exclusively against the Prisma
one. Reconciling these — deciding which is canonical, migrating/mapping the others into it — is
the single largest piece of "must eventually be merged" work surfaced by this audit.
**Classification: CONFLICT.**

## 10. Architecture Drift

| Category | Finding | Classification |
|---|---|---|
| Persistence layers | 4 distinct, uncoordinated DB access mechanisms (see §2) | DUPLICATE/CONFLICT |
| Models | `Billing` (Mongoose, dead) vs `Invoice` (Prisma, live) | DUPLICATE |
| Services (frontend) | `billingService.js` (orphaned) vs `paymentService.js` (live) — same endpoints, incompatible response unwrapping | DUPLICATE/CONFLICT |
| Types (frontend) | `types/billing.js` `BillingRecord` vs `types/payment.ts` `Invoice` — same concept, different shape | DUPLICATE |
| Controllers/Routes (backend) | Replaced, not duplicated | SAFE |
| Stores (frontend) | `paymentStore.ts` additive, no overlap with `patientStore.ts`/`authStore.js` | SAFE |
| Role definitions | Two hand-maintained lists (frontend `roles.js` usage in `routes.tsx`, backend `requireRole` calls) currently in agreement, no shared source of truth | DUPLICATE (dormant risk) |
| Auth logic | One real backend mechanism; see startup-crash and no-real-token findings in §3 | SAFE in design / BLOCKED in practice |
| API clients | Single shared `api.js` | SAFE |
| Currency-formatting utility | `src/pages/Dashboard.tsx` hand-rolls its own ad hoc `"₹11.6L"` lakh-format string inline; the new `src/utils/formatCurrency.ts` is a second, more rigorous implementation using `Intl.NumberFormat`. No pre-existing shared utility existed for either to converge on. Dashboard's revenue KPI remains mock data, disconnected from real Payment figures. | DUPLICATE (minor) |

## 11. Classification Summary

- **SAFE:** billing controller/routes replacement, payment routes/controllers (no pre-existing
  equivalent), shared UI components, axios client, navigation, lazy-route pattern, RBAC role
  list alignment (now), receipt/PDF (nothing to conflict with).
- **COMPATIBLE (integration required later):** Appointment/Laboratory/Pharmacy/Telemedicine
  references in `Invoice` (opaque strings by design), Pharmacy pricing vs Invoice pricing,
  Prescription vs `pharmacyOrderRef`, protected vs unprotected route coverage across the app.
- **DUPLICATE:** `models/Billing.js` (Mongoose, dormant) vs Prisma `Invoice`; frontend
  `billingService.js` vs `paymentService.js`; frontend `types/billing.js` vs `types/payment.ts`;
  hand-maintained role lists (frontend/backend); Dashboard's inline currency formatting vs the
  new `formatCurrency.ts`.
- **CONFLICT:** `DATABASE_URL` collision between Prisma and the legacy root `backend/db.js`;
  three non-integrated Patient identity representations; inconsistent API response envelopes
  across the app; ID-format inconsistency (UUID vs SERIAL vs ad hoc strings).
- **BLOCKED:** end-to-end auth verification (`firebaseAdmin.js` startup-crash risk with no
  `.env`; frontend never sends a real bearer token to anything; no account-provisioning flow to
  populate `User` rows matching real Firebase UIDs); live Prisma migration (Prisma CLI itself
  blocked by sandbox egress restrictions, reported previously); a live Razorpay round-trip.
- **UNKNOWN:** whether pharmacy fulfillment should require payment-first per the original
  brief's aspiration (no product decision found in the repo either way).

## 12. Final Recommendation

1. **Can the Payment module be integrated into the current MediCare Pro repository without
   architectural changes?** Partially. The Payment module itself is internally consistent and
   correctly reuses the design system, the Firebase auth *mechanism*, and (now) the correct RBAC
   role list. But it cannot be exercised end-to-end without touching two things outside its own
   scope: (a) the `DATABASE_URL` collision with the legacy `backend/db.js`/`routes/patients.js`
   pair must be resolved before any real database is pointed at this app, and (b) the
   frontend/backend auth gap (§3) must be closed before any authenticated route — Payment's or
   otherwise — can be called from the actual UI.

2. **What must eventually be merged?** The three Patient identity representations (§2/§9) into
   one canonical source; the four persistence mechanisms into one (Prisma is the only one with
   real migrations and the only one this session was asked to standardize on); the two
   hand-maintained RBAC role lists into a shared source of truth if this repo ever gets a
   frontend/backend shared-package setup.

3. **What should be removed or consolidated?** `backend/models/Billing.js` (Mongoose, superseded
   by Prisma `Invoice`, never connected to a live DB anyway); `src/services/billingService.js`
   and `src/types/billing.js` (orphaned, superseded by `paymentService.js`/`types/payment.ts`,
   and the former is silently broken against the current response shape if ever reconnected).
   These are recommendations for a future cleanup pass, not changes made in this audit.

4. **What must NOT be touched?** `config/db.js` + `models/Medicine.js`/`Prescription.js` (a
   working, self-contained pair — changing it is a Pharmacy-module concern, not Payment's);
   `models/Department.js`/`Staff.js` (Mongoose, dormant, out of scope); the frontend design
   system and shared `ui/*` components (Payment correctly reuses these as-is); `pharmacyRoutes.js`/
   `hospitalRoutes.js` (their lack of RBAC is a pre-existing gap outside this module's mandate).

5. **What infrastructure is required for final end-to-end verification?** A reachable Postgres
   instance with a `DATABASE_URL` that is *not* also consumed by `routes/patients.js` (or that
   file needs to be retired/migrated first); real Firebase project credentials
   (`FIREBASE_PROJECT_ID`/`FIREBASE_CLIENT_EMAIL`/`FIREBASE_PRIVATE_KEY`) for the backend to even
   boot with auth routes mounted; a real Firebase sign-in flow on the frontend that writes a
   token to the key `api.js` actually reads (`medicare_auth_token`); real Razorpay sandbox keys;
   and network egress to `binaries.prisma.sh` (still blocked in this sandbox, per the prior
   report) to run `prisma generate`/`migrate` at all.

6. **Are there any serious architectural conflicts that should be resolved before building
   another module?** Yes, two, and both predate Payment but are now more consequential because
   Payment is the first module to actually depend on them working: the `DATABASE_URL` collision
   between Prisma and the legacy raw-SQL patient route, and the complete absence of a working
   frontend-to-backend auth path. Building a second module on top of either without resolving
   them first would compound both problems rather than isolate them — the next module will hit
   the identical "no real token, no real database coordination" wall Payment did.

---

*No files outside this report were created or modified to produce this audit.*
