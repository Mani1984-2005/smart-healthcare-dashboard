# MediCare Pro — Payment & Financial Transaction Module
## Implementation Report

Status labels used below: **IMPLEMENTED** / **PARTIALLY IMPLEMENTED** / **CONFIGURATION REQUIRED**
/ **SANDBOX ONLY** / **NOT IMPLEMENTED** / **NOT VERIFIED**.

---

## 1. Repository Findings (see PAYMENT_IMPLEMENTATION_PLAN.md §1 for full detail)

The backend was largely scaffolding, not the mature platform the original brief assumed:
unmounted routes, a fully-stubbed billing controller, two conflicting database layers
(Postgres `pg.Pool` + Mongoose), an empty `Patient.js` model, no RBAC, no queue
infrastructure, and no `.env`. A third data-access pattern was also found during
implementation: `routes/patients.js` + root-level `backend/db.js` do raw SQL against a
`patients` table with no schema/migration anywhere — a second, different Postgres access
path from `config/db.js`. This file was **left untouched** (out of scope for Payment; flagged
here for visibility since it's one more inconsistency you'll want to resolve).

## 2. Existing Modules Reused

- `middleware/authMiddleware.js` (Firebase token verification) — reused unchanged as the
  authentication layer; RBAC is layered on top via the new `middleware/rbac.js`.
- `middleware/auditMiddleware.js` — untouched, still runs generically for all mutating requests.
- Design system / frontend service pattern — not consumed yet (no frontend UI built this
  session; see §9).

## 3. New Files Created

| File | Status |
|---|---|
| `backend/prisma/schema.prisma` | IMPLEMENTED, **NOT VERIFIED** — see §6 |
| `backend/src/lib/prisma.js` | IMPLEMENTED |
| `backend/utils/errors.js` | IMPLEMENTED |
| `backend/middleware/rbac.js` | IMPLEMENTED |
| `backend/modules/payments/payment.constants.js` | IMPLEMENTED, unit-tested |
| `backend/modules/payments/payment.provider.js` | IMPLEMENTED |
| `backend/modules/payments/providers/razorpay.provider.js` | IMPLEMENTED against Razorpay's documented contract; **CONFIGURATION REQUIRED** (no real keys exist); **NOT VERIFIED** against a live Razorpay account (no network egress to `api.razorpay.com` from this sandbox) |
| `backend/modules/payments/idempotency.js` | IMPLEMENTED |
| `backend/modules/payments/payment.service.js` | IMPLEMENTED, unit-tested against a mocked Prisma client |
| `backend/modules/payments/refund.service.js` | IMPLEMENTED, **NOT unit-tested** (see §8 known gaps) |
| `backend/modules/payments/payment.controller.js` | IMPLEMENTED |
| `backend/modules/payments/payment.routes.js` | IMPLEMENTED |
| `backend/modules/payments/webhook.controller.js` | IMPLEMENTED; the event-id derivation fallback and exact payload shape are **NOT VERIFIED** against live Razorpay traffic (see inline comment in the file) |
| `backend/modules/payments/webhook.routes.js` | IMPLEMENTED |
| `backend/modules/payments/__tests__/*.test.js` | IMPLEMENTED — **actually run**, 23/23 passing (see §7) |
| `backend/vitest.config.js` | IMPLEMENTED (needed to stop vitest from picking up the frontend's `vite.config.js`, which fails to load in this sandbox for an unrelated reason — a missing `@rolldown/binding-linux-x64-gnu` native module) |
| `backend/.env.example` | IMPLEMENTED |
| `PAYMENT_IMPLEMENTATION_PLAN.md`, this file | IMPLEMENTED |

## 4. Existing Files Modified

- `backend/controllers/billing.controller.js` — replaced 6 placeholder handlers with real
  Prisma-backed CRUD, zod validation, and RBAC-aware behavior (e.g. paid invoices reject edits).
- `backend/routes/billingRoutes.js` — added `authenticate` + `loadAppUser` + `requireRole` per
  route.
- `backend/routes/index.js` — actually imports and mounts `billingRoutes` and the new
  `payment.routes.js` (it previously existed but was dead code — nothing imported it).
- `backend/server.js` — imports `routes/index.js` under `/api`, mounts the webhook route with
  `express.raw()` **before** the global `express.json()` (required for HMAC verification to see
  the exact signed bytes), and registers the centralized `errorHandler` as the last middleware.
- `backend/package.json` — added `prisma`, `@prisma/client`, `razorpay`, `zod`, `vitest`;
  added `test`, `prisma:generate`, `prisma:migrate` scripts.

## 5. Database Changes

Full Prisma schema at `backend/prisma/schema.prisma`: `User` (with `Role` enum — the RBAC
foundation that didn't exist), `Patient`, `Invoice`/`InvoiceItem` (supersedes the Mongoose
`Billing` model), and the payment lifecycle `PaymentOrder → PaymentAttempt → Payment → Refund`,
plus `WebhookEvent` and `PaymentAuditLog`. Field-level rationale is documented inline in the
schema file.

**No migration has been run.** `prisma migrate dev` needs a reachable Postgres instance, which
doesn't exist here. `PostgreSQL provider + Prisma` was your explicit choice; this schema is
ready to migrate once you point `DATABASE_URL` at a real database.

## 6. Sandbox Limitation — Prisma CLI Blocked Entirely

`prisma generate`, `prisma validate`, and `prisma format` all failed with `403 Forbidden`
fetching from `binaries.prisma.sh`, which is not in this sandbox's allowed egress list (only
package registries — npm/pypi/github — are permitted). This means **I could not mechanically
verify the schema compiles**, the same class of limitation already documented on the Vikrant
engagement. I wrote and reviewed it carefully by hand, but treat it as **NOT VERIFIED** until
you run `npx prisma generate` (or `validate`) in an environment with normal network access.

## 7. What Was Actually Run and Verified

Unlike the schema, the payment-domain **logic** could be verified, because it doesn't depend on
a live database or a live Razorpay account:

```
npx vitest run
 ✓ modules/payments/__tests__/razorpay.provider.test.js (9 tests)
 ✓ modules/payments/__tests__/payment.service.test.js (5 tests)
 ✓ modules/payments/__tests__/payment.constants.test.js (9 tests)
 Test Files  3 passed (3)
      Tests  23 passed (23)
```

This is the literal output from this sandbox, not a claimed/assumed result. It covers:
state-machine transition rules, Razorpay checkout-signature HMAC verification (including a
rejected-tampered-signature and a rejected-cross-payment-replay case), webhook-signature
verification (including rejecting a byte-reordered-but-logically-identical payload — proving
the raw-body requirement actually matters), idempotent order creation, and the
never-trust-frontend-alone confirmation path with a mocked Prisma client.

It does **not** cover: actual Postgres unique-constraint enforcement, an actual Razorpay API
round trip, or `refund.service.js` (no test file written for it this session — flagged as a gap
below, not silently skipped).

## 8. Known Limitations / Gaps

- **`refund.service.js` has no unit tests.** The logic mirrors `payment.service.js`'s
  transaction pattern, but wasn't independently verified this session.
- **Webhook event-id derivation is a documented assumption**, not a confirmed fact: Razorpay's
  webhook payloads don't always carry one obvious stable id, and the fallback hash in
  `webhook.controller.js` hasn't been checked against real webhook samples.
- **`GET /billing/invoices/:id` has no patient-ownership check yet** — any authenticated user
  can currently fetch any invoice by id. Every other invoice/payment route enforces role or
  ownership; this one specifically was left as a documented gap rather than guessed at, since
  the "staff acting on behalf of a patient" access pattern needs a decision from you (should a
  doctor see a patient's invoice? Only their own patients'?) before I encode it.
- **Reconciliation (brief §26) is not built.** It needs settlement-report ingestion from a real
  provider account, which doesn't exist here.
- **`RECONCILIATION_PENDING` / `DISPUTED` payment states are documented but not implemented** —
  same reason.
- **No frontend payment UI was built this session** — you asked to fix the backend foundation
  first; the patient payment page, staff dashboard UI, and receipt rendering are natural next
  steps once the backend is confirmed working against a real database.
- **Offline/counter payments (brief §30), international payments (§29), and
  Appointment/Laboratory/Pharmacy/Telemedicine integration (§18–23)** are not implemented —
  those modules don't have working schemas or endpoints of their own yet in this repo to
  integrate against (Appointments/Laboratory/Pharmacy exist as frontend pages only; there's no
  backend for them). `Invoice.appointmentRef` / `labOrderRef` / `pharmacyOrderRef` are included
  as opaque string fields so those integrations can be wired in later without a schema change.

## 8b. Frontend Payment Module (this continuation)

Scope moved on to the frontend patient/staff UI, reusing the existing design system and
component library (`src/components/ui/*`) rather than introducing new styling.

**New files:**

| File | Status |
|---|---|
| `src/types/payment.ts` | IMPLEMENTED — mirrors the Prisma enums by hand (frontend/backend are separate build targets with no shared package) |
| `src/services/paymentService.js` | IMPLEMENTED — axios calls against the new `/api/billing` and `/api/payments` routes, using an `Idempotency-Key` header on order creation |
| `src/services/razorpayCheckout.js` | IMPLEMENTED against Razorpay's documented client-side Checkout.js contract; **CONFIGURATION REQUIRED** (`VITE_RAZORPAY_KEY_ID` unset); **NOT VERIFIED** — this sandbox cannot load `checkout.razorpay.com` or open a real checkout modal |
| `src/utils/formatCurrency.ts` | IMPLEMENTED |
| `src/stores/paymentStore.ts` | IMPLEMENTED — zustand store driving the pay flow state machine and staff dashboard state |
| `src/components/payments/PaymentStatusBadge.tsx` | IMPLEMENTED |
| `src/components/payments/InvoiceList.tsx` | IMPLEMENTED |
| `src/components/payments/SecurePaymentDialog.tsx` | IMPLEMENTED — brief section 6 layout, section 7's "never ask for PIN/CVV/password" boundary, section 35's "don't let processing be dismissed mid-flight" |
| `src/components/payments/PaymentDashboardKpis.tsx` | IMPLEMENTED (brief section 24 KPI cards) |
| `src/components/payments/TransactionTable.tsx` | IMPLEMENTED (brief sections 24-25, with inline refund action) |

**Modified:**
- `src/pages/Billing.tsx` — was a static placeholder (`EmptyState` only, "coming soon"). Rebuilt as
  role-aware: `PATIENT` sees invoice list + outstanding balance + Pay Now + payment history;
  `ADMIN`/`BILLING` see the KPI dashboard + transaction table with refund actions.
- `src/app/routes.tsx` — **the `/billing` route's role list did not include `PATIENT` at all**
  before this fix. A patient literally could not have reached their own billing page — this is
  the single most important correctness fix in this half of the session, since the entire
  point of the Payment module is a patient-facing pay flow.
- `backend/prisma/schema.prisma`, `backend/middleware/rbac.js`, `backend/modules/payments/*`,
  `backend/routes/billingRoutes.js` — **role-naming reconciliation.** The backend `Role` enum I
  wrote initially (`BILLING_STAFF`, `LAB_STAFF`, `PHARMACY_STAFF`, `MANAGEMENT`) did not match
  the frontend's actual `src/app/roles.js` (`ADMIN`, `DOCTOR`, `NURSE`, `RECEPTIONIST`,
  `LAB_TECHNICIAN`, `PHARMACIST`, `BILLING`, `PATIENT`), which the frontend has been built
  against all along (`PermissionGuard`, `Sidebar`, `Login.tsx`). Renamed the backend enum and
  every `requireRole(...)` call site to match exactly. Backend tests re-run after the rename:
  still 23/23 passing.

**Verified, for real, in this sandbox:** `npx tsc --noEmit` on the entire frontend. Pre-existing,
unrelated errors exist across the repo (e.g. every `.tsx` extension import throws `TS5097` —
a mismatch between the installed TypeScript `6.0.3` and this repo's target `^5.9.3`; a few
implicit-`any` parameters in `PatientForm.tsx`/`Login.tsx`/`Patients.tsx`; one `recharts` type
issue in `Dashboard.tsx`). **None of the new or modified payment-module files produce any type
error** — confirmed by grepping the full error output for every new/modified filename. One real
bug was caught and fixed this way: `SecurePaymentDialog.tsx` passed a `Invoice | null`-typed
parameter into a nested closure where TypeScript couldn't prove it had been narrowed to
non-null; fixed by binding it to a local `const` before the closures reference it.

**Known gap surfaced, not fixed:** the frontend's `useAuthStore`/`Login.tsx` is a pure client-side
mock (stores `{id, name, email, role}` in `localStorage`, no real Firebase sign-in), while
`backend/middleware/authMiddleware.js` expects a real Firebase ID token. This mismatch predates
this session — the payment routes will 401 against the current mock login until real Firebase
auth is wired into the frontend. Flagging it here because it directly blocks exercising the new
UI end-to-end, but fixing the frontend's auth system is outside Payment-module scope.

**Known gap surfaced, not fixed:** `RECEPTIONIST` has frontend route access to `/billing` (it
already did, before this session) but no backend RBAC grant on any billing/payment endpoint —
a logged-in receptionist would currently get 403s from the APIs `Billing.tsx` calls. Left as an
open question rather than guessed at, same reasoning as the invoice-ownership gap in §8.

## 9. Production-Readiness Status
**NOT PRODUCTION READY.** Concretely, before this could handle a real payment:

1. Run `npx prisma migrate dev` against a real Postgres instance and confirm the schema
   actually creates cleanly (§6).
2. Obtain real Razorpay sandbox keys, set them in `.env`, and run an actual test-mode checkout
   end-to-end — nothing here has touched Razorpay's live API.
3. Register a real webhook endpoint with Razorpay and confirm the payload shape assumptions in
   `webhook.controller.js` against real deliveries.
4. Seed real `User` rows with roles (a `prisma/seed.js` was planned but not written this
   session — flagging rather than fabricating one against an unrun schema).
5. Decide and implement the ownership rule in §8's invoice-access gap.
6. Build the frontend patient payment page and staff dashboard.

## 10. Future Roadmap (unprioritized, for your call)

- Wire real Firebase authentication into the frontend so the new UI can actually be exercised
  against the backend (currently blocked by the mock-auth gap in §8b).
- Resolve the `RECEPTIONIST` billing-access gap (§8b) and the invoice-ownership gap (§8) —
  both need a decision from you on the intended access model before encoding either.
- Reconciliation engine once a live provider account exists.
- Extend `PaymentProvider` with a second adapter (e.g. Stripe) to prove out the abstraction
  with more than one implementation.
- RBAC seed data + an admin UI to manage roles, since `User.role` currently has to be set
  directly in the database.
- Receipt generation/download once a real payment has actually been verified end-to-end.

## 11. Continuation — RBAC Gap Closure and Seed Data

Picked up the two open items flagged in §8/§8b, plus the planned-but-not-written seed file:

- **Invoice-ownership gap closed.** `GET /billing/invoices/:id` now uses the existing
  `requireSelfOrStaff` middleware: a `PATIENT` may only fetch their own invoice (verified by
  looking up the invoice's `patientId` and comparing against the caller's linked `Patient`
  record); every staff role (`DOCTOR`, `NURSE`, `RECEPTIONIST`, `LAB_TECHNICIAN`, `PHARMACIST`,
  `BILLING`, `ADMIN`) bypasses the check, consistent with needing cross-patient visibility for
  care coordination and front-desk work.
- **`RECEPTIONIST` backend gap closed, deliberately partially.** Added to
  `GET /billing/invoices` and `POST /billing/invoices` (front-desk staff view and create
  invoices at checkout) but intentionally left out of `/billing/summary` and everything under
  `/api/payments/dashboard/*` and `/api/payments/refunds` — those stay `BILLING`/`ADMIN`-only,
  matching the brief's own distinction between general "Staff: authorized operational actions"
  and "Billing Staff: financial operations". This is a judgment call, not a certainty — flag it
  if your actual front-desk workflow needs broader or narrower access.
- **`prisma/seed.js` written** — one demo `User` per role (including a `PATIENT` with a linked
  `Patient` record) and one demo `UNPAID` invoice, all via `upsert` so it's safe to re-run.
  `IMPLEMENTED, NOT VERIFIED` — same Prisma-CLI sandbox block as the schema itself (§6); the
  `firebaseUid` values are placeholders and must be replaced with real Firebase UIDs once real
  accounts exist. Wired up as `backend/package.json`'s `prisma.seed` config so
  `npx prisma db seed` picks it up once a database is reachable.
- **New test file**: `backend/middleware/__tests__/rbac.test.js` — 10 tests actually run,
  covering `requireRole`'s allow/deny paths, `requireSelfOrStaff`'s staff-bypass and
  self-vs-other-patient logic, and `loadAppUser`'s active/inactive/missing-token paths, all
  against a mocked Prisma client. Combined with the two existing payment test files, the full
  suite is now **33/33 passing**, run for real in this sandbox:

```
npx vitest run
 ✓ middleware/__tests__/rbac.test.js (10 tests)
 ✓ modules/payments/__tests__/razorpay.provider.test.js (9 tests)
 ✓ modules/payments/__tests__/payment.service.test.js (5 tests)
 ✓ modules/payments/__tests__/payment.constants.test.js (9 tests)
 Test Files  4 passed (4)
      Tests  33 passed (33)
```

One real bug was caught writing this test file, not just in application code: the first draft's
`vi.mock("../src/lib/prisma.js", ...)` and `import("../middleware/rbac.js")` paths were copied
from the `modules/payments/__tests__/` test files without adjusting for
`middleware/__tests__/`'s shallower nesting, and failed with `Cannot find module` on the first
run. Fixed to `../../src/lib/prisma.js` and `../rbac.js` respectively and re-run to confirm.

**Still open, unchanged from §8b:** the frontend mock-auth vs. real-Firebase-token mismatch —
nothing in this continuation touched frontend auth, so the new backend authorization logic is
verified by unit test but still cannot be exercised end-to-end from the actual UI yet.
