# Payment Module — Final Code-Completion Pass

## PAYMENT MODULE — CODE-COMPLETE / READY FOR INFRASTRUCTURE VALIDATION

This pass closed every remaining actionable code-level gap identified across all prior reports.
No environment/infrastructure blocker was closed or claimed closed — those are unchanged and are
restated precisely in §4. This document supersedes `PAYMENT_MODULE_HANDOFF.md`'s gap list (§2 of
that file) with the current, post-fix state; the handoff file's architecture/history sections
remain valid and are not repeated here.

---

## 1. Gaps Identified and Fixed This Pass

### 1a. Oversized-payload verification — was `NOT EXECUTED`, now genuinely tested

Real gap: no explicit body-size limit was configured (Express's undocumented 100kb default was
relied on implicitly), and no test had ever exercised it.

**Fix:** extracted the limit to `backend/config/bodyLimit.js` (single source of truth, `256kb` —
generous for every legitimate Payment/Billing payload, still bounded) and applied it explicitly
in `server.js`'s `express.json({ limit: JSON_BODY_LIMIT })`, replacing the implicit default.

**Test:** `backend/config/__tests__/bodyLimit.test.js` — 5 tests, using `supertest` for a **real
HTTP request/response round trip** (not mocked) through the actual `express.json({limit})` +
`errorHandler` pipeline, built as a minimal standalone app (the full `server.js` can't boot
without a generated Prisma client, per every prior report). Verified: a normal payment-confirm-
shaped payload is accepted; a payload comfortably over the limit is rejected with `413`, not a
crash; a payload right at the boundary is accepted and one just over it is rejected; malformed
JSON is rejected with `400`; neither case triggers the `[UNHANDLED ERROR]` log path reserved for
genuinely unexpected failures.

### 1b. `errorHandler` mishandled known body-parser errors — real bug found and fixed

While building the test above, found that `errorHandler` (`utils/errors.js`) treated *every*
non-`AppError` — including Express body-parser's `PayloadTooLargeError` (413) and JSON
`SyntaxError` (400) — as a generic 500 "unexpected error." This is semantically wrong (an
oversized or malformed *client* request is a 4xx, not a server failure) and would have logged
every such request as `[UNHANDLED ERROR]` even though it's an entirely expected input class.

**Fix:** added `classifyKnownNonAppError()`, recognizing `entity.too.large`/413 and
`entity.parse.failed`/JSON `SyntaxError` specifically, returning the correct status/code/message
for those without leaking the underlying error's message or stack. Every other non-`AppError` is
still treated as a genuine 500 and still logged — this narrows the false-500 case, it doesn't
weaken the "never leak internals" guarantee for anything else.

### 1c. `refund.service.js` had no dedicated test file — closed

Flagged in every prior report as a known gap. **Fix:** `backend/modules/payments/__tests__/refund.service.test.js`
— 16 tests covering `initiateRefund` (nonexistent payment, wrong payment status, full-refund
default, partial-refund-on-top-of-partial-refund arithmetic, zero/negative amount rejection,
over-refund rejection, correctly ignoring non-`PROCESSED` refunds when computing the remaining
balance, audit log write), `markRefundProcessed` (nonexistent refund, idempotent re-processing,
`REFUNDED` vs `PARTIALLY_REFUNDED` classification, invalid transition rejection), and
`markRefundFailed` (nonexistent refund, reason correctly persisted to the audit log — a direct
regression test for the lint fix from the prior pass, invalid transition rejection).

### 1d. Webhook silent-drop paths had zero observability — fixed

Reviewed `webhook.controller.js`'s `dispatchEvent` closely per this pass's explicit instruction
to review webhook handling. Found that every "we received a signature-valid webhook but can't
match it to our own records" case (`payment.captured`/`payment.failed` with no matching
`PaymentOrder`, `refund.processed`/`refund.failed` with no matching `Refund`, or any event with a
missing `entity`) did a bare `return` with **zero logging** — these events vanished with no trace.
This matters because `initiateRefund`/`createPaymentOrder` both call the payment provider *before*
persisting locally (a documented, pre-existing architectural tradeoff shared with the order-
creation path, not newly introduced — see §3 for why it wasn't restructured), so a provider-side
refund or order can genuinely exist with no local record if persistence fails after the provider
call succeeds; a webhook for that orphaned record would previously disappear silently, forever.

**Fix:** added `console.warn` with the relevant correlation id (never sensitive data) at every one
of these early-return points. This is purely additive observability — no behavior changed, no
service call added or removed, confirmed by re-running `webhook.controller.test.js` unmodified
and it still passes without adjustment.

---

## 2. Review Findings — No Fix Needed (Verified, Not Assumed)

- **Duplicated/dead Payment logic:** every exported function in `modules/payments/*` was grepped
  for external references — all are used at least once outside their own definition; none are
  orphaned. No duplicate invoice-fetching, no duplicate validation logic, no duplicate error
  classes.
- **Architecture/convention conformance:** the module continues to follow the repo's established
  patterns — zod validation in controllers, `asyncHandler`-wrapped handlers, `AppError` subclasses
  for all thrown errors, `prisma.$transaction` for multi-step writes, RBAC via
  `requireRole`/`requireSelfOrStaff` at the route layer. No deviation introduced this pass.
- **Tenant isolation:** re-confirmed by grep that `hospitalId` exists *only* in the frontend mock
  (`src/types/user.js`, `src/pages/Login.tsx`, hardcoded to `"hospital-01"`) — it is never read by
  any backend code, never present in `prisma/schema.prisma`, never passed to any API call. MediCare
  Pro's actual backend has no multi-tenancy concept at all. **This is an accurate architectural
  fact, not a Payment-module defect** — there is nothing to isolate between, because nothing in
  the real system currently distinguishes one tenant/hospital from another. Introducing tenant
  scoping now would be a schema-level redesign, explicitly out of scope for this pass.
- **Validation:** every Payment/Billing route input is zod-validated; re-confirmed no endpoint
  accepts a client-supplied `amount` or `status` field (unchanged from prior passes).
- **Idempotency:** `PaymentOrder.idempotencyKey`, `Payment.paymentAttemptId`,
  `WebhookEvent.providerEventId` are all declared `@unique` in the schema and each has a
  corresponding catch-and-recover code path, all with regression tests. Unchanged, re-verified.
- **Payment state transitions:** unchanged, `payment.constants.js`'s enforced transition tables
  remain the single source of truth; no endpoint bypasses them.

## 3. Known Limitation Documented, Not Fixed (By Design This Pass)

`initiateRefund`/`createPaymentOrder` call the payment provider *before* persisting the local
record. If the provider call succeeds and the subsequent database write fails, the provider-side
resource exists with no local record — until this pass, a webhook about it would vanish silently
(§1d fixes the silence; the underlying window itself is unchanged). Restructuring both creation
paths to persist a `PENDING` placeholder before calling the provider (and reconciling after) is
the correct long-term fix, but it touches the core creation flow in two places and is a genuine
design change, not a bug fix — explicitly out of scope for "fix all code-level gaps" versus
"do not refactor unless a concrete defect is discovered." The defect (silent webhook drop) *was*
discovered and *was* fixed; the underlying architectural tradeoff is flagged, not silently
accepted.

---

## 4. Environment/Infrastructure Blockers — Unchanged, Restated Precisely

No infrastructure check was attempted, re-attempted, or claimed passed in this pass beyond what
code-level fixes could verify locally. These four items are exactly as reported in
`MEDICARE_PRO_PAYMENT_FINAL_CLOSURE_REPORT.md` and `PAYMENT_MODULE_HANDOFF.md`:

| Blocker | Status |
|---|---|
| Reachable PostgreSQL + generated Prisma client | ENVIRONMENT-BLOCKED — no network path to `binaries.prisma.sh` |
| Real Firebase project/configuration | ENVIRONMENT-BLOCKED — no credentials, no network path to Firebase |
| Real Razorpay sandbox credentials | ENVIRONMENT-BLOCKED — no credentials, no network path to `api.razorpay.com` |
| Real external-provider connectivity generally | ENVIRONMENT-BLOCKED — sandbox egress is package-registries-only |

---

## 5. Regression — Run Fresh After Every Fix in This Pass

```
$ npx vitest run
 ✓ config/__tests__/bodyLimit.test.js (5 tests)                          ← new
 ✓ modules/payments/__tests__/razorpay.provider.test.js (9 tests)
 ✓ modules/payments/__tests__/refund.service.test.js (16 tests)          ← new
 ✓ modules/payments/__tests__/payment.service.test.js (7 tests)
 ✓ modules/payments/__tests__/webhook.controller.test.js (5 tests)
 ✓ modules/payments/__tests__/payment.controller.idor.test.js (6 tests)
 ✓ middleware/__tests__/authMiddleware.test.js (5 tests)
 ✓ middleware/__tests__/rbac.test.js (10 tests)
 ✓ modules/payments/__tests__/payment.constants.test.js (9 tests)

 Test Files  9 passed (9)
      Tests  72 passed (72)          (up from 51 — 21 new tests, all targeting real gaps closed this pass)

$ npx eslint .
(no output — clean)

$ npx tsc --noEmit --ignoreDeprecations 6.0 | grep -c "error TS"
38   (unchanged pre-existing/unrelated count; 0 in any payment-module or new file)

$ npx vite build
✓ 2486 modules transformed
dist/assets/Billing-B2B8mStc.js   17.60 kB │ gzip: 5.26 kB
✓ built in 3.25s

$ rm -f backend/.env && node backend/server.js
Error: Missing Firebase Admin environment variables    ← unchanged, expected, credential-only
```

No test was skipped, weakened, or deleted to obtain these results. No mock was introduced in
place of a check that used to be real; the one new real-HTTP test (`bodyLimit.test.js`) is
strictly additive verification that didn't exist before.

---

## 6. Files Changed This Pass

| File | Change |
|---|---|
| `backend/config/bodyLimit.js` | New — single source of truth for the JSON body-size limit |
| `backend/config/__tests__/bodyLimit.test.js` | New — 5 real HTTP-level tests |
| `backend/server.js` | Modified — explicit `express.json({ limit: JSON_BODY_LIMIT })` replacing the implicit default |
| `backend/utils/errors.js` | Modified — `errorHandler` now correctly classifies known body-parser errors (413/400) instead of reporting them as generic 500s |
| `backend/modules/payments/__tests__/refund.service.test.js` | New — 16 tests, closes the previously-flagged gap |
| `backend/modules/payments/webhook.controller.js` | Modified — added observability logging to four previously-silent early-return paths; no behavior change |
| `backend/package.json` | Modified — added `supertest` devDependency |

**Not changed:** any Payment feature, any RBAC rule, any database schema field, any Razorpay
integration logic beyond the webhook logging above, any frontend file, any other MediCare Pro
module.

---

## 7. Final Status

### PAYMENT MODULE — CODE-COMPLETE / READY FOR INFRASTRUCTURE VALIDATION

Every actionable code-level gap identified across this entire engagement — including the ones
newly surfaced by this pass's own closer review (the `errorHandler` 413/400 misclassification,
the silent webhook-drop observability gap) — has been fixed, tested, and regression-verified.
72 tests, all passing (up from 51 at the start of this pass); lint clean; typecheck clean in
scope; production build clean; backend boot fails only and exactly where real credentials are
required.

This is **not** the same as `CLOSED`. Per every prior report and this pass's own instructions,
`CLOSED` requires real evidence from a live PostgreSQL instance, a real Firebase project, and real
Razorpay sandbox credentials — none of which exist in this sandbox, and none of which any further
code change can substitute for. What *is* true, and wasn't fully true before this pass: there is
no longer any known, actionable, code-level work remaining. The module is ready to be verified
against real infrastructure the moment that infrastructure exists; the exact manual procedure for
that remains recorded in `PAYMENT_FINAL_VERIFICATION_GATE.md` §6 and
`MEDICARE_PRO_PAYMENT_FINAL_CLOSURE_REPORT.md` §4–§6, unchanged and still accurate.
