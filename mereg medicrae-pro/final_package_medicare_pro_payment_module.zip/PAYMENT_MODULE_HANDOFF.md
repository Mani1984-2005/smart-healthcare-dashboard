# Payment Module — Handoff / Status Note

**Status: CONDITIONALLY APPROVED — NOT CLOSED (code-complete, pending real infrastructure verification)**

This is a short pointer, not a new report. For full detail and evidence, see (in chronological
order): `PAYMENT_IMPLEMENTATION_PLAN.md`, `PAYMENT_IMPLEMENTATION_REPORT.md`,
`PAYMENT_INTEGRATION_COMPATIBILITY_REPORT.md`, `PAYMENT_FINAL_VERIFICATION_GATE.md`,
`PAYMENT_MODULE_CLOSURE_REPORT.md`, `MEDICARE_PRO_PAYMENT_FINAL_CLOSURE_REPORT.md`.

## What's done and verified (code-level, real evidence)

- Full payment lifecycle implemented: Invoice → PaymentOrder → PaymentAttempt → Payment → Refund,
  with an enforced state machine (`modules/payments/payment.constants.js`).
- Razorpay provider abstraction (`modules/payments/providers/razorpay.provider.js`) — signature
  verification logic is real and unit-tested; the provider itself has never made a live API call.
- IDOR protection on `/payments/attempts` and `/payments/confirm` (`assertOwnsPaymentOrder`).
- Concurrency/idempotency protection on `confirmPayment` (P2002-race handling) and on webhook
  replay (`WebhookEvent.providerEventId` unique constraint).
- RBAC aligned with the frontend's actual role set; `authMiddleware.js`/`config/firebaseAdmin.js`
  fixed to work with the installed `firebase-admin@14.1.0` API shape (was previously broken
  unconditionally, independent of credentials).
- Frontend patient/staff UI built on the existing design system; frontend production build passes.
- Database architecture hazard isolated: the legacy `backend/db.js`/`routes/patients.js` pool no
  longer shares `DATABASE_URL` with Prisma (now `LEGACY_PATIENTS_DATABASE_URL`).
- **51/51 backend tests passing, lint clean, 0 TypeScript errors in any payment-module file.**

## Remaining blockers — infrastructure only, not code

1. **Reachable PostgreSQL + generated Prisma client.** `npx prisma generate` cannot run in this
   sandbox — no network path to `binaries.prisma.sh`. No live database exists to migrate or query.
2. **Real Firebase project/configuration.** No `FIREBASE_PROJECT_ID`/`FIREBASE_CLIENT_EMAIL`/
   `FIREBASE_PRIVATE_KEY` (backend) or `VITE_FIREBASE_*` (frontend) exist; no network path to
   Firebase's services from this sandbox. **Update:** the frontend/backend code-level wiring for
   this is now complete — see `AUTH_GAP_FIX_REPORT.md`. What remains is purely supplying real
   credentials and testing against them; no further code work is anticipated.
3. **Real Razorpay sandbox credentials.** No `RAZORPAY_KEY_ID`/`RAZORPAY_KEY_SECRET`/
   `RAZORPAY_WEBHOOK_SECRET` exist; no network path to `api.razorpay.com`.
4. **Real external-provider connectivity, generally.** All three above share one root cause: this
   sandbox's egress is restricted to package registries only.
5. **Oversized-payload verification.** Never explicitly tested against the Payment routes
   (Express's default 100kb JSON limit is presumed in effect but unconfirmed).

None of these can be closed by further code changes — see `MEDICARE_PRO_PAYMENT_FINAL_CLOSURE_REPORT.md`
§4–§6 for the exact commands already attempted and their output, and §6 of
`PAYMENT_FINAL_VERIFICATION_GATE.md` for the manual Razorpay verification procedure to run once
credentials exist.

## Path to CLOSED (unchanged, for whoever picks this up next)

1. Provide a reachable Postgres instance + network access; run `npx prisma generate` and
   `npx prisma migrate dev`; run `node prisma/seed.js`.
2. Provide real Firebase project credentials; wire real sign-in into the frontend (currently a
   mock — `src/pages/Login.tsx`); confirm `api.js` actually sends the resulting token.
3. Provide real Razorpay sandbox credentials; execute the manual procedure in
   `PAYMENT_FINAL_VERIFICATION_GATE.md` §6.
4. Add an oversized-payload test against the Payment routes.
5. Re-run the full suite + a live end-to-end pass; only then is `CLOSED` justified.

## Additional finding for whoever picks up the next module

While cleaning up confirmed-dead code in Payment's vicinity, found that `hospitalRoutes.js` /
`hospitalController.js` (Department/Staff dashboard) is never mounted anywhere — same class of
bug as the original unmounted billing/patient routes at the start of this engagement. Unlike
`models/Billing.js` (now removed — zero references anywhere, fully superseded by the Prisma
`Invoice` model), `Department.js`/`Staff.js` **are** referenced, by `hospitalController.js` — they
represent real, unwired future-module code, not orphaned duplicates, so they were left untouched
rather than deleted. Whoever builds a Hospital/Staff module next will need to either wire this in
(after resolving the same Mongoose-is-never-connected issue Payment's `Invoice` model already
solved for Billing) or make a deliberate call to rebuild it on Prisma instead, matching the
pattern already established for Billing.

## Handoff instruction

No further Payment implementation work should be undertaken without the infrastructure above.
Development should proceed to the next MediCare Pro module. If a concrete defect is found in
Payment later (not merely "we now have infra to test more"), fix it, add a regression test, and
update this note — don't silently drift the code without updating the record.
