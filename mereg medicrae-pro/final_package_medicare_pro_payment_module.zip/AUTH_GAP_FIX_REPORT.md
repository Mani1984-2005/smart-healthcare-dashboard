# Frontend Authentication Gap — Fix Report

This addresses the auth-gap finding from `PAYMENT_INTEGRATION_COMPATIBILITY_REPORT.md` §3, which
blocked exercising Payment (and every other module) end-to-end: the frontend had no real Firebase
integration, and `api.js` read a bearer token from a localStorage key nothing ever wrote to.

## What was actually broken

1. `src/pages/Login.tsx` was a pure client-side mock — a role *picker*, not a sign-in form. A
   "patient" could select "ADMIN" from a dropdown. No credential was ever verified against
   anything.
2. `firebase` (^12.14.0) was an installed frontend dependency, imported nowhere.
3. `src/services/api.js` read its bearer token from `localStorage["medicare_auth_token"]` — a key
   nothing in the codebase ever wrote to, before or after this fix's predecessor work.
4. The backend's `GET /api/auth/me` endpoint existed but returned only raw Firebase token claims
   (`uid`/`email`/`name`/`picture`) — never the application's actual `role` from Prisma. Even with
   a real token, the frontend would have had no trustworthy source for role.

## What was fixed

- **`backend/routes/authRoutes.js`**: `/auth/me` now runs through `loadAppUser` and returns the
  authoritative Prisma `User` record (`id`, `role`, `name`, `email`, `isActive`) — the one place
  the frontend should ever get role from. 4 new tests (`routes/__tests__/authRoutes.test.js`),
  real HTTP round trip via `supertest`.
- **`src/services/firebase.js`** (new): initializes the Firebase client SDK from
  `VITE_FIREBASE_*` env vars, exports `isFirebaseConfigured` so the rest of the app can branch
  cleanly. `CONFIGURATION REQUIRED` / `NOT VERIFIED` — same honest labeling as the Razorpay
  checkout integration; no `VITE_FIREBASE_*` values exist in this sandbox and there's no network
  path to Firebase to test against regardless.
- **`src/store/authStore.js`**: added `loginWithFirebase(firebaseUser)` (gets the real ID token,
  writes it to the key `api.js` actually reads, fetches the authoritative role from `/auth/me`)
  and `initAuthTokenRefresh()` (keeps the token fresh across the session via
  `onIdTokenChanged` — Firebase tokens expire hourly). The old `login()` is now explicitly
  `loginDevMode()` — unchanged behavior, but honestly named, and now documented as *not* writing
  a token, since faking one would be worse than sending none.
- **`src/pages/Login.tsx`**: renders a real Firebase email/password form when configured, and the
  original role-picker (now clearly labeled "Dev mode") when it isn't — automatically, with no
  code change needed once real Firebase config exists.
- **`src/main.tsx`**: wires `initAuthTokenRefresh()` at startup; no-ops entirely when Firebase
  isn't configured.
- **`.env.example`** (new, frontend root — none existed before) and `backend/.env.example`
  (already existed) both document every required variable.

## What this does and does not close

**Closes:** the token-storage-key mismatch (real code fix, verified by reading `api.js` against
the new `authStore.js` — they now agree); the "no trustworthy role source" gap (real code fix,
tested); the "Firebase installed but unused" finding (now actually wired, correctly gated).

**Does not close, and does not claim to:** live Firebase authentication. No `VITE_FIREBASE_*`
values exist in this sandbox, no network path to Firebase's services exists here, and nothing in
this fix pretends otherwise. The dev-mode fallback remains fully functional so local development
isn't broken by this change — it's an explicit, labeled fallback, not a silent gap. The path to
real verification is unchanged: real Firebase project credentials (backend `FIREBASE_*` +
frontend `VITE_FIREBASE_*`), then the same login flow tested end-to-end.

## Regression

```
$ npx vitest run
 Test Files  10 passed (10)
      Tests  76 passed (76)     (72 → 76, +4 new authRoutes.test.js tests)

$ npx eslint .
(clean)

$ npx tsc --noEmit --ignoreDeprecations 6.0 | grep -c "error TS"
36    (was 38 — net -2, from fixing 2 genuinely pre-existing errors while rewriting Login.tsx)

$ npx vite build
✓ 2498 modules transformed
✓ built in 4.28s

$ rm -f backend/.env && node backend/server.js
Error: Missing Firebase Admin environment variables    ← unchanged, same documented credential gap
```
