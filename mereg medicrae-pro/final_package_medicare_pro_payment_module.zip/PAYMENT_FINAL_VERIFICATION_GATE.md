# Payment Module — Final Integration Verification Gate

## Executive Verdict

### CONDITIONALLY APPROVED — SPECIFIC ITEMS REMAIN

Three P0-severity bugs and one P1 concurrency bug were found by actually executing code
(not by reading it, and not by trusting that passing unit tests meant the system worked) and
were fixed in this pass, with regression tests added and the full suite re-run. Every finding
below is backed by either a command that was actually run in this sandbox (output included) or
an explicit code citation — nothing here is inferred or assumed. The remaining blockers are
**infrastructure-only**: they require a network-unrestricted environment, real Firebase
credentials, and real Razorpay sandbox credentials, none of which exist in this sandbox. No
Payment feature scope was added, redesigned, or expanded in this pass — every change below is
either a targeted correctness/security fix or a verification step.

---

## 1. Database Architecture

**Traced every import, not assumed.** Four persistence paths exist; classifications below are
based on `grep`-verified import chains, not the earlier audit's inference:

| Path | Env var | Consumers | Classification |
|---|---|---|---|
| Prisma (`prisma/schema.prisma`) | `DATABASE_URL` | `src/lib/prisma.js` → all of `modules/payments/*`, rebuilt `controllers/billing.controller.js` | **ACTIVE** — this is the Payment module's only data layer |
| Legacy raw `pg.Pool` (`backend/db.js`) | *was* `DATABASE_URL`, now `LEGACY_PATIENTS_DATABASE_URL` | `routes/patients.js` only, mounted at `/patients` in `server.js` | **ACTIVE, was DANGEROUS, now ISOLATED** (see fix below) |
| Raw `pg.Pool` via `config/db.js` | `PG_HOST`/`PG_PORT`/`PG_DATABASE`/`PG_USER`/`PG_PASSWORD` | `models/Medicine.js`, `models/Prescription.js`, reachable via `pharmacyRoutes.js` → `routes/index.js` → `server.js` | **ACTIVE, LEGACY** — separate env namespace, no collision risk, out of Payment's scope |
| Mongoose (`models/Billing.js`, `Department.js`, `Staff.js`) | none read | nothing — no `mongoose.connect()` call exists anywhere in the repo (`grep -rn "mongoose.connect" backend` returns zero results) | **DEAD** |

**Fix applied — P1, database correctness:** `backend/db.js` and Prisma both read
`process.env.DATABASE_URL`. `routes/patients.js` is genuinely mounted (`server.js:32`,
`app.use("/patients", patientRoutes)`), so this was not a theoretical risk — the moment a real
`DATABASE_URL` was set for Prisma, this pool would silently also connect to it and run
unmigrated raw SQL (`SELECT * FROM patients`) against whatever the same database happened to
contain. Fixed by splitting `backend/db.js` onto its own `LEGACY_PATIENTS_DATABASE_URL`
variable, with a console warning if it's unset, so the two paths can never collide by accident —
an operator now has to deliberately set both to the same value to reunite them. **No SQL,
schema, or route behavior in `routes/patients.js` was touched.** `.env.example` updated to
document the new variable and why it's separate.

**Can the two systems safely point at the same database?** Only if an operator deliberately
sets `LEGACY_PATIENTS_DATABASE_URL` to the same value as `DATABASE_URL`. Even then: Prisma's
`Patient` model and the legacy `patients` table are different physical tables (Prisma quotes
identifiers, so its table is `"Patient"`; the legacy raw SQL is unquoted `patients`, which
Postgres folds to lowercase) — they cannot silently overwrite each other's rows. The real risk
was operational confusion (two divergent "patient" data stores that look related but aren't),
not row-level corruption. That risk is now gated behind an explicit opt-in instead of a shared
default.

**Whether Payment data can diverge across the two systems:** No — nothing in `modules/payments/*`
imports `backend/db.js` or `config/db.js` at all. Payment/Invoice/PaymentOrder/Payment/Refund
all live exclusively in Prisma. Verified by `grep -rn "from.*db\.js\|getPool" backend/modules
backend/controllers/billing.controller.js` → zero matches.

**Whether transactions can cross the two systems:** No. `prisma.$transaction()` only spans
Prisma-managed tables; the legacy pool has no participation in any Payment code path.

---

## 2. Patient Identity

**Traced the actual chain, end to end, by reading the real code:**

```
Firebase ID token (Authorization: Bearer <token>)
  → middleware/authMiddleware.js: admin.auth().verifyIdToken(token) → req.user (Firebase claims, incl. uid)
  → middleware/rbac.js: loadAppUser — prisma.user.findUnique({ where: { firebaseUid: req.user.uid } }) → req.appUser
  → payment.controller.js: resolvePatientContext(req) —
      if req.appUser.role === "PATIENT": prisma.patient.findUnique({ where: { userId: req.appUser.id } })
      else (staff): patientId must be explicitly supplied in the request, looked up and validated to exist
  → that Patient.id is what PaymentOrder.patientId / Invoice.patientId are ever set to
```

**Can Payment reliably answer "which patient does this authenticated user belong to?"** For a
`PATIENT`-role caller: **yes**, and the answer is derived entirely server-side from the
Firebase-verified `uid` → `User` → `Patient` chain — never from anything the client supplies in
the request body, query string, or URL. Verified by code inspection of `resolvePatientContext`
(`payment.controller.js`) and by the passing IDOR regression tests in §4.

**P0 gap found and fixed — see §4.** The chain above was correctly enforced for `createOrder`
and `getHistory`, but **not** for `recordAttempt` or `confirmPayment`, which took a
client-supplied `paymentOrderId` and acted on it with zero ownership check. This is now fixed.

**Does the answer depend on frontend-supplied IDs, localStorage, or mock users?** No — for every
Payment mutation, ownership is now either (a) derived from the server-side Firebase→User→Patient
chain (patient-initiated actions) or (b) gated by role (staff-initiated actions, where the role
itself — not a patient ID — is the authorization boundary, matching the brief's own distinction
between patient self-service and staff operational access).

**Classification: the mapping mechanism itself is now correct and enforced.** It remains
**BLOCKED** for actual end-to-end exercise, because (a) no real Firebase project exists to issue
real tokens, and (b) no `User`/`Patient` rows can be created without a working Prisma client
(§16). The *logic* is verified by unit test against a mocked Prisma client; the *live* mapping
is not.

---

## 3. Authentication

**Is Firebase the actual provider?** Yes — `middleware/authMiddleware.js` verifies a Firebase ID
token via the Admin SDK; there is no second auth mechanism anywhere in the backend.

**P0 bug found and fixed — the Firebase Admin SDK integration was completely non-functional,
independent of credentials.** Discovered by actually running `node server.js`, not by reading
the code:

```
$ node server.js   # with placeholder (fake-format) Firebase env vars set
...
TypeError: Cannot read properties of undefined (reading 'length')
    at file:///.../backend/config/firebaseAdmin.js:19:17
```

Root cause, confirmed by directly importing the installed package:

```
$ node -e "import('firebase-admin').then(m => console.log(m.default.apps, m.default.credential, m.default.auth))"
undefined undefined undefined
```

`firebase-admin@14.1.0` (the installed version) does not expose the old namespaced API
(`admin.apps`, `admin.credential.cert()`, `admin.auth()`) that `config/firebaseAdmin.js` was
written against — that shape belongs to firebase-admin v8 and earlier. The installed version
only exposes the flat modular API (`getApps()`, `cert()`, `initializeApp()` from
`firebase-admin/app`; `getAuth()` from `firebase-admin/auth`). **This means authentication could
never have worked in this repository, with or without real credentials, before this fix** — not
something introduced by the Payment module, but something Payment is the first code path to have
actually exercised by running the server rather than just importing test mocks.

**Fix applied:** `config/firebaseAdmin.js` rewritten against the modular API, exporting the same
`{ auth: () => Auth }` shape so `middleware/authMiddleware.js`'s existing
`admin.auth().verifyIdToken(...)` call site needed no changes. Re-verified by running the server
again with a structurally-valid (self-generated, not-tied-to-any-real-project) RSA key:

```
$ node server.js
◇ injected env (4) from .env
[legacy backend/db.js] LEGACY_PATIENTS_DATABASE_URL is not set. ...
Firebase Admin SDK initialised          ← confirms the fix works
Error: Cannot find module '.prisma/client/default'   ← next, separate, pre-existing blocker (§16)
```

**Where does the frontend obtain a token, and how is it attached?** It doesn't, currently.
`src/pages/Login.tsx` is a pure client-side mock (`localStorage.setItem("medicare_pro_user", ...)`
— no Firebase SDK call anywhere in `src/`, confirmed by `find src -iname "*firebase*"` returning
nothing, despite `firebase` being an installed-but-unused frontend dependency).
`src/services/api.js` attaches a bearer token by reading `localStorage.getItem("medicare_auth_token")`
— a key **nothing in this codebase, before or after Payment, ever writes to.** This is a
pre-existing, repo-wide gap (Payment/Billing are simply the first routes to actually enforce
`authenticate` at all — `pharmacyRoutes.js`/`hospitalRoutes.js` apply no auth middleware).
**Not fixed in this pass** — per the instructions, only the minimum necessary to make the
*existing* architecture functional was in scope, and this requires standing up a real Firebase
project and a real sign-in flow, which is new infrastructure, not a bug fix. **Classification:
BLOCKED.**

**Test matrix — what was actually exercised vs. what's blocked:**

| Case | Verified how | Result |
|---|---|---|
| No token | Code inspection: `authMiddleware.js` returns 401 if no `Bearer` header | Verified by inspection (unconditional check, no DB/Firebase call needed to reach this branch) |
| Malformed token | Code inspection: any non-`Bearer`-prefixed header returns 401 before Firebase is even called | Verified by inspection |
| Invalid/expired token | `admin.auth().verifyIdToken()` throws → caught → 401 | Verified by inspection of the try/catch; **not exercised against a real token** (needs a real Firebase project) — BLOCKED |
| Valid token, own patient | `resolvePatientContext`/`assertOwnsPaymentOrder` logic | Verified by unit test against mocked Prisma (§4/§15); **not exercised end-to-end** — BLOCKED |
| Valid token for another patient | IDOR fix, §4 | Verified by unit test (new regression tests, passing) |
| Staff token | RBAC `requireRole`/`requireSelfOrStaff` | Verified by unit test (`middleware/__tests__/rbac.test.js`, pre-existing from last session, still passing) |
| Unauthorized role | Same as above | Verified by unit test |

---

## 4. Payment Authorization / IDOR — P0 FOUND AND FIXED

**The single most important finding of this pass.** `POST /api/payments/attempts` and
`POST /api/payments/confirm` accepted a client-supplied `paymentOrderId` (and, for confirm,
`paymentAttemptId`) and passed them directly to the service layer with **no check that the
calling `PATIENT` actually owned that order**. Concretely, before this fix, any authenticated
patient could:

- `POST /api/payments/attempts { paymentOrderId: "<someone else's order>", method: "UPI" }` —
  this would create a `PaymentAttempt` row against another patient's order and flip that order's
  status from `CREATED` to `ATTEMPTED`, with zero relationship to the caller.
- `POST /api/payments/confirm { paymentOrderId: "<someone else's order>", ... }` — this would
  reach the signature-verification step (which *would* independently block an actual funds
  transfer, since forging a valid HMAC requires the Razorpay API secret), but the ownership
  bypass itself is a real access-control failure regardless of whether the crypto happens to
  also block the worst-case outcome — exactly the class of bug the brief asked to hunt for by
  name.

**Fix:** added `assertOwnsPaymentOrder(req, paymentOrderId)` in `payment.controller.js`, called
before either service function runs. Staff roles bypass (consistent with the existing
`resolvePatientContext`/`requireSelfOrStaff` trust model elsewhere in this module); a `PATIENT`
caller must have their Firebase-derived `Patient.id` match `PaymentOrder.patientId`, or the
request is rejected with `403 FORBIDDEN` before any state changes.

**Regression tests added** (`modules/payments/__tests__/payment.controller.idor.test.js`, 6
tests, all passing): rejects cross-patient `recordAttempt`, allows same-patient `recordAttempt`,
allows staff through without an ownership lookup, returns `404` for a nonexistent order, rejects
cross-patient `confirmPayment`, allows same-patient `confirmPayment`.

**Other endpoints checked for the same class of bug:**
- `createOrder` — already correct (`resolvePatientContext` derives patient server-side for
  `PATIENT` role; staff must supply `patientId`, which is looked up and validated to exist, and
  staff-initiated actions are an intentional, role-gated capability, not an IDOR).
- `getHistory` — already correct, same mechanism.
- `createRefund` — role-gated to `BILLING`/`ADMIN` only; `refund.service.js` independently
  validates the referenced `Payment` exists and the refund amount doesn't exceed what's
  refundable. No patient-facing ownership concept applies here by design.
- `getDashboardSummary`/`listTransactions` — role-gated to `BILLING`/`ADMIN`, aggregate/list
  views with no single-entity ownership concept.
- **`GET /billing/invoices/:id`** — already correct from the prior session's continuation
  (`requireSelfOrStaff`), re-verified by reading the current route file, unchanged in this pass.

**Client-controlled ownership/amount fields — checked explicitly, see §5 for amount.** No Payment
endpoint accepts a client-supplied `patientId` for `PATIENT`-role callers at all; the only place
`patientId` is ever read from the request body is the staff-on-behalf-of-patient path, which is
role-gated by design, not a bypass.

---

## 5. Payment Amount Integrity — Verified SAFE by Code Inspection

Traced the authoritative amount from source to persistence:

```
Invoice.balanceDue (Prisma, server-computed by billing.controller.js from InvoiceItem rows)
  → payment.service.js: createPaymentOrder() reads invoice.balanceDue directly from the DB row
    it just fetched — the request body schema (createOrderSchema = z.object({ invoiceId: z.string().uuid() }))
    has NO amount field at all, so there is nothing for a client to tamper with here
  → provider.createOrder({ amount: balanceDue, ... }) — sent to Razorpay using the server value
  → PaymentOrder.amount persisted = balanceDue (server value)
  → confirmPayment(): Payment.amount = order.amount, read from the PaymentOrder row fetched
    inside the transaction — never from the request body, which doesn't carry an amount field
    at all (confirmSchema has no `amount` field)
  → Invoice.amountPaid/balanceDue updated using order.amount (server value)
```

**Zero client-controlled amount field exists anywhere in the order-creation or confirmation
request schemas** (`createOrderSchema`, `recordAttemptSchema`, `confirmSchema` in
`payment.controller.js` — inspected directly, none contain an `amount` field). The only place an
amount is ever accepted from a client is `refundSchema`'s optional `amount` (for partial
refunds), which is role-gated to `BILLING`/`ADMIN` and independently bounded server-side against
`payment.amount - alreadyRefunded` in `refund.service.js` — a legitimate, validated operational
input, not a tampering vector.

**Decimal precision:** Prisma schema uses `Decimal @db.Decimal(12, 2)` for every money field, not
floating point; `toDecimalNumber()` helper converts Prisma's `Decimal` type to a JS number only
for arithmetic, and the results are written back through Prisma's own `Decimal`-aware writes.
Negative/zero/oversized amounts: `createPaymentOrder` explicitly rejects `balanceDue <= 0`
(`ConflictError`); nothing in the schema currently caps a maximum amount (a real gap if
extremely large invoices are a concern, but not something this repository's existing invoicing
flow surfaces as attacker-controlled, since invoice totals are staff-authored, not
patient-authored). **Classification: SAFE**, verified by inspection, not by assumption.

---

## 6. Razorpay Integration

**No credentials of any kind exist in this sandbox** — confirmed by `env | grep -i razorpay`
returning nothing, and no `.env` file present at any point except the one I created and deleted
for the Firebase boot test in §16 (which contained no Razorpay values).

### BLOCKED — CREDENTIALS REQUIRED

Not faked, not claimed as passing. **Exact manual verification procedure for later:**

1. Obtain Razorpay **test-mode** credentials (`Key Id` / `Key Secret`) and a webhook secret from
   the Razorpay dashboard.
2. Set `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` in `backend/.env`, and
   `VITE_RAZORPAY_KEY_ID` in the frontend's env.
3. Get a real Postgres instance reachable, run `prisma generate` and `prisma migrate dev` (blocked
   in this sandbox, see §16), then `node prisma/seed.js` to create demo `User`/`Patient`/`Invoice`
   rows.
4. Stand up real Firebase auth (§3) so a real ID token can be obtained and sent by the frontend.
5. From the patient UI, click **Pay Now** on the seeded demo invoice → confirm a Razorpay Order
   is created (check the Razorpay dashboard's Orders list for a matching `receipt` = the seeded
   invoice number).
6. Complete checkout using a [Razorpay test card/UPI](https://razorpay.com/docs/payments/payments/test-mode/) →
   confirm the frontend's `onSuccess` handler fires and calls `POST /api/payments/confirm`.
7. Confirm server-side: `Payment.status = SUCCESS`, `PaymentOrder.status = PAID`,
   `Invoice.status = PAID`, `Invoice.balanceDue = 0` in the database.
8. Re-submit the exact same `POST /api/payments/confirm` body a second time → confirm it returns
   the same `Payment` row (idempotent) rather than creating a duplicate — this exercises the
   fix in §14/§8b of this document.
9. Send an intentionally invalid `providerSignature` → confirm `422`/`400`-class rejection and
   that `PaymentAttempt.status` becomes `FAILED`, not `SUCCESS`.
10. Configure a webhook endpoint in the Razorpay dashboard pointing at
    `POST /api/webhooks/razorpay` → trigger a test webhook → confirm `WebhookEvent` row is
    created with `signatureValid: true` and `processedAt` populated.
11. Re-deliver the identical webhook (Razorpay dashboard supports manual redelivery) → confirm
    the second delivery returns `200 { deduped: true }` and does **not** re-run `dispatchEvent`.
12. Send a request to the webhook endpoint with a deliberately wrong `X-Razorpay-Signature`
    header → confirm `401` and that no `WebhookEvent` row is created.

None of steps 5–12 could be executed in this sandbox; steps 1–4 describe infrastructure this
sandbox cannot provide (no reachable Postgres, no `binaries.prisma.sh` access, no Firebase
project, no Razorpay account).

---

## 7. Webhook / Callback Safety — Verified by Code Inspection

Read `modules/payments/webhook.controller.js` in full for this pass (not re-quoted here in
full — see the file). Confirmed:

- **Signature validation:** every request is passed through
  `provider.verifyWebhookSignature(rawBody, signatureHeader)` (HMAC-SHA256 over the raw request
  bytes, using `crypto.timingSafeEqual`) before any other code runs. Invalid signatures get a
  `401` and are never persisted or processed. Route-level: `webhook.routes.js` uses
  `express.raw({ type: "application/json" })`, mounted in `server.js` **before**
  `express.json()` — verified by re-reading `server.js` — so the raw bytes the HMAC was computed
  over are exactly what gets verified, not a re-serialized copy.
- **Idempotency/replay protection:** `WebhookEvent.providerEventId` is a Prisma `@unique` column;
  a re-delivered event hits `P2002` and is acknowledged `200 { deduped: true }` without
  `dispatchEvent` running a second time. Verified by reading the try/catch around
  `prisma.webhookEvent.create`.
- **Amount/patientId/invoiceId trust:** `dispatchEvent`'s `payment.captured` handler looks up the
  `PaymentOrder` via **our own** `providerOrderId` (a value we generated and stored, matched
  against the webhook payload's `entity.order_id`) — it never uses any patientId or invoiceId
  taken directly from the payload for authorization. The amount used to update `Invoice`/`Payment`
  is `order.amount` — the server's own stored value — never anything from the webhook payload.
  **Confirmed SAFE by inspection**, matching §5's guarantee.
- **Transaction boundaries:** webhook-triggered confirmations go through the exact same
  `confirmPayment()` function as the frontend confirm path (via the `trustedByWebhook: true`
  flag), so they inherit the same `$transaction`-wrapped, state-machine-enforced write path —
  not a separate, less-guarded code path.
- **Safe logging:** `console.warn("[webhook] signature verification failed")` logs no payload
  content, no headers, no secrets — just the fact of failure.

**One real, minor limitation found and documented (not fixed — genuinely deferred, not a
security hole):** the `payment.failed`/`refund.*` handlers select `order.attempts[0]` (most
recent attempt) rather than matching by a provider-side payment ID, because `PaymentAttempt`
doesn't store a `providerPaymentId` until *after* confirmation succeeds. In the normal single-
attempt-per-order flow this is correct; if a patient generates multiple concurrent attempts
against the same order before any resolves, a `payment.failed` webhook could theoretically be
applied to a different (also-still-pending) attempt than the one that actually failed at the
provider. This does not create a security vulnerability (it can only mark an attempt `FAILED`,
never `SUCCESS`, and `FAILED` is a terminal, non-financial state per the state machine in §8) —
it's a correctness edge case under a usage pattern (rapid multi-attempt races) the current UI
doesn't actually produce (the frontend's `SecurePaymentDialog` blocks a second attempt while one
is in flight). **Classification: DEFERRED**, documented rather than fixed, per the instruction
not to redesign Payment in this pass.

---

## 8. Payment State Machine

Documented in `modules/payments/payment.constants.js`, unchanged in this pass (already correct,
already tested — 9 tests in `payment.constants.test.js`, still passing). Restated here for the
gate record:

```
PaymentOrder:  CREATED → ATTEMPTED → PAID (terminal)
                       → EXPIRED (terminal) / CANCELLED (terminal)
PaymentAttempt: INITIATED → PENDING → SUCCESS (terminal) / FAILED (terminal) / CANCELLED (terminal)
Payment:        PENDING → PROCESSING → SUCCESS → REFUNDED / PARTIALLY_REFUNDED → REFUNDED
                                     → FAILED (terminal)
Refund:         PENDING → PROCESSED (terminal) / FAILED (terminal)
```

Every transition is enforced through `assertValidTransition()`, which throws
`InvalidTransitionError` (409) for anything not in the allowed-transitions table, including the
brief's explicit examples: `FAILED → SUCCESS` is not in `PAYMENT_ATTEMPT_TRANSITIONS.FAILED`
(empty array, terminal) and `SUCCESS → PENDING` is not in `PAYMENT_TRANSITIONS.SUCCESS`
(`["REFUNDED", "PARTIALLY_REFUNDED"]` only). **No endpoint accepts an arbitrary client-supplied
status value at all** — every status transition happens as a side effect of a verified action
(signature-checked confirmation, role-gated refund initiation, webhook-verified provider events),
never as a direct field the client sets. Verified by inspection of every Prisma `update()` call
across `payment.service.js`/`refund.service.js` — none take `status` from `req.body`.

---

## 9. Legacy Billing Files — RESOLVED (removed, with evidence)

Exhaustive grep run before any deletion:

```
$ grep -rn "billingService" --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" . | grep -v node_modules | grep -v dist
./src/stores/paymentStore.ts: import * as billingService from "../services/paymentService.js"   ← a LOCAL ALIAS NAME, not a reference to the actual file
(no other matches)

$ grep -rn "types/billing\|BillingRecord" --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" . | grep -v node_modules | grep -v dist
./src/types/billing.js:1:export const BillingRecord = {...}   ← only self-reference, no external imports
```

**Confirmed 100% dead** — the `billingService` name appearing in `paymentStore.ts` was a
misleading local import alias for `paymentService.js`, not an actual import of the real
`src/services/billingService.js` file (which is a real, separate, unused file). This naming
coincidence was itself worth fixing for clarity, independent of the deletion.

**Actions taken:**
- Deleted `src/services/billingService.js` and `src/types/billing.js` (zero external references,
  confirmed above).
- Renamed the misleading `billingService` alias in `paymentStore.ts` to `paymentService` so it
  accurately reflects what it imports.
- Re-ran `npx tsc --noEmit` after both changes — zero new errors, confirmed by grepping the
  output for any of the touched filenames (see §12).

---

## 10. PDF / Receipt Claim — Independently Re-Verified, Still Absent

Re-ran the search from scratch in this pass, not reusing the prior audit's conclusion:

```
$ grep -riE "jspdf|pdfkit|puppeteer|pdfmake|react-pdf|pdf-lib" package.json backend/package.json
(no output — none installed)

$ grep -rn "\.pdf\b|generatePDF|createPDF|PDFDocument" --include="*.js" --include="*.ts" --include="*.tsx" . | grep -v node_modules | grep -v dist
(no output — no PDF generation code anywhere)
```

**Confirmed: not implemented.** Recorded exactly as instructed: **"Not implemented — deferred
feature."** No documentation in this repository (the plan, the two implementation reports, or
this gate) claims otherwise — checked `PAYMENT_IMPLEMENTATION_REPORT.md` §7's wording
("...should eventually be connected to Payment") does not assert current existence, so no
correction was needed there.

---

## 11. API Contract — Final Inventory

All routes below were confirmed **actually mounted** by tracing `server.js` → `routes/index.js`
→ each router file directly (not assumed from file existence).

| Method | Endpoint | Auth | Role | Ownership Check | Input | Output | DB Effect | Test Coverage |
|---|---|---|---|---|---|---|---|---|
| POST | `/api/billing/invoices` | Firebase | BILLING, ADMIN, RECEPTIONIST | n/a (staff-only) | invoice payload (zod) | `{success,data:Invoice}` | Create Invoice+Items | Unit (billing.controller not separately tested this pass — pre-existing) |
| GET | `/api/billing/invoices` | Firebase | BILLING, ADMIN, DOCTOR, RECEPTIONIST | n/a | query filters | `{success,data:{items,total}}` | Read | — |
| GET | `/api/billing/invoices/:id` | Firebase | any | **Yes** — `requireSelfOrStaff` | — | `{success,data:Invoice}` | Read | Unit (`rbac.test.js`) |
| PUT | `/api/billing/invoices/:id` | Firebase | BILLING, ADMIN | n/a | partial invoice payload | `{success,data:Invoice}` | Update | — |
| DELETE | `/api/billing/invoices/:id` | Firebase | ADMIN | n/a | — | `{success,message}` | Soft-cancel | — |
| GET | `/api/billing/summary` | Firebase | BILLING, ADMIN | n/a | — | `{success,data:{...}}` | Read/aggregate | — |
| POST | `/api/payments/orders` | Firebase | any (patient-self or staff-on-behalf) | **Yes** — `resolvePatientContext` | `{invoiceId}` | `{success,data:PaymentOrder}` | Create PaymentOrder | Unit (`payment.service.test.js`) |
| POST | `/api/payments/attempts` | Firebase | any | **Yes** — `assertOwnsPaymentOrder` (fixed this pass) | `{paymentOrderId,method}` | `{success,data:PaymentAttempt}` | Create Attempt | Unit (`payment.controller.idor.test.js`, new this pass) |
| POST | `/api/payments/confirm` | Firebase | any | **Yes** — `assertOwnsPaymentOrder` (fixed this pass) | `{paymentOrderId,paymentAttemptId,providerOrderId,providerPaymentId,providerSignature}` | `{success,data:Payment}` | Create Payment, update Order+Invoice | Unit (`payment.service.test.js`, `payment.controller.idor.test.js`) |
| GET | `/api/payments/history` | Firebase | any | **Yes** — `resolvePatientContext` | pagination | `{success,data:{items,total}}` | Read | — |
| POST | `/api/payments/refunds` | Firebase | BILLING, ADMIN | n/a (role-gated) | `{paymentId,amount?,reason?}` | `{success,data:Refund}` | Create Refund | Unit (state machine only; `refund.service.js` itself not unit-tested — pre-existing gap) |
| GET | `/api/payments/dashboard/summary` | Firebase | BILLING, ADMIN | n/a | — | `{success,data:{...}}` | Read/aggregate | — |
| GET | `/api/payments/dashboard/transactions` | Firebase | BILLING, ADMIN | n/a | pagination/filters | `{success,data:{items,total}}` | Read | — |
| POST | `/api/webhooks/razorpay` | HMAC signature (not Firebase) | n/a | n/a | raw Razorpay payload | `{success}` / `{deduped:true}` / 401 | Create WebhookEvent, dispatch to Payment/Refund services | Verified by code inspection (§7); not live-tested (§6) |

**No orphaned endpoints found** — every controller function is wired to exactly one mounted
route; no dead route files exist in `modules/payments/` or the billing path (unlike the original
engagement's finding that `routes/billingRoutes.js` and `routes/index.js` were written but never
imported — that was fixed in an earlier session and re-confirmed still correct here).

---

## 12. Frontend Compatibility

Re-verified request/response shape alignment by reading `src/services/paymentService.js`
against the controller schemas in §11 directly (not assumed from memory of writing them):

- `createPaymentOrder(invoiceId)` → `POST /payments/orders {invoiceId}` — matches
  `createOrderSchema`. ✓
- `recordPaymentAttempt(paymentOrderId, method)` → matches `recordAttemptSchema`. ✓
- `confirmPayment({...})` → field names match `confirmSchema` exactly. ✓
- Every service function does `.then(res => res.data.data)`, matching the backend's
  `{success, data}` envelope. ✓ (this is the exact shape mismatch that made the now-deleted
  `billingService.js` silently broken — see §9 — confirming that finding was correct and that
  the live `paymentService.js` does not share the bug.)
- Idempotency: `paymentService.js` sends an `Idempotency-Key` header on order creation, matching
  `idempotency.js`'s `resolveIdempotencyKey(req)` reading `req.headers["idempotency-key"]`. ✓

**No REQUIRED FIX found in the frontend service layer itself in this pass** (§9's fix was
cleanup of a dead duplicate, not a live mismatch). **RECOMMENDED (not fixed, out of scope for
this pass):** the frontend cannot exercise any of this because of the auth gap in §3 — that's an
infrastructure/architecture item, not a Payment-frontend code defect. **DEFERRED:** real
Razorpay checkout round-trip (§6).

---

## 13. Error Handling

Verified by reading `utils/errors.js` and tracing which status codes each Payment error path
actually produces:

| Scenario | Status | Verified how |
|---|---|---|
| Nonexistent invoice | 404 (`NotFoundError`) | Code inspection, `createPaymentOrder` |
| Nonexistent payment order (attempts/confirm) | 404 | Code inspection + new IDOR test |
| Unauthorized invoice/payment access | 403 (`ForbiddenError`) | Code inspection + tests (§4, `rbac.test.js`) |
| Duplicate payment order (same idempotency key) | 409 (`ConflictError`, via `runIdempotently`'s P2002 catch) | Code inspection |
| Malformed request body | 400 (`ValidationError`, zod `safeParse`) | Code inspection |
| Invalid amount (e.g. zero-balance invoice) | 409 (`ConflictError`) | Code inspection |
| Invalid state transition | 409 (`InvalidTransitionError`) | Code inspection + `payment.constants.test.js` |
| Gateway failure (Razorpay unconfigured) | 503, `PAYMENT_PROVIDER_NOT_CONFIGURED` | Code inspection, `razorpay.provider.js._assertConfigured()`; unit-tested (`razorpay.provider.test.js`) |
| Database failure (generic) | 500, generic message | `errorHandler`'s non-`AppError` branch — confirmed it does **not** forward `err.message` for unrecognized errors, only for `AppError` subclasses |

**No stack traces, SQL, secrets, gateway credentials, or filesystem paths are exposed** —
confirmed by reading `errorHandler` directly: for any error that isn't an `AppError` instance,
the response body is hardcoded to `"An unexpected error occurred."`, regardless of what the
underlying error actually says. This was true before this pass and is unchanged.

---

## 14. Database Transaction Safety — P1 FOUND AND FIXED

**Race condition found and fixed.** `confirmPayment()` is wrapped in `prisma.$transaction()`,
which correctly prevents a *partial* write (Payment created but Invoice not updated) — that part
was already correct. But under Postgres's default READ COMMITTED isolation, **two concurrent
calls to `confirmPayment()` for the same attempt** (realistic scenario: the frontend confirm
call and a webhook delivery for the same payment arriving nearly simultaneously) could both read
`PaymentAttempt.status` as not-yet-`SUCCESS` before either transaction commits, and both proceed
toward creating a `Payment` row. The `Payment.paymentAttemptId` `@unique` constraint is what
actually stops a duplicate row at the database level — but before this fix, the losing
transaction's `P2002` error was **not caught**, so it would propagate as an unhandled 500 instead
of the idempotent result callers expect.

**Fix:** wrapped the transaction call in try/catch; on a `P2002` specifically targeting
`paymentAttemptId`, re-fetch and return the winning transaction's `Payment` row instead of
erroring. A `P2002` on any *other* constraint is deliberately re-thrown, not swallowed, so this
fix cannot mask an unrelated integrity violation.

**Regression tests added** (in `payment.service.test.js`): one confirms the race resolves to the
winner's payment; one confirms a *different* constraint's P2002 is still thrown, not silently
absorbed. Both passing.

**Other concurrency checks performed:** `createPaymentOrder`'s idempotency relies on
`PaymentOrder.idempotencyKey` `@unique` + `runIdempotently`'s P2002 catch — already correct,
already tested from the prior session, re-confirmed still passing. `refund.service.js`'s
`markRefundProcessed` uses the same `$transaction` pattern as `confirmPayment` but was not
specifically stress-tested for the equivalent race in this pass (no `@unique` constraint exists
on `Refund` the way it does on `Payment.paymentAttemptId`, since a `Refund` legitimately can have
multiple rows per `Payment` for partial refunds — a race here would be a genuine gap, flagged as
**DEFERRED** rather than fixed, since fixing it would require a new locking strategy, which
borders on redesign).

---

## 15. Testing — Full Suite, Actually Run

```
$ npx vitest run
 ✓ modules/payments/__tests__/razorpay.provider.test.js (9 tests)
 ✓ modules/payments/__tests__/payment.service.test.js (7 tests)
 ✓ modules/payments/__tests__/payment.controller.idor.test.js (6 tests)
 ✓ middleware/__tests__/rbac.test.js (10 tests)
 ✓ modules/payments/__tests__/payment.constants.test.js (9 tests)

 Test Files  5 passed (5)
      Tests  41 passed (41)
```

| Category | Test Files | Tests | Passed | Failed | Skipped | Blocked |
|---|---|---|---|---|---|---|
| Totals | 5 | 41 | 41 | 0 | 0 | 0 (unit-level) |

**New this pass:** `payment.controller.idor.test.js` (6 tests, §4) and 2 new tests inside
`payment.service.test.js` (§14) — 8 new tests total, up from the 33 at the start of this pass.

**What these 41 tests do and do not prove — stated plainly, not glossed over:** they prove the
*logic* is correct against mocked Prisma/Razorpay clients: state transitions, idempotency
handling, signature verification math, ownership checks, RBAC decisions. **They do not prove**
the system works against a real database, a real Firebase project, or a real Razorpay account —
that would require integration/E2E tests, which are impossible to run in this sandbox (§16) and
are not claimed as having been run. This distinction is the reason the verdict is not "APPROVED."

---

## 16. Server Boot Verification — Actually Executed, Not Simulated

This section is the evidence that produced §1, §3, and this document's overall verdict. Every
command below was actually run in this sandbox; outputs are trimmed for length but not edited
for content.

**Run 1 — zero env vars:**
```
$ node server.js
SyntaxError: Named export 'PrismaClient' not found. The requested module '@prisma/client' is a
CommonJS module, which may not support all module.exports as named exports.
```
→ **P0 bug found** (§16a). Root cause confirmed by inspecting
`node_modules/@prisma/client/default.js` (`module.exports = {...require('.prisma/client/default')}`
— a dynamic spread, not statically analyzable into ESM named exports) and confirming
`node_modules/.prisma/client/` does not exist on disk at all (never generated, blocked since the
first session by `binaries.prisma.sh` egress restrictions). **Fixed**: `src/lib/prisma.js` and
`prisma/seed.js` changed to `import pkg from "@prisma/client"; const { PrismaClient } = pkg;`.

**Run 2 — same env, after the fix:**
```
$ node server.js
Error: Missing Firebase Admin environment variables
```
→ Confirms the fix worked (no more `SyntaxError`) and the *next* real gate is Firebase
configuration, exactly as expected.

**Run 3 — placeholder Firebase env vars (fake project id/email, syntactically-invalid key):**
```
$ node server.js
TypeError: Cannot read properties of undefined (reading 'length')
    at config/firebaseAdmin.js:19:17
```
→ **Second, independent P0 bug found** (§3/§16b). `firebase-admin@14.1.0`'s default export has
no `.apps`/`.credential`/`.auth` — confirmed by directly importing the package and inspecting its
keys. **Fixed**: `config/firebaseAdmin.js` rewritten against the modular
`firebase-admin/app`/`firebase-admin/auth` API.

**Run 4 — same fake env vars, after the fix:**
```
$ node server.js
FirebaseAppError: Failed to parse private key.
```
→ Correct behavior — the placeholder key genuinely isn't valid PEM. Confirms the fix works and
fails for the *right* reason.

**Run 5 — a structurally-valid, self-generated RSA key (not tied to any real Firebase project):**
```
$ node server.js
Firebase Admin SDK initialised          ← auth fix fully confirmed working
Error: Cannot find module '.prisma/client/default'
Require stack:
- .../node_modules/@prisma/client/default.js
```
→ **Firebase initialization now genuinely succeeds.** The only remaining blocker is the missing
generated Prisma client — the same root cause identified (but not fixed, because it can't be, in
this sandbox) in the very first session of this engagement. This is not a new problem and not
something introduced by Payment; it is infrastructure this sandbox cannot provide
(`binaries.prisma.sh` is not in the allowed egress list — confirmed again this session with the
same result as before).

**Test credentials were generated locally with `openssl genrsa` purely to exercise this code
path, are not tied to any real Firebase project, and were deleted immediately after this test
(`rm .env /tmp/test_key.pem`), before writing this report.** No real or placeholder secret value
appears anywhere in this document or in the repository.

**Was `app.listen()` / the health endpoint / a live 401-on-protected-route ever reached?** No —
because `server.js` statically imports the entire route graph (including `modules/payments/*`,
which import `src/lib/prisma.js`) before calling `app.listen()`, a missing Prisma client blocks
the **entire** server from starting, including routes that don't need Prisma at all (`/health`).
This is a real architectural brittleness worth naming: one subsystem's missing dependency
currently takes down completely unrelated routes. **Not restructured in this pass** — doing so
(e.g., lazy-loading route modules, isolating failure domains) would be a structural change to
`server.js` beyond "the minimum necessary for integration correctness," and the actual fix for
production is simply to run `prisma generate` in the build step, which resolves this without any
code change. Recorded here as a **DEFERRED** observation, not fixed.

---

## 17. Environment / Secret Audit

- `.env` is listed in `.gitignore` at the repo root (confirmed: `cat .gitignore` shows `.env` as
  its own line, plus `backend/node_modules/`).
- No `.env` file exists in the repository as delivered — only `backend/.env.example`, which
  contains **placeholder values only** (`""`, `"postgresql://USER:PASSWORD@HOST:5432/medicare_pro"`)
  — confirmed by reading the file directly, no real-looking secret strings present.
- No Docker or CI configuration exists in this repository (confirmed: `find . -iname "Dockerfile*"
  -o -iname "*.yml" -path "*workflows*"` → no matches outside `node_modules`), so there is nothing
  to audit there.
- The test Firebase credentials generated during §16's boot verification (`openssl genrsa`, fake
  project id) were never committed, never written to any file outside a `.env` that was deleted
  before this report was written, and do not appear in this document.
- Required variables are now documented: `.env.example` lists `DATABASE_URL`,
  `LEGACY_PATIENTS_DATABASE_URL` (new this pass, §1), Firebase's three variables, and Razorpay's
  three variables, each with a comment explaining its purpose.

---

## Files Changed This Pass

| File | Change | Severity |
|---|---|---|
| `backend/src/lib/prisma.js` | Fixed CJS/ESM interop bug (unconditional boot crash) | P0 |
| `backend/prisma/seed.js` | Same fix, same root cause | P0 |
| `backend/config/firebaseAdmin.js` | Rewritten against the actually-installed firebase-admin v14 modular API | P0 |
| `backend/modules/payments/payment.controller.js` | Added `assertOwnsPaymentOrder` IDOR fix on `recordAttempt`/`confirmPayment` | P0 |
| `backend/modules/payments/payment.service.js` | Fixed race-condition handling in `confirmPayment` (P2002 catch) | P1 |
| `backend/db.js` | Isolated from Prisma's `DATABASE_URL` onto `LEGACY_PATIENTS_DATABASE_URL` | P1 |
| `backend/.env.example` | Documented the new legacy-DB variable | Documentation |
| `backend/modules/payments/__tests__/payment.controller.idor.test.js` | New — 6 regression tests for the P0 IDOR fix | Test |
| `backend/modules/payments/__tests__/payment.service.test.js` | +2 regression tests for the P1 concurrency fix | Test |
| `src/services/billingService.js` | Deleted — confirmed 100% dead code | Cleanup |
| `src/types/billing.js` | Deleted — confirmed 100% dead code | Cleanup |
| `src/stores/paymentStore.ts` | Renamed misleading `billingService` import alias to `paymentService` | Cleanup |

**Not changed:** any Payment feature surface, any UI, any database schema field, any RBAC role
definition, any Razorpay integration logic beyond the confirm/webhook ownership and race-condition
fixes above. `routes/patients.js`'s actual SQL/behavior is untouched — only its connection
string source. `config/db.js`, `models/Medicine.js`, `models/Prescription.js`,
`models/Department.js`, `models/Staff.js`, `pharmacyRoutes.js`, `hospitalRoutes.js` — all
untouched, as instructed.

---

## Exact Commands Executed (for reproducibility)

```
grep -rn "DATABASE_URL" backend --include="*.js" --include="*.prisma"
grep -rn "from \"../db.js\"" backend --include="*.js"
grep -rn "mongoose.connect" backend
node -c backend/modules/payments/payment.service.js
node -c backend/modules/payments/payment.controller.js
npx vitest run                              # 33/33, then 41/41 after new tests
npx tsc --noEmit --ignoreDeprecations 6.0   # frontend, 38 pre-existing unrelated errors, 0 in payment files
grep -rn "billingService" --include="*.ts,*.tsx,*.js,*.jsx" .
node server.js                               # x5, see §16 transcripts
node -e "import('firebase-admin').then(m => console.log(Object.keys(m.default)))"
node -e "import('firebase-admin/app').then(m => console.log(Object.keys(m)))"
openssl genrsa 2048 > /tmp/test_key.pem      # test-only, deleted after use
rm .env /tmp/test_key.pem                    # cleanup, before writing this report
```

---

## Remaining Deferred Items

1. Webhook `payment.failed` attempt-matching heuristic (§7) — correctness edge case under a
   usage pattern the current UI doesn't produce, not a security issue.
2. `refund.service.js`'s `markRefundProcessed` concurrency behavior under simultaneous partial
   refunds — no unique constraint exists to make this race safe the way `Payment.paymentAttemptId`
   does; not stress-tested or hardened this pass.
3. `server.js`'s all-or-nothing static import graph (§16) — a missing dependency in any one route
   module currently blocks the entire server, including unrelated routes like `/health`.
4. `refund.service.js` itself has no dedicated unit test file (pre-existing gap, noted in the
   prior session's report, not addressed this pass since it's not a newly-discovered
   integration/security issue).

## Environment Limitations (unchanged from prior sessions, re-confirmed this pass)

- `binaries.prisma.sh` is not reachable from this sandbox → `.prisma/client` was never generated
  → no Payment/Billing/RBAC route can be exercised against a real database from here, full stop.
- No real Firebase project → no real ID token can be issued or verified end-to-end.
- No real Razorpay credentials → §6 is BLOCKED as documented, with the manual procedure recorded
  for later.
- No Docker/CI configuration exists in this repository to audit.

---

## Final Recommendation

### CONDITIONALLY APPROVED — SPECIFIC ITEMS REMAIN

The Payment module's **code-level correctness and security posture are now verified to the
maximum extent this sandbox allows**, including three P0 bugs that would have prevented the
system from ever running at all or would have allowed cross-patient payment-state tampering —
found by actually executing the code, not by re-reading it or trusting passing unit tests, and
fixed with regression tests added and the full suite re-run (41/41 passing). The database
architecture's one genuinely dangerous condition (the `DATABASE_URL` collision) is resolved via
isolation, without touching or deleting the legacy code it isolates.

What remains is **entirely infrastructure**, not further code work within this sandbox's reach:
a real Postgres instance and network access to generate the Prisma client (§16), a real Firebase
project (§3), and real Razorpay sandbox credentials (§6, manual procedure provided). None of these
can be faked, and none were faked in this report. Once they exist, the specific, itemized
verification steps in §6 and the test matrix in §3 are exactly what's needed to move this from
CONDITIONAL to full APPROVAL — no further design or implementation work is anticipated to be
required first.
